ILIM Commons Library
====================
*This is the Phoenix project commons library*

com.ilim.commons.conf      => configuration utilities
com.ilim.commons.logging   => logging utilities
com.ilim.commons.file      => file io utilities

