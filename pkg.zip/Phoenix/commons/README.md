ILIM Commons Library
====================
*This is the Phoenix project commons library*

com.ilim.commons.api       => shared api's
com.ilim.commons.conf      => configuration utilities
com.ilim.commons.db        => db utilities and core types
com.ilim.commons.domain    => DDD abstract domain types
com.ilim.commons.file      => file io utilities
com.ilim.commons.logging   => logging utilities
com.ilim.commons.security  => security utilities and core types



