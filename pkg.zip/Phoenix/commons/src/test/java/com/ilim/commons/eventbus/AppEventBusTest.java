package com.ilim.commons.eventbus;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.domain.IEvent;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDateTime;

public class AppEventBusTest {

  private static final String name = "Test Event Bus";
  
  private AppEventBus eventBus;
  private TestEventSubscriber testSubcriber;
  
  /** Create test bus for each test. */
  @Before
  public void setUp() {

    System.setProperty("eventbus.deadevent.storage.limit", "10");
    eventBus = new AppEventBus(name);
    testSubcriber = new TestEventSubscriber(eventBus);
  }

  @Test
  public void busCreated() {

    assertThat(eventBus.name()).isEqualTo(name);
    assertThat(eventBus.eventBus()).isNotNull();
  }
  
  @Test
  public void publish() {

    eventBus.publish(new TestEvent());
    assertThat(testSubcriber.filterEventStore(TestEvent.class)).hasSize(1);
  }

  @Test
  public void unsubscribe() {

    eventBus.unsubscribe(TestEventSubscriber.class.getCanonicalName());
    eventBus.publish(new TestEvent());
    assertThat(testSubcriber.filterEventStore(TestEvent.class)).hasSize(0);
    assertThat(eventBus.deadEvents()).hasSize(1);
  }
  
  @Test
  public void deadEventStore() {

    eventBus.unsubscribe(TestEventSubscriber.class.getCanonicalName());
    // dead event store max = 10
    for (int i = 0; i <= 12; i++) {
      eventBus.publish(new TestEvent());
    }
    assertThat(eventBus.deadEvents()).hasSize(10);
    
  }

  private class TestEvent implements IEvent<TestEvent> {

    public final LocalDateTime occuredOn;

    public TestEvent() {

      this.occuredOn = LocalDateTime.now();
    }

    @Override
    public LocalDateTime occuredOn() {
      return occuredOn;
    }
  }

}
