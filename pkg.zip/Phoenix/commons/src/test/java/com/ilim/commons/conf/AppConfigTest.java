package com.ilim.commons.conf;

import static com.ilim.commons.conf.AppConfig.settings;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class AppConfigTest {

  @Before
  public void setUp() throws Exception {

  }

  @Test
  public void findDevFooBarSetting() throws Exception {

    assertThat(settings().getString("dev.foo.bar"), equalTo("foobardev"));
  }

  @Test
  public void findProdFooBarSetting() throws Exception {
    assertThat(settings().getString("prod.foo.bar"), equalTo("foobarprod"));
  }

  @Test
  public void defaultFooBarEnvIsDev() throws Exception {

    assertThat(settings().getString("foo.bar"), equalTo("foobardev"));
  }

  @Test
  public void settingsInAppConfOverrideRefConf() throws Exception {

    assertThat(settings().getString("goo.baz"), equalTo("goobazappdev"));
  }

  @Test
  public void ssystemPropsOverrideConfs() throws Exception {

    System.setProperty("dev.goo.baz", "goobazsystemdev");
    AppConfig.INSTANCE.reload(); // system settings are cached.
    assertThat(settings().getString("dev.goo.baz"), equalTo("goobazsystemdev"));
  }

  @Test
  public void loadUatSettingsDirectly() throws Exception {

    assertThat(AppConfig.INSTANCE.uat().getString("foo.bar"),
        equalTo("foobarappuat"));
  }

  @Test
  public void loadDevEnv() throws Exception {

    assertThat(AppEnv.load().text(), equalTo("dev"));
  }

  @Test
  public void loadUatEnv() throws Exception {

    String original = System.getProperty("ilim.env");

    System.setProperty("ilim.env", "uat");
    assertThat(AppEnv.load().text(), equalTo("uat"));
    rollbackEnv(original);
  }

  @Test(expected = AppConfigException.class)
  public void loadUnknownEnvFails() throws Exception {

    String original = System.getProperty("ilim.env");

    try {
      System.setProperty("ilim.env", "XXX");
      AppEnv.load();
      fail("should have thrown AppConfigException!");
    } catch (AppConfigException ex) {
      assertThat(ex.getMessage(), equalTo("failed to load config env vars!"));
      throw ex;
    } finally {
      rollbackEnv(original);
    }
  }

  private void rollbackEnv(String to) {
    if (to != null) {
      System.setProperty("ilim.env", to);
    } else {
      System.getProperties().remove("ilim.env");
    }
  }
}
