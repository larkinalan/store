package com.ilim.commons.domain.model;

public enum Currency {

  ADP("ADP"), AED("AED"), AFA("AFA"), ALL("ALL"), AMD("AMD"), ANG("ANG"), 
  AON("AON"), AOR("AOR"), ARS("ARS"), ATS("ATS"), AUD("AUD"), AWG("AWG"), 
  AZM("AZM"), BAM("BAM"), BBD("BBD"), BDT("BDT"), BEF("BEF"), BGL("BGL"), 
  BGN("BGN"), BHD("BHD"), BIF("BIF"), BMD("BMD"), BND("BND"), BOB("BOB"), 
  BRL("BRL"), BSD("BSD"), BTN("BTN"), BWP("BWP"), BYB("BYB"), BZD("BZD"), 
  CAD("CAD"), CDF("CDF"), CHF("CHF"), CLF("CLF"), CLP("CLP"), CNY("CNY"), 
  COP("COP"), CRC("CRC"), CUP("CUP"), CVE("CVE"), CYP("CYP"), CZK("CZK"), 
  DEM("DEM"), DJF("DJF"), DKK("DKK"), DOP("DOP"), DZD("DZD"), ECS("ECS"), 
  EEK("EEK"), EGP("EGP"), ERN("ERN"), ESP("ESP"), ETB("ETB"), EUR("EUR"), 
  FIM("FIM"), FJD("FJD"), FKP("FKP"), FRF("FRF"), GBP("GBP"), GEK("GEK"), 
  GEL("GEL"), GHC("GHC"), GIP("GIP"), GMD("GMD"), GNF("GNF"), GRD("GRD"), 
  GTQ("GTQ"), GWP("GWP"), GYD("GYD"), HKD("HKD"), HNL("HNL"), HRD("HRD"), 
  HRK("HRK"), HTG("HTG"), HUF("HUF"), IDR("IDR"), IEP("IEP"), ILS("ILS"), 
  INR("INR"), IQD("IQD"), IRR("IRR"), ISK("ISK"), ITL("ITL"), JMD("JMD"), 
  JOD("JOD"), JPY("JPY"), KES("KES"), KGS("KGS"), KHR("KHR"), KMF("KMF"),
  KPW("KPW"), KRW("KRW"), KWD("KWD"), KYD("KYD"), KZT("KZT"), LAK("LAK"),
  LBP("LBP"), LKR("LKR"), LRD("LRD"), LSL("LSL"), LTL("LTL"), LUF("LUF"), 
  LVL("LVL"), LYD("LYD"), MAD("MAD"), MDL("MDL"), MGF("MGF"), MKD("MKD"), 
  MMK("MMK"), MNT("MNT"), MOP("MOP"), MRO("MRO"), MTL("MTL"), MUR("MUR"), 
  MVR("MVR"), MWK("MWK"), MXN("MXN"), MYR("MYR"), MZM("MZM"), NAD("NAD"), 
  NGN("NGN"), NIO("NIO"), NLG("NLG"), NOK("NOK"), NPR("NPR"), NZD("NZD"), 
  OMR("OMR"), PAB("PAB"), PEN("PEN"), PGK("PGK"), PHP("PHP"), PKR("PKR"), 
  PLN("PLN"), PLZ("PLZ"), PTE("PTE"), PYG("PYG"), QAR("QAR"), ROL("ROL"), 
  RON("RON"), RUB("RUB"), RUR("RUR"), RWF("RWF"), SAR("SAR"), SBD("SBD"), 
  SCR("SCR"), SDD("SDD"), SEK("SEK"), SGD("SGD"), SHP("SHP"), SIT("SIT"), 
  SKK("SKK"), SLL("SLL"), SOS("SOS"), SRG("SRG"), STD("STD"), SVC("SVC"), 
  SYP("SYP"), SZL("SZL"), THB("THB"), TJR("TJR"), TMM("TMM"), TND("TND"), 
  TOP("TOP"), TPE("TPE"), TRL("TRL"), TRY("TRY"), TTD("TTD"), TWD("TWD"), 
  TZS("TZS"), UAH("UAH"), UGX("UGX"), USD("USD"), UYU("UYU"), UZS("UZS"), 
  VEB("VEB"), VNB("VNB"), VND("VND"), VUV("VUV"), WST("WST"), XAF("XAF"), 
  XCD("XCD"), XEU("XEU"), XOF("XOF"), XPD("XPD"), XPF("XPF"), YER("YER"), 
  YUM("YUM"), YUN("YUN"), ZAL("ZAL"), ZAR("ZAR"), ZMK("ZMK"), ZRN("ZRN"), 
  ZWD("ZWD"), NA("#NA");
  
  private String id;
  
  Currency(String id) {
    this.id = id;
  }
  
  public String id() {
    return id;
  }
}
