package com.ilim.commons.security;

public class AppSecurityException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  protected AppSecurityException(String message, Throwable cause) {
    super(message, cause);
  }

  public static class AuthenticationFailed extends AppSecurityException {

    private static final long serialVersionUID = 1L;

    public AuthenticationFailed(String message, Throwable cause) {
      super(message, cause);
    }
  }
  
  public static class UserNotFound extends AuthenticationFailed {

    private static final long serialVersionUID = 1L;

    public UserNotFound(String message, Throwable cause) {
      super(message, cause);
    }
  }
  
  public static class RoleNotFound extends AuthenticationFailed {

    private static final long serialVersionUID = 1L;

    public RoleNotFound(String message, Throwable cause) {
      super(message, cause);
    }
  }
  
  public static class AccessDenied extends AuthenticationFailed {

    private static final long serialVersionUID = 1L;

    public AccessDenied(String message, Throwable cause) {
      super(message, cause);
    }
  }
}
