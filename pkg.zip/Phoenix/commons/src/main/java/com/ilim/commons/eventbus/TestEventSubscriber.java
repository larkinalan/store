package com.ilim.commons.eventbus;

import com.ilim.commons.domain.IEvent;

import com.google.common.eventbus.Subscribe;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Guava EventBus Subscriber used for TESTING.
 * 
 * <p>Has an in memory event store, so we can verify events have been raised.
 * 
 * <p>Generally you just extend this class and add your own assertion methods. 
 * 
 * @author alan larkin
 *
 */
public class TestEventSubscriber implements IEventSubscriber {

  protected static final Logger log =
      LoggerFactory.getLogger(TestEventSubscriber.class);

  private final AppEventBus eventBus;
  private final Set<IEvent<?>> eventStore = new HashSet<>();

  /** Initialize or Inject with the event bus under test. */
  public TestEventSubscriber(AppEventBus eventBus) {

    this.eventBus = eventBus;
    eventBus.subscribe(this);
  }
  
  /** EventBus. */
  @Override
  public AppEventBus subscribedTo() {
    return eventBus;
  }

  /** In memory cachge of all events. */
  public Set<IEvent<?>> eventStore() {

    return eventStore;
  }

  /** Handles events. */
  @Subscribe
  public void onEvent(IEvent<?> event) {

    log.info("Recieved test event " + event);
    eventStore.add(event);
  }

  /** Returns true if event is in store. */
  public boolean recieved(IEvent<?> event) {

    return eventStore.contains(event);
  }
  
  /** 
   * Filter the eventStore on implementation type T of IEvent.
   * 
   * @param type to compare to.
   * @return Set of types if they exist.
   */
  public <T extends IEvent<T>> Set<T> filterEventStore(Class<T> type) {

    return eventStore.stream().filter(type::isInstance).map(type::cast)
        .collect(Collectors.toSet());
  }

}
