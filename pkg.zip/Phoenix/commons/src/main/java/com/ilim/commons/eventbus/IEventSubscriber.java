package com.ilim.commons.eventbus;

public interface IEventSubscriber {

  AppEventBus subscribedTo();
  
}
