package com.ilim.commons.web.client;

import com.ilim.commons.web.api.ErrorCode;
import com.ilim.commons.web.api.ErrorData;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit2.Converter;
import retrofit2.Response;
import retrofit2.Retrofit;

import java.io.IOException;
import java.lang.annotation.Annotation;


/**
 * RetrofitClient SDK Builder. 
 * 
 * <p>Uses squares 
 * (1) retrofit http client adapter.
 * See <a href="http://square.github.io/retrofit/">http://square.github.io/retrofit/</a>
 * (2) okttp as the http client. 
 * See <a href="http://square.github.io/okhttp/">http://square.github.io/okhttp/</a>
 * 
 * @author alan larkin
 */
public class RetrofitClient {

  private static final Logger log =
      LoggerFactory.getLogger(RetrofitClient.class);

  private final String baseUrl;
  private final OkHttpClient httpClient;
  private final Retrofit retrofitAdapter;

  /** Construct the client with given builders. */
  RetrofitClient(RetrofitClient.Builder builder) {

    baseUrl = builder.baseUrl;
    log.debug("Creating RetrofitClient for {}", baseUrl);

    // http client
    httpClient =
        builder.okhttp.addInterceptor(httpLogger(builder.logger)).build();
    // retrofit
    retrofitAdapter = builder.retrofit.baseUrl(baseUrl).client(httpClient)
        .addConverterFactory(builder.converter).build();
  }

  /** Retrofit Client Adapter. */
  public Retrofit adapter() {

    return this.retrofitAdapter;
  }

  /** Convert Response error body -> ErrorData. */
  public ErrorData toErrorData(Response<?> response) {

    Converter<ResponseBody, ErrorData> converter = retrofitAdapter
        .responseBodyConverter(ErrorData.class, new Annotation[0]);

    final ErrorData error;
    try {

      error = converter.convert(response.errorBody());

    } catch (IOException ex) {

      return ErrorData.newErrorData(ErrorCode.CLIENT.id(), ex);
    }

    return error;
  }

  /** Add sl4j logger. */
  private static HttpLoggingInterceptor httpLogger(Logger logger) {

    HttpLoggingInterceptor httpLogger =
        new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
          @Override
          public void log(String message) {
            if (logger != null) {
              logger.info(message);
            } else {
              log.info(message);
            }
          }
        });

    if (isDebugEnabled(logger)) {
      httpLogger.setLevel(HttpLoggingInterceptor.Level.BODY);
    } else {
      httpLogger.setLevel(HttpLoggingInterceptor.Level.BASIC);
    }

    return httpLogger;
  }

  private static boolean isDebugEnabled(Logger logger) {

    if (logger != null) {
      return logger.isDebugEnabled();
    } else {
      return log.isDebugEnabled();
    }
  }

  /** Helps new the builder. */
  public static RetrofitClient.Builder newBuilder(String baseUrl) {
    return new Builder(baseUrl);
  }

  public static final class Builder {

    private String baseUrl;
    private Logger logger;
    private OkHttpClient.Builder okhttp;
    private Retrofit.Builder retrofit;
    private Converter.Factory converter;

    /** Init with baseurl of service. */
    public Builder(String baseUrl) {

      this.baseUrl = baseUrl;
    }

    /** Add sl4j log from calling class. */
    public Builder witLogger(Logger logger) {

      this.logger = logger;
      return this;
    }

    /** Add converter. e.g. Jackson */
    public Builder withConverter(Converter.Factory converter) {

      this.converter = converter;
      return this;
    }

    /** Build client. */
    public RetrofitClient build() {

      this.okhttp = new OkHttpClient().newBuilder();
      this.retrofit = new Retrofit.Builder();

      return new RetrofitClient(this);
    }
  }

}
