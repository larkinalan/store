package com.ilim.commons.domain;

/**
 * <p>A domain value object interface.</p>
 *
 * @param <T> is the key type for value object
 *
 * @author Alan Larkin
 */
public interface IValueObject<T> {

}
