package com.ilim.commons.web.api;

/**
 * Api error codes.
 * 
 * <p>Simple error codes that we through back to the client.
 * 
 * @author Alan Larkin
 */
public enum ErrorCode {

  CLIENT("CLIENT_ERROR"),
  CONFIG("CONFIG_ERROR"),
  DATA("DATA_ERROR"),
  NOT_IMPL("NOT_IMPLEMENTED_ERROR"), 
  STATE("STATE_ERROR"),
  WEBAPP("WEBAPP_ERROR");

  private String id;

  ErrorCode(String id) {
    this.id = id;
  }

  public String id() {
    return id;
  }

}
