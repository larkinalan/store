package com.ilim.commons.conf;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigException;
import com.typesafe.config.ConfigFactory;

/**
 * Application configuration helper
 * 
 * <p>Based on typesafe's config library. 
 * @see <a href="https://github.com/typesafehub/config"></a>
 *
 * @author Alan Larkin
 */
public enum AppConfig {

  INSTANCE; // singleton

  private AppEnv env;
  private Config conf;

  private AppConfig() {

    load();
  }

  private void load() {

    env = AppEnv.load();
    conf = ConfigFactory.load();
    conf.checkValid(ConfigFactory.defaultReference());
  }
  
  /**
   * Reloads any cached configuration settings.
   * 
   * <p>example: 
   * {@code AppConfig.INSTANCE.reload().settings()}
   */
  public void reload() {

    ConfigFactory.invalidateCaches();
    load();
  }
  
  private Config getConf() {

    try {

      return getConf(env);
    } catch (ConfigException ex) {
      throw new AppConfigException(ex.getMessage(), ex.getCause());
    }
  }

  private Config getConf(AppEnv env) {

    return conf.getConfig(env.text()).withFallback(conf);
  }
  
  /**
   * Loads all configuration settings.
   *
   * <p>Uses {@link AppEnv#load()} to get current environment. 
   * With default fallback to DEV. 
   * 
   * <p>example:
   * <pre>
   * {@code
   *    import static com.ilim.commons.conf.AppConfig.settings;
   *    // ...
   *    private String fooBar = settings().getString("foo.bar");
   *    // ...
   *    public boolean isSomeFeatureOn() { 
   *        settings().getBoolean("some.feature.enabled"); 
   *    }
   *    //...
   * }
   * </pre>
   * 
   * @throws AppConfigException
   *    
   */
  public static Config settings() {

    return INSTANCE.getConf();
  }
  
  /** Returns DEV settings. */
  public Config dev() {

    return getConf(AppEnv.DEV);
  }

  /** Returns UAT settings. */
  public Config uat() {

    return getConf(AppEnv.UAT);
  }

  /** Returns UAT2 settings. */
  public Config uat2() {

    return getConf(AppEnv.UAT2);
  }

  /** Returns PROD settings. */
  public Config prod() {

    return getConf(AppEnv.PROD);
  }
}
