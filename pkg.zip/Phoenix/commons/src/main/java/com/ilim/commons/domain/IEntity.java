package com.ilim.commons.domain;

/**
 * <p>An entity aggregate root - provides the following to repositories:</p>
 * <ul>
 * <li>Methods common to all entities to ease persistence 
 * and global identification</li>
 * </ul>
 * <p/>
 * <p>AggregateRoot Design Rules:</p>
 * <ol>
 * <li>Model true invariants in consistency boundaries</li>
 * <li>Keep Aggregates as small as possible.</li>
 * <li>Reference other Aggregates by Identity only.</li>
 * <li>When multiple Aggregates must be updated by a single client request 
 * use eventual consistency.</li>
 * </ol>
 * <p/>
 * <p>See the <a href="http://en.wikipedia.org/wiki/Domain-driven_design">Wikipedia article on DDD</a> for more details</p>
 * <p/>
 * <p>For a deeper understanding of Aggregates and AggregateRoots:</p>
 * <ol>
 * <li><a href="http://dddcommunity.org/wp-content/uploads/files/pdf_articles/Vernon_2011_1.pdf">Part I: Modeling a Single Aggregate </a></li>
 * <li><a href="http://dddcommunity.org/wp-content/uploads/files/pdf_articles/Vernon_2011_2.pdf">Part II: Making Aggregates Work Together </a></li>
 * <li><a href="http://dddcommunity.org/wp-content/uploads/files/pdf_articles/Vernon_2011_3.pdf">Part III: Gaining Insight Through Discovery </a></li>
 * <p/>
 * </ol>
 *
 * @param <K> is the key type for the common (e.g. Integer )
*
 * @author Alan Larkin
 */
public interface IEntity<K> {

  /**
   * The annotations are set here on the interface to maintain consistency.
   *
   * @return The unique ID for this entity
   */
  K getId();

}
