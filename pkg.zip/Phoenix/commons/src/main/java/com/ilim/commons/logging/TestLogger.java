package com.ilim.commons.logging;

import org.junit.rules.TestRule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Junit test watcher to log all test failures and success.
 * 
 * @author alan larkin
 *
 */
public class TestLogger extends TestWatcher implements TestRule {

  public static final Logger log = LoggerFactory.getLogger(TestLogger.class);

  @Override
  protected void failed(Throwable ex, Description description) {

    String error = description + " test failed!\n" + ex.getMessage();
    Throwable cause = ex.getCause();
    if (cause != null) {
      error += " : " + cause.getMessage();
    }
    log.error(error);
  }

  @Override
  protected void succeeded(Description description) {

    log.info(description + " test succeeded!\n");
  }

}

