package com.ilim.commons.domain;

import java.time.LocalDateTime;

/**
 * <p>A domain event interface.</p>
 * 
 * @author Alan Larkin
 */
public interface IEvent {

  LocalDateTime occuredOn();

}
