package com.ilim.commons.db;

public class AppSqlException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public AppSqlException(String message, Throwable cause) {
    super(message, cause);
  }
  
  public AppSqlException(String sql, String message, Throwable cause) {
    super("SQL: " + sql + "/nERROR: " + message , cause);
  }
}
