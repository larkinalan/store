package com.ilim.commons.conf;

/**
 * Application Environment helper.
 *
 * @author Alan Larkin
 */
public enum AppEnv {

  DEV("dev"), UAT("uat"), UAT2("uat2"), PROD("prod");

  private final String env;

  private AppEnv(String env) {
    this.env = env;
  }

  public String text() {
    return env;
  }

  /**
   * Loads all env from system or os variables.
   * 
   * <p><b>Overrides priority:</b>
   * (1) Java system variable "ilim.env".
   * (2) OS environment variable "ILIM_ENV".
   * (3) Finally fallback to DEV.
   * 
   * @throws AppConfigException
   * 
   */
  public static AppEnv load() {

    try {
      
      // First try JVM system var
      String var = System.getProperty("ilim.env");
      if (var == null) {
        // Then OS env var
        var = System.getenv("ILIM_ENV");
      }
      
      if (var != null) {
        return AppEnv.valueOf(var.trim().toUpperCase());
      } else {
        return AppEnv.DEV; // Finally fallback to DEV;
      }
    } catch (IllegalArgumentException ex) {
      throw new AppConfigException("failed to load config env vars!", ex);
    }
  }

}
