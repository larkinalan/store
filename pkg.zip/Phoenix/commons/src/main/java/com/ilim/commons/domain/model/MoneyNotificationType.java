package com.ilim.commons.domain.model;

/** Money notification types. */
public enum MoneyNotificationType {

  UNKNOWN(0), 
  CASH(1), 
  UNIT(2);

  private final int id;

  MoneyNotificationType(int id) {
    this.id = id;
  }

  public int id() {
    return id;
  }

  /** Gets a MoneyNotificationType corresponding to the id passed in. */
  public static MoneyNotificationType from(int id) {

    for (MoneyNotificationType type : MoneyNotificationType.values()) {
      if (type.id() == id) {
        return type;
      }
    }
    return UNKNOWN;
  }

  /** Gets a MoneyNotificationType corresponding to the name passed in. */
  public static MoneyNotificationType from(String name) {

    for (MoneyNotificationType type : MoneyNotificationType.values()) {
      if (type.name().equalsIgnoreCase(name)) {
        return type;
      }
    }
    return UNKNOWN;
  }
}
