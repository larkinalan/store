package com.ilim.commons.domain.model;


/** Fund Levels. */
public enum FundLevel {

  CLIENT(1), TAX(2), PRIMARY(3), INVESTING(4), SCHEME(5);

  private int id;

  FundLevel(int id) {
    this.id = id;
  }

  public int id() {
    return id;
  }

  /** Gets a FundLevel corresponding to the id passed in. */
  public static FundLevel from(int id) {

    for (FundLevel level : FundLevel.values()) {
      if (id == level.id()) {
        return level;
      }
    }
    throw new IllegalArgumentException("Unknown FundLevel Id: " + id);
  }

  /** Gets a FundLevel corresponding to the name passed in. */
  public static FundLevel from(String name) {

    for (FundLevel level : FundLevel.values()) {
      if (name.equalsIgnoreCase(level.name())) {
        return level;
      }
    }
    throw new IllegalArgumentException("Unknown FundLevel name: " + name);
  }

}

