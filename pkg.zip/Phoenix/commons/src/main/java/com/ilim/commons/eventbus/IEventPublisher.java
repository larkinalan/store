package com.ilim.commons.eventbus;

public interface IEventPublisher {

  AppEventBus publishingTo();

}
