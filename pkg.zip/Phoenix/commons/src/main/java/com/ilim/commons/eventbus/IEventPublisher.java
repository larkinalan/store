package com.ilim.commons.eventbus;

import com.ilim.commons.domain.IEvent;

public interface IEventPublisher {

  AppEventBus publishingTo();
  
  void publish(IEvent<?> event);
 
}
