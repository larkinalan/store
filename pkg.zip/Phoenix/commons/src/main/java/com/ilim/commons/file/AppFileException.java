package com.ilim.commons.file;

public class AppFileException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public AppFileException(String message, Throwable cause) {
    super(message, cause);
  }
  
  public AppFileException(String file, String message, Throwable cause) {
    super("FILE: " + file + "/nERROR: " + message , cause);
  }
}
