package com.ilim.commons.domain.model;


/** Forecast types. */
public enum ForecastType {

  UNKNOWN(0), 
  NEW_MONEY(1), 
  ZAP(2), 
  MGMT_CHARGE(3);

  private final int id;

  ForecastType(int id) {
    this.id = id;
  }

  public int id() {
    return id;
  }

  /** Gets a ForecastType corresponding to the id passed in. */
  public static ForecastType from(int id) {

    for (ForecastType type : ForecastType.values()) {
      if (type.id() == id) {
        return type;
      }
    }
    return UNKNOWN;
  }

  /** Gets a ForecastType corresponding to the name passed in. */
  public static ForecastType from(String name) {

    for (ForecastType type : ForecastType.values()) {
      if (type.name().equalsIgnoreCase(name)) {
        return type;
      }
    }
    return UNKNOWN;
  }
}
