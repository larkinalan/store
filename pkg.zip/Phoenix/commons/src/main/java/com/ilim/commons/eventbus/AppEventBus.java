package com.ilim.commons.eventbus;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.domain.IEvent;

import com.google.common.eventbus.AsyncEventBus;
import com.google.common.eventbus.DeadEvent;
import com.google.common.eventbus.EventBus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;

/**
 * AppEventBus allows publish-subscribe-style communication between components 
 * without requiring the components to be aware of each other. 
 * 
 * <p>Wrapper for Google' Guava EventBus.
 * @see <a href="https://github.com/google/guava/wiki/EventBusExplained"></a>   
 * 
 * @author alan larkin
 */
public class AppEventBus {

  private static final Logger log = LoggerFactory.getLogger(AppEventBus.class);

  private final String name;
  private final EventBus eventBus;
  private final Map<String, IEventSubscriber> registeredListeners;
  private final DeadEventSubscriber deadEventSubscriber;

  /** Create an event bus for name. */
  public AppEventBus(String name) {

    this.name = name;
    if (settings().getBoolean("eventbus.async")) {
      this.eventBus = new AsyncEventBus(name, Executors.newCachedThreadPool());
    } else {
      this.eventBus = new EventBus(name);
    }

    this.registeredListeners = new ConcurrentHashMap<>();
    int storageLimit = settings().getInt("eventbus.deadevent.storage.limit");
    deadEventSubscriber = new DeadEventSubscriber(this, storageLimit);

    log.info("Created AppEventBus " + name);
  }

  /** Event bus name. */
  public String name() {
    return name;
  }

  /** Access to underlying Guava EventBus. */
  public EventBus eventBus() {
    return eventBus;
  }

  /** Publish event to bus. */
  public void publish(IEvent<?> event) {

    log.info("Publishing event : " + event);
    eventBus.post(event);
  }

  /** Start listening to event bus. */
  public void subscribe(IEventSubscriber listener) {

    String canonicalName = listener.getClass().getCanonicalName();
    IEventSubscriber value =
        registeredListeners.putIfAbsent(canonicalName, listener);

    if (value == null) {

      eventBus.register(listener);
      log.info("Registered listener " + canonicalName + " to " + name());

    } else {
      log.warn(
          name() + " listener " + canonicalName + " is already registered!");
    }
  }

  /** Stop listening to event bus. */
  public void unsubscribe(Class<? extends IEventSubscriber> listenerClass) {

    unsubscribe(listenerClass.getCanonicalName());
  }

  /** Stop listening to event bus. */
  public void unsubscribe(String canonicalName) {

    IEventSubscriber value = registeredListeners.get(canonicalName);
    if (value != null) {

      eventBus.unregister(value);
      registeredListeners.remove(canonicalName);
      log.info("Unregistered listener " + canonicalName + " from " + name());

    } else {
      log.warn(name() + " listener " + canonicalName
          + " could not be unregistered!");
    }
  }

  /** Cache of dead events. */
  public Queue<DeadEvent> deadEvents() {

    return deadEventSubscriber.eventStore();
  }

}
