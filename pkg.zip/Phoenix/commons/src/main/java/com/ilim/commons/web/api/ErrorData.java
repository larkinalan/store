package com.ilim.commons.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;

/**
 * Api error data type annotated for JSON serialization.
 * 
 * @author Alan Larkin
 */
public class ErrorData {

  @JsonProperty
  public final String code;
  @JsonProperty
  public final String message;
  @JsonProperty
  public final String description;

  /** Creates Error data type. */
  @JsonCreator
  public ErrorData(@JsonProperty("code") String code,
      @JsonProperty("message") String message,
      @JsonProperty("description") String description) {

    this.code = code;
    this.message = message;
    this.description = description;
  }

  /** Helps create error data. */
  public static ErrorData newErrorData(String code, Exception ex) {

    return new ErrorData(code, ex.getMessage(), toDesc(ex));
  }

  private static String toDesc(Exception ex) {

    Throwable cause = ex.getCause();
    if (cause != null) {
      return cause.getMessage();
    } else {
      return "";
    }
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("code", code)
        .add("message", message).add("description", description).toString();
  }

}
