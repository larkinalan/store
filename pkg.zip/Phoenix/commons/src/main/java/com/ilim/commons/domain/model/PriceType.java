package com.ilim.commons.domain.model;

/**  Fund Price types. */
public enum PriceType {

  TOTAL_RETURN(1), 
  PRICE_RETURN(2), 
  UNIT_TRANSACTION(3), 
  BID(4), 
  OFFER(5), 
  SEGO_PRICE(6), 
  BID_ASK(7), 
  ASK(8), 
  ILIM_UTE_APPROPRIATIONS_PRICE(9), 
  CONSULTANT_PRICE(10), 
  GIPS_PRICE(11);

  private int id;

  PriceType(int id) {
    this.id = id;
  }

  public int getId() {
    return id;
  }

  /** Gets a PriceType corresponding to the id passed in. */
  public static PriceType from(int id) {

    for (PriceType priceType : PriceType.values()) {
      if (id == priceType.getId()) {
        return priceType;
      }
    }
    throw new IllegalArgumentException("Unknown PriceType Id: " + id);
  }

  /** Gets a PriceType corresponding to the id passed in. */
  public static PriceType from(String name) {

    for (PriceType priceType : PriceType.values()) {
      if (name.equalsIgnoreCase(priceType.name())) {
        return priceType;
      }
    }
    throw new IllegalArgumentException("Unknown PriceType Name: " + name);
  }
}
