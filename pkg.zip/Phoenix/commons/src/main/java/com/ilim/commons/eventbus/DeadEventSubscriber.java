package com.ilim.commons.eventbus;

import com.google.common.collect.EvictingQueue;
import com.google.common.eventbus.AllowConcurrentEvents;
import com.google.common.eventbus.DeadEvent;
import com.google.common.eventbus.Subscribe;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Queue;

/**
 * DeadEventSubscriber used to store dead events.
 * 
 * <p>Store dead events to configurable limit, then evicts when full. 
 * 
 * @author alan larkin
 *
 */
public class DeadEventSubscriber implements IEventSubscriber {

  protected static final Logger log =
      LoggerFactory.getLogger(DeadEventSubscriber.class);

  private final AppEventBus eventBus;
  private final EvictingQueue<DeadEvent> eventStore;

  /** Listen to eventBus and setup eventStore. */
  public DeadEventSubscriber(AppEventBus eventBus, int storeLimit) {

    this.eventBus = eventBus;
    this.eventStore = EvictingQueue.create(storeLimit);
    eventBus.subscribe(this);
  }

  /** EventBus. */
  @Override
  public AppEventBus subscribedTo() {
    return eventBus;
  }

  /** Handles dead events. */
  @Subscribe
  @AllowConcurrentEvents
  public void onEvent(DeadEvent event) {

    log.warn("Recieved dead event " + event);
    store(event);
  }

  /** In memory cache of dead events. */
  public Queue<DeadEvent> eventStore() {

    return eventStore;
  }

  private void store(DeadEvent event) {

    if (eventStore.remainingCapacity() == 0) {
      log.warn("Dead EventStore has reached max capactity (" + eventStore.size()
          + "), " + " Evicting : " + eventStore.peek().getEvent());
    }
    eventStore.add(event);
  }

}
