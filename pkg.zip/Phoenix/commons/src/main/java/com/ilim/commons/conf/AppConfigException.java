package com.ilim.commons.conf;

import java.io.Serializable;

public class AppConfigException extends RuntimeException
    implements Serializable {

  private static final long serialVersionUID = 1L;

  public AppConfigException(String message, Throwable cause) {
    super(message, cause);
  }
}
