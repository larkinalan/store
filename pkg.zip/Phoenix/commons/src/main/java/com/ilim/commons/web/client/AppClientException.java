package com.ilim.commons.web.client;

import com.ilim.commons.web.api.ErrorCode;
import com.ilim.commons.web.api.ErrorData;

import okhttp3.ResponseBody;
import retrofit2.Converter;
import retrofit2.Response;
import retrofit2.Retrofit;

import java.io.IOException;
import java.io.Serializable;
import java.io.UncheckedIOException;
import java.lang.annotation.Annotation;

public class AppClientException extends UncheckedIOException
    implements Serializable {

  private static final long serialVersionUID = 1L;

  public AppClientException(String message, Throwable cause) {
    super(new IOException(message, cause));
  }

  public AppClientException(Response<?> response, Retrofit retrofit) {

    this(toErrorData(response, retrofit));
  }

  public AppClientException(ErrorData error) {

    super(new IOException(error.toString()));
  }

  public AppClientException(IOException ex) {
    super("Network error!", ex);
  }

  /** Convert Retrofit response body -> ErrorData. */
  protected static ErrorData toErrorData(Response<?> response,
      Retrofit retrofit) {

    Converter<ResponseBody, ErrorData> converter =
        retrofit.responseBodyConverter(ErrorData.class, new Annotation[0]);

    final ErrorData error;
    try {

      error = converter.convert(response.errorBody());

    } catch (IOException ex) {

      return ErrorData.newErrorData(ErrorCode.CLIENT.id(), ex);
    }

    return error;
  }

}
