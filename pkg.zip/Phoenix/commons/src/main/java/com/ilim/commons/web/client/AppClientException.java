package com.ilim.commons.web.client;

import com.ilim.commons.web.api.ErrorData;

import java.io.IOException;
import java.io.Serializable;
import java.io.UncheckedIOException;

public class AppClientException extends UncheckedIOException
    implements Serializable {

  private static final long serialVersionUID = 1L;

  public AppClientException(String message, Throwable cause) {
    super(new IOException(message, cause));
  }

  public AppClientException(ErrorData error) {

    super(new IOException("Service error! " + error.toString()));
  }

  public AppClientException(IOException ex) {
    super("Network error!", ex);
  }

}
