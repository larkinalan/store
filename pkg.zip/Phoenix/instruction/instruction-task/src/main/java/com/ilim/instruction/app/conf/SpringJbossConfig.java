package com.ilim.instruction.app.conf;

import static com.ilim.commons.conf.AppConfig.settings;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.jta.JtaTransactionManager;

import javax.sql.DataSource;

/**
 * Spring jboss config.
 *
 * @author Michael Cunningham
 */
@Configuration
@EnableTransactionManagement()
@Import(SpringCamelConfig.class)
public class SpringJbossConfig {

  /** Jboss container jndi Datasource. */
  @Bean
  public DataSource dataSource() {

    final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
    dsLookup.setResourceRef(true);
    DataSource dataSource =
        dsLookup.getDataSource(settings().getString("jndi.datasource.fm"));
    return dataSource;
  }

  /** Jboss container JtaTransactionManager bean. */
  @Bean
  public PlatformTransactionManager transactionManager() {

    JtaTransactionManager txnMgr = new JtaTransactionManager();
    txnMgr.setTransactionManagerName(settings().getString("jndi.txnmanager"));
    return txnMgr;
  }

}
