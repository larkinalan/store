package com.ilim.instruction.infra.db;

/*
 *  Sql statements used in JdbcInstructionDao
 *  
 *  <p>Formatted and wrapped using TOAD. 
 *  
 *  @author Alan Larkin
 *  
 *  @formatter:off
 *  CHECKSTYLE:OFF
 */
public class SQL {
  
  /*******************************************
   * T_INSTRUCTION_EVENT sql statements
   *******************************************/

  public static final String insert_into_instruction_event = 
      "INSERT INTO instruction_event( instruction_event_id " +
      "                             , event_type_id " +
      "                             , event_source_id " +
      "                             , created_ts " +
      "                             , instruction_data ) " +
      "VALUES ( :id " +
      "       , :eventTypeId " +
      "       , :eventSourceId " +
      "       , :occurredOn " +
      "       , :instrData ) "; 
  
  public static final String select_from_instruction_event_by_id = 
      "SELECT instruction_event_id " +
      "     , event_type_id " +
      "     , event_source_id " +
      "     , created_ts " +
      "     , DECODE(delivered_fg, 'Y', 1, 0) as delivered_fg " +
      "     , instruction_data " +
      "  FROM instruction_event " +
      " WHERE instruction_event_id = :eventId "; 
  
  public static final String select_from_instruction_event_by_undelivered_and_type = 
      "SELECT instruction_event_id " +
      "     , event_type_id " +
      "     , event_source_id " +
      "     , created_ts " +
      "     , DECODE(delivered_fg, 'Y', 1, 0) as delivered_fg " +
      "     , instruction_data " +
      "  FROM instruction_event " +
      " WHERE delivered_fg IS NULL " +
      "   AND event_type_id = :eventTypeId "; 
  
  public static final String update_instruction_event_delivered =        
      "UPDATE instruction_event " +
      "   SET delivered_fg = 'Y' " +
      " WHERE instruction_event_id = :eventId"; 

  public static final String select_from_instr_event_seq =
      "SELECT instr_event_seq.NEXTVAL AS id " +
      "  FROM DUAL ";   
}