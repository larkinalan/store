package com.ilim.instruction.domain.event;

import com.ilim.commons.domain.IEvent;

import com.google.common.base.MoreObjects;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Core Instruction Event that get saved to the event store.
 * 
 * <p>Represents events that are raised from the ECLIPPS and FUSION apps.
 *
 * @author Michael Cunningham
 */
public class InstructionEvent implements IEvent {

  private final int eventId;
  private final InstructionEventType eventType;
  private final int eventSourceId;
  private final LocalDateTime occuredOn;
  private final boolean isDelivered;
  private final String instrData;

  /** Creates an Instruction Event domain event. */
  public InstructionEvent(int eventId, InstructionEventType eventType,
      int eventSourceId, LocalDateTime occuredOn, boolean isDelivered,
      String instrData) {

    this.eventId = eventId;
    this.eventType = eventType;
    this.eventSourceId = eventSourceId;
    this.occuredOn = occuredOn;
    this.isDelivered = isDelivered;
    this.instrData = instrData;

  }

  public Integer getEventId() {
    return eventId;
  }

  public InstructionEventType getEventType() {
    return eventType;
  }

  public int getEventSourceId() {
    return eventSourceId;
  }

  @Override
  public LocalDateTime occuredOn() {
    return occuredOn;
  }

  public boolean isDelivered() {
    return isDelivered;
  }

  public String data() {
    return instrData;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final InstructionEvent other = (InstructionEvent) obj;
    return Objects.equals(this.getEventId(), other.getEventId());
  }

  @Override
  public int hashCode() {

    return Objects.hashCode(this.getEventId());
  }

  @Override
  public String toString() {

    return MoreObjects.toStringHelper(this).add("eventId", getEventId())
        .add("eventType", eventType).add("eventSourceId", getEventSourceId())
        .add("occurredOn", occuredOn()).add("isDelivered", isDelivered())
        .toString();
  }

}
