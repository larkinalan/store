package com.ilim.instruction.infra.model;

import com.ilim.crd.web.api.CrdCashForecast;
import com.ilim.crd.web.client.CrdMessagingClient;
import com.ilim.instruction.app.service.IModelService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Crd Messaging Service client adapter.
 * 
 * @author Michael Cunningham
 */
@Service
public class CrdServiceAdapter implements IModelService {

  private static final Logger log = LoggerFactory
      .getLogger(CrdServiceAdapter.class);

  private final CrdMessagingClient crdMessagingClient;

  /**Creates adapter to remote crd messaging service. */
  public CrdServiceAdapter() {

    this.crdMessagingClient = new CrdMessagingClient();
  }

  @Override
  public boolean sendToBbcw(CrdCashForecast crdCashForecast) {

    log.info("sendToBbcw ({})", crdCashForecast);

    return crdMessagingClient.sendToBbcw(crdCashForecast);
  }

}
