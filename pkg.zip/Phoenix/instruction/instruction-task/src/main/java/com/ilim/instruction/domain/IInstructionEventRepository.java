package com.ilim.instruction.domain;

import com.ilim.instruction.domain.event.InstructionEvent;

import java.util.List;

/**
 * Instruction Event Repository.
 * 
 * <p>persistence api for instructions.
 *
 * @author Michael Cunningham
 */
public interface IInstructionEventRepository {

  InstructionEvent findById(int eventId);

  List<InstructionEvent> findUndeliveredByType(int eventTypeId);

  void updateToDelivered(int eventId);
}
