package com.ilim.instruction.app.service;

import static com.google.common.base.Preconditions.checkArgument;

import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_APPROVED;
import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_RELEASED;

import com.ilim.instruction.domain.IInstructionEventRepository;
import com.ilim.instruction.domain.event.InstructionEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public class InstructionEventService implements IInstructionEventService {

  private static final Logger log =
      LoggerFactory.getLogger(InstructionEventService.class);

  private IInstructionEventRepository dao;

  /**
   * Initalize InstructionService.
   * 
   * @param dao persistence layer
   */
  @Autowired
  public InstructionEventService(IInstructionEventRepository dao) {

    this.dao = dao;
  }

  /**
   * Find all the undelivered fusion approved events.
   * 
   * @return List of InstructionEvent
   */
  @Transactional
  @Override
  public List<InstructionEvent> findUndeliveredFusionApproved() {

    log.info("findUndeliveredFusionApprovedEvents ()");

    return dao.findUndeliveredByType(FUSION_APPROVED.id());
  }

  /**
   * Find all the undelivered fusion released events.
   * 
   * @return List of InstructionEvent
   */
  @Transactional
  @Override
  public List<InstructionEvent> findUndeliveredFusionReleased() {

    log.info("findUndeliveredFusionReleasedEvents ()");

    return dao.findUndeliveredByType(FUSION_RELEASED.id());
  }

  /**
   * Update the instruction event to delivered.
   * 
   * @param eventId id
   */
  @Transactional
  @Override
  public void updateToDelivered(int eventId) {

    log.info("updateInstructionEventDelivered ({})", eventId);

    checkArgument(eventId > 0, "invalid event id!");
    dao.updateToDelivered(eventId);
  }

}
