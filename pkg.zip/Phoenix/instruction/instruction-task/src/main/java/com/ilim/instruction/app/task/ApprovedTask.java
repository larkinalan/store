package com.ilim.instruction.app.task;

import com.ilim.forecast.web.api.NewForecastInstructionData;
import com.ilim.instruction.app.service.IForecastService;
import com.ilim.instruction.app.service.IInstructionEventService;
import com.ilim.instruction.domain.event.InstructionEvent;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.camel.Consume;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ApprovedTask {

  private static Logger log = LoggerFactory.getLogger(ApprovedTask.class);

  private final ObjectMapper jsonMapper = new ObjectMapper();

  private IInstructionEventService instrEventService;

  private IForecastService forecastService;

  /**
   * ApprovedTask which has a scheduled poller associated. The poller will
   * periodically retrieve undelivered instruction events and create the 
   * corresponding forecast instruction via forecast client adapter.      
   * 
   * @param instrEventService service to extract undelivered events
   * @param forecastService service to integrate to forecast client adapter.
   */
  @Autowired
  public ApprovedTask(IInstructionEventService instrEventService,
      IForecastService forecastService) {

    this.instrEventService = instrEventService;
    this.forecastService = forecastService;
  }

  /**
   * Process instruction events based upon a configurable polling schedule.
   * 
   * @throws Exception when error happens
   */
  @Consume(uri = "timer://onApprovedTimer?delay=10s&period=60s")
  public void processInstrEvents() throws Exception {

    log.info("processApprovedInstrEvents ()");

    List<InstructionEvent> instrEvents =
        instrEventService.findUndeliveredFusionApprovedEvents();

    for (InstructionEvent instructionEvent : instrEvents) {

      NewForecastInstructionData instr =
          toNewForecastInstructionData(instructionEvent);

      int instrId = forecastService.create(instr);

      log.info("created forecast instruction ({})", instrId);

      int eventId = instructionEvent.getEventId();

      instrEventService.updateToDelivered(eventId);

      log.info("update instruction event ({})", eventId);
    }

  }

  /**
   * Helper method to extract and build the NewForecastInstructionData object
   * used by forecast client adapter.
   * TODO: moved to data mapper class
   * 
   * @param instructionEvent instruction event to be parsed
   * @return NewForecastInstructionData to be used on call to forecast client
   * @throws Exception if an error hapens during processing
   */
  private NewForecastInstructionData toNewForecastInstructionData(
      InstructionEvent instructionEvent) throws Exception {

    final String eventData = instructionEvent.data();

    Map<String, Object> map = new HashMap<String, Object>();
    try {
      map = jsonMapper.readValue(eventData, HashMap.class);
    } catch (Exception e) {
      
      // TODO: correct this to return correct exception
      
      log.error("Error while parsing instruction data: " + e.getMessage());
      throw e;
    }

    final String forecastDate = (String) map.get("forecastDate");

    final int fundId = (Integer) map.get("fundId");
    final int eventSourceId = (Integer) map.get("instrId");

    // TODO: correctly align moneyType to moneyNotificationType (from FUSION)
    String moneyType = (String) map.get("moneyNotificationType");
    if (moneyType != null && moneyType.equalsIgnoreCase("UNIT")) {
      moneyType = "UNITS";
    }

    // TODO: correctly align forecastType to instructionType (from FUSION)
    String forecastType = (String) map.get("instructionType");
    if (forecastType != null
        && forecastType.equalsIgnoreCase("MONEY_NOTIFICATION")) {
      forecastType = "NEW_MONEY";
    }

    Double tmp = (Double) map.get("amount");
    final BigDecimal amount = BigDecimal.valueOf(tmp);

    return new NewForecastInstructionData(forecastDate, forecastType, fundId,
        moneyType, amount, eventSourceId);
  }
}
