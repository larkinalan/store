package com.ilim.instruction.app.service;

import com.ilim.crd.web.api.CrdCashForecast;


public interface ICrdService {

  boolean sendToBbcw(CrdCashForecast crdCashForecast);

}
