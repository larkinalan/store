package com.ilim.instruction.domain.event;

/** Instruction Event Types. */
public enum InstructionEventType {

  UNKNOWN(0),
  FUSION_APPROVED(1),
  FUSION_RELEASED(2);

  private final int id;

  InstructionEventType(int id) {
    this.id = id;
  }

  public int id() {
    return id;
  }

  /** Gets a InstructionEventType corresponding to the id passed in. */
  public static InstructionEventType from(int id) {

    for (InstructionEventType type : InstructionEventType.values()) {
      if (type.id() == id) {
        return type;
      }
    }
    return UNKNOWN;
  }

  /** Gets a ForecastType corresponding to the name passed in. */
  public static InstructionEventType from(String name) {

    for (InstructionEventType type : InstructionEventType.values()) {
      if (type.name().equalsIgnoreCase(name)) {
        return type;
      }
    }
    return UNKNOWN;
  }
}
