package com.ilim.instruction.app.conf;

import com.ilim.instruction.app.task.ForecastApprovedFusionInstructionTask;
import com.ilim.instruction.app.task.ModelReleasedFusionInstructionTask;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.spring.javaconfig.CamelConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import java.util.Arrays;
import java.util.List;

/**
 * Camel Spring configuration.
 *
 * @author Michael Cunningham
 */
@Configuration
@Import({SpringConfig.class})
public class CamelSpringConfig extends CamelConfiguration {

  @Autowired
  private ForecastApprovedFusionInstructionTask approvedFusionInstrTask;

  @Autowired
  private ModelReleasedFusionInstructionTask releasedFusionInstrTask;

  /* Add all routes here. */
  @Override
  public List<RouteBuilder> routes() {

    return Arrays.asList(approvedFusionInstrTask, releasedFusionInstrTask);
  }

}
