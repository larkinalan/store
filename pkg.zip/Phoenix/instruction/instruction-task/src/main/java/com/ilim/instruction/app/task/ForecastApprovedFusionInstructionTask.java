package com.ilim.instruction.app.task;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.instruction.app.service.IForecastService;
import com.ilim.instruction.app.service.IInstructionEventService;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Approved Event Task which is a scheduled Camel Route to handle undelivered
 * Approved Instruction Events. They are firstly retrieved from the instruction
 * event store and then routed to the ForecastServiceAdpater for creation in the
 * Forecast Service.
 * 
 * @author Michael Cunningham
 *
 */
public class ForecastApprovedFusionInstructionTask extends RouteBuilder {

  @Autowired
  private IInstructionEventService instructionEventService;

  @Autowired
  private IForecastService forecastService;

  @Override
  public void configure() throws Exception {
    
    String schedule = settings()
        .getString("forecast.approved.fusion.instruction.task.schedule");
    int poolSize = settings()
        .getInt("forecast.approved.fusion.instruction.task.pool.size");
    
    //TODO: handle exceptions properly
    // onException(Exception.class)
    //   .log("Failure! " + body()).end();

    from("quartz2:forecastApprovedFusionInstructionPoller?cron=" + schedule)
        .routeId("ilim.route.forecastApprovedFusionInstructionPoller")
        .to("direct:findUndeliveredFusionApprovedEvents")
        .end();
    
    from("direct:findUndeliveredFusionApprovedInstructionEvents")
        .routeId("ilim.route.findUndeliveredFusionApprovedInstructionEvents")
        .bean(instructionEventService, "findUndeliveredFusionApprovedEvents")
        .choice()
          .when(body().isNull()) //FIXME. might be an empty list
            .log("No approved fusion instr events found!, sleeping....")
         .otherwise()
            .split(body())
            .threads(poolSize)
            .to("direct:createForecastInstruction")
         .end();
    
    from("direct:createForecastInstruction")
        .routeId("ilim.route.createForecastInstruction")
        .setHeader("eventId", simple("${body.eventId}"))
        .log("Processing fusion instuction event ${headers.eventId}")
        .bean(forecastService, "create")
        .log("Created forecast instuction ${body}")
        .setBody(header("eventId"))
        .bean(instructionEventService, "updateToDelivered")
        .log("Updated fusion instuction event ${headers.eventId} to delivered.")
        .end();

  }
}
