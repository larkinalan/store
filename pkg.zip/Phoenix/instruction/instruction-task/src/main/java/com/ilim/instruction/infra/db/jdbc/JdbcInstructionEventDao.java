package com.ilim.instruction.infra.db.jdbc;

import static com.ilim.commons.time.DateUtils.asLocalDateTime;

import com.ilim.commons.db.AppSqlException;
import com.ilim.instruction.domain.IInstructionEventRepository;
import com.ilim.instruction.domain.event.InstructionEvent;
import com.ilim.instruction.domain.event.InstructionEventType;
import com.ilim.instruction.infra.db.SQL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

/**
 * Database operations for instruction events. 
 *
 * @author Michael Cunningham
 */
@Repository
public class JdbcInstructionEventDao extends NamedParameterJdbcDaoSupport
    implements IInstructionEventRepository {

  private static final Logger log =
      LoggerFactory.getLogger(JdbcInstructionEventDao.class);

  /** Initialize Dao with sql dataSource. */
  @Autowired
  public JdbcInstructionEventDao(DataSource dataSource) {

    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  /**
   * Find instruction event by id.
   * 
   * @param eventId id 
   * @return InstructionEvent
   * @throws AppSqlException with db errors 
   */
  @Override
  public InstructionEvent findById(int eventId) {

    log.info("findById ({}) ", eventId);

    final String sql = SQL.select_from_instruction_event_by_id;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("eventId", eventId);

    final InstructionEvent result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toInstructionEvent(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findById " + eventId, ex);
    }

    return result;
  }

  /**
   * Find undelivered events by type.
   * 
   * @param eventTypeId type
   * @return List of InstructionEvent
   * @throws AppSqlException with db errors 
   */
  @Override
  public List<InstructionEvent> findUndeliveredByType(int eventTypeId) {

    log.info("findUndeliveredByType ({}) ", eventTypeId);

    final String sql =
        SQL.select_from_instruction_event_by_undelivered_and_type;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("eventTypeId", eventTypeId);

    final List<InstructionEvent> result = new ArrayList<>();
    try {

      result.addAll(
          getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
            return toInstructionEvent(rs);
          }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findUndeliveredByType " + eventTypeId,
          ex);
    }

    return result;
  }

  /**
   * Update event to delivered.
   * 
   * @param eventId event id to be updated
   * @throws AppSqlException with db errors 
   */
  @Override
  public void updateToDelivered(int eventId) {

    log.info("updateToDelivered ({})", eventId);

    final String sql = SQL.update_instruction_event_delivered;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("eventId", eventId);

    try {

      getNamedParameterJdbcTemplate().update(sql, params);

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in updateToDelivered event " + eventId,
          ex);
    }
  }

  private InstructionEvent toInstructionEvent(ResultSet rs) {

    try {

      int eventId = rs.getInt("instruction_event_id");
      InstructionEventType eventType =
          InstructionEventType.from(rs.getInt("event_type_id"));
      int eventSourceId = rs.getInt("event_source_id");
      LocalDateTime occurredOn = asLocalDateTime(rs.getDate("created_ts"));
      boolean isDelivered = rs.getBoolean("delivered_fg");
      String instrData = rs.getString("instruction_data");

      return new InstructionEvent(eventId, eventType, eventSourceId, occurredOn,
          isDelivered, instrData);

    } catch (SQLException ex) {
      throw new AppSqlException(
          "Error mapping sql resultset to instruction event!", ex);
    }
  }
}
