package com.ilim.instruction.infra.forecast;

import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.web.client.AppClientException;
import com.ilim.forecast.web.api.NewForecastInstructionData;
import com.ilim.forecast.web.client.ForecastClient;
import com.ilim.instruction.app.service.IForecastService;
import com.ilim.instruction.domain.event.InstructionEvent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.math.BigDecimal;

/**
 * Forecast Service client adapter.
 * 
 * @author Michael Cunningham
 */
public class ForecastServiceAdapter implements IForecastService {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastServiceAdapter.class);

  private static final ObjectMapper jsonMapper = new ObjectMapper();

  private final ForecastClient forecastClient;

  /**Creates adapter to remote forecast service. */
  public ForecastServiceAdapter() {

    this.forecastClient = new ForecastClient();
  }

  /**
   * Adpter to create forecast instruction.
   * 
   * @param instr instruction event
   * @return int id of the created forecast instruction
   * @throws AppClientException when create fails
   */
  @Override
  public int create(InstructionEvent instr) {

    log.info("create ({})", instr);

    NewForecastInstructionData instrData =
        toNewForecastInstructionData(instr.data());
    return forecastClient.create(instrData);
  }

  /** Converts to fusion event data to forecast api type. */ 
  private static NewForecastInstructionData toNewForecastInstructionData(
      String eventData) {

    final NewForecastInstructionData instr;
    try {

      JsonNode json = jsonMapper.readTree(eventData);
     
      String forecastDate = json.get("forecastDate").asText();
      int fundId = json.get("fundId").asInt();
      long eventSourceId = json.get("instrId").asLong();
      String moneyType = json.get("moneyNotificationType").asText();
      String forecastType =
          toForecastType(json.get("instructionType").asText());
      BigDecimal amount = new BigDecimal(json.get("amount").asText());

      instr = new NewForecastInstructionData(forecastDate, forecastType, fundId,
          moneyType, amount, eventSourceId);

    } catch (IOException ex) {
      throw new AppClientException("Failed to read instr event data", ex);
    }

    return instr;
  }
  
  /** Converts from fusion -> forecast instr type. */
  private static String toForecastType(String fusionInstrType)
      throws IOException {

    switch (fusionInstrType) {
      case "MONEY_NOTIFICATION":
        return ForecastType.NEW_MONEY.name();
      case "ZAP":
        return ForecastType.ZAP.name();
      default:
        throw new IOException("Unknown type : " + fusionInstrType);
    }
  }
  
  /*
  private static NewForecastInstructionData toNewForecastInstructionData(
      String eventData) {

    final NewForecastInstructionData instr;
    try {
      Map<String, String> data = jsonMapper.readValue(eventData,
          new TypeReference<Map<String, String>>() {});
      
      String forecastDate = data.get("forecastDate");
      int fundId = Integer.parseInt(data.get("fundId"));
      long eventSourceId = Long.parseLong(data.get("instrId"));
      String moneyType = data.get("moneyNotificationType");
      String forecastType = toForecastType(data.get("instructionType"));
      BigDecimal amount = new BigDecimal(data.get("amount"));
      
      instr = new NewForecastInstructionData(forecastDate, forecastType, fundId,
          moneyType, amount, eventSourceId);
      
    } catch (IOException ex) {
      throw new AppClientException("Failed to read instr event data", ex);
      
    } catch (NumberFormatException ex) {
      throw new AppClientException(
          "Failed to parse numeric column in instr event data!", ex);
    }
    
    return instr;
  }
  */
  
 

}
