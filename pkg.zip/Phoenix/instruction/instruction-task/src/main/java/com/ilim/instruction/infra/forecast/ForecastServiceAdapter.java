package com.ilim.instruction.infra.forecast;

import com.ilim.forecast.web.api.NewForecastInstructionData;
import com.ilim.forecast.web.client.ForecastClient;
import com.ilim.instruction.app.service.IForecastService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Forecast Service client adapter.
 * 
 * @author Michael Cunningham
 */
@Service
public class ForecastServiceAdapter implements IForecastService {

  private static final Logger log = LoggerFactory
      .getLogger(ForecastServiceAdapter.class);

  private final ForecastClient forecastClient;

  /**Creates adapter to remote forecast service. */
  public ForecastServiceAdapter() {

    this.forecastClient = new ForecastClient();
  }

  @Override
  public int create(NewForecastInstructionData instr) {

    log.info("create ({})", instr);

    return forecastClient.create(instr);
  }

}
