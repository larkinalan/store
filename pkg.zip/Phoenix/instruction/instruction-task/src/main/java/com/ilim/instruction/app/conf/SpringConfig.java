package com.ilim.instruction.app.conf;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.db.AppSqlException;
import com.ilim.instruction.app.service.ICrimsService;
import com.ilim.instruction.app.service.IForecastService;
import com.ilim.instruction.app.service.IInstructionEventService;
import com.ilim.instruction.app.service.InstructionEventService;
import com.ilim.instruction.app.task.ForecastApprovedFusionInstructionTask;
import com.ilim.instruction.app.task.ModelReleasedFusionInstructionTask;
import com.ilim.instruction.domain.IInstructionEventRepository;
import com.ilim.instruction.infra.db.jdbc.JdbcInstructionEventDao;
import com.ilim.instruction.infra.forecast.ForecastServiceAdapter;
import com.ilim.instruction.infra.model.CrimsServiceAdapter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.jta.JtaTransactionManager;

import java.io.IOException;
import java.sql.SQLException;

import javax.sql.DataSource;

/**
 * Spring component config.
 *
 * @author Michael Cunningham
 */
@Configuration
public class SpringConfig {

  private static final Logger log = LoggerFactory.getLogger(SpringConfig.class);

  private static boolean standaloneServer =
      settings().getBoolean("server.standalone");

  /** The jdbc Datasource. */
  @Bean
  public DataSource dataSource() {

    final DataSource dataSource;

    if (standaloneServer) {

      // standalone or testing
      dataSource = oracleConnection(new DriverManagerDataSource());

    } else {

      // assume jboss container
      final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
      dsLookup.setResourceRef(true);
      dataSource =
          dsLookup.getDataSource(settings().getString("jndi.datasource.fm"));
    }

    testConnection(dataSource);
    return dataSource;
  }

  /** The spring DataSourceTransactionManager. */
  @Bean
  public PlatformTransactionManager transactionManager(DataSource dataSource) {

    final PlatformTransactionManager txnMgr;

    if (standaloneServer) {

      // simple datasoource for testing
      txnMgr = new DataSourceTransactionManager(dataSource);

    } else {

      // assume jboss container
      txnMgr = jbossTransactionManager();
    }

    return txnMgr;
  }

  /** Create conn to oracle using conf file. */
  private DataSource oracleConnection(DriverManagerDataSource dataSource) {

    dataSource
        .setDriverClassName(settings().getString("db.jdbc.oracle.driver"));
    dataSource.setUrl(settings().getString("db.fm.url"));
    dataSource.setUsername(settings().getString("db.fm.user"));
    dataSource.setPassword(settings().getString("db.fm.pass"));

    return dataSource;
  }

  /** Simple test of of db connection. */
  private void testConnection(DataSource dataSource) {

    try {
      log.info("Testing database connection to "
          + dataSource.getConnection().getMetaData().getURL());
    } catch (SQLException ex) {
      throw new AppSqlException("Failed to connect to database!", ex);
    }
  }

  /** Jboss container JtaTransactionManager bean. */
  private PlatformTransactionManager jbossTransactionManager() {

    JtaTransactionManager txnMgr = new JtaTransactionManager();
    txnMgr.setTransactionManagerName(settings().getString("jndi.txnmanager"));
    return txnMgr;
  }

  /** JdbcInstructionEventDao spring bean. */
  @Bean
  public IInstructionEventRepository instructionEventDao(
      DataSource dataSource) {

    return new JdbcInstructionEventDao(dataSource);
  }

  /** InstructionEventService spring bean. */
  @Bean
  public IInstructionEventService instructionEventService(
      IInstructionEventRepository dao) {

    return new InstructionEventService(dao);
  }

  /** ForecastServiceAdpater spring bean. */
  @Bean
  public IForecastService forecastService() {

    return new ForecastServiceAdapter();
  }

  /** ApprovedTask spring bean. */
  @Bean
  public ForecastApprovedFusionInstructionTask approvedFusionInstrTask() {

    return new ForecastApprovedFusionInstructionTask();
  }

  /** CrimsServiceAdpater spring bean. */
  @Bean
  public ICrimsService crimsService() throws IOException {

    return new CrimsServiceAdapter();
  }

  /** ReleasedTask spring bean. */
  @Bean
  public ModelReleasedFusionInstructionTask releasedFusionInstrTask() {

    return new ModelReleasedFusionInstructionTask();
  }

}
