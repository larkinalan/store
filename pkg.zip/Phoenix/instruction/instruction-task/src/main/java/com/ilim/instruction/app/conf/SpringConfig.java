package com.ilim.instruction.app.conf;

import com.ilim.instruction.app.service.IInstructionEventService;
import com.ilim.instruction.app.service.InstructionEventService;
import com.ilim.instruction.domain.IInstructionEventRepository;
import com.ilim.instruction.infra.db.jdbc.JdbcInstructionEventDao;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * Spring component config.
 *
 * @author Michael Cunningham
 */
@Configuration
public class SpringConfig {

  /** JdbcInstructionDao spring bean. */
  @Bean
  public IInstructionEventRepository instructionEventDao(
      DataSource dataSource) {

    return new JdbcInstructionEventDao(dataSource);
  }

  /** InstructionService spring bean. */
  @Bean
  public IInstructionEventService instructionEventService(
      IInstructionEventRepository dao) {

    return new InstructionEventService(dao);
  }
}
