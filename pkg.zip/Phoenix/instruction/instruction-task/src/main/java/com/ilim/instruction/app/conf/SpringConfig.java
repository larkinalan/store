package com.ilim.instruction.app.conf;

import com.ilim.instruction.app.service.IForecastService;
import com.ilim.instruction.app.service.IInstructionEventService;
import com.ilim.instruction.app.service.InstructionEventService;
import com.ilim.instruction.app.task.ApprovedTask;
import com.ilim.instruction.domain.IInstructionEventRepository;
import com.ilim.instruction.infra.db.jdbc.JdbcInstructionEventDao;
import com.ilim.instruction.infra.forecast.ForecastServiceAdapter;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * Spring component config.
 *
 * @author Michael Cunningham
 */
@Configuration
public class SpringConfig {

  /** JdbcInstructionEventDao spring bean. */
  @Bean
  public IInstructionEventRepository instructionEventDao(
      DataSource dataSource) {

    return new JdbcInstructionEventDao(dataSource);
  }

  /** InstructionEventService spring bean. */
  @Bean
  public IInstructionEventService instructionEventService(
      IInstructionEventRepository dao) {

    return new InstructionEventService(dao);
  }

  /** ForecastServiceAdpater spring bean. */
  @Bean
  public IForecastService forecastService() {

    return new ForecastServiceAdapter();
  }

  /** ApprovedTask spring bean. */
  @Bean
  public ApprovedTask approvedTask(
      IInstructionEventService instructionEventService,
      IForecastService forecastService) {

    return new ApprovedTask(instructionEventService, forecastService);
  }

}
