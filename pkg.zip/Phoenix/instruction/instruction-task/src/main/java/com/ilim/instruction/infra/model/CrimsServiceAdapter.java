package com.ilim.instruction.infra.model;

import com.ilim.commons.web.client.AppClientException;
import com.ilim.crd.web.api.CrdCashForecast;
import com.ilim.crd.web.client.CrdMessagingClient;
import com.ilim.instruction.app.service.ICrimsService;
import com.ilim.instruction.domain.event.InstructionEvent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Crd Messaging Service client adapter.
 * 
 * @author Michael Cunningham
 */
@Service
public class CrimsServiceAdapter implements ICrimsService {

  private static final Logger log =
      LoggerFactory.getLogger(CrimsServiceAdapter.class);

  public static final DateTimeFormatter DATE_TIME_FMT_BBCW =
      DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

  private static final ObjectMapper jsonMapper = new ObjectMapper();

  private final CrdMessagingClient crdMessagingClient;

  /**Creates adapter to remote crd messaging service. */
  public CrimsServiceAdapter() {

    this.crdMessagingClient = new CrdMessagingClient();
  }

  /**Creates adapter to remote crd messaging service. */
  public CrimsServiceAdapter(String baseUrl) {

    this.crdMessagingClient = new CrdMessagingClient(baseUrl);
  }

  /**
   * Adapter to send a released instruction to Bbcw.
   * 
   * @param instr instruction event
   * @return result true|false on sending to bbcw
   */
  @Override
  public boolean sendToBbcw(InstructionEvent instr) {

    log.info("sendToBbcw ({})", instr);

    CrdCashForecast crdCashForecast = toCrdCashForecast(instr);
    return crdMessagingClient.sendToBbcw(crdCashForecast);
  }

  /** Converts event data to CrdCashForecast object. 
   *
   * @param eventData event data to be converted
   * @return CrdCashForecast converted data
   */
  private static CrdCashForecast toCrdCashForecast(InstructionEvent instr) {

    final CrdCashForecast cashForecast;
    try {

      JsonNode json = jsonMapper.readTree(instr.data());

      String acctCd = json.get("fundCode").asText();
      String amtType = "FTC";
      String crrncyCd = json.get("fundCurrency").asText();
      String forecastDate = LocalDateTime.now().format(DATE_TIME_FMT_BBCW);
      BigDecimal amount = new BigDecimal(json.get("amount").asText());
      String descr = "Forecast Instruction " + instr.getEventSourceId()
          + " on event " + instr.getEventId();

      cashForecast = new CrdCashForecast(acctCd, amtType, crrncyCd, amount,
          forecastDate, descr);

    } catch (IOException ex) {
      throw new AppClientException("Failed to read instr event data", ex);
    }

    return cashForecast;
  }
}
