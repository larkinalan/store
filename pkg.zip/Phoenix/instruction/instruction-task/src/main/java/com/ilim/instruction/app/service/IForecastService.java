package com.ilim.instruction.app.service;

import com.ilim.instruction.domain.event.InstructionEvent;

public interface IForecastService {

  int create(InstructionEvent instr);
  
}
