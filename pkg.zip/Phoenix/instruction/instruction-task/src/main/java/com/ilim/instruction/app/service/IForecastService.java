package com.ilim.instruction.app.service;

import com.ilim.forecast.web.api.NewForecastInstructionData;

public interface IForecastService {

  public int create(NewForecastInstructionData instr);

}
