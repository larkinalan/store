package com.ilim.instruction.app.service;

import com.ilim.instruction.domain.event.InstructionEvent;


public interface ICrimsService {

  boolean sendToBbcw(InstructionEvent instr);

}
