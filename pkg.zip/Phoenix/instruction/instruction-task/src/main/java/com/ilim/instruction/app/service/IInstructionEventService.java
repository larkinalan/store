package com.ilim.instruction.app.service;

import com.ilim.instruction.domain.event.InstructionEvent;

import java.util.List;

public interface IInstructionEventService {

  List<InstructionEvent> findUndeliveredFusionApproved();

  List<InstructionEvent> findUndeliveredFusionReleased();

  void updateToDelivered(int eventId);

}
