package com.ilim.instruction.app.service;

import com.ilim.instruction.domain.event.InstructionEvent;

import java.util.List;

public interface IInstructionEventService {

  List<InstructionEvent> findUndeliveredFusionApprovedEvents();

  List<InstructionEvent> findUndeliveredFusionReleasedEvents();

  void updateToDelivered(int eventId);

}
