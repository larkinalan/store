package com.ilim.instruction.app.task;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.web.client.AppClientException;
import com.ilim.instruction.app.service.ICrimsService;
import com.ilim.instruction.app.service.IInstructionEventService;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Released Event Task which is a scheduled Camel Route to handle undelivered
 * Released Instruction Events. They are firstly retrieved from the instruction
 * event store and then routed to the CrdServiceAdpater for sending to the Bbcw.
 * 
 * @author Michael Cunningham
 *
 */
public class ModelReleasedFusionInstructionTask extends RouteBuilder {

  @Autowired
  private IInstructionEventService instructionEventService;

  @Autowired
  private ICrimsService crimsService;

  @Override
  public void configure() throws Exception {

    String schedule =
        settings().getString("model.released.fusion.instruction.task.schedule");
    int poolSize =
        settings().getInt("model.released.fusion.instruction.task.pool.size");

    onException(AppClientException.class)
        .to("seda:notifyTechSupportSendToBbcwFailed")
        .stop();

    from("quartz2:modelReleasedFusionEventsPoller?cron=" + schedule)
        .routeId("ilim.route.modelReleasedFusionEventsPoller")
        .to("direct:findUndeliveredFusionReleasedEvents")
        .end();

    from("direct:findUndeliveredFusionReleasedEvents")
        .routeId("ilim.route.findUndeliveredFusionReleasedEvents")
        .bean(instructionEventService, "findUndeliveredFusionReleased")
        .choice()
          .when(body().isLessThan(1))
          .log("No released fusion instr events found!, sleeping....")
        .otherwise()
          .split(body()).threads(poolSize)
          .to("direct:sendToCrimsBbcw")
        .end();

    from("direct:sendToCrimsBbcw").routeId("ilim.route.sendToCrimsBbcw")
        .setHeader("eventId", simple("${body.eventId}"))
        .log("Processing released instruction event ${headers.eventId}")
        .bean(crimsService, "sendToBbcw")
        .log("Sent instruction to Bbcw, result (${body})")
        .setBody(header("eventId"))
        .bean(instructionEventService, "updateToDelivered")
        .log("Updated instuction event ${headers.eventId} to delivered.")
        .stop();

    from("seda:notifyTechSupportSendToBbcwFailed")
        .routeId("ilim.route.notifyTechSupportSendToBbcwFailed")
        .log("TOOD: send email via camel-mail")
        .end();

  }

}
