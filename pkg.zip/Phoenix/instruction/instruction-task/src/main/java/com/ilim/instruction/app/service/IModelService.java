package com.ilim.instruction.app.service;

import com.ilim.crd.web.api.CrdCashForecast;


public interface IModelService {

  boolean sendToBbcw(CrdCashForecast crdCashForecast);

}
