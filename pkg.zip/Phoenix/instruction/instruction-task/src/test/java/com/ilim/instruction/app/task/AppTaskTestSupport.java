package com.ilim.instruction.app.task;

import com.ilim.instruction.app.conf.CamelSpringTestConfig;
import com.ilim.instruction.app.service.IInstructionEventService;
import com.ilim.instruction.domain.IInstructionEventRepository;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;

import org.apache.camel.CamelContext;
import org.apache.camel.test.spring.CamelSpringDelegatingTestContextLoader;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.apache.camel.test.spring.CamelTestContextBootstrapper;
import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.BootstrapWith;
import org.springframework.test.context.ContextConfiguration;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@BootstrapWith(CamelTestContextBootstrapper.class)
@ContextConfiguration(classes = {CamelSpringTestConfig.class},
    loader = CamelSpringDelegatingTestContextLoader.class)
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
public abstract class AppTaskTestSupport {

  @Rule
  @Autowired
  @Qualifier("testLogger")
  public TestRule logger;
  
  @Autowired
  @Qualifier("mockWebServer")
  public MockWebServer mockWebServer;
  
  @Autowired
  protected IInstructionEventRepository instrEventDao;
  
  @Autowired
  @InjectMocks
  protected IInstructionEventService instrEventService;
  
  @Autowired
  protected CamelContext camelContext;
  
  protected void addMockCreateResponse(int httpStatusCode,
      String locationHeader) {

    MockResponse response = new MockResponse().setResponseCode(httpStatusCode);
    response.addHeader("Location", locationHeader);
    mockWebServer.enqueue(response);
  }

  protected void addMockBbcwResponse(int httpStatusCode, boolean result) {

    MockResponse response = new MockResponse().setResponseCode(httpStatusCode);
    response.setBody(Boolean.toString(result));
    mockWebServer.enqueue(response);
  }
  
}
