package com.ilim.instruction.app;

import com.ilim.instruction.app.conf.SpringTestConfig;
import com.ilim.instruction.domain.IInstructionEventRepository;

import org.junit.Rule;
import org.junit.rules.TestRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

@ContextConfiguration(classes = SpringTestConfig.class)
public abstract class SpringTestSupport extends
    AbstractTransactionalJUnit4SpringContextTests {

  @Rule
  @Autowired
  public TestRule logger;

  @Autowired
  public IInstructionEventRepository dao;

}
