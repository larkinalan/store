package com.ilim.instruction.app.task;

import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_RELEASED;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.ilim.instruction.app.TestData;
import com.ilim.instruction.domain.event.InstructionEvent;

import net.jcip.annotations.NotThreadSafe;

import org.apache.camel.EndpointInject;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.spring.MockEndpoints;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@NotThreadSafe
@MockEndpoints()
public class ModelReleasedFusionInstructionTaskTest extends AppTaskTestSupport {

  @Autowired
  private ModelReleasedFusionInstructionTask modelReleasedFusionInstructionTask;

  @Produce(uri = "direct:findUndeliveredFusionReleasedEvents")
  private ProducerTemplate findUndeliveredFusionReleasedEvents;

  @EndpointInject(uri = "mock:direct:sendToCrimsBbcw")
  protected MockEndpoint mockSendToCrimsBbcw;

  /**
   * Setup the mocks and add the tested route to the camel context.
   * 
   * @throws Exception during the setup process
   */
  @Before
  public void setUp() throws Exception {

    MockitoAnnotations.initMocks(this);
    camelContext.addRoutes(modelReleasedFusionInstructionTask);
    camelContext.getRoute("ilim.route.modelReleasedFusionEventsPoller")
        .getEndpoint().stop();
  }

  public String bbcwResource() {
    return mockWebServer.url("/mock/CRDIntegration/").toString();
  }

  @Test
  public void modelReleasedFusionInstructionTask() throws Exception {

    // setup data
    List<Integer> updatedEventIds = new ArrayList<Integer>();
    List<InstructionEvent> undelivered =
        TestData.InstructionEvents.listReleased;

    for (InstructionEvent instructionEvent : undelivered) {
      updatedEventIds.add(instructionEvent.getEventId());
    }

    // set mocks
    when(instrEventDao.findUndeliveredByType(FUSION_RELEASED.id()))
        .thenReturn(undelivered);

    // add mock web server response for each event.
    for (int i = 0; i < undelivered.size(); i++) {
      addMockBbcwResponse(201, true);
    }

    mockSendToCrimsBbcw.expectedBodiesReceived(undelivered);

    // test
    findUndeliveredFusionReleasedEvents.sendBody("Mock Poller");

    // verify
    mockSendToCrimsBbcw.expectedMessageCount(2);
    mockSendToCrimsBbcw.assertIsSatisfied();

    // verify that the update was at least called correctly as expected
    ArgumentCaptor<Integer> argument = ArgumentCaptor.forClass(Integer.class);
    verify(instrEventDao, times(2)).updateToDelivered(argument.capture());
    assertThat(argument.getAllValues().size()).isGreaterThan(0);
    assertThat(argument.getAllValues()).containsOnlyElementsOf(updatedEventIds);
  }

  @Test
  public void whenNoUndeliveredReleasedEventsFound() throws Exception {

    // setup data
    List<InstructionEvent> undelivered = new ArrayList<InstructionEvent>();

    // set mocks
    when(instrEventDao.findUndeliveredByType(FUSION_RELEASED.id()))
        .thenReturn(undelivered);

    mockSendToCrimsBbcw.expectedBodiesReceived(undelivered);

    // test
    findUndeliveredFusionReleasedEvents.sendBody("Mock Poller");

    // verify
    mockSendToCrimsBbcw.expectedMessageCount(0);
    mockSendToCrimsBbcw.assertIsSatisfied();

    // verify that the update was not called
    verify(instrEventDao, times(0)).updateToDelivered(Mockito.anyInt());
  }

  @Test()
  public void crimsServiceError() throws Exception {

    // setup data
    List<InstructionEvent> undelivered =
        TestData.InstructionEvents.listReleased;

    // set mocks
    when(instrEventDao.findUndeliveredByType(FUSION_RELEASED.id()))
        .thenReturn(undelivered);

    // add mock web server response for each event.
    for (int i = 0; i < undelivered.size(); i++) {
      addMockBbcwResponse(500, true);
    }

    // test
    findUndeliveredFusionReleasedEvents.sendBody("Mock Poller");
  }
}
