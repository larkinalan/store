package com.ilim.instruction.app.service;

import static org.junit.Assert.fail;

import com.ilim.instruction.app.SpringTestSupport;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class ModelServiceTest extends SpringTestSupport {

  @Autowired
  private IModelService modelService;

  @Test
  public void create() {

    fail("TODO");
  }

}
