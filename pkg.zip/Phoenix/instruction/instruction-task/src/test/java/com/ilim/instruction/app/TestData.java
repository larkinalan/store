package com.ilim.instruction.app;

import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_APPROVED;
import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_RELEASED;
import static java.util.stream.Collectors.toList;

import com.ilim.instruction.domain.event.InstructionEvent;
import com.ilim.instruction.domain.event.InstructionEventType;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class TestData {

  private static final Random id = new Random();
  private static final ObjectMapper jsonMapper = new ObjectMapper();

  public static class InstructionEvents {

    // TEST EVENTS
    public static final InstructionEvent fusionApprovedBPL =
        new InstructionEvent(randId(), FUSION_APPROVED, 1, LocalDateTime.now(),
            false, newEventData(1, 26320, "BPL", "101.01"));
    public static final InstructionEvent fusionReleasedBPL =
        new InstructionEvent(randId(), FUSION_RELEASED, 1, LocalDateTime.now(),
            false, newEventData(1, 26320, "BPL", "101.01"));
    public static final InstructionEvent fusionApprovedPCF =
        new InstructionEvent(randId(), FUSION_APPROVED, 2, LocalDateTime.now(),
            false, newEventData(2, 17444, "PCF", "101.01"));
    public static final InstructionEvent fusionReleasedPCF =
        new InstructionEvent(randId(), FUSION_RELEASED, 2, LocalDateTime.now(),
            false, newEventData(2, 17444, "PCF", "101.01"));

    public static final InstructionEvent fusionApprovedDelivered =
        new InstructionEvent(randId(), FUSION_APPROVED, 2, LocalDateTime.now(),
            true, newEventData(2, 17444, "PCF", "101.01"));

    // COLLECTORS

    public static final List<InstructionEvent> list =
        ImmutableList.of(fusionApprovedBPL, fusionReleasedBPL,
            fusionApprovedPCF, fusionReleasedPCF);

    public static final List<InstructionEvent> listApproved =
        list.stream().filter(i -> i.getEventType().equals(FUSION_APPROVED))
            .collect(toList());
    public static final List<InstructionEvent> listReleased =
        list.stream().filter(i -> i.getEventType().equals(FUSION_RELEASED))
            .collect(toList());
  }

  /** Creates random positive int. */
  public static int randId() {
    return id.nextInt(Integer.SIZE - 1);
  }
  
  /** Creates unsaved instr event. */
  public static InstructionEvent newInstrEvent(InstructionEventType type,
      String amt) {

    int dummy = -1;
    int instrId = randId();
    return new InstructionEvent(dummy, type, instrId, LocalDateTime.now(),
        false, newEventData(-1, 26320, "BPL", amt));
  }

  /** Creates instr json data. */
  public static String newEventData(int instrId, int fundId, String fundCode,
      String amt) {

    try {
      Map<String, Object> data = new HashMap<>();
      data.put("instrId", instrId);
      data.put("instructionType", "MONEY_NOTIFICATION");
      data.put("fundId", fundId);
      data.put("fundCode", fundCode);
      data.put("fundCurrency", "EUR");
      data.put("moneyNotificationType", "CASH");
      data.put("forecastDate", "01/02/2016");
      data.put("amount", amt);

      return jsonMapper.writeValueAsString(data);

    } catch (IOException ex) {
      throw new UncheckedIOException(ex);
    }
  }

  /** Changes event to undelivered. TODO: a builder for this would be nice. */
  public static InstructionEvent toDelivered(InstructionEvent event) {

    return new InstructionEvent(event.getEventId(), event.getEventType(),
        event.getEventSourceId(), event.occuredOn(), true, event.data());
  }
}
