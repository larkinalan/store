package com.ilim.instruction.app.conf;

import com.ilim.commons.logging.TestLogger;

import org.junit.rules.TestRule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Spring component test config.
 *
 * @author Michael Cunningham
 */
@Configuration
@EnableTransactionManagement
@Import({SpringStandaloneConfig.class})
public class SpringTestConfig {

  /** TestLogger bean. helps log root cause of errors.  */
  @Bean
  public TestRule testLogger() {
    return new TestLogger();
  }

}
