package com.ilim.instruction.app.service;

import static org.junit.Assert.fail;

import com.ilim.instruction.app.SpringTestSupport;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class ForecastServiceTest extends SpringTestSupport {

  @Autowired
  private IForecastService forecastService;

  @Test
  public void create() {

    fail("TODO");
  }

}
