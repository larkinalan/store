package com.ilim.instruction.app.service;

import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_APPROVED;
import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_RELEASED;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import com.ilim.instruction.app.SpringTestSupport;
import com.ilim.instruction.domain.IInstructionEventRepository;
import com.ilim.instruction.domain.event.InstructionEvent;
import com.ilim.instruction.domain.event.InstructionEventType;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@RunWith(MockitoJUnitRunner.class)
public class InstructionEventServiceTest extends SpringTestSupport {

  public final AtomicInteger eventId = new AtomicInteger(9999);
  public final AtomicInteger eventSourceId = new AtomicInteger(9999);

  @InjectMocks
  private InstructionEventService service;

  @Mock
  private IInstructionEventRepository dao;

  @Test
  public void findUndeliveredFusionApprovedEvents() {

    List<InstructionEvent> undeliveredEvents =
        testEvents(FUSION_APPROVED, false);
    when(dao.findUndeliveredByType(Mockito.anyInt())).thenReturn(
        undeliveredEvents);

    List<InstructionEvent> events =
        service.findUndeliveredFusionApprovedEvents();

    assertThat(events).isNotNull();
    assertThat(events.size()).isGreaterThan(0);
    assertTrue(events.stream().allMatch(
        i -> i.getEventType().equals(FUSION_APPROVED) && !i.isDelivered()
            && !i.data().isEmpty()));
  }

  @Test
  public void findUndeliveredFusionReleasedEvents() {

    List<InstructionEvent> undeliveredEvents =
        testEvents(FUSION_RELEASED, false);
    when(dao.findUndeliveredByType(Mockito.anyInt())).thenReturn(
        undeliveredEvents);

    List<InstructionEvent> events =
        service.findUndeliveredFusionReleasedEvents();

    assertThat(events).isNotNull();
    assertThat(events.size()).isGreaterThan(0);
    assertTrue(events.stream().allMatch(
        i -> i.getEventType().equals(FUSION_RELEASED) && !i.isDelivered()
            && !i.data().isEmpty()));
  }

  @Test
  public void updateInstructionEventDevlivered() throws Exception {

    List<InstructionEvent> undeliveredEvents =
        testEvents(FUSION_APPROVED, false);
    List<InstructionEvent> deliveredEvents = testEvents(FUSION_APPROVED, true);

    when(dao.findUndeliveredByType(Mockito.anyInt())).thenReturn(
        undeliveredEvents);
    doNothing().when(dao).updateToDelivered(Mockito.anyInt());
    when(dao.findById(Mockito.anyInt())).thenReturn(deliveredEvents.get(0));

    List<InstructionEvent> events =
        service.findUndeliveredFusionApprovedEvents();

    assertThat(events).isNotNull();
    assertThat(events.size()).isGreaterThan(0);

    for (InstructionEvent event : events) {
      service.updateToDelivered(event.getEventId());
      InstructionEvent actual = dao.findById(event.getEventId());
      assertTrue(actual.isDelivered());
    }
  }

  /**
   * Helper to build test instruction events.
   * 
   * @param eventType event type to include
   * @param isDelivered delivered flag setting
   * @return List of InstructionEvent
   */
  public List<InstructionEvent> testEvents(InstructionEventType eventType,
      boolean isDelivered) {

    List<InstructionEvent> events = new ArrayList<InstructionEvent>();

    int eventId = this.eventId.getAndIncrement();
    int eventSourceId = this.eventSourceId.getAndIncrement();
    LocalDateTime occurredOn = LocalDateTime.now();
    String instrData = "instruction_data";

    events.add(new InstructionEvent(eventId, eventType, eventSourceId,
        occurredOn, isDelivered, instrData));

    return events;
  }

}
