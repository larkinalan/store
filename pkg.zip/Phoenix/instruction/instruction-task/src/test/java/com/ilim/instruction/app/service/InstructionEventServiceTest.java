package com.ilim.instruction.app.service;

import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_APPROVED;
import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_RELEASED;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.ilim.instruction.app.SpringTestSupport;
import com.ilim.instruction.domain.event.InstructionEvent;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class InstructionEventServiceTest extends SpringTestSupport {

  @Autowired
  private IInstructionEventService service;

  @Test
  public void findUndeliveredFusionApprovedEvents() {

    List<InstructionEvent> events =
        service.findUndeliveredFusionApprovedEvents();

    assertThat(events).isNotNull();
    assertThat(events.size()).isGreaterThan(0); 
    assertTrue(
        events.stream().allMatch(i -> i.getEventType().equals(FUSION_APPROVED)
            && !i.isDelivered() && !i.data().isEmpty()));
  }
  
  @Test
  public void findUndeliveredFusionReleasedEvents() {

    List<InstructionEvent> events =
        service.findUndeliveredFusionReleasedEvents();

    assertThat(events).isNotNull();
    assertThat(events.size()).isGreaterThan(0); 
    assertTrue(
        events.stream().allMatch(i -> i.getEventType().equals(FUSION_RELEASED)
            && !i.isDelivered() && !i.data().isEmpty()));
  }

  @Test
  public void updateInstructionEventDevlivered() throws Exception {

    List<InstructionEvent> events =
        service.findUndeliveredFusionApprovedEvents();

    assertThat(events).isNotNull();
    assertThat(events.size()).isGreaterThan(0);

    for (InstructionEvent event : events) {
      service.updateToDelivered(event.getEventId());
      InstructionEvent actual = dao.findById(event.getEventId());
      assertTrue(actual.isDelivered());
    }
  }

}
