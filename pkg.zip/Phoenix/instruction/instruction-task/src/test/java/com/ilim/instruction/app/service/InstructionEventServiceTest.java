package com.ilim.instruction.app.service;

import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_APPROVED;
import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_RELEASED;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import com.ilim.instruction.app.SpringTestSupport;
import com.ilim.instruction.app.TestData;
import com.ilim.instruction.domain.IInstructionEventRepository;
import com.ilim.instruction.domain.event.InstructionEvent;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class InstructionEventServiceTest extends SpringTestSupport {

  @InjectMocks
  private InstructionEventService service;

  @Mock
  private IInstructionEventRepository dao;

  @Test
  public void findUndeliveredFusionApprovedEvents() {

    // setup data
    List<InstructionEvent> undeliveredEvents =
        TestData.InstructionEvents.listApproved;
    when(dao.findUndeliveredByType(anyInt())).thenReturn(undeliveredEvents);

    // test
    List<InstructionEvent> events =
        service.findUndeliveredFusionApprovedEvents();

    // verify
    assertThat(events).hasSize(2);
    assertTrue(
        events.stream().allMatch(i -> i.getEventType().equals(FUSION_APPROVED)
            && !i.isDelivered() && !i.data().isEmpty()));
  }

  @Test
  public void findUndeliveredFusionReleasedEvents() {

    // setup data
    List<InstructionEvent> undeliveredEvents =
        TestData.InstructionEvents.listReleased;
    when(dao.findUndeliveredByType(anyInt())).thenReturn(undeliveredEvents);

    // test
    List<InstructionEvent> events =
        service.findUndeliveredFusionReleasedEvents();

    // verify
    assertThat(events).hasSize(2);
    assertTrue(
        events.stream().allMatch(i -> i.getEventType().equals(FUSION_RELEASED)
            && !i.isDelivered() && !i.data().isEmpty()));
  }

  @Test
  public void updateApprovedInstructionEventsToDevlivered() throws Exception {

    // setup data
    List<InstructionEvent> undeliveredEvents =
        TestData.InstructionEvents.listApproved;
    when(dao.findUndeliveredByType(FUSION_APPROVED.id()))
        .thenReturn(undeliveredEvents);
    doNothing().when(dao).updateToDelivered(anyInt());
    when(dao.findById(anyInt()))
        .thenReturn(TestData.toDelivered(undeliveredEvents.get(0)));

    // test & verify
    List<InstructionEvent> events =
        service.findUndeliveredFusionApprovedEvents();
    assertThat(events).hasSize(2);
    for (InstructionEvent event : events) {
      service.updateToDelivered(event.getEventId());
      InstructionEvent actual = dao.findById(event.getEventId());
      assertTrue(actual.isDelivered());
    }
  }

}
