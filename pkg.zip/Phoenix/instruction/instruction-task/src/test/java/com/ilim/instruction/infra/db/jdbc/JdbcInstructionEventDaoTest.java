package com.ilim.instruction.infra.db.jdbc;

import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_APPROVED;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.ilim.instruction.app.SpringTestSupport;
import com.ilim.instruction.domain.event.InstructionEvent;

import org.junit.Test;

import java.util.List;

/**
 * Tests for JdbcInstructionEventDao.
 *
 * @author Michael Cunningham
 */
public class JdbcInstructionEventDaoTest extends SpringTestSupport {

  @Test
  public void findUndeliveredByEventType() throws Exception {

    List<InstructionEvent> actual =
        dao.findUndeliveredByType(FUSION_APPROVED.id());

    assertThat(actual).isNotNull();
    assertThat(actual.size()).isGreaterThan(0);
    
    assertTrue(actual.stream().allMatch(
        i -> i.getEventType().equals(FUSION_APPROVED)
            && !i.isDelivered()
            && !i.data().isEmpty()));
  }

  @Test
  public void updateInstructionEventDevlivered() throws Exception {
    
    //TODO: setup some test data;

    List<InstructionEvent> instrEvents =
        dao.findUndeliveredByType(FUSION_APPROVED.id());

    assertThat(instrEvents).isNotNull();
    assertThat(instrEvents.size()).isGreaterThan(0);

    for (InstructionEvent event : instrEvents) {
      dao.updateToDelivered(event.getEventId());
      InstructionEvent actual = dao.findById(event.getEventId());
      assertTrue(actual.isDelivered());
    }
  }
}
