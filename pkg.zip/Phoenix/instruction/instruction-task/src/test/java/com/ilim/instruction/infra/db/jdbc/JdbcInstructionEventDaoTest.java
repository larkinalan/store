package com.ilim.instruction.infra.db.jdbc;

import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_APPROVED;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.ilim.commons.db.AppSqlException;
import com.ilim.instruction.app.AppTestSupport;
import com.ilim.instruction.app.TestData;
import com.ilim.instruction.domain.event.InstructionEvent;

import org.junit.Test;

import java.util.List;

/**
 * Tests for JdbcInstructionEventDao.
 *
 * @author Michael Cunningham
 */
public class JdbcInstructionEventDaoTest extends AppTestSupport {

  @Test
  public void createAndFindById() throws Exception {

    // set up data
    InstructionEvent expected =
        TestData.newInstrEvent(FUSION_APPROVED, "100.01");
    
    // test
    int id = dao.create(expected);
    InstructionEvent actual = dao.findById(id);

    // verify
    assertThat(actual).isEqualToIgnoringGivenFields(expected, "eventId",
        "occuredOn");
    assertThat(actual.occuredOn())
        .isEqualToIgnoringSeconds(expected.occuredOn());

  }

  @Test(expected = AppSqlException.class)
  public void findByIdException() throws Exception {

    dao.findById(-1);
  }

  @Test
  public void findUndeliveredByEventType() throws Exception {
    
    // set up data
    InstructionEvent expected =
        TestData.newInstrEvent(FUSION_APPROVED, "100.01");
    int id = dao.create(expected);

    // test
    List<InstructionEvent> actual =
        dao.findUndeliveredByType(FUSION_APPROVED.id());

    // verify
    assertThat(actual.size()).isGreaterThan(0);
    assertTrue(
        actual.stream().allMatch(i -> i.getEventType().equals(FUSION_APPROVED)
            && !i.isDelivered() && !i.data().isEmpty()));
    
    assertThat(actual).extracting("eventId").containsOnlyOnce(id);
  }

  @Test
  public void updateInstructionEventDelivered() throws Exception {

    // set up data
    InstructionEvent expected =
        TestData.newInstrEvent(FUSION_APPROVED, "100.01");
    int id = dao.create(expected);

    // test & verify
    assertThat(dao.findById(id).isDelivered()).isFalse();
    dao.updateToDelivered(id);
    assertThat(dao.findById(id).isDelivered()).isTrue();
  }

}
