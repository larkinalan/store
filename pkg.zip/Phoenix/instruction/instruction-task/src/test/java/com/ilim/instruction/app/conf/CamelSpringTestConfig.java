package com.ilim.instruction.app.conf;

import com.ilim.commons.logging.TestLogger;
import com.ilim.instruction.app.service.ICrimsService;
import com.ilim.instruction.app.service.IForecastService;
import com.ilim.instruction.app.service.IInstructionEventService;
import com.ilim.instruction.app.service.InstructionEventService;
import com.ilim.instruction.app.task.ForecastApprovedFusionInstructionTask;
import com.ilim.instruction.app.task.ModelReleasedFusionInstructionTask;
import com.ilim.instruction.domain.IInstructionEventRepository;
import com.ilim.instruction.infra.db.jdbc.JdbcInstructionEventDao;
import com.ilim.instruction.infra.forecast.ForecastServiceAdapter;
import com.ilim.instruction.infra.model.CrimsServiceAdapter;

import okhttp3.mockwebserver.MockWebServer;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.spring.javaconfig.CamelConfiguration;
import org.junit.rules.TestRule;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


/**
 * Camel Spring component config.
 *
 * @author Michael Cunningham
 */
@Configuration
public class CamelSpringTestConfig extends CamelConfiguration {

  /** TestLogger bean. helps log root cause of errors.  */
  @Bean()
  @Qualifier("testLogger")
  public TestRule testLogger() {
    return new TestLogger();
  }

  /**
   * Override routes with empty list.
   *  
   * <p>We don't add routes here, we do it dynamically in the test setup.
   **/
  @Override
  public List<RouteBuilder> routes() {
    return new ArrayList<>();
  }

  /** Mock JdbcInstructionEventDao. */
  @Bean
  public IInstructionEventRepository instructionEventDao() {

    return Mockito.mock(JdbcInstructionEventDao.class);
  }

  /** InstructionEventService spring bean. */
  @Bean
  public IInstructionEventService instructionEventService(
      IInstructionEventRepository dao) {

    return new InstructionEventService(dao);
  }

  /** Mock http server. */
  @Bean
  @Qualifier("mockWebServer")
  public TestRule mockWebSever() throws IOException {

    MockWebServer server = new MockWebServer();
    server.start();
    return server;
  }

  /** ForecastServiceAdpater spring bean.
   *  
   * @throws IOException while initialising the forecast service client 
   */
  @Bean
  public IForecastService forecastService(TestRule mockWebSever)
      throws IOException {

    String baseUrl =
        ((MockWebServer) mockWebSever).url("/mock/forecast/").toString();
    return new ForecastServiceAdapter(baseUrl);
  }

  /** ApprovedTask spring bean. */
  @Bean
  public ForecastApprovedFusionInstructionTask approvedFusionInstrTask() {

    return new ForecastApprovedFusionInstructionTask();
  }

  /** CrdServiceAdpater spring bean.
   *  
   * @throws IOException while initialising the crd service client 
   */
  @Bean
  public ICrimsService modelService(TestRule mockWebSever) throws IOException {

    String baseUrl =
        ((MockWebServer) mockWebSever).url("/mock/CRDIntegration/").toString();
    return new CrimsServiceAdapter(baseUrl);
  }

  /** ReleasedTask spring bean. */
  @Bean
  public ModelReleasedFusionInstructionTask releasedFusionInstrTask() {

    return new ModelReleasedFusionInstructionTask();
  }

}
