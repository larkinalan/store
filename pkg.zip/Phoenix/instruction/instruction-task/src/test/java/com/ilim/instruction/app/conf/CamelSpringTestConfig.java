package com.ilim.instruction.app.conf;

import com.ilim.commons.logging.TestLogger;
import com.ilim.instruction.app.service.IForecastService;
import com.ilim.instruction.app.service.IInstructionEventService;
import com.ilim.instruction.app.service.InstructionEventService;
import com.ilim.instruction.domain.IInstructionEventRepository;
import com.ilim.instruction.infra.db.jdbc.JdbcInstructionEventDao;
import com.ilim.instruction.infra.forecast.ForecastServiceAdapter;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.spring.javaconfig.CamelConfiguration;
import org.junit.rules.TestRule;
import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

/**
 * Camel Spring component config.
 *
 * @author Michael Cunningham
 */
@Configuration
public class CamelSpringTestConfig extends CamelConfiguration {

  /** TestLogger bean.  */
  @Bean
  public TestRule testLogger() {
    return new TestLogger();
  }

  /**
   * Override routes with empty list.
   *  
   * <p>We don't add routes here, we do it dynamically in the test setup.
   **/
  @Override
  public List<RouteBuilder> routes() {
    return new ArrayList<>();
  }

  /** Mock ForecastServiceAdpater bean. */
  @Bean
  public IForecastService forecastService() {

    return Mockito.mock(ForecastServiceAdapter.class);
  }

  /** Mock InstructionEventService bean. */
  @Bean
  public IInstructionEventService instructionEventService() {

    return Mockito.mock(InstructionEventService.class);
  }
  
  /** JdbcInstructionEventDao spring bean. */
  @Bean
  public IInstructionEventRepository instructionEventDao() {

    return Mockito.mock(JdbcInstructionEventDao.class);
  }
}
