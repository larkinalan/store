package com.ilim.instruction.app.task;

import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import com.ilim.instruction.app.TestData;
import com.ilim.instruction.app.service.IForecastService;
import com.ilim.instruction.app.service.IInstructionEventService;
import com.ilim.instruction.domain.event.InstructionEvent;

import org.apache.camel.EndpointInject;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.spring.MockEndpoints;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@MockEndpoints()
public class ForecastApprovedFusionInstructionTaskTest
    extends AppTaskTestSupport {

  @Autowired
  private IInstructionEventService instructionEventService;

  @Autowired
  private IForecastService forecastService;

  @InjectMocks
  private ForecastApprovedFusionInstructionTask forecastApprovedFusionInstrTask;

  @Produce(uri = "direct:findUndeliveredFusionApprovedInstructionEvents")
  private ProducerTemplate findUndeliveredFusionApprovedInstrEvents;

  @Produce(uri = "direct:createForecastInstruction")
  private ProducerTemplate createForecastInstr;

  @EndpointInject(uri = "mock:direct:createForecastInstruction")
  protected MockEndpoint mockCreateForecastInstr;

  /**
   * Setup the mocks and add the tested route to the camel context.
   * 
   * @throws Exception during the setup process
   */
  @Before
  public void setUp() throws Exception {

    MockitoAnnotations.initMocks(this);
    camelContext.addRoutes(forecastApprovedFusionInstrTask);
    camelContext.getRoute("ilim.route.forecastApprovedFusionInstructionPoller")
        .getEndpoint().stop();
  }

  @Test
  public void findUndeliveredFusionApprovedEvents() {
    fail("TODO");
  }

  @Test
  public void createForecastInstruction() {
    fail("TODO");
  }

  @Test
  public void forecastApprovedFusionInstructionTask() throws Exception {

    // setup data
    List<InstructionEvent> undelivered =
        TestData.InstructionEvents.listApproved;
    when(instructionEventService.findUndeliveredFusionApprovedEvents())
        .thenReturn(undelivered);
    when(forecastService.create(any(InstructionEvent.class)))
        .thenReturn(TestData.randId());

    mockCreateForecastInstr.expectedBodiesReceived(undelivered);

    // test
    findUndeliveredFusionApprovedInstrEvents.sendBody("Mock Poller");

    // verify
    mockCreateForecastInstr.expectedMessageCount(2);
    mockCreateForecastInstr.assertIsSatisfied();
  }

  /*
   * 
   * @Test
   * public void testRetrieveApprovedRoute() throws Exception {
   * 
   * // setup expected test data
   * List<InstructionEvent> undeliveredEvents =
   * TestData.testEvents(FUSION_APPROVED, false);
   * 
   * when(instructionEventService.findUndeliveredFusionApprovedEvents())
   * .thenReturn(undeliveredEvents);
   * 
   * ArrayList<List<?>> expectedListEvents = new ArrayList<>();
   * expectedListEvents.add(undeliveredEvents);
   * mockCreateForecastInstrEndpoint.expectedBodiesReceived(expectedListEvents);
   * 
   * // test
   * retrieveApprovedInstrsRoute.sendBody(null);
   * 
   * // verify
   * mockCreateForecastInstrEndpoint.expectedMessageCount(1);
   * mockCreateForecastInstrEndpoint.assertIsSatisfied();
   * }
   * 
   * @Test
   * public void testCreateForecastInstrRoute() throws Exception {
   * 
   * // setup expected test data
   * List<InstructionEvent> undeliveredEvents =
   * TestData.testEvents(FUSION_APPROVED, false);
   * 
   * List<Integer> expectedInstrIds = new ArrayList<Integer>();
   * for (InstructionEvent instructionEvent : undeliveredEvents) {
   * expectedInstrIds.add(instructionEvent.getEventId());
   * }
   * 
   * when(
   * forecastService.createInstrs(Mockito.anyListOf(InstructionEvent.class)))
   * .thenReturn(expectedInstrIds);
   * 
   * ArrayList<List<?>> expectedListOfIds = new ArrayList<>();
   * expectedListOfIds.add(expectedInstrIds);
   * mockOnSuccessEndpoint.expectedBodiesReceived(expectedListOfIds);
   * 
   * // test
   * createForecastInstrsRoute.sendBody(undeliveredEvents);
   * 
   * // verify
   * mockOnSuccessEndpoint.expectedMessageCount(1);
   * mockOnSuccessEndpoint.assertIsSatisfied();
   * }
   * 
   */

}
