package com.ilim.instruction.app.task;

import static com.ilim.instruction.domain.event.InstructionEventType.FUSION_APPROVED;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.ilim.instruction.app.TestData;
import com.ilim.instruction.domain.event.InstructionEvent;

import net.jcip.annotations.NotThreadSafe;

import org.apache.camel.CamelExecutionException;
import org.apache.camel.EndpointInject;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.spring.MockEndpoints;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;


@NotThreadSafe
@MockEndpoints()
public class ForecastApprovedFusionInstructionTaskTest
    extends AppTaskTestSupport {

  @Autowired
  private ForecastApprovedFusionInstructionTask forecastApprovedFusionInstrTask;

  @Produce(uri = "direct:findUndeliveredFusionApprovedEvents")
  private ProducerTemplate findUndeliveredFusionApprovedEvents;

  @EndpointInject(uri = "mock:direct:createForecastInstruction")
  protected MockEndpoint mockCreateForecastInstr;

  /**
   * Setup the mocks and add the tested route to the camel context.
   * 
   * @throws Exception during the setup process
   */
  @Before
  public void setUp() throws Exception {

    MockitoAnnotations.initMocks(this);
    camelContext.addRoutes(forecastApprovedFusionInstrTask);
    camelContext.getRoute("ilim.route.forecastApprovedFusionEventsPoller")
        .getEndpoint().stop();
  }

  public String forecastInstructionResource() {
    return mockWebServer.url("/mock/forecast/instructions/").toString();
  }

  @Test
  public void forecastApprovedFusionInstructionTask() throws Exception {

    // setup data
    List<Integer> updatedEventIds = new ArrayList<Integer>();
    List<InstructionEvent> undelivered =
        TestData.InstructionEvents.listApproved;

    for (InstructionEvent instructionEvent : undelivered) {
      updatedEventIds.add(instructionEvent.getEventId());
    }

    // set mocks
    when(instrEventDao.findUndeliveredByType(FUSION_APPROVED.id()))
        .thenReturn(undelivered);

    // add mock web server response for each event.
    for (int i = 0; i < undelivered.size(); i++) {
      addMockCreateResponse(201,
          forecastInstructionResource() + TestData.randId());
    }

    mockCreateForecastInstr.expectedBodiesReceived(undelivered);

    // test
    findUndeliveredFusionApprovedEvents.sendBody("Mock Poller");

    // verify
    mockCreateForecastInstr.expectedMessageCount(2);
    mockCreateForecastInstr.assertIsSatisfied();

    // verify that the update was at least called correctly as expected
    ArgumentCaptor<Integer> argument = ArgumentCaptor.forClass(Integer.class);
    verify(instrEventDao, times(2)).updateToDelivered(argument.capture());
    assertThat(argument.getAllValues().size()).isGreaterThan(0);
    assertThat(argument.getAllValues()).containsOnlyElementsOf(updatedEventIds);
  }

  @Test
  public void whenNoUndeliveredApprovedEventsFound() throws Exception {

    // setup data
    List<InstructionEvent> undelivered = new ArrayList<InstructionEvent>();

    // set mocks
    when(instrEventDao.findUndeliveredByType(FUSION_APPROVED.id()))
        .thenReturn(undelivered);

    mockCreateForecastInstr.expectedBodiesReceived(undelivered);

    // test
    findUndeliveredFusionApprovedEvents.sendBody("Mock Poller");

    // verify
    mockCreateForecastInstr.expectedMessageCount(0);
    mockCreateForecastInstr.assertIsSatisfied();

    // verify that the update was not called
    verify(instrEventDao, times(0)).updateToDelivered(Mockito.anyInt());
  }

  @Test(expected = CamelExecutionException.class)
  public void forecastServiceError() throws Exception {

    // setup data
    List<InstructionEvent> undelivered =
        TestData.InstructionEvents.listApproved;

    // set mocks
    when(instrEventDao.findUndeliveredByType(FUSION_APPROVED.id()))
        .thenReturn(undelivered);

    // add mock web server response for each event.
    for (int i = 0; i < undelivered.size(); i++) {
      addMockCreateResponse(500,
          forecastInstructionResource() + TestData.randId());
    }

    // test
    findUndeliveredFusionApprovedEvents.sendBody("Mock Poller");
  }
}
