package com.ilim.example.web.client;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.example.web.api.CrdAuth;
import com.ilim.example.web.api.CrdCashForecast;
import com.ilim.example.web.api.CrdMessagingApi;
import com.ilim.example.web.api.CrdMessagingEnvelope;

import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.logging.HttpLoggingInterceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit.Retrofit;
import retrofit.SimpleXmlConverterFactory;

import java.io.IOException;

/**
 * Example sdk for a soap service. 
 * 
 * <p>Using:
 * (1) squares retrofit http client adapter.
 * @see <a href="http://square.github.io/retrofit/"></a>
 * (2) squares okttp as a http client. 
 * @see <a href="http://square.github.io/okhttp/"></a>   
 * (3) simplexml to build the soap envelope, body and serialize the xml. 
 * @see <a href="http://simple.sourceforge.net"></a>  
 * 
 * @author alan larkin
 */
public class CrdMessagingClient {

  private static final Logger log =
      LoggerFactory.getLogger(CrdMessagingClient.class);

  private final Retrofit retrofitAdapter;
  private final CrdMessagingApi api;

  /** Create client using default url. */
  public CrdMessagingClient() {

    this(settings().getString("crd.messaging.service.baseurl"));
  }

  /** Configures client using CrdMessagingApi. */
  public CrdMessagingClient(String baseUrl) {

    log.debug("Creating CrdMessagingClient for " + baseUrl);
    
    // create http client with logging
    OkHttpClient client = new OkHttpClient();
    HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
    interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
    client.interceptors().add(interceptor);

    // Create retrofit adapter with xml converter
    this.retrofitAdapter =
        new Retrofit.Builder().baseUrl(baseUrl).client(client)
            .addConverterFactory(SimpleXmlConverterFactory.create()).build();

    // Generate crd messaging api
    this.api = retrofitAdapter.create(CrdMessagingApi.class);
  }


  /** Sends cash forecast message to CRD BBCW.
   *
   * @param cashForecast bbcw data
   * @return true on success
   */
  public boolean sendToBbcw(CrdCashForecast cashForecast) {

    log.info("sendToBbcw " + cashForecast);

    CrdMessagingEnvelope soapEnvelope = new CrdMessagingEnvelope()
        .withAuthToken(CrdAuth.newAuthToken()).withCashForecast(cashForecast);

    boolean isSuccess = false;
    try {

      isSuccess = api.sendMessage(soapEnvelope).execute().isSuccess();

    } catch (IOException ex) {

      log.error("sendToBbcw network error! " + ex.getMessage());
    }
    return isSuccess;
  }

}
