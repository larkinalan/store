package com.ilim.example.web.api;

import static com.ilim.commons.conf.AppConfig.settings;

import com.google.common.base.MoreObjects;

import org.simpleframework.xml.Element;

public class CrdAuth {

  @Element
  public final String user;
  @Element
  public final String password;
  @Element
  public final String session;

  /** CRD Messaging authorization token. */
  public CrdAuth(String user, String password, String session) {

    this.user = user;
    this.password = password;
    this.session = session;
  }

  /** Factory method that uses env props to create token. */
  public static CrdAuth newAuthToken() {

    String user = settings().getString("crd.messaging.auth.user");
    String pass = settings().getString("crd.messaging.auth.pass");
    String session = settings().getString("crd.messaging.auth.session");

    return new CrdAuth(user, pass, session);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("user", user)
        .add("session", session).toString();
  }

}
