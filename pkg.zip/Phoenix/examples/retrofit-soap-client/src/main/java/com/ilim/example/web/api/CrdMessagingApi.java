package com.ilim.example.web.api;

import retrofit.Call;
import retrofit.http.Body;
import retrofit.http.Headers;
import retrofit.http.POST;

public interface CrdMessagingApi {

  @Headers({"Content-Type: application/soap+xml", "Accept-Charset: utf-8"})
  @POST("CRDMessagingService")
  Call<Void> sendMessage(@Body CrdMessagingEnvelope soapEnvelope);

}
