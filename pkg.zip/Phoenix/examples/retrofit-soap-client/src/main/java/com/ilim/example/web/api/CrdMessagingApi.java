package com.ilim.example.web.api;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface CrdMessagingApi {

  @Headers({"Content-Type: application/soap+xml", "Accept-Charset: utf-8"})
  @POST("CRDMessagingService")
  Call<Void> sendMessage(@Body CrdMessagingEnvelope soapEnvelope);

}
