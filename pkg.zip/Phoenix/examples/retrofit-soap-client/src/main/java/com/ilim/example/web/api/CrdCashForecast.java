package com.ilim.example.web.api;

import com.google.common.base.MoreObjects;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;

import java.math.BigDecimal;

/*
 * CRD create forecast Message for insert into BBCW.
 */
public class CrdCashForecast {

  @Attribute
  private final String op; // create, update, insert
  @Element(required = false)
  public final Integer id;
  @Element
  public final String acctCd;
  @Element
  public final String amtType;
  @Element
  public final String crrncyCd;
  @Element
  public final BigDecimal amt;
  @Element
  public final String forecastDate;
  @Element
  public final String descr;

  /** CRD Cash forecast message with order id for update/delete operation. */
  public CrdCashForecast(String op, Integer id, String acctCd, String amtType,
      String crrncyCd, BigDecimal amt, String forecastDate, String descr) {

    this.op = op;
    this.id = id;
    this.acctCd = acctCd;
    this.amtType = amtType;
    this.crrncyCd = crrncyCd;
    this.amt = amt;
    this.forecastDate = forecastDate;
    this.descr = descr;
  }

  /** CRD Cash forecast message for create operation. */
  public CrdCashForecast(String acctCd, String amtType, String crrncyCd,
      BigDecimal amt, String forecastDate, String descr) {

    this("create", null, acctCd, amtType, crrncyCd, amt, forecastDate, descr);
  }
  
  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("op", op).add("id", id)
        .add("acctCd", acctCd).add("amtType", amtType).add("crrncyCd", crrncyCd)
        .add("amt", amt).add("forecastDate", forecastDate).toString();
  }

}
