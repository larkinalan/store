Example Jersey Clent 
======================
*The Java client SDK for soap service.*
*This uses Retrofit and simplexml to builder the sdk from an interface*

build
-----
   
`mvn clean install`

*requires* 
* [Java8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)   
* [Maven3](https://maven.apache.org/)

deploy
------

`mvn clean deploy`

libs
----

`mvn dependency:tree`

* [retrofit](http://square.github.io/retrofit/) http client binder.
* [simplexml](http://simple.sourceforge.net/) for xml data mapping.

