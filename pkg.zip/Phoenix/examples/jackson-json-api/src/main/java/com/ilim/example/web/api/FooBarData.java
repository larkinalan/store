package com.ilim.example.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * FooBar DataType.
 * 
 * @author Alan Larkin
 */
public class FooBarData {

  public final String foo;
  public final String bar;

  /** Creates FooBar type. */
  @JsonCreator
  public FooBarData(@JsonProperty("foo") String foo,
      @JsonProperty("bar") String bar) {

    this.foo = foo;
    this.bar = bar;
  }
}
