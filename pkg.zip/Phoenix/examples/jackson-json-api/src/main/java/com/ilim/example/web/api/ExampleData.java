package com.ilim.example.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Example DataType.
 * 
 * <p>Prefer C struct style over Java bean Style.
 * <b>Must remain immutable</b> .
 * 
 * @author Alan Larkin
 *
 */
public class ExampleData {

  @JsonProperty
  public final int id;
  @JsonProperty
  public final String name;
  @JsonProperty
  public final BigDecimal number;
  @JsonProperty
  public final String date;
  @JsonProperty
  public final ImmutableList<String> list;
  @JsonProperty
  public final ImmutableMap<Integer, String> map;

  /**
   * Should only requires one constructor.
   * Create another DataType instead of adding multiple constructors. 
   */
  @JsonCreator
  public ExampleData(@JsonProperty("id") int id,
      @JsonProperty("name") String name,
      @JsonProperty("number") BigDecimal number,
      @JsonProperty("date") String date,
      @JsonProperty("list") List<String> list,
      @JsonProperty("map") Map<Integer, String> map) {

    this.id = id;
    this.name = name;
    this.number = number;
    this.date = date;
    this.list = ImmutableList.copyOf(list);
    this.map = ImmutableMap.copyOf(map);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("id", id).add("name", name)
        .add("number", number).add("date", date).toString();
  }

}
