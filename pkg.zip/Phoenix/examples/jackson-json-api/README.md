Example Jersey Api 
======================
*The api contains the data transfer objects (which are different than our domain objects)
That are shared between the service and client *

build
-----
   
`mvn clean install`

*requires* 
* [Java8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)   
* [Maven3](https://maven.apache.org/)

deploy
------

`mvn clean deploy`

libs
----

`mvn dependency:tree`

* [Jackson](http://wiki.fasterxml.com/JacksonHome) for Json data mapping.
* [Errorprone](http://errorprone.info/) to detect common bugs at compile time.

docs
----
* [Architecture](L:\ITUNIT\PROJECTS\Strategy\FMA_Phoenix\System Architecture\phoenix-architecture.docx)  
* [confluence](http://ilm12807:7090/).
