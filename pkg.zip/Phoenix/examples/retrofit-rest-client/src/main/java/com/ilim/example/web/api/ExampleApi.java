package com.ilim.example.web.api;

import com.ilim.example.web.api.ExampleData;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

import java.util.List;

public interface ExampleApi {

  @GET("examples/")
  Call<List<ExampleData>> findAll();

  @GET("examples/greet")
  Call<String> greet(@Query("firstName") String firstName);

}
