package com.ilim.example.web.client;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.example.web.api.ExampleApi;

import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.logging.HttpLoggingInterceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit.JacksonConverterFactory;
import retrofit.Retrofit;

/**
 * ExampleClient sdk for restful example-service. 
 * 
 * <p>Uses squares
 * (1) retrofit http client adapter.
 * @see <a href="http://square.github.io/retrofit/"></a>
 * (2) okttp as a http client. 
 * @see <a href="http://square.github.io/okhttp/"></a>   
 * 
 * @author alan larkin
 */
public class ExampleClient {
  
  private static final Logger log =
      LoggerFactory.getLogger(ExampleClient.class);

  private final Retrofit retrofitAdapter;
  private final ExampleApi exampleApi;

  /** Default constructor (uses conf file). */
  public ExampleClient() {

    this(settings().getString("crd.messaging.service.baseurl"));
  }

  /** Configures client using ExampleApi. */
  public ExampleClient(String baseUrl) {
    
    log.debug("Creating ExampleClient for " + baseUrl);
    
    // create http client with logging
    OkHttpClient client = new OkHttpClient();
    HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
    interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
    client.interceptors().add(interceptor);

    // Create retrofit adapter with jackson converter
    this.retrofitAdapter =
        new Retrofit.Builder().baseUrl(baseUrl).client(client)
            .addConverterFactory(JacksonConverterFactory.create()).build();

    // Generate example api
    exampleApi = retrofitAdapter.create(ExampleApi.class);
  }

  /**  ExampleApi @see#com.ilim.web.api.ExampleApi. */
  public ExampleApi api() {

    return exampleApi;
  }

}
