package com.ilim.example.web.client;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.web.client.RetrofitClient;
import com.ilim.example.web.api.ExampleApi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit2.JacksonConverterFactory;

/**
 * ExampleClient sdk for restful example-service. 
 * 
 * @author alan larkin
 */
public class ExampleClient {

  private static final Logger log =
      LoggerFactory.getLogger(ExampleClient.class);

  private final RetrofitClient retrofitClient;
  private final ExampleApi exampleApi;

  /** Default constructor (uses conf file). */
  public ExampleClient() {

    this(settings().getString("example.service.baseurl"));
  }

  /** Configures client using ExampleApi. */
  public ExampleClient(String baseUrl) {

    // Create retrofit http client with jackson converter
    retrofitClient = RetrofitClient.newBuilder(baseUrl).witLogger(log)
        .withConverter(JacksonConverterFactory.create()).build();

    // Generate example api
    exampleApi = retrofitClient.adapter().create(ExampleApi.class);
  }

  /**  RetrofitClient Adapter. */
  public RetrofitClient adapter() {

    return retrofitClient;
  }

  /**  ExampleApi @see#com.ilim.web.api.ExampleApi. */
  public ExampleApi api() {

    return exampleApi;
  }

}
