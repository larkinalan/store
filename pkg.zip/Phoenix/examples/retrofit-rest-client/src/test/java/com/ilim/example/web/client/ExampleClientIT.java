package com.ilim.example.web.client;

import static org.junit.Assert.assertEquals;

import com.ilim.example.web.api.ExampleData;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.util.List;

public class ExampleClientIT {
  
  private ExampleClient client;
  
  /** Create client against mock web server. */
  @Before
  public void setUp() throws Exception {
    
    client = new ExampleClient();
  }

  @Test
  public void findAll() throws Exception {
    
    List<ExampleData> response = client.api().findAll().execute().body();
    assertEquals(1, response.size());
    response.forEach(System.out::println);
  }

  @Test
  @Ignore
  public void greet() throws Exception {
    
    String response = client.api().greet("Rowan").execute().body();
    assertEquals("hello, Rowan!", response);
  }

}
