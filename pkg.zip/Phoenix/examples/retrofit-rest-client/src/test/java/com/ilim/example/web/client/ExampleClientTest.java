package com.ilim.example.web.client;

import static org.junit.Assert.assertEquals;

import com.ilim.commons.web.api.ErrorData;
import com.ilim.commons.web.client.AppClientException;
import com.ilim.example.web.api.ExampleData;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.HttpUrl;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import retrofit2.Response;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExampleClientTest {

  private MockWebServer server;
  private ExampleClient client;
  private HttpUrl baseUrl;

  private static final ObjectMapper jsonMapper = new ObjectMapper();

  /** Create client against mock web server. */
  @Before
  public void setUp() throws Exception {

    server = new MockWebServer();
    server.start();
    baseUrl = server.url("/mock/");
    client = new ExampleClient(baseUrl.toString());
  }

  @After
  public void tearDown() throws Exception {

    server.shutdown();
  }

  @Test
  public void findAll() throws Exception {

    List<ExampleData> data = listOfExampleData();
    server.enqueue(mockJsonResponse(data));

    List<ExampleData> response = client.api().findAll().execute().body();
    assertEquals(1, response.size());
    response.forEach(System.out::println);
  }

  @Test(expected = AppClientException.class)
  public void failFindAll() throws Exception {

    MockResponse mockResponse = mockJsonResponse(ErrorData
        .newErrorData("failure", new IllegalArgumentException("oh oh!")));
    mockResponse.setResponseCode(500);
    server.enqueue(mockResponse);

    final List<ExampleData> data;
    try {

      Response<List<ExampleData>> response = client.api().findAll().execute();
      if (response.isSuccess()) {
        data = response.body();
      } else {
        throw new AppClientException(client.adapter().toErrorData(response));
      }
    } catch (IOException ex) {
      throw new AppClientException(ex);
    }

    data.forEach(System.out::println);
    Assert.fail("Should have throw an error!");
  }

  @Test
  @Ignore
  public void greet() throws Exception {

    server.enqueue((new MockResponse()).setBody("hello, Rowan!"));

    String response = client.api().greet("Rowan").execute().body();
    assertEquals("hello, Rowan!", response);
  }

  private List<ExampleData> listOfExampleData() {

    List<ExampleData> data = new ArrayList<>();
    data.add(new ExampleData(1, "foo", new BigDecimal("1.514"), "21/12/2015",
        new ArrayList<String>(), new HashMap<Integer, String>()));
    return data;
  }

  private MockResponse mockJsonResponse(Object data)
      throws JsonProcessingException {

    return new MockResponse()
        .addHeader("Content-Type", "application/json; charset=utf-8")
        .addHeader("Cache-Control", "no-cache")
        .setBody(jsonMapper.writeValueAsString(data));
  }

}
