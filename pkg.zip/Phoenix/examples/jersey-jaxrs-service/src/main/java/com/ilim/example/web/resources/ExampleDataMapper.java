package com.ilim.example.web.resources;

import com.ilim.commons.time.DateUtils;
import com.ilim.example.domain.model.ExampleEntity;
import com.ilim.example.web.api.ExampleData;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Error DataType Mapper.
 * 
 * @author Alan Larkin
 */
public final class ExampleDataMapper {

  private ExampleDataMapper() {}

  /** Returns ExampleData. */
  public static ExampleData toExampleData(final ExampleEntity entity) {

    String date = entity.getDate().format(DateUtils.DATE_FMT);
    return new ExampleData(entity.getId(), entity.getName(),
        entity.getNumber(), date, entity.getList(),
        entity.getMap());
  }

  /** Returns List of ExampleData. */
  public static List<ExampleData> toExampleDataList(
      final List<ExampleEntity> entityList) {

    final List<ExampleData> dataList = new ArrayList<>();
    for (ExampleEntity entity : entityList) {
      dataList.add(toExampleData(entity));
    }
    return dataList;
  }

  /** Returns ExampleEntity. */
  public static ExampleEntity toExampleEntity(final ExampleData data) {

    LocalDate date = LocalDate.parse(data.date, DateUtils.DATE_FMT);
    return new ExampleEntity(data.id, data.name, data.number, date,
        data.list, data.map);
  }

  /** Returns List of ExampleEntity. */
  public static List<ExampleEntity> toExampleEntityList(
      final List<ExampleData> dataList) {

    final List<ExampleEntity> entityList = new ArrayList<>();
    for (ExampleData data : dataList) {
      entityList.add(toExampleEntity(data));
    }
    return entityList;
  }
}
