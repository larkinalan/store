package com.ilim.example.domain.model;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Example Entity.
 * 
 * <p>Immutable so No setters.
 * Create use a constructor or Builder if it gets complex.
 *
 * @author Alan Larkin
 */
public class ExampleEntity {

  private final int id;
  private final String name;
  private final BigDecimal number;
  private final LocalDate date;
  private final List<String> list;
  private final Map<Integer, String> map;

  /**
   * Create use a constructor.
   * 
   * <p>Consider a builder when faced with many constructor parameters,
   * to avoid telescoping.
   * 
   */
  public ExampleEntity(int id, String name, BigDecimal number, LocalDate date,
      List<String> list, Map<Integer, String> map) {

    this.id = id;
    this.name = name;
    this.number = number;
    this.date = date;
    this.list = new ArrayList<String>(list);
    this.map = new HashMap<Integer, String>(map);
  }

  public int getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public BigDecimal getNumber() {
    return number;
  }

  public LocalDate getDate() {
    return date;
  }

  public List<String> getList() {
    return new ArrayList<String>(list);
  }

  public Map<Integer, String> getMap() {
    return new HashMap<Integer, String>(map);
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }

    final ExampleEntity other = (ExampleEntity) obj;
    return Objects.equals(this.getId(), other.getId());
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(this.getId());
  }

  public String toString() {
    return MoreObjects.toStringHelper(this).add("id", id).toString();
  }

}
