package com.ilim.example.app.conf;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.example.app.service.ExampleService;
import com.ilim.example.app.service.IExampleExternalService;
import com.ilim.example.app.service.IExampleService;
import com.ilim.example.domain.IExampleRepository;
import com.ilim.example.infra.db.jdbc.JdbcExampleDao;
import com.ilim.example.infra.pricing.ExampleExternalService;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.jta.JtaTransactionManager;

import javax.sql.DataSource;

/**
 * Spring component config.
 *
 * @author Alan Larkin
 */
@Configuration
@EnableTransactionManagement()
public class SpringConfig {

  /** The jndi Datasource. */
  @Bean
  public DataSource dataSource() {

    final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
    dsLookup.setResourceRef(true);
    DataSource dataSource =
        dsLookup.getDataSource(settings().getString("jndi.datasource.fm"));
    return dataSource;
  }

  /** The JtaTransactionManager. */
  @Bean
  public PlatformTransactionManager transactionManager() {

    JtaTransactionManager txnMgr = new JtaTransactionManager();
    txnMgr.setTransactionManagerName(settings().getString("jndi.txnmanager"));
    return txnMgr;
  }
  
  /** ExampleService Bean. */
  @Bean
  public IExampleService exampleService() {
    return new ExampleService();
  }
  
  /** JdbcExampleDao bean. */
  @Bean
  public IExampleRepository exampleRepository() {
    return new JdbcExampleDao(dataSource());
  }
  
  /** ExampleExternalService bean. */
  @Bean
  public IExampleExternalService exampleExternalService() {
    return new ExampleExternalService();
  }
  

}
