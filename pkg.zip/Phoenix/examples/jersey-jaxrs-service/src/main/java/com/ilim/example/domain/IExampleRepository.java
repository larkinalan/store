package com.ilim.example.domain;

import com.ilim.example.domain.model.ExampleEntity;

import java.util.List;

/**
 * Example Repository.
 * 
 * <p>usually implmented in jdbc or jpa package
 *
 * @author Alan Larkin
 */
public interface IExampleRepository {

  String greet(String who);

  List<ExampleEntity> findExampleList();
}

