package com.ilim.example.infra.pricing;

import com.ilim.example.app.service.IExampleExternalService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * Mock Pricing external service.
 * 
 * @author Alan Larkin
 */
@Service
public class ExampleExternalService implements IExampleExternalService {
  
  private static final Logger log =
      LoggerFactory.getLogger(ExampleExternalService.class);

  @Override
  public BigDecimal getPrice(int ilimId) {
    
    log.info("find price for " + ilimId);
    
    // fake lookup to external service.
    // in reality we would delegate to a rest or soap client here.
    return BigDecimal.ONE;
  }

}
