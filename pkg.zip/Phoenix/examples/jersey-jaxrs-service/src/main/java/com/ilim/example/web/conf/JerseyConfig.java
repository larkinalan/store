package com.ilim.example.web.conf;

import com.ilim.example.web.filter.CorsResponseFilter;
import com.ilim.example.web.filter.LoggingResponseFilter;
import com.ilim.example.web.resources.AppExceptionMapper.AppConfigExceptionMapper;
import com.ilim.example.web.resources.AppExceptionMapper.AppDataExceptionMapper;
import com.ilim.example.web.resources.AppExceptionMapper.IllegalArgumentExceptionMapper;
import com.ilim.example.web.resources.AppExceptionMapper.IllegalStateExceptionMapper;
import com.ilim.example.web.resources.AppExceptionMapper.WebApplicationExceptionMapper;
import com.ilim.example.web.resources.ExampleResource;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.jersey2.InstrumentedResourceMethodApplicationListener;

import org.glassfish.jersey.filter.LoggingFilter;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.spring.scope.RequestContextFilter;
import org.springframework.stereotype.Component;

/**
 * Jersey resource config.
 *
 * @author alan Larkin
 */
@Component
public class JerseyConfig extends ResourceConfig {

  private final MetricRegistry metrics = new MetricRegistry();

  /** Register JAX-RS application components. */
  public JerseyConfig() {

    // resources
    register(ExampleResource.class);

    // filters
    register(RequestContextFilter.class); // jersey spring
    register(CorsResponseFilter.class); // cross origin
    register(LoggingFilter.class); // default logging
    register(LoggingResponseFilter.class); // custom logging

    // exceptions
    register(AppConfigExceptionMapper.class);
    register(AppDataExceptionMapper.class);
    register(IllegalArgumentExceptionMapper.class);
    register(IllegalStateExceptionMapper.class);
    register(WebApplicationExceptionMapper.class); 
    
    // Jackson
    register(JacksonFeature.class);
    
    // metrics
    register(new InstrumentedResourceMethodApplicationListener(metrics));
  }

  public MetricRegistry metrics() {
    return metrics;
  }

}
