package com.ilim.example.app.service;

import static com.google.common.base.Preconditions.checkArgument;

import com.ilim.example.domain.IExampleRepository;
import com.ilim.example.domain.model.ExampleEntity;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

import javax.inject.Inject;

/**
 * Example spring service.
 * 
 * <p>Transactions should be handled here!
 *
 * @author Alan Larkin
 */
@Service
public class ExampleService implements IExampleService {

  @Transactional
  @Override
  public String greet(String who) {

    checkArgument(who != null, "Param required!");

    return exampleDao.greet(who);
  }
  
  @Transactional
  @Override
  public List<ExampleEntity> findAll() {

    return exampleDao.findExampleList();
  }

  @Transactional
  @Override
  public BigDecimal findPrice(int ilimId) {

    checkArgument(ilimId > 0, "ilimId is invalid!");

    return externalService.getPrice(ilimId);
  }

  @Inject
  private IExampleRepository exampleDao;

  @Inject
  private IExampleExternalService externalService;
}
