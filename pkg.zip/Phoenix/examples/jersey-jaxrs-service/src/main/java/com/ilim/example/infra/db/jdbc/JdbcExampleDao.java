package com.ilim.example.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.example.domain.IExampleRepository;
import com.ilim.example.domain.model.ExampleEntity;

import com.codahale.metrics.annotation.Timed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;

/**
 * Example Jdbc DAO (Data Access Object).
 * 
 * <p>Simple jdbc wrapper.
 *
 * @author Alan Larkin
 */
@Repository
public class JdbcExampleDao extends NamedParameterJdbcDaoSupport
    implements IExampleRepository {

  private static final Logger log =
      LoggerFactory.getLogger(JdbcExampleDao.class);

  /** Initialize Dao with sql dataSource. */
  @Inject
  public JdbcExampleDao(DataSource dataSource) {

    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  /**
   * Returns a greeting.
   * 
   * @param who person to greet
   * @return String greeting
   * @throws AppSqlException
   * 
   */
  @Timed
  @Override
  public String greet(String who) {

    log.info("greet ({})", who);

    // Toad formatted so turning @formatter:off and CHECKSTYLE:OFF
    final String sql = "select 'hello, " + who + "!' from dual";
    // @formatter:on and CHECKSTYLE:ON
    
    final String result;

    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql,
          new MapSqlParameterSource(), (rs, rowNum) -> {
            return rs.getString(1);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in query greet " + who, ex);
    }

    return result;
  }

  /**
   * Returns a list of example entities.
   * 
   * @return {@code List<ExampleEntity>}
   * 
   */
  @Timed
  @Override
  public List<ExampleEntity> findExampleList() {

    log.info("findExampleList()");

    // Prefer returning and empty list over a null one.
    final List<ExampleEntity> result = new ArrayList<>();

    try {
      
      result.add(
          new ExampleEntity(1, "foo", new BigDecimal("1.514"), LocalDate.now(),
              new ArrayList<String>(), new HashMap<Integer, String>()));
      
    } catch (Exception ex) {
      throw new AppSqlException("Error in query example list ", ex);
    }

    return result;
  }

}
