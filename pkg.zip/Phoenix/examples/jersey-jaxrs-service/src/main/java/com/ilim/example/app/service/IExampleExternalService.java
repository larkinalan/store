package com.ilim.example.app.service;

import java.math.BigDecimal;

public interface IExampleExternalService {

  BigDecimal getPrice(int ilimId);

}

