package com.ilim.example.web.filter;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;

/**
 * Logging filter.
 * 
 * @author Alan Larkin
 */
@Provider
public class LoggingResponseFilter implements ContainerResponseFilter {

  private static final Logger logger =
      LoggerFactory.getLogger(LoggingResponseFilter.class);

  /** 
   * Add request logs.
   * {@link javax.ws.rs.container.ContainerResponseFilter#filter}
   */
  public void filter(ContainerRequestContext requestContext,
      ContainerResponseContext responseContext) throws IOException {

    logger.debug(requestContext.getMethod() + " "
        + requestContext.getUriInfo().getPath());

    Object entity = responseContext.getEntity();
    if (entity != null) {
      logger.debug("Response :\n" + new ObjectMapper()
          .writerWithDefaultPrettyPrinter().writeValueAsString(entity));
    }

  }
}
