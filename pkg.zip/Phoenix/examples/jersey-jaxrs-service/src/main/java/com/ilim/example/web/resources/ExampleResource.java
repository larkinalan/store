package com.ilim.example.web.resources;

import static com.ilim.example.web.resources.ExampleDataMapper.toExampleDataList;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import com.ilim.example.app.service.IExampleService;
import com.ilim.example.web.api.ExampleData;
import com.ilim.example.web.api.FooBarData;

import com.codahale.metrics.annotation.Timed;
import com.google.common.base.Strings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

/**
 * Example Jersey JAX-RS service with spring integration. 
 * 
 * <p>This rest controller is a singleton spring bean, 
 * with autowired dependencies from spring.
 *
 * @author Alan Larkin
 */
@Singleton
@Service
@Path("examples")
@Produces({APPLICATION_JSON})
public class ExampleResource {

  private static final Logger log =
      LoggerFactory.getLogger(ExampleResource.class);

  /** Returns List of ExampleData. */
  @GET
  @Timed
  public List<ExampleData> findAll() {

    final List<ExampleData> data = toExampleDataList(exampleService.findAll());
    log.info("found " + data.size() + " examples");

    return data; // Response.ok(data).build();
  }

  /** Returns greeting. */
  @GET
  @Path("/greet")
  @Timed
  public String greet(@QueryParam("firstName") String firstName,
      @DefaultValue("") @QueryParam("lastName") String lastName) {
    
    if (Strings.isNullOrEmpty(lastName)) {
      return exampleService.greet(firstName);
    } else {
      return exampleService.greet(firstName + ' ' + lastName);
    }
  }

  /** Returns FooBarData. */
  @GET
  @Path("/foobar")
  @Timed
  public Response foobar() {

    // return new FooBarData("foo", "bar");
    return Response.ok(new FooBarData("foo", "bar")).build();
  }

  @Inject
  private IExampleService exampleService;
}
