package com.ilim.example.app.service;

import com.ilim.example.domain.model.ExampleEntity;

import java.math.BigDecimal;
import java.util.List;

public interface IExampleService {

  String greet(String who);
  
  List<ExampleEntity> findAll();
  
  BigDecimal findPrice(int ilimId);

}

