
package com.ilim.example.web.resources;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;

/**
 * Object Mappers that convert to Json.
 * 
 * <p>Only need this if you want to do some custom mapping.
 *
 * @author Alan Larkin
 */
@Provider
public class AppObjectMapper implements ContextResolver<ObjectMapper> {


  final ObjectMapper defaultObjectMapper;

  /** 
   * Jacksons Json Object Serialization mapper.. 
   */
  public AppObjectMapper() {
    defaultObjectMapper = createDefaultMapper();
  }

  @Override
  public ObjectMapper getContext(Class<?> type) {
    return defaultObjectMapper;
  }

  private static ObjectMapper createDefaultMapper() {
    final ObjectMapper result = new ObjectMapper();
    result.enable(SerializationFeature.INDENT_OUTPUT);

    return result;
  }

}
