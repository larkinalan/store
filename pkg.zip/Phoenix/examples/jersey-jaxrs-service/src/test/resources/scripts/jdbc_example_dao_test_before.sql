-- SQL to execute before the test(s) run. Insert, Update, Delete data etc.
-- This script is called from JdbcExampleDaoTest.java
select * from fund_type;