package com.ilim.example.app.conf;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.logging.TestLogger;
import com.ilim.example.app.service.ExampleService;
import com.ilim.example.app.service.IExampleExternalService;
import com.ilim.example.app.service.IExampleService;
import com.ilim.example.domain.IExampleRepository;
import com.ilim.example.infra.db.jdbc.JdbcExampleDao;
import com.ilim.example.infra.pricing.ExampleExternalService;

import org.junit.rules.TestRule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.sql.SQLException;

import javax.sql.DataSource;

/**
 * Spring component test config.
 *
 * @author Alan Larkin
 */
@Configuration
@EnableTransactionManagement()
public class SpringTestConfig {

  private static final Logger log =
      LoggerFactory.getLogger(SpringTestConfig.class);

  /** Returns TestLogger. */
  @Bean
  public TestRule testLogger() {
    return new TestLogger();
  }

  /** Returns the jdbc Datasource. */
  @Bean
  public DataSource dataSource() {

    final DataSource dataSource;
    final String db = settings().getString("database");

    // Get connection
    if (db.equalsIgnoreCase("fm")) {
      dataSource = oracleConnection(new DriverManagerDataSource());
    } else {
      dataSource = h2Connection(new DriverManagerDataSource());
    }

    // Test connection
    try {
      log.info("Set database connection to "
          + dataSource.getConnection().getMetaData().getURL());
    } catch (SQLException ex) {
      throw new AppSqlException("Failed to connect to database " + db, ex);
    }
    return dataSource;
  }

  /** Returns the spring DataSourceTransactionManager. */
  @Bean
  public PlatformTransactionManager transactionManager() {
    return new DataSourceTransactionManager(dataSource());
  }
  
  /** ExampleService bean. */
  @Bean
  public IExampleService exampleService() {
    return new ExampleService();
  }
  
  /** JdbcExampleDao bean. */
  @Bean
  public IExampleRepository exampleRepository() {
    return new JdbcExampleDao(dataSource());
  }
  
  /** ExampleExternalService bean. */
  @Bean
  public IExampleExternalService exampleExternalService() {
    return new ExampleExternalService();
  }
  
  private DataSource oracleConnection(DriverManagerDataSource dataSource) {

    dataSource
        .setDriverClassName(settings().getString("db.jdbc.oracle.driver"));
    dataSource.setUrl(settings().getString("db.fm.url"));
    dataSource.setUsername(settings().getString("db.fm.user"));
    dataSource.setPassword(settings().getString("db.fm.pass"));

    return dataSource;
  }

  private DataSource h2Connection(DriverManagerDataSource dataSource) {

    dataSource.setDriverClassName(settings().getString("db.jdbc.h2.driver"));
    dataSource.setUrl(settings().getString("db.local.url"));
    dataSource.setUsername(settings().getString("db.local.user"));
    dataSource.setPassword(settings().getString("db.local.pass"));

    return dataSource;
  }

}
