package com.ilim.example.web.resources;

import static com.codahale.metrics.MetricRegistry.name;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import com.ilim.example.web.api.ExampleData;
import com.ilim.example.web.api.FooBarData;

import com.codahale.metrics.Timer;

import org.junit.Test;

import java.util.List;

import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

/**
 * Testing our web service. 
 *
 * @author Alan Larkin
 */
public class ExampleResourceTest extends JerseySpringTestSupport {

  @Test
  public void greet() throws Exception {
    
    // junit style
    final String greeting = target("examples/greet")
        .queryParam("firstName", "Rowan").request().get(String.class);
    assertEquals("hello, Rowan!", greeting);

    // hamcrest style
    assertThat(target("examples/greet").queryParam("firstName", "Alan")
        .request().get(String.class), equalTo(("hello, Alan!")));
  }

  @Test
  public void greetFullName() throws Exception {

    final String greeting =
        target("examples/greet").queryParam("firstName", "Rowan")
            .queryParam("lastName", "Larkin").request().get(String.class);
    assertEquals("hello, Rowan Larkin!", greeting);
  }

  @Test()
  public void greetNobody() throws Exception {

    Response resp = target("examples").path("greet").request().get();
    assertThat(resp.getStatus(), equalTo(Status.BAD_REQUEST.getStatusCode()));
  }

  @Test
  public void greetRequestIsTimed() throws Exception {

    assertThat(target("examples").path("greet").queryParam("firstName", "there")
        .request().get(String.class), equalTo(("hello, there!")));

    final Timer timer =  metrics().timer(name(ExampleResource.class, "greet"));
    assertEquals(1, timer.getCount());
  }

  @Test()
  public void findExamples() throws Exception {

    // Use GenericType to convert list
    final List<ExampleData> response =
        target("examples").request(MediaType.APPLICATION_JSON)
            .get(new GenericType<List<ExampleData>>() {});
    assertEquals(1, response.size());

    // TODO: add .equals to entities
    // ExampleEntity expected = new ExampleEntity("foo", 1,
    // new ArrayList<String>(), new HashMap<Integer, String>());
    // assertThat(response, contains(expected));
  }

  @Test()
  public void foobar() throws Exception {
    
    // Get the repsonse
    Response resp = target("examples").path("foobar")
        .request(MediaType.APPLICATION_JSON).get();
    assertThat(resp.getStatus(), equalTo(Status.OK.getStatusCode()));

    // or get the data directly
    FooBarData data = target("examples").path("foobar")
        .request(MediaType.APPLICATION_JSON).get(FooBarData.class);
    assertThat(data.foo, equalTo("foo"));
    assertThat(data.bar, equalTo("bar"));
  }

}
