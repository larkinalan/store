package com.ilim.example.web.resources;

import com.ilim.example.app.conf.SpringTestConfig;
import com.ilim.example.web.conf.JerseyConfig;

import com.codahale.metrics.MetricRegistry;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.test.JerseyTest;
import org.glassfish.jersey.test.TestProperties;
import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.ws.rs.core.Application;


/**
 * Support class for Testing our jersey services with spring transactions.
 * 
 * <p>Extend this class instead of JerseyTest.
 *
 * @author Alan Larkin
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringTestConfig.class)
@Transactional
@Rollback
public class JerseySpringTestSupport extends JerseyTest {

  private JerseyConfig jerseyConfig;
  private AnnotationConfigApplicationContext springConfig;

  @Override
  protected Application configure() {

    enable(TestProperties.LOG_TRAFFIC);
    enable(TestProperties.DUMP_ENTITY);
    forceSet(TestProperties.CONTAINER_PORT, "0");

    jerseyConfig = new JerseyConfig();
    springConfig =
        new AnnotationConfigApplicationContext(SpringTestConfig.class);
    jerseyConfig.property("contextConfig", springConfig);

    return jerseyConfig;
  }

  @Override
  protected void configureClient(ClientConfig config) {

    config.register(JacksonFeature.class);
  }
  
  protected JerseyConfig jerseyConfig() {
    return jerseyConfig;
  }
  
  protected AnnotationConfigApplicationContext springConfig() {
    return springConfig;
  }
  
  protected MetricRegistry metrics() {
    return jerseyConfig.metrics();
  }
  
  @Rule
  @Inject
  public TestRule logger;
  
}

