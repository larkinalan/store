package com.ilim.example.infra.db.jdbc;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import com.ilim.example.app.conf.SpringTestConfig;
import com.ilim.example.domain.IExampleRepository;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import javax.inject.Inject;

/**
 * Tests for JdbcExampleDao.
 *
 * @author Alan Larkin
 */
@ContextConfiguration(classes = SpringTestConfig.class)
public class JdbcExampleDaoTest
    extends AbstractTransactionalJUnit4SpringContextTests {

  @Rule
  @Inject
  public TestRule logger;

  @Inject
  private IExampleRepository exampleDao;

  @Test
  public void greetAlan() {
    assertThat(exampleDao.greet("Alan"), equalTo("hello, Alan!"));
  }

  @Test
  public void findExampleList() {
    assertThat(exampleDao.findExampleList().size(), equalTo(1));
  }
}
