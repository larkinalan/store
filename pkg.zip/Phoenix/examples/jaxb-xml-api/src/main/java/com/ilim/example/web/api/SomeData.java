package com.ilim.example.web.api;

import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Example JAXB DataType.
 * 
 * <p>Prefer C struct style over Java bean Style.
 * <b>Must remain immutable</b> .
 * 
 * @author Alan Larkin
 *
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SomeData {

  @XmlElement
  public final int id;
  @XmlElement
  public final String name;
  @XmlElement
  public final BigDecimal number;
  @XmlElement
  public final String date;
  @XmlElement
  public final ImmutableList<String> list;
  @XmlElement
  public final ImmutableMap<Integer, String> map;

  /**
   * Should only requires one constructor.
   * Create another DataType instead of adding multiple constructors. 
   */
  public SomeData(int id, String name, BigDecimal number, String date,
      List<String> list, Map<Integer, String> map) {

    this.id = id;
    this.name = name;
    this.number = number;
    this.date = date;
    this.list = ImmutableList.copyOf(list);
    this.map = ImmutableMap.copyOf(map);
  }
  
  // jaxb needs a no arg constructor to do its magic
  @SuppressWarnings("unused")
  private SomeData() {
    this(0, null, null, null, null, null);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("id", id).add("name", name)
        .add("number", number).add("date", date).toString();
  }

}
