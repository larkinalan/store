package com.ilim.example.web.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * FooBar JAXB DataType.
 * 
 * @author Alan Larkin
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class GooBazData {

  @XmlElement
  public final String goo;
  @XmlElement
  public final String baz;

  /** Creates FooBar type. */
  public GooBazData(String goo, String baz) {

    this.goo = goo;
    this.baz = baz;
  }
  
  // jaxb needs a no arg constructor to do its magic
  @SuppressWarnings("unused")
  private GooBazData() {
    this(null, null);
  }
}
