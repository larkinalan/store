package com.ilim.example.app.task;

import org.apache.camel.EndpointInject;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.spring.MockEndpoints;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

@MockEndpoints("direct:exampleRouteB")
public class ExampleTaskTest extends AppTaskTestSupport {

  @Autowired
  ExampleTask exampleTask;

  @Produce(uri = "direct:exampleRouteA")
  private ProducerTemplate exampleRouteA;

  @EndpointInject(uri = "mock:direct:exampleRouteB")
  protected MockEndpoint mockEndpoint;

  @Before
  public void setUp() throws Exception {
    //camelContext.setTracing(true);
    camelContext.addRoutes(exampleTask);
  }

  @Test
  public void testExampleTask() throws Exception {
    
    // setup expected test data
    String expectedBody = "Hello, Alan!";
    mockEndpoint.expectedBodiesReceived(expectedBody);

    // test
    exampleRouteA.sendBody("Alan");

    // verify
    mockEndpoint.expectedMessageCount(1);
    mockEndpoint.assertIsSatisfied();
  }


}
