package com.ilim.example.app.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.example.app.conf.CamelSpringTestConfig;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import java.math.BigDecimal;


/**
 * Tests for IExampleExternalService.
 *
 * @author Alan Larkin
 */
@ContextConfiguration(classes = CamelSpringTestConfig.class)
public class ExampleExternalServiceTest
    extends AbstractJUnit4SpringContextTests {

  @Rule
  @Autowired
  public TestRule logger;

  @Autowired
  private IExampleExternalService service;

  @Test
  public void greetAlan() {

    assertThat(service.greet("Alan")).isEqualTo("Hello, Alan!");
  }

  @Test
  public void findPrice() {

    assertThat(service.findPrice(123)).isEqualByComparingTo(BigDecimal.ONE);
  }
}
