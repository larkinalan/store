package com.ilim.example;

import com.ilim.example.app.conf.CamelSpringConfig;
import com.ilim.example.infra.external.ExampleExternalServiceAdapter;

import org.apache.camel.spring.javaconfig.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


/**
 * Simple stand alone Task Scheduler.
 * 
 * <p>Embeds apache camel <a><href>http://camel.apache.org/</href></a>
 * {@code mvn exec:java}
 * 
 * @author alan larkin
 */
public class Application {

  private static final Logger log =
      LoggerFactory.getLogger(ExampleExternalServiceAdapter.class);

  /**
   * Application main.
   */
  public static void main(final String[] args) {

    try {

      System.out.println("ILIM Camel task scheduling application");

      final Main app = new Main();
      app.setApplicationContext(
          new AnnotationConfigApplicationContext(CamelSpringConfig.class));
      app.run(args);

    } catch (Exception ex) {
      log.error("Application crash! " + ex.getMessage());
    }
  }

}
