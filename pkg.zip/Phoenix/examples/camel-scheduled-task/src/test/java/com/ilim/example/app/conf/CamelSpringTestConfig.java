package com.ilim.example.app.conf;

import com.ilim.commons.logging.TestLogger;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.spring.javaconfig.CamelConfiguration;
import org.junit.rules.TestRule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import java.util.ArrayList;
import java.util.List;

/**
 * Camel Spring component config.
 *
 * @author Alan Larkin
 */
@Configuration
@Import({SpringConfig.class})
public class CamelSpringTestConfig extends CamelConfiguration {

  /** TestLogger bean.  */
  @Bean
  public TestRule testLogger() {
    return new TestLogger();
  }

  /**
   * Override routes with empty list.
   *  
   * <p>We don't add routes here, we do it dynamically in the test setup.
   **/
  @Override
  public List<RouteBuilder> routes() {
    return new ArrayList<>();
  }

}
