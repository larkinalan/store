package com.ilim.example.app.task;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.example.app.service.IExampleExternalService;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.language.SimpleExpression;
import org.springframework.beans.factory.annotation.Autowired;

public class ExampleTask extends RouteBuilder {
  
  @Autowired
  private IExampleExternalService exampleService;

  @Override
  public void configure() throws Exception {
    
    final String schedule = settings().getString("example.task.schedule");
    
    from("quartz2:examplePollingRoute?cron=" + schedule)
      .routeId("examplePollingRoute")
      .log("polling....")
      .setBody(new SimpleExpression("Eve"))
      .to("direct:exampleRouteA")
      .end();
   
    from("direct:exampleRouteA")
      .routeId("exampleRouteA")
      .bean(exampleService, "greet")
      .log("exampleRouteA says ${body}")
      .to("direct:exampleRouteB")
      .end();
    
    from("direct:exampleRouteB")
      .routeId("exampleRouteB")
      .log("exampleRouteB says ${body}")
      .end();
  }
}
