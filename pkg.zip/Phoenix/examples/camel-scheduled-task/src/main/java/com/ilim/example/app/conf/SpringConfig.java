package com.ilim.example.app.conf;

import com.ilim.example.app.service.IExampleExternalService;
import com.ilim.example.app.task.ExampleTask;
import com.ilim.example.infra.external.ExampleExternalServiceAdapter;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Camel Spring component config.
 *
 * @author Alan Larkin
 */
@Configuration
public class SpringConfig {
  
  /** ExampleExternalService bean. */
  @Bean
  public IExampleExternalService exampleExternalService() {
    return new ExampleExternalServiceAdapter();
  }
  
  /** ExampleTask bean. */
  @Bean
  public ExampleTask exampleTask() {
    return new ExampleTask();
  }

}
