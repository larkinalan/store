package com.ilim.example.app.service;

import java.math.BigDecimal;

public interface IExampleExternalService {

  String greet(String who);

  BigDecimal findPrice(int ilimId);

}

