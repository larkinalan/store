package com.ilim.example.infra.external;

import com.ilim.example.app.service.IExampleExternalService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * Mock external external service.
 * 
 * @author Alan Larkin
 */
@Service
public class ExampleExternalServiceAdapter implements IExampleExternalService {

  private static final Logger log =
      LoggerFactory.getLogger(ExampleExternalServiceAdapter.class);

  @Override
  public String greet(String who) {
    
    log.info("greet ({})", who);

    return "Hello, " + who + "!";
  }

  @Override
  public BigDecimal findPrice(int ilimId) {

    log.info("findPrice ()", ilimId);

    // fake lookup to external service.
    // in reality we would delegate to a rest or soap client here.
    return BigDecimal.ONE;
  }

}
