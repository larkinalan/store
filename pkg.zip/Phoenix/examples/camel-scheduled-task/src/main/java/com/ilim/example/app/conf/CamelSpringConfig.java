package com.ilim.example.app.conf;

import com.ilim.example.app.task.ExampleTask;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.spring.javaconfig.CamelConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import java.util.Arrays;
import java.util.List;

/**
 * Camel Spring configuration.
 *
 * @author Alan Larkin
 */
@Configuration
@Import({SpringConfig.class})
public class CamelSpringConfig extends CamelConfiguration {
  
  @Autowired
  private ExampleTask exampleTask;
  
  /* Add all routes here. */
  @Override
  public List<RouteBuilder> routes() {

    return Arrays.asList(exampleTask);
  }

}
