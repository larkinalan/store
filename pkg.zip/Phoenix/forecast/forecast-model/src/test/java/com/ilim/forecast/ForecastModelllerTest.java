package com.ilim.forecast;

import static org.junit.Assert.*;

import com.ilim.commons.domain.model.ForecastType;
import com.ilim.forecast.app.service.ForecastModeller;
import com.ilim.forecast.app.service.IForecastModeller;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.PendingInstruction;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class ForecastModelllerTest {

  @Test
  public void process() {

    IForecastModeller modeller =
        new ForecastModeller(TestData.funds(), TestData.prices(), TestData.positions());

    PendingInstruction instr =
        new PendingInstruction(1, LocalDate.now(), ForecastType.NEW_MONEY.id(),
            TestData.C101.fundId, new BigDecimal("15"));

    List<ForecastModelAlloc> model = modeller.model(instr);
    assertTrue(model.size() > 0);
  }
  
  /*
  @Test
  public void process_AAQ() {

    IForecastModeller modeller =
        new ForecastModeller(null, null, TestData.AAQ_positions());

    PendingInstruction instr = new PendingInstruction(1, 1,
        TestData.C_AAQ.fundId, new BigDecimal("2362985.46"));

    List<ForecastModelAlloc> model = modeller.model(instr);
    assertTrue(model.size() > 0);
  }
  
  
  @Test
  public void process_AGBP() {

    IForecastModeller modeller =
        new ForecastModeller(TestData.C_AAQ, TestData.prices(), TestData.AAQ_positions());

    PendingInstruction instr = new PendingInstruction(1, 1,
        TestData.C_AGBP.fundId, new BigDecimal("1000"));

    List<ForecastModelAlloc> model = modeller.model(instr);
    assertTrue(model.size() > 0);
  }
  */
  
}
  