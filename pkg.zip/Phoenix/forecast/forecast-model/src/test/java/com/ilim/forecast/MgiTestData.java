package com.ilim.forecast;


import static com.ilim.commons.domain.model.FundLevel.CLIENT;
import static com.ilim.commons.domain.model.FundLevel.INVESTING;
import static com.ilim.commons.domain.model.FundLevel.PRIMARY;
import static com.ilim.commons.domain.model.FundLevel.TAX;
import static com.ilim.commons.domain.model.PriceType.UNIT_TRANSACTION;

import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import com.google.common.collect.ImmutableList;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MgiTestData {
  
  /** Fund test data. */
  public static class Funds {

    // Client
    public static final FundData BPL = new FundData(26320, CLIENT.name(),
        new BigDecimal("10959220.0000"), "EUR", 19);
    // Tax
    public static final FundData TBPL = new FundData(26321, TAX.name(),
        new BigDecimal("10195362.4130"), "EUR", -1);
    // Primary
    public static final FundData PBPL = new FundData(26322, PRIMARY.name(),
        new BigDecimal("10195362.4160"), "EUR", -1);
    // Investing
    public static final FundData UKPENPRP = new FundData(25080,
        INVESTING.name(), new BigDecimal("196456157.1700"), "EUR", 41);
    public static final FundData MGIEUCSH = new FundData(26339,
        INVESTING.name(), new BigDecimal("1473474.6370"), "EUR", 41);
    public static final FundData MGIEUREQ = new FundData(26341,
        INVESTING.name(), new BigDecimal("2302004.2750"), "EUR", 41);
    public static final FundData MGIEMMKT = new FundData(26344,
        INVESTING.name(), new BigDecimal("2762819.7820"), "EUR", 41);
    public static final FundData MGIEUBND = new FundData(26345,
        INVESTING.name(), new BigDecimal("2548283.1540"), "EUR", 41);
    public static final FundData ILIMCBF = new FundData(27702, INVESTING.name(),
        new BigDecimal("711627135.8050"), "EUR", 41);
    public static final FundData MGILSF = new FundData(41659, INVESTING.name(),
        new BigDecimal("4262873.1460"), "EUR", 41);
    public static final FundData MGIEMD = new FundData(41946, INVESTING.name(),
        new BigDecimal("1586013.1580"), "EUR", 41);
    public static final FundData MWSGLBE = new FundData(41948, INVESTING.name(),
        new BigDecimal("1811380.8800"), "EUR", 41);
    public static final FundData MWSPGE = new FundData(41949, INVESTING.name(),
        new BigDecimal("2707238.9040"), "EUR", 41);
    public static final FundData MWSLVEF = new FundData(41950, INVESTING.name(),
        new BigDecimal("2691576.5400"), "EUR", 41);

    // COLLECTORS

    public static final List<FundData> list = ImmutableList.of(BPL, TBPL, PBPL,
        UKPENPRP, MGIEUCSH, MGIEUREQ, MGIEMMKT, MGIEUBND, ILIMCBF, MGILSF,
        MGIEMD, MWSGLBE, MWSPGE, MWSLVEF);

    public static final Map<Integer, FundData> map =
        list.stream().collect(Collectors.toMap(f -> f.fundId, f -> f));
  }

  /** FundHolding test data. */
  public static class FundHoldings {

    // CLIENT -> TAX
    public static final FundHoldingData BPL_TBPL =
        new FundHoldingData(Funds.BPL.fundId, Funds.TBPL.fundId,
            new BigDecimal("10203269.9510"));
    // TAX -> PRIMARY
    public static final FundHoldingData TBPL_PBPL =
        new FundHoldingData(Funds.TBPL.fundId, Funds.PBPL.fundId,
            new BigDecimal("10203269.9470"));
    // PRIMARY -> INVESTING
    public static final FundHoldingData PBPL_UKPENPRP =
        new FundHoldingData(Funds.PBPL.fundId, Funds.UKPENPRP.fundId,
            new BigDecimal("9280904.5300"));
    public static final FundHoldingData PBPL_MGIEUCSH =
        new FundHoldingData(Funds.PBPL.fundId, Funds.MGIEUCSH.fundId,
            new BigDecimal("481150.3010"));
    public static final FundHoldingData PBPL_MGIEUREQ =
        new FundHoldingData(Funds.PBPL.fundId, Funds.MGIEUREQ.fundId,
            new BigDecimal("1063833.2370"));
    public static final FundHoldingData PBPL_MGIEMMKT =
        new FundHoldingData(Funds.PBPL.fundId, Funds.MGIEMMKT.fundId,
            new BigDecimal("1401763.5160"));
    public static final FundHoldingData PBPL_MGIEUBND =
        new FundHoldingData(Funds.PBPL.fundId, Funds.MGIEUBND.fundId,
            new BigDecimal("622045.6530"));
    public static final FundHoldingData PBPL_ILIMCBF =
        new FundHoldingData(Funds.PBPL.fundId, Funds.ILIMCBF.fundId,
            new BigDecimal("579556.4500"));
    public static final FundHoldingData PBPL_MGILSF =
        new FundHoldingData(Funds.PBPL.fundId, Funds.MGILSF.fundId,
            new BigDecimal("1550760.5370"));
    public static final FundHoldingData PBPL_MGIEMD =
        new FundHoldingData(Funds.PBPL.fundId, Funds.MGIEMD.fundId,
            new BigDecimal("639728.8550"));
    public static final FundHoldingData PBPL_MWSGLBE =
        new FundHoldingData(Funds.PBPL.fundId, Funds.MWSGLBE.fundId,
            new BigDecimal("841424.5710"));
    public static final FundHoldingData PBPL_MWSPGE =
        new FundHoldingData(Funds.PBPL.fundId, Funds.MWSPGE.fundId,
            new BigDecimal("1234588.1850"));
    public static final FundHoldingData PBPL_MWSLVEF =
        new FundHoldingData(Funds.PBPL.fundId, Funds.MWSLVEF.fundId,
            new BigDecimal("1273930.7780"));

    // COLLECTORS
    public static final List<FundHoldingData> list =
        ImmutableList.of(BPL_TBPL, TBPL_PBPL, PBPL_UKPENPRP, PBPL_MGIEUCSH,
            PBPL_MGIEUREQ, PBPL_MGIEMMKT, PBPL_MGIEUBND, PBPL_ILIMCBF,
            PBPL_MGILSF, PBPL_MGIEMD, PBPL_MWSGLBE, PBPL_MWSPGE, PBPL_MWSLVEF);

    public static final Map<String, FundHoldingData> map =
        list.stream().collect(Collectors.toMap(
            fh -> String.valueOf(fh.fundId + ":" + fh.holdingId), fh -> fh));
  }

  /** FundPrice test data. */
  public static class FundPrices {

    public static String priceDate = "31/01/2016";
    public static String priceType = UNIT_TRANSACTION.name();

    // PRICE DATA
    public static final FundPriceData BPL = new FundPriceData(
        Funds.BPL.fundId, priceDate, priceType, new BigDecimal("1.3141460"));
    public static final FundPriceData TBPL = new FundPriceData(
        Funds.TBPL.fundId, priceDate, priceType, new BigDecimal("1.4126040"));
    public static final FundPriceData PBPL = new FundPriceData(
        Funds.PBPL.fundId, priceDate, priceType, new BigDecimal("1.4126040"));
    public static final FundPriceData UKPENPRP =
        new FundPriceData(Funds.UKPENPRP.fundId, priceDate, priceType,
            new BigDecimal("0.1562540"));
    public static final FundPriceData MGIEUCSH =
        new FundPriceData(Funds.MGIEUCSH.fundId, priceDate, priceType,
            new BigDecimal("1.0392720"));
    public static final FundPriceData MGIEUREQ =
        new FundPriceData(Funds.MGIEUREQ.fundId, priceDate, priceType,
            new BigDecimal("1.505460"));
    public static final FundPriceData MGIEMMKT =
        new FundPriceData(Funds.MGIEMMKT.fundId, priceDate, priceType,
            new BigDecimal("1.1440170"));
    public static final FundPriceData MGIEUBND =
        new FundPriceData(Funds.MGIEUBND.fundId, priceDate, priceType,
            new BigDecimal("1.3881690"));
    public static final FundPriceData ILIMCBF = new FundPriceData(
        Funds.ILIMCBF.fundId, priceDate, priceType, new BigDecimal("1.4951330"));
    public static final FundPriceData MGILSF = new FundPriceData(
        Funds.MGILSF.fundId, priceDate, priceType, new BigDecimal("1.1387660"));
    public static final FundPriceData MGIEMD =
        new FundPriceData(Funds.MGIEMD.fundId, priceDate, priceType,
            new BigDecimal("0.9057440"));
    public static final FundPriceData MWSGLBE = new FundPriceData(
        Funds.MWSGLBE.fundId, priceDate, priceType, new BigDecimal("1.5388720"));
    public static final FundPriceData MWSPGE = new FundPriceData(
        Funds.MWSPGE.fundId, priceDate, priceType, new BigDecimal("1.5746290"));
    public static final FundPriceData MWSLVEF = new FundPriceData(
        Funds.MWSLVEF.fundId, priceDate, priceType, new BigDecimal("1.5255840"));

    // COLLECTORS
    public static final List<FundPriceData> list = ImmutableList.of(BPL, TBPL,
        PBPL, UKPENPRP, MGIEUCSH, MGIEUREQ, MGIEMMKT, MGIEUBND, ILIMCBF, MGILSF,
        MGIEMD, MWSGLBE, MWSPGE, MWSLVEF);

    public static final Map<Integer, BigDecimal> map = list.stream()
        .collect(Collectors.toMap(fp -> fp.fundId, fp -> fp.price));
  }

}
