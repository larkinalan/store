package com.ilim.forecast;

import static org.junit.Assert.assertEquals;

import com.ilim.forecast.domain.model.FundOfFundsGraph;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import com.google.common.collect.ImmutableMap;

import org.junit.Test;

import java.math.BigDecimal;

public class FundOfFundsGraphTest {

  @Test
  public void createFundGraph() {

    FundOfFundsGraph graph =
        new FundOfFundsGraph(null, null, fundHoldings());

    assertEquals(4, graph.vertices());
    assertEquals(7, graph.edges());

    FundData f = new FundData(301, "PRIMARY", new BigDecimal("100"));
    assertEquals(3, graph.indegree(f));
  }

  @Test
  public void bfs() {

    FundOfFundsGraph graph =
        new FundOfFundsGraph(null, null, fundHoldings());

    graph.breathFirstSearch(TestData.T201);
  }

  @Test
  public void bfsMultipleSources() {

    // TODO:
    // FundOfFundsGraph graph = new FundOfFundsGraph(ForecastModellerfundHoldingsData());
    // graph.breathFirstSearch(C101, C102);
  }

  private ImmutableMap<String, FundHoldingData> fundHoldings() {
    return null;
   //return ForecastModeller.mapOfPositions(TestData.fundHoldings()).build();
  }



}
