package com.ilim.forecast;

import static org.junit.Assert.assertEquals;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.forecast.domain.model.FundOfFundsGraph;
import com.ilim.fund.web.api.FundData;

import org.junit.Test;

import java.math.BigDecimal;

public class FundOfFundsGraphTest {

  @Test
  public void createFundGraph() {

    FundOfFundsGraph graph = new FundOfFundsGraph(TestData.funds(),
        TestData.prices(), TestData.positions());

    assertEquals(5, graph.vertices());
    assertEquals(10, graph.edges());

    FundData f = new FundData(301, FundLevel.PRIMARY.name(),
        new BigDecimal("100"), "EUR", -1);
    assertEquals(3, graph.indegree(f));
  }

  @Test
  public void bfs() {

    FundOfFundsGraph graph = new FundOfFundsGraph(TestData.funds(),
        TestData.prices(), TestData.positions());

    graph.breathFirstSearch(TestData.T201);
  }

  @Test
  public void bfsMultipleSources() {

    // TODO:
    // FundOfFundsGraph graph = new FundOfFundsGraph(ForecastModellerfundHoldingsData());
    // graph.breathFirstSearch(C101, C102);
  }

}
