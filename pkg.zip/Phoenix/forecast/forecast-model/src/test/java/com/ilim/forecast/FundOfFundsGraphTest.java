package com.ilim.forecast;

import static org.junit.Assert.assertEquals;

import com.ilim.forecast.app.service.ForecastModeller;
import com.ilim.forecast.domain.model.FundOfFundsGraph;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import com.google.common.collect.ImmutableMap;

import org.junit.Test;

import java.math.BigDecimal;

public class FundOfFundsGraphTest {

  @Test
  public void createFundGraph() {

    FundOfFundsGraph graph =
        new FundOfFundsGraph(funds(), prices(), positions());

    assertEquals(5, graph.vertices());
    assertEquals(10, graph.edges());

    FundData f = new FundData(301, "PRIMARY", new BigDecimal("100"), "EUR", 1);
    assertEquals(3, graph.indegree(f));
  }

  @Test
  public void bfs() {

    FundOfFundsGraph graph =
        new FundOfFundsGraph(funds(), prices(), positions());

    graph.breathFirstSearch(TestData.T201);
  }

  @Test
  public void bfsMultipleSources() {

    // TODO:
    // FundOfFundsGraph graph = new FundOfFundsGraph(ForecastModellerfundHoldingsData());
    // graph.breathFirstSearch(C101, C102);
  }

  private ImmutableMap<Integer, FundData> funds() {
    return ForecastModeller.mapOfFunds(TestData.funds()).build();
  }

  private ImmutableMap<Integer, BigDecimal> prices() {
    return ForecastModeller.mapOfPrices(TestData.prices()).build();
  }

  private ImmutableMap<String, FundHoldingData> positions() {
    return ForecastModeller.mapOfPositions(TestData.positions()).build();
  }



}
