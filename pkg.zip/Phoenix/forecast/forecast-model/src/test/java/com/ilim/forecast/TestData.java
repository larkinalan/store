package com.ilim.forecast;


import static com.ilim.commons.domain.model.FundLevel.CLIENT;
import static com.ilim.commons.domain.model.FundLevel.INVESTING;
import static com.ilim.commons.domain.model.FundLevel.PRIMARY;
import static com.ilim.commons.domain.model.FundLevel.TAX;
import static com.ilim.commons.domain.model.PriceType.UNIT_TRANSACTION;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TestData {

  // FUND DATA
  public static final FundData C101 = newClient(101, "100");

  public static final FundData T201 = newTax(201, "100");
  public static final FundData T202 = newTax(202, "100");

  public static final FundData P301 = newPrimary(301, "100");
  public static final FundData P302 = newPrimary(302, "100");

  public static final FundData I401 = newInvesting(401, "100");
  public static final FundData I402 = newInvesting(402, "100");
  public static final FundData I403 = newInvesting(403, "100");
  public static final FundData I404 = newInvesting(404, "100");
  public static final FundData I405 = newInvesting(405, "100");


  public static Map<Integer, FundData> funds() {
    
    return ImmutableMap.<Integer, FundData>builder()
      .put(C101.fundId, C101)
      .put(T201.fundId, T201)
      .put(T202.fundId, T202)
      .put(P301.fundId, P301)
      .put(P302.fundId, P302)
      .put(I401.fundId, I401)
      .put(I402.fundId, I402)
      .put(I403.fundId, I403)
      .put(I404.fundId, I404)
      .put(I405.fundId, I405).build();
  }

  public static Map<String, FundHoldingData> positions() {

    return ImmutableMap.<String, FundHoldingData>builder()
        // client -> tax
       .put(makeKey(C101, T201), newPosition(C101.fundId, T201.fundId, "50"))
       .put(makeKey(C101, T202), newPosition(C101.fundId, T202.fundId, "50"))
       // tax -> primary
       .put(makeKey(T201, P301), newPosition(T201.fundId, P301.fundId, "100"))
       // complex
       .put(makeKey(T202, P301), newPosition(T202.fundId, P301.fundId, "50"))
       .put(makeKey(T202, P302), newPosition(T202.fundId, P302.fundId, "50"))
       // primary -> investing
       .put(makeKey(P301, I401), newPosition(P301.fundId, I401.fundId, "100"))
       .put(makeKey(P301, I402), newPosition(P301.fundId, I402.fundId, "50"))
       .put(makeKey(P301, I403), newPosition(P301.fundId, I403.fundId, "25"))
       .put(makeKey(P302, I404), newPosition(P302.fundId, I404.fundId, "25"))
       .put(makeKey(P302, I405), newPosition(P302.fundId, I405.fundId, "25"))
       .build();

    /*
     * // tax -> primary
     * fundHoldings.add(new FundHoldingData(T201, P301, new BigDecimal("50")));
     * fundHoldings.add(new FundHoldingData(T202, P301, new BigDecimal("25")));
     * fundHoldings.add(new FundHoldingData(T202, P302, new BigDecimal("25")));
     * // primary -> investing
     * fundHoldings.add(new FundHoldingData(P301, I401, new BigDecimal("50")));
     * fundHoldings.add(new FundHoldingData(P301, I402, new BigDecimal("20")));
     * fundHoldings.add(new FundHoldingData(P301, I403, new BigDecimal("5")));
     * fundHoldings.add(new FundHoldingData(P302, I404, new BigDecimal("15")));
     * fundHoldings.add(new FundHoldingData(P302, I405, new BigDecimal("10")));
     */
  }


  // simple fund AAQ
  public static final FundData C_AAQ = newClient(37881, "8076976");
  public static final FundData T_TRIA = newTax(37707, "24349721.528");
  public static final FundData P_TRIA = newPrimary(37708, "24349721.538");
  public static final FundData I_AAAMBF = newInvesting(35647, "24349721.538");

  public static final FundData C_T186 = newClient(57592, "11020");
  public static final FundData T_T186 = newTax(57593, "11019.999");
  public static final FundData P_T186 = newPrimary(57594, "11019.999");
  public static final FundData I_TRAN186 = newInvesting(57612, "11019.999");

  public static List<FundHoldingData> AAQ_positions() {

    List<FundHoldingData> positions = new ArrayList<>();
    positions.add(newPosition(C_AAQ.fundId, T_TRIA.fundId, "7947409.393"));
    positions.add(newPosition(T_TRIA.fundId, P_TRIA.fundId, "24349721.538"));
    positions.add(newPosition(P_TRIA.fundId, I_AAAMBF.fundId, "24349737.373"));
    positions.add(newPosition(C_T186.fundId, T_T186.fundId, "11019.999"));
    positions.add(newPosition(T_T186.fundId, P_T186.fundId, "11019.999"));
    positions.add(newPosition(P_T186.fundId, I_TRAN186.fundId, "11019.999"));

    return positions;
  }

  // multi tax fund AGBP
  public static final FundData C_AGBP = newClient(59151, "6508015");
  public static final FundData T_AGFA = newTax(57414, "57866900.468");
  public static final FundData T_IPRP = newTax(17772, "479822938.396");
  public static final FundData P_AGFA = newPrimary(57415, "57866900.468");
  public static final FundData P_IPRP = newPrimary(200, "479822938.21");
  public static final FundData I_MINVOL = newInvesting(42005, "140378335.309");
  public static final FundData I_EMERGMKT =
      newInvesting(18911, "112954383.864");
  public static final FundData I_IPAIBM = newInvesting(8828, "241642804.247");
  public static final FundData I_IPAIPE = newInvesting(209, "660310422.448");
  public static final FundData I_IPAINA = newInvesting(208, "617536855.955");
  public static final FundData I_ILIMRAFI = newInvesting(43865, "19445629.563");
  public static final FundData I_IPAIEE = newInvesting(203, "351146383.167");
  public static final FundData I_IPAIEN = newInvesting(4633, "835688283.838");
  public static final FundData I_IPAIUF = newInvesting(6815, "555130528.342");
  public static final FundData I_IPRP = newInvesting(7, "1374088823.942");
  public static final FundData I_IPAIJE = newInvesting(207, "5150956439.475");


  public static List<FundHoldingData> AGBP_positions() {

    List<FundHoldingData> positions = new ArrayList<>();
    positions.add(newPosition(C_AGBP.fundId, T_AGFA.fundId, "5839460.084"));
    positions.add(newPosition(C_AGBP.fundId, T_IPRP.fundId, "488218.314"));
    positions.add(newPosition(T_AGFA.fundId, P_AGFA.fundId, "57866900.468"));
    positions.add(newPosition(T_IPRP.fundId, P_IPRP.fundId, "479588106.556"));
    positions.add(newPosition(P_AGFA.fundId, I_MINVOL.fundId, "9362112.861"));
    positions.add(newPosition(P_AGFA.fundId, I_EMERGMKT.fundId, "1468688.914"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIBM.fundId, "1026537.014"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIPE.fundId, "2596699.385"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAINA.fundId, "1329591.074"));
    positions.add(newPosition(P_AGFA.fundId, I_ILIMRAFI.fundId, "9966657.978"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIEE.fundId, "345857.749"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIEN.fundId, "2963682.021"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIUF.fundId, "831038.645"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIJE.fundId, "8913758.411"));
    positions.add(newPosition(P_IPRP.fundId, I_IPRP.fundId, "653808022.282"));

    return positions;
  }

  public static Map<Integer, BigDecimal> prices() {

    return ImmutableMap.<Integer, BigDecimal>builder()
        .put(C101.fundId, BigDecimal.ONE)
        .put(T201.fundId, BigDecimal.ONE)
        .put(T202.fundId, BigDecimal.ONE)
        .put(P301.fundId, BigDecimal.ONE)
        .put(P302.fundId, BigDecimal.ONE)
        .put(I401.fundId, BigDecimal.ONE)
        .put(I402.fundId, BigDecimal.ONE)
        .put(I403.fundId, BigDecimal.ONE)
        .put(I404.fundId, BigDecimal.ONE)
        .put(I405.fundId, BigDecimal.ONE)
        .build();
 
    /*
    // simple FundData AAQ
    prices.add(newPrice(C_AAQ.fundId, "1.577068"));
    prices.add(newPrice(T_TRIA.fundId, "1.602779"));
    prices.add(newPrice(P_TRIA.fundId, "1.602779"));
    prices.add(newPrice(I_AAAMBF.fundId, "1.602778"));
    prices.add(newPrice(C_T186.fundId, "1.353322"));
    prices.add(newPrice(T_T186.fundId, "1.353322"));
    prices.add(newPrice(P_T186.fundId, "1.353322"));
    prices.add(newPrice(I_TRAN186.fundId, "1.353322"));

    // multi tax FundData AGBP
    prices.add(newPrice(C_AGBP.fundId, "0.949007"));
    prices.add(newPrice(T_AGFA.fundId, "0.95032"));
    prices.add(newPrice(T_IPRP.fundId, "1.283844"));
    prices.add(newPrice(P_AGFA.fundId, "0.95032"));
    prices.add(newPrice(P_IPRP.fundId, "1.283844"));
    prices.add(newPrice(I_MINVOL.fundId, "1.660951"));
    prices.add(newPrice(I_EMERGMKT.fundId, "5.353279"));
    prices.add(newPrice(I_IPAIBM.fundId, "0.312063"));
    prices.add(newPrice(I_IPAIPE.fundId, "0.472092"));
    prices.add(newPrice(I_IPAINA.fundId, "6.919622"));
    prices.add(newPrice(I_ILIMRAFI.fundId, "4.962743"));
    prices.add(newPrice(I_IPAIEE.fundId, "1.353322"));
    prices.add(newPrice(I_IPAIEN.fundId, "0.298778"));
    prices.add(newPrice(I_IPAIUF.fundId, "1.38963"));
    prices.add(newPrice(I_IPRP.fundId, "0.941739"));
    prices.add(newPrice(I_IPAIJE.fundId, "0.165835"));

    return prices;
    */
  }

  public static FundData newClient(int fundId, String price) {

    return new FundData(fundId, FundLevel.CLIENT.name(), new BigDecimal(price),
        "EUR", 1);
  }

  public static FundData newTax(int fundId, String price) {

    return new FundData(fundId, FundLevel.TAX.name(), new BigDecimal(price),
        "EUR", 2);
  }

  public static FundData newPrimary(int fundId, String price) {

    return new FundData(fundId, FundLevel.PRIMARY.name(), new BigDecimal(price),
        "EUR", 3);
  }

  public static FundData newInvesting(int fundId, String price) {

    return new FundData(fundId, FundLevel.INVESTING.name(),
        new BigDecimal(price), "EUR", 4);
  }
  
  public static String makeKey(FundData fund, FundData holding) {

    return fund.fundId + ":" + holding.fundId;
  }

  public static FundHoldingData newPosition(int fundId, int holdingId,
      String heldUnits) {

    return new FundHoldingData(fundId, holdingId, new BigDecimal(heldUnits));
  }

}
