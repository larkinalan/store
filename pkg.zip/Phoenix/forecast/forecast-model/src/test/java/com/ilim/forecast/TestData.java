package com.ilim.forecast;


import com.ilim.commons.time.DateUtils;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TestData {

  // FUND DATA
  public static final FundData C101 = newClient(101, "100");

  public static final FundData T201 = newTax(201, "100");
  public static final FundData T202 = newTax(202, "100");

  public static final FundData P301 = newPrimary(301, "100");
  public static final FundData P302 = newPrimary(302, "100");

  public static final FundData I401 = newInvesting(401, "100");
  public static final FundData I402 = newInvesting(402, "100");
  public static final FundData I403 = newInvesting(403, "100");
  public static final FundData I404 = newInvesting(404, "100");
  public static final FundData I405 = newInvesting(405, "100");
  

  public static List<FundData> funds() {
    
    List<FundData> funds = new ArrayList<>();
    funds.add(C101);
    funds.add(T201);
    funds.add(T202);
    funds.add(P301);
    funds.add(P302);
    funds.add(I401);
    funds.add(I402);
    funds.add(I403);
    funds.add(I404);
    funds.add(I405);
    return funds;
  }

  public static List<FundHoldingData> positions() {

    List<FundHoldingData> positions = new ArrayList<>();
    // client -> tax
    positions.add(newPosition(C101.fundId, T201.fundId, "50"));
    positions.add(newPosition(C101.fundId, T202.fundId, "50"));

    // tax -> primary
    positions.add(newPosition(T201.fundId, P301.fundId, "100"));
    positions.add(newPosition(T202.fundId, P301.fundId, "50")); // complex
    positions.add(newPosition(T202.fundId, P302.fundId, "50"));

    // primary -> investing
    positions.add(newPosition(P301.fundId, I401.fundId, "100"));
    positions.add(newPosition(P301.fundId, I402.fundId, "50"));
    positions.add(newPosition(P301.fundId, I403.fundId, "25"));
    positions.add(newPosition(P302.fundId, I404.fundId, "25"));
    positions.add(newPosition(P302.fundId, I405.fundId, "25"));

    /*
     * // tax -> primary
     * fundHoldings.add(new FundHoldingData(T201, P301, new BigDecimal("50")));
     * fundHoldings.add(new FundHoldingData(T202, P301, new BigDecimal("25")));
     * fundHoldings.add(new FundHoldingData(T202, P302, new BigDecimal("25")));
     * // primary -> investing
     * fundHoldings.add(new FundHoldingData(P301, I401, new BigDecimal("50")));
     * fundHoldings.add(new FundHoldingData(P301, I402, new BigDecimal("20")));
     * fundHoldings.add(new FundHoldingData(P301, I403, new BigDecimal("5")));
     * fundHoldings.add(new FundHoldingData(P302, I404, new BigDecimal("15")));
     * fundHoldings.add(new FundHoldingData(P302, I405, new BigDecimal("10")));
     */
    return positions;
  }


  // simple fund AAQ
  public static final FundData C_AAQ = newClient(37881, "8076976");
  public static final FundData T_TRIA = newTax(37707, "24349721.528");
  public static final FundData P_TRIA = newPrimary(37708, "24349721.538");
  public static final FundData I_AAAMBF = newInvesting(35647, "24349721.538");

  public static final FundData C_T186 = newClient(57592, "11020");
  public static final FundData T_T186 = newTax(57593, "11019.999");
  public static final FundData P_T186 = newPrimary(57594, "11019.999");
  public static final FundData I_TRAN186 = newInvesting(57612, "11019.999");

  public static List<FundHoldingData> AAQ_positions() {

    List<FundHoldingData> positions = new ArrayList<>();
    positions.add(newPosition(C_AAQ.fundId, T_TRIA.fundId, "7947409.393"));
    positions.add(newPosition(T_TRIA.fundId, P_TRIA.fundId, "24349721.538"));
    positions.add(newPosition(P_TRIA.fundId, I_AAAMBF.fundId, "24349737.373"));
    positions.add(newPosition(C_T186.fundId, T_T186.fundId, "11019.999"));
    positions.add(newPosition(T_T186.fundId, P_T186.fundId, "11019.999"));
    positions.add(newPosition(P_T186.fundId, I_TRAN186.fundId, "11019.999"));

    return positions;
  }

  // multi tax fund AGBP
  public static final FundData C_AGBP = newClient(59151, "6508015");
  public static final FundData T_AGFA = newTax(57414, "57866900.468");
  public static final FundData T_IPRP = newTax(17772, "479822938.396");
  public static final FundData P_AGFA = newPrimary(57415, "57866900.468");
  public static final FundData P_IPRP = newPrimary(200, "479822938.21");
  public static final FundData I_MINVOL = newInvesting(42005, "140378335.309");
  public static final FundData I_EMERGMKT =
      newInvesting(18911, "112954383.864");
  public static final FundData I_IPAIBM = newInvesting(8828, "241642804.247");
  public static final FundData I_IPAIPE = newInvesting(209, "660310422.448");
  public static final FundData I_IPAINA = newInvesting(208, "617536855.955");
  public static final FundData I_ILIMRAFI = newInvesting(43865, "19445629.563");
  public static final FundData I_IPAIEE = newInvesting(203, "351146383.167");
  public static final FundData I_IPAIEN = newInvesting(4633, "835688283.838");
  public static final FundData I_IPAIUF = newInvesting(6815, "555130528.342");
  public static final FundData I_IPRP = newInvesting(7, "1374088823.942");
  public static final FundData I_IPAIJE = newInvesting(207, "5150956439.475");


  public static List<FundHoldingData> AGBP_positions() {

    List<FundHoldingData> positions = new ArrayList<>();
    positions.add(newPosition(C_AGBP.fundId, T_AGFA.fundId, "5839460.084"));
    positions.add(newPosition(C_AGBP.fundId, T_IPRP.fundId, "488218.314"));
    positions.add(newPosition(T_AGFA.fundId, P_AGFA.fundId, "57866900.468"));
    positions.add(newPosition(T_IPRP.fundId, P_IPRP.fundId, "479588106.556"));
    positions.add(newPosition(P_AGFA.fundId, I_MINVOL.fundId, "9362112.861"));
    positions.add(newPosition(P_AGFA.fundId, I_EMERGMKT.fundId, "1468688.914"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIBM.fundId, "1026537.014"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIPE.fundId, "2596699.385"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAINA.fundId, "1329591.074"));
    positions.add(newPosition(P_AGFA.fundId, I_ILIMRAFI.fundId, "9966657.978"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIEE.fundId, "345857.749"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIEN.fundId, "2963682.021"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIUF.fundId, "831038.645"));
    positions.add(newPosition(P_AGFA.fundId, I_IPAIJE.fundId, "8913758.411"));
    positions.add(newPosition(P_IPRP.fundId, I_IPRP.fundId, "653808022.282"));

    return positions;
  }

  public static List<FundPriceData> prices() {

    List<FundPriceData> prices = new ArrayList<>();
    prices.add(newPrice(C101.fundId, "1.0"));
    prices.add(newPrice(T201.fundId, "1.0"));
    prices.add(newPrice(T202.fundId, "1.0"));
    prices.add(newPrice(P301.fundId, "1.0"));
    prices.add(newPrice(P302.fundId, "1.0"));
    prices.add(newPrice(I401.fundId, "1.0"));
    prices.add(newPrice(I402.fundId, "1.0"));
    prices.add(newPrice(I403.fundId, "1.0"));
    prices.add(newPrice(I404.fundId, "1.0"));
    prices.add(newPrice(I405.fundId, "1.0"));

    // simple FundData AAQ
    prices.add(newPrice(C_AAQ.fundId, "1.577068"));
    prices.add(newPrice(T_TRIA.fundId, "1.602779"));
    prices.add(newPrice(P_TRIA.fundId, "1.602779"));
    prices.add(newPrice(I_AAAMBF.fundId, "1.602778"));
    prices.add(newPrice(C_T186.fundId, "1.353322"));
    prices.add(newPrice(T_T186.fundId, "1.353322"));
    prices.add(newPrice(P_T186.fundId, "1.353322"));
    prices.add(newPrice(I_TRAN186.fundId, "1.353322"));

    // multi tax FundData AGBP
    prices.add(newPrice(C_AGBP.fundId, "0.949007"));
    prices.add(newPrice(T_AGFA.fundId, "0.95032"));
    prices.add(newPrice(T_IPRP.fundId, "1.283844"));
    prices.add(newPrice(P_AGFA.fundId, "0.95032"));
    prices.add(newPrice(P_IPRP.fundId, "1.283844"));
    prices.add(newPrice(I_MINVOL.fundId, "1.660951"));
    prices.add(newPrice(I_EMERGMKT.fundId, "5.353279"));
    prices.add(newPrice(I_IPAIBM.fundId, "0.312063"));
    prices.add(newPrice(I_IPAIPE.fundId, "0.472092"));
    prices.add(newPrice(I_IPAINA.fundId, "6.919622"));
    prices.add(newPrice(I_ILIMRAFI.fundId, "4.962743"));
    prices.add(newPrice(I_IPAIEE.fundId, "1.353322"));
    prices.add(newPrice(I_IPAIEN.fundId, "0.298778"));
    prices.add(newPrice(I_IPAIUF.fundId, "1.38963"));
    prices.add(newPrice(I_IPRP.fundId, "0.941739"));
    prices.add(newPrice(I_IPAIJE.fundId, "0.165835"));

    return prices;
  }

  public static FundData newClient(int fundId, String price) {

    return new FundData(fundId, "CLIENT", new BigDecimal(price));
  }

  public static FundData newTax(int fundId, String price) {

    return new FundData(fundId, "TAX", new BigDecimal(price));
  }

  public static FundData newPrimary(int fundId, String price) {

    return new FundData(fundId, "PRIMARY", new BigDecimal(price));
  }

  public static FundData newInvesting(int fundId, String price) {

    return new FundData(fundId, "INVESTING", new BigDecimal(price));
  }

  public static FundHoldingData newPosition(int fundId, int holdingId,
      String heldUnits) {

    return new FundHoldingData(fundId, holdingId, new BigDecimal(heldUnits));
  }

  private static FundPriceData newPrice(int fundId, String price) {

    return new FundPriceData(fundId, new BigDecimal(price),
        LocalDate.now().format(DateUtils.DATE_FMT), "UNIT_TRANSACTION");
  }

}
