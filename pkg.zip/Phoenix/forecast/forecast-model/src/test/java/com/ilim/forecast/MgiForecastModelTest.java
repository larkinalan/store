package com.ilim.forecast;

import static org.junit.Assert.assertTrue;

import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.domain.model.MoneyNotificationType;
import com.ilim.forecast.app.service.ForecastModeller;
import com.ilim.forecast.app.service.IForecastModeller;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.ProcessingForecastInstruction;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class MgiForecastModelTest {

  @Test
  public void model() {

    IForecastModeller modeller = new ForecastModeller(MgiTestData.Funds.map,
        MgiTestData.FundPrices.map, MgiTestData.FundHoldings.map);


    ProcessingForecastInstruction instr =
        new ProcessingForecastInstruction(9999, LocalDate.now(),
            ForecastType.NEW_MONEY, MgiTestData.Funds.BPL.fundId,
            MoneyNotificationType.CASH, new BigDecimal("100"));

    List<ForecastModelAlloc> model = modeller.model(instr);
    assertTrue(model.size() > 0);

    // TODO: assert mix, cash, units calcs as the should be exactl.
  }

}
