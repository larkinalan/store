package com.ilim.forecast;

import static org.junit.Assert.*;

import com.ilim.commons.domain.model.ForecastType;
import com.ilim.forecast.app.service.ForecastModeller;
import com.ilim.forecast.app.service.IForecastModeller;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.Instruction;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class MgiForecastModelTest {
  
  @Test
  public void model() {

    IForecastModeller modeller = new ForecastModeller(MgiTestData.Funds.map,
        MgiTestData.FundPrices.map, MgiTestData.FundHoldings.map);

    Instruction instr =
        new Instruction(-1, LocalDate.now(), ForecastType.NEW_MONEY.id(),
            MgiTestData.Funds.BPL.fundId, new BigDecimal("100"));

    List<ForecastModelAlloc> model = modeller.model(instr);
    assertTrue(model.size() > 0);
    
    //TODO: assert mix, cash, units calcs as the should be exactl.
  }
  
}
  