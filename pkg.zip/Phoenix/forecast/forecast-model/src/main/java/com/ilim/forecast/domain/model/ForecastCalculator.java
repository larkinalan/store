package com.ilim.forecast.domain.model;

import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_CASH;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_MIX;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_UNITS;
import static java.math.BigDecimal.ONE;
import static java.math.BigDecimal.ZERO;
import static java.math.RoundingMode.HALF_EVEN;

import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Funcs used to calculate a forecast postion 
 * 
 * @author Alan larkin
 */
public class ForecastCalculator {


  /**
   * Calculates the cash value of a fund. 
   * 
   * @param fund asset
   * @param price latest price
   */
  public static BigDecimal cashValue(FundData fund, BigDecimal price) {

    BigDecimal units = fund.committedUnits;
    BigDecimal cash = units.multiply(price);
    return cash.setScale(ROUND_CASH.scale(), HALF_EVEN);
  }

  public static BigDecimal cashValue(BigDecimal units, BigDecimal price) {

    BigDecimal cash = units.multiply(price);
    return cash.setScale(ROUND_CASH.scale(), HALF_EVEN);
  }

  /**
   * Calculates the sum cash value of a list of holdings. 
   * 
   * @param holdings list of holdings
   * @param prices map of latest prices 
   */
  public static BigDecimal totalCashValue(List<FundData> holdings,
      Map<Integer, BigDecimal> prices) {

    BigDecimal totalCash = ZERO;

    for (FundData h : holdings) {

      BigDecimal price = prices.getOrDefault(h.fundId, ZERO);
      BigDecimal cash = cashValue(h, price);

      totalCash = totalCash.add(cash);
    }

    return totalCash.setScale(ROUND_CASH.scale(), HALF_EVEN);
  }

  /**
   * Calculates the latest mix percentage of a fund -> holding. 
   * 
   * @param fund parent fund
   * @param holding child holding or underlying fund
   * @param holdings the size or number of holdings the fund holds  
   */
  public static BigDecimal latestMix(FundData fund, FundData holding, int holdings,
      BigDecimal price, BigDecimal totalAssetValue) {
    BigDecimal mix = ZERO;

    if (totalAssetValue.compareTo(ZERO) == 0) {

      BigDecimal size = new BigDecimal(holdings);
      mix = ONE.divide(size, ROUND_MIX.scale(), HALF_EVEN);

    } else {

      BigDecimal units = holding.committedUnits;
      mix = units.multiply(price).divide(totalAssetValue, ROUND_MIX.scale(),
          HALF_EVEN);
    }

    return mix;
  }

  /**
   * Calculates the latest mix percentage. 
   * 
   * @param fundValue asset value
   * @param holdingValue asset value 
   */
  public static BigDecimal latestMix(BigDecimal fundValue,
      BigDecimal holdingValue) {

    BigDecimal mix = ZERO; // default

    if (holdingValue.compareTo(ZERO) != 0) {

      mix = holdingValue.divide(fundValue, ROUND_MIX.scale(), HALF_EVEN);
    }

    return mix;
  }

  /**
   * Calculates the cash move using the latest mix. 
   * 
   * @param cash amount
   * @param mix percentage
   */
  public static BigDecimal cashMove(BigDecimal cash, BigDecimal mix) {

    BigDecimal move = cash.multiply(mix);
    return move.setScale(ROUND_CASH.scale(), HALF_EVEN);
  }

  /**
   * Calculates the new position
   * 
   * @param currentPostion the current fund holding position
   * @param cashMove the new cash amount
   * @param price the latest price
   * @return FundHolding  
   */
  public static BigDecimal unitPositionMove(FundHoldingData currentPostion,
      BigDecimal cashMove, BigDecimal price) {

    BigDecimal unitMove = cashMove.multiply(price);
    BigDecimal newPosition = currentPostion.heldUnits.add(unitMove);

    return newPosition.setScale(ROUND_UNITS.scale(), HALF_EVEN);
  }

}
