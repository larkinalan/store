package com.ilim.forecast.domain.model;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkState;
import static com.ilim.forecast.domain.model.ForecastCalculator.cashMove;
import static com.ilim.forecast.domain.model.ForecastCalculator.cashValue;
import static com.ilim.forecast.domain.model.ForecastCalculator.latestMix;
import static com.ilim.forecast.domain.model.ForecastCalculator.unitPositionMove;

import com.ilim.forecast.domain.ModelFactory;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;

/**
 *  A FundModel, implemented using an adjacency list.
 *  Parallel edges and self-loops are permitted. 
 *  TODO: disable these! 
 *
 *  <p>example 1:
 *  13 vertices, 22 edges
 *  0: 5 1 
 *  1: 
 *  2: 0 3 
 *  3: 5 2 
 *  4: 3 2 
 *  5: 4 
 *  6: 9 4 8 0 
 *  7: 6 9
 *  8: 6 
 *  9: 11 10 
 *  10: 12 
 *  11: 4 12 
 *  12: 9   
 *  
 *  <p>example 2:
 *  3 vertices, 5 edges
 *  101: 201
 *  201: 301
 *  301: 401 402, 403 
 *  
 */
public class FundOfFundsGraph {

  private final ImmutableMap<Integer, FundData> funds;
  private final ImmutableMap<Integer, BigDecimal> prices;
  private final ImmutableMap<String, FundHoldingData> positions;
  private final ImmutableSet<FundData> rootFunds;
  private final Multimap<FundData, FundData> adjacencyList;

  public FundOfFundsGraph(Map<Integer, FundData> funds,
      Map<Integer, BigDecimal> prices,
      ImmutableMap<String, FundHoldingData> positions) {

    // cache of funds
    checkArgument(funds != null && funds.size() != 0, "Missing funds");
    this.funds = ImmutableMap.copyOf(funds);

    // cache of prices
    checkArgument(prices != null && prices.size() != 0, "Missing prices");
    this.prices = ImmutableMap.copyOf(prices);

    // cache of current positions
    checkArgument(positions != null && positions.size() != 0,
        "Missing positions!");
    this.positions = ImmutableMap.copyOf(positions);

    // build graph
    Set<FundData> clients = new HashSet<>();
    // Using linked list maintain order
    this.adjacencyList =
        MultimapBuilder.linkedHashKeys().arrayListValues().build();

    for (FundHoldingData pos : positions.values()) {

      FundData fund = this.funds.get(pos.fundId);
      FundData holding = this.funds.get(pos.holdingId);
      addEdge(fund, holding);

      if (fund.level.equals("CLIENT")) {
        clients.add(fund);
      }
    }
    this.rootFunds = ImmutableSet.copyOf(clients);
  }

  /**
   * Adds the directed edge f->h to.
   *
   * @param  fund the tail vertex
   * @param  holding the head vertex
   * @throws IllegalArgumentException
   */
  public void addEdge(FundData fund, FundData holding) {

    checkSelfloop(fund, holding);
    checkParallelEdge(fund, holding);
    checkRelationship(fund, holding);

    adjacencyList.put(fund, holding);
  }

  /* Returns number of Fund vertices */
  public int vertices() {

    return adjacencyList.keySet().size();
  }

  /* Returns number of Holding edges */
  public int edges() {

    return adjacencyList.entries().size();
  }

  /* Returns indegree of fund vertex f */
  public int indegree(FundData f) {

    return adjacencyList.get(f).size();
  }

  /*
   * //System.out.println(prefix + (isLeaf() ? "|- " : "|+ ") + this + " with " + fund.asString());
   * 
   * System.out.println(a.fundHolding.fund);
   * System.out.println("|  " + a.fundHolding.holding);
   */

  /** Breath First Search */
  public List<ForecastModelAlloc> modelOld(PendingInstruction instr) {

    final List<ForecastModelAlloc> allocs = new ArrayList<>();
    Queue<FundData> q = new ArrayDeque<>(edges());
    Set<String> visited = new HashSet<>();

    BigDecimal cashToAllocate = instr.cash; // cash to model

    q.offer(funds.get(instr.fundId)); // client fund
    while (!q.isEmpty()) {

      FundData fund = q.poll();
      List<FundData> holdings = (List<FundData>) adjacencyList.get(fund);
      final BigDecimal currentValue = cashValue(fund, price(fund.fundId));
      BigDecimal allocatedCash = BigDecimal.ZERO;

      for (FundData holding : holdings) {

        // TODO: this will break for multiple tax, we need to store the parents.
        final String fundHolding = makeKey(fund.fundId, holding.fundId);

        if (!visited.contains(fundHolding)) {

          final FundHoldingData currentPostion =
              position(fund.fundId, holding.fundId);
          final BigDecimal price = price(holding.fundId);

          ForecastModelAlloc alloc =
              allocateLatestMix(fund, holding, holdings.size(), cashToAllocate,
                  currentValue, currentPostion, price, instr.id, instr.type);

          allocatedCash = allocatedCash.add(alloc.getCash());

          allocs.add(alloc);
          visited.add(fundHolding);
          q.offer(holding);
        }
      }

      validate(fund, cashToAllocate, allocatedCash);
      cashToAllocate = allocatedCash; // allocate the cash to holdings
    }

    return allocs;
  }

  /** Breath First Search */
  public List<ForecastModelAlloc> modelBFS(PendingInstruction instr) {

    final List<ForecastModelAlloc> allocs = new ArrayList<>();

    Map<FundData, BigDecimal> fundCash =
        memoize(funds.get(instr.fundId), instr.cash, new HashMap<>());

    Set<FundData> visited = new HashSet<>();
    Queue<FundData> q = new ArrayDeque<>(edges());
    q.offer(funds.get(instr.fundId));

    while (!q.isEmpty()) {

      FundData fund = q.poll();
      final BigDecimal cashToAllocate = fundCash.get(fund);
      final BigDecimal fundValue = cashValue(fund, price(fund.fundId));
      List<FundData> holdings = (List<FundData>) adjacencyList.get(fund);

      for (FundData holding : holdings) {

        FundHoldingData currentPostion = position(fund.fundId, holding.fundId);

        ForecastModelAlloc alloc =
            allocateLatestMix(fund, holding, cashToAllocate, fundValue,
                currentPostion, price(holding.fundId), instr.id, instr.type);

        if (!visited.contains(holding)) {
          memoize(holding, alloc.getCash(), fundCash);
        }

        allocs.add(alloc);
        visited.add(holding);
        q.offer(holding);
      }
    }

    print();
    return allocs;
  }

  /** Depth First Search */
  public List<ForecastModelAlloc> modelDFS(PendingInstruction instr) {

    final List<ForecastModelAlloc> allocs = new ArrayList<>();

    Map<FundData, BigDecimal> fundCash =
        memoize(funds.get(instr.fundId), instr.cash, new HashMap<>());

    Set<FundData> visited = new HashSet<>();
    Deque<FundData> stack = new ArrayDeque<>(edges());
    stack.push(funds.get(instr.fundId));

    while (!stack.isEmpty()) {

      FundData fund = stack.pop();
      final BigDecimal cashToAllocate = fundCash.get(fund);
      final BigDecimal fundValue = cashValue(fund, price(fund.fundId));
      List<FundData> holdings = (List<FundData>) adjacencyList.get(fund);

      for (FundData holding : holdings) {

        FundHoldingData currentPostion = position(fund.fundId, holding.fundId);

        ForecastModelAlloc alloc =
            allocateLatestMix(fund, holding, cashToAllocate, fundValue,
                currentPostion, price(holding.fundId), instr.id, instr.type);

        if (!visited.contains(holding)) {
          memoize(holding, alloc.getCash(), fundCash);
        }

        allocs.add(alloc);
        visited.add(holding);
        stack.push(holding);
      }
    }

    print();
    return allocs;
  }

  private Map<FundData, BigDecimal> memoize(FundData fund, BigDecimal cash,
      Map<FundData, BigDecimal> fundCash) {

    BigDecimal allocatedCash = fundCash.get(fund);
    if (allocatedCash == null) {
      fundCash.put(fund, cash);
    } else {
      fundCash.put(fund, allocatedCash.add(cash));
    }
    return fundCash;
  }

  /**
   * Calculates a fund -> holding allocation using latest mix
   * 
   * @param fund the parent fund
   * @param holding the child holding or underlying fund
   * @param holdings the number of holdings in the fund
   * @param cash to allocate
   * @param currentValue f the fund (cash)
   * @param currentPostioncurrent unit position of the fund->holding
   * @param price the latest price
   * @param instrId instruction id
   * @param instrType instruction type 
   */
  public ForecastModelAlloc allocateLatestMix(FundData fund, FundData holding,
      int holdings, BigDecimal totalCash, BigDecimal currentValue,
      FundHoldingData currentPostion, BigDecimal price, int instrId,
      int instrType) {

    final BigDecimal mix =
        latestMix(fund, holding, holdings, price, currentValue);
    final BigDecimal cashMove = cashMove(totalCash, mix);
    final BigDecimal unitPosition =
        unitPositionMove(currentPostion, cashMove, price);
    final LocalDate forecastDate = LocalDate.now(); // FIXME: this is wrong

    return ModelFactory.createNewForecastModelAlloc(forecastDate, instrId,
        fund.fundId, holding.fundId, unitPosition, price, mix, cashMove);
  }

  public ForecastModelAlloc allocateLatestMix(FundData fund, FundData holding,
      BigDecimal cashToAllocate, BigDecimal fundValue,
      FundHoldingData currentPostion, BigDecimal price, int instrId,
      int instrType) {

    final BigDecimal holdingValue = cashValue(currentPostion.heldUnits, price);
    final BigDecimal mix = latestMix(fundValue, holdingValue);
    final BigDecimal cashMove = cashMove(cashToAllocate, mix);
    System.out.println(fund + ", " + holding + ",  cashToAllocate "
        + cashToAllocate + ",  mix " + mix + ", cashMove " + cashMove);
    final BigDecimal unitPosition =
        unitPositionMove(currentPostion, cashMove, price);
    final LocalDate forecastDate = LocalDate.now(); // FIXME: this is wrong

    return ModelFactory.createNewForecastModelAlloc(forecastDate, instrId,
        fund.fundId, holding.fundId, unitPosition, price, mix, cashMove);
  }


  public void validate(FundData fund, BigDecimal cashToAllocate,
      BigDecimal allocatedCash) {

    if (!fund.level.equals("INVESTING")) {

      checkState(allocatedCash.compareTo(cashToAllocate) != -1,
          "Under allocated " + fund + " , cashToAllocate=" + cashToAllocate
              + " , allocatedCash=" + allocatedCash + " , diff="
              + cashToAllocate.subtract(allocatedCash));

      checkState(allocatedCash.compareTo(cashToAllocate) != 1,
          "Over allocated " + fund + " , cashToAllocate=" + cashToAllocate
              + " , allocatedCash=" + allocatedCash + " , diff="
              + cashToAllocate.subtract(allocatedCash));
    }
  }

  public FundHoldingData position(int fundId, int holdingId) {

    return positions.get(makeKey(fundId, holdingId));
  }

  public String makeKey(int fundId, int holdingId) {
    return fundId + ":" + holdingId;
  }

  public BigDecimal price(int fundId) {

    return prices.getOrDefault(fundId, BigDecimal.ZERO).setScale(6,
        RoundingMode.HALF_EVEN);
  }

  public void breathFirstSearch(FundData fund) {

    Queue<FundData> q = new ArrayBlockingQueue<>(edges());
    Set<FundData> marked = new HashSet<>(); // is there an fund->vertex path?
    Map<FundData, Integer> distTo = new HashMap<>(); // last edge on shortest fund->vertex path
    Map<FundData, FundData> edgeTo = new HashMap<>(); // length of shortest fund->vertex path

    q.offer(fund);

    while (!q.isEmpty()) {

      FundData vertex = q.poll();
      List<FundData> edges = (List<FundData>) adjacencyList.get(vertex);

      for (FundData f : edges) {

        if (!marked.contains(f)) {

          edgeTo.put(f, vertex);
          distTo.put(f, distTo.getOrDefault(vertex, 0) + 1);
          marked.add(f);
          q.offer(f);
        }
      }
    }

    printMarked(marked);
    printDistTo(distTo);
    printEdgeTo(edgeTo);

  }

  // Multiple soruces
  public void breathFirstSearch(FundData... funds) {

    Queue<FundData> q = new ArrayDeque<>(edges());
    Set<FundData> marked = new HashSet<>(); // is there an fund->vertex path?
    Map<FundData, Integer> distTo = new HashMap<>(); // last edge on shortest fund->vertex path
    Map<FundData, FundData> edgeTo = new HashMap<>(); // length of shortest fund->vertex path

    for (FundData f : funds) {
      q.offer(f);
    }

    while (!q.isEmpty()) {

      FundData vertex = q.poll();

      List<FundData> edges = (List<FundData>) adjacencyList.get(vertex);
      for (FundData e : edges) {

        if (!marked.contains(e)) {

          edgeTo.put(e, vertex);
          distTo.put(e, distTo.getOrDefault(vertex, 0) + 1);
          marked.add(e);
          q.offer(e);
        }
      }
    }

    printMarked(marked);
    printDistTo(distTo);
    printEdgeTo(edgeTo);
  }

  private void checkSelfloop(FundData fund, FundData holding) {

    checkArgument(fund.fundId != holding.fundId,
        "Self loops are not allowed /n " + " FUND [ " + fund + " ] "
            + " HOLDING [ " + holding + " ] ");
  }

  private void checkParallelEdge(FundData fund, FundData holding) {

    checkArgument(!adjacencyList.containsEntry(fund, holding),
        "Parralled edges not allowed /n " + " FUND [ " + fund + " ] "
            + " HOLDING [ " + holding + " ] ");
  }

  private void checkRelationship(FundData fund, FundData holding) {

    /*
     * checkArgument(holding.level.isChild(fund.level),
     * "holding must be child level of fund  /n " + " FUND [ " + fund + ", "
     * + fund.level + " ] " + " HOLDING [ " + holding + ", "
     * + holding.level + " ] ");
     */
  }


  private static void printMarked(Set<FundData> marked) {

    System.out.println("CAN BE REACHED FROM");
    for (FundData m : marked) {
      System.out.println("marked with fund->vertex path : " + m);
    }
  }

  private static void printDistTo(Map<FundData, Integer> distTo) {

    System.out.println("DISTANCE TO");
    for (Map.Entry<FundData, Integer> d : distTo.entrySet()) {
      System.out.println(d.getKey() + " has shortest length " + d.getValue());
    }
  }

  private static void printEdgeTo(Map<FundData, FundData> edgeTo) {

    System.out.println("EDGES TO");
    for (Map.Entry<FundData, FundData> d : edgeTo.entrySet()) {
      System.out.println(d.getKey()
          + " length of shortest fund->vertex path is " + d.getValue());
    }
  }

  /*
   * public void print() {
   * 
   * Queue<Fund> q = new ArrayDeque<>(edges());
   * 
   * // Add all clients
   * for (Fund f : rootFunds) {
   * q.offer(f);
   * }
   * 
   * System.out.println("FundOfFunds");
   * String prefix = "";
   * while (!q.isEmpty()) {
   * 
   * Fund fund = q.poll();
   * List<Fund> holdings = (List<Fund>) adjacencyList.get(fund);
   * 
   * if (holdings.isEmpty()) {
   * System.out.println("|- " + fund.id);
   * } else {
   * System.out.println("|+ " + fund.id);
   * }
   * 
   * prefix += "|  ";
   * for (Fund holding : holdings) {
   * System.out.println(prefix + holding.id);
   * q.offer(holding);
   * }
   * }
   * }
   */

  public void print() {

    System.out.println("");
    System.out.println("=============== FoF Graph ======================");

    Deque<FundData> stack = new ArrayDeque<>(edges());
    for (FundData f : rootFunds) {
      stack.push(f);
    }

    while (!stack.isEmpty()) {

      FundData fund = stack.pop();
      List<FundData> holdings = (List<FundData>) adjacencyList.get(fund);
      print(fund, holdings.isEmpty());
      for (FundData holding : holdings) {
        stack.push(holding);
      }
    }

    System.out.println("");
  }

  private static void print(FundData fund, boolean isLeaf) {

    String prefix = "";
    if (fund.level.equals("TAX")) {
      prefix = " ";
    } else if (fund.level.equals("PRIMARY")) {
      prefix = "  ";
    } else if (fund.level.equals("INVESTING")) {
      prefix = "   ";
    }

    System.out.println(prefix + (isLeaf ? "|- " : "|+ ") + fund.fundId);
    // + ", " + fund.level.name());
  }

}


