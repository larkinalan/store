package com.ilim.forecast.domain.model;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkState;
import static com.ilim.forecast.domain.model.ForecastCalculator.cashMove;
import static com.ilim.forecast.domain.model.ForecastCalculator.cashValue;
import static com.ilim.forecast.domain.model.ForecastCalculator.latestMix;
import static com.ilim.forecast.domain.model.ForecastCalculator.unitPositionMove;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.forecast.domain.ModelFactory;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;

/**
 *  A FundModel, implemented using an adjacency list.
 *  Parallel edges and self-loops are permitted. 
 *  TODO: disable these! 
 *
 *  <p>example 1:
 *  13 vertices, 22 edges
 *  0: 5 1 
 *  1: 
 *  2: 0 3 
 *  3: 5 2 
 *  4: 3 2 
 *  5: 4 
 *  6: 9 4 8 0 
 *  7: 6 9
 *  8: 6 
 *  9: 11 10 
 *  10: 12 
 *  11: 4 12 
 *  12: 9   
 *  
 *  <p>example 2:
 *  3 vertices, 5 edges
 *  101: 201
 *  201: 301
 *  301: 401 402, 403 
 *  
 */
public class FundOfFundsGraph {

  private final ImmutableMap<Integer, FundData> funds;
  private final ImmutableMap<Integer, BigDecimal> prices;
  private final ImmutableMap<String, FundHoldingData> positions;
  private final ImmutableSet<FundData> rootFunds;
  private final Multimap<FundData, FundData> adjacencyList;
  
  public FundOfFundsGraph(Map<Integer, FundData> funds,
      Map<Integer, BigDecimal> prices, Map<String, FundHoldingData> positions) {

    // cache of funds
    checkArgument(funds != null && !funds.isEmpty(), "Missing funds");
    this.funds = ImmutableMap.copyOf(funds);

    // cache of prices
    checkArgument(prices != null && !prices.isEmpty(), "Missing prices");
    this.prices = ImmutableMap.copyOf(prices);

    // cache of current positions
    checkArgument(positions != null && !positions.isEmpty(),
        "Missing positions!");
    this.positions = ImmutableMap.copyOf(positions);

    // build graph
    Set<FundData> clients = new HashSet<>();
    // Using linked list to maintain order
    this.adjacencyList =
        MultimapBuilder.linkedHashKeys().arrayListValues().build();

    for (FundHoldingData pos : this.positions.values()) {

      FundData fund = this.funds.get(pos.fundId);
      FundData holding = this.funds.get(pos.holdingId);
      addEdge(fund, holding);

      if (fund.level.equals(FundLevel.CLIENT.name())) {
        clients.add(fund);
      }
    }
    this.rootFunds = ImmutableSet.copyOf(clients);
  }

  /**
   * Adds the directed edge f->h to.
   *
   * @param  fund the tail vertex
   * @param  holding the head vertex
   * @throws IllegalArgumentException
   */
  public void addEdge(FundData fund, FundData holding) {

    checkSelfloop(fund, holding);
    checkParallelEdge(fund, holding);
    checkRelationship(fund, holding);

    adjacencyList.put(fund, holding);
  }

  /* Returns number of Fund vertices */
  public int vertices() {

    return adjacencyList.keySet().size();
  }

  /* Returns number of Holding edges */
  public int edges() {

    return adjacencyList.entries().size();
  }

  /* Returns indegree of fund vertex f */
  public int indegree(FundData f) {

    return adjacencyList.get(f).size();
  }

  /** Breath First Search */
  public List<ForecastModelAlloc> modelBFS(Instruction instr) {

    final List<ForecastModelAlloc> allocs = new ArrayList<>();

    final Map<FundData, BigDecimal> fundCash =
        memoize(new ConcurrentHashMap<>(), funds.get(instr.fundId), instr.cash);
    
    Set<FundData> visited = new HashSet<>();
    Queue<FundData> q = new ArrayDeque<>(edges());
    q.offer(funds.get(instr.fundId));

    while (!q.isEmpty()) {

      FundData fund = q.poll();
      final BigDecimal cashToAllocate = fundCash.get(fund);
      final BigDecimal fundValue = cashValue(fund, price(fund.fundId));
      List<FundData> holdings = (List<FundData>) adjacencyList.get(fund);

      for (FundData holding : holdings) {

        ForecastModelAlloc alloc =
            allocateLatestMix(fund, holding, cashToAllocate, fundValue, instr);

        if (!visited.contains(holding)) {
          memoize(fundCash, holding, alloc.getCash());
        }

        allocs.add(alloc);
        visited.add(holding);
        q.offer(holding);
      }
    }

    print();
    return allocs;
  }

  /** Depth First Search */
  public List<ForecastModelAlloc> modelDFS(Instruction instr) {

    final List<ForecastModelAlloc> allocs = new ArrayList<>();

    final Map<FundData, BigDecimal> fundCash =
        memoize(new ConcurrentHashMap<>(), funds.get(instr.fundId), instr.cash);

    Set<FundData> visited = new HashSet<>();
    Deque<FundData> stack = new ArrayDeque<>(edges());
    stack.push(funds.get(instr.fundId));

    while (!stack.isEmpty()) {

      FundData fund = stack.pop();
      final BigDecimal cashToAllocate = fundCash.get(fund);
      final BigDecimal fundValue = cashValue(fund, price(fund.fundId));
      List<FundData> holdings = (List<FundData>) adjacencyList.get(fund);

      for (FundData holding : holdings) {

         ForecastModelAlloc alloc =
            allocateLatestMix(fund, holding, cashToAllocate, fundValue, instr);
         System.out.println(alloc.toString());

        if (!visited.contains(holding)) {
          memoize(fundCash, holding, alloc.getCash());
        }

        allocs.add(alloc);
        visited.add(holding);
        stack.push(holding);
      }
    }

    print();
    return allocs;
  }

  private Map<FundData, BigDecimal> memoize(Map<FundData, BigDecimal> fundCash,
      FundData fund, BigDecimal cash) {

    BigDecimal allocatedCash = fundCash.putIfAbsent(fund, cash);
    if (allocatedCash != null) {
      fundCash.put(fund, allocatedCash.add(cash));
    }
    return fundCash;
  }

  private ForecastModelAlloc allocateLatestMix(FundData fund, FundData holding,
      BigDecimal cashToAllocate, BigDecimal fundValue, Instruction instr) {

    final FundHoldingData currentPostion = position(fund.fundId, holding.fundId);
    final BigDecimal price = price(holding.fundId);
    final BigDecimal holdingValue = cashValue(currentPostion.heldUnits, price);
    final BigDecimal mix = latestMix(fundValue, holdingValue);
    final BigDecimal cashMove = cashMove(cashToAllocate, mix);
    final BigDecimal unitPosition =
        unitPositionMove(currentPostion, cashMove, price);

    return ModelFactory.createNewForecastModelAlloc(instr.forecastDate, instr.id,
        fund.fundId, holding.fundId, unitPosition, price, mix, cashMove);
  }


  private void validate(FundData fund, BigDecimal cashToAllocate,
      BigDecimal allocatedCash) {

    if (!fund.level.equals(FundLevel.INVESTING.name())) {

      checkState(allocatedCash.compareTo(cashToAllocate) != -1,
          "Under allocated " + fund + " , cashToAllocate=" + cashToAllocate
              + " , allocatedCash=" + allocatedCash + " , diff="
              + cashToAllocate.subtract(allocatedCash));

      checkState(allocatedCash.compareTo(cashToAllocate) != 1,
          "Over allocated " + fund + " , cashToAllocate=" + cashToAllocate
              + " , allocatedCash=" + allocatedCash + " , diff="
              + cashToAllocate.subtract(allocatedCash));
    }
  }

  private FundHoldingData position(int fundId, int holdingId) {

    return positions.get(makeKey(fundId, holdingId));
  }

  private String makeKey(int fundId, int holdingId) {
    return fundId + ":" + holdingId;
  }

  private BigDecimal price(int fundId) {

    return prices.getOrDefault(fundId, BigDecimal.ZERO).setScale(6,
        RoundingMode.HALF_EVEN);
  }

  public void breathFirstSearch(FundData fund) {

    Queue<FundData> q = new ArrayBlockingQueue<>(edges());
    Set<FundData> marked = new HashSet<>(); // is there an fund->vertex path?
    Map<FundData, Integer> distTo = new HashMap<>(); // last edge on shortest fund->vertex path
    Map<FundData, FundData> edgeTo = new HashMap<>(); // length of shortest fund->vertex path

    q.offer(fund);

    while (!q.isEmpty()) {

      FundData vertex = q.poll();
      List<FundData> edges = (List<FundData>) adjacencyList.get(vertex);

      for (FundData f : edges) {

        if (!marked.contains(f)) {

          edgeTo.put(f, vertex);
          distTo.put(f, distTo.getOrDefault(vertex, 0) + 1);
          marked.add(f);
          q.offer(f);
        }
      }
    }

    printMarked(marked);
    printDistTo(distTo);
    printEdgeTo(edgeTo);

  }

  // Multiple soruces
  public void breathFirstSearch(FundData... funds) {

    Queue<FundData> q = new ArrayDeque<>(edges());
    Set<FundData> marked = new HashSet<>(); // is there an fund->vertex path?
    Map<FundData, Integer> distTo = new HashMap<>(); // last edge on shortest fund->vertex path
    Map<FundData, FundData> edgeTo = new HashMap<>(); // length of shortest fund->vertex path

    for (FundData f : funds) {
      q.offer(f);
    }

    while (!q.isEmpty()) {

      FundData vertex = q.poll();

      List<FundData> edges = (List<FundData>) adjacencyList.get(vertex);
      for (FundData e : edges) {

        if (!marked.contains(e)) {

          edgeTo.put(e, vertex);
          distTo.put(e, distTo.getOrDefault(vertex, 0) + 1);
          marked.add(e);
          q.offer(e);
        }
      }
    }

    printMarked(marked);
    printDistTo(distTo);
    printEdgeTo(edgeTo);
  }

  private void checkSelfloop(FundData fund, FundData holding) {

    checkArgument(fund.fundId != holding.fundId,
        "Self loops are not allowed /n " + " FUND [ " + fund + " ] "
            + " HOLDING [ " + holding + " ] ");
  }

  private void checkParallelEdge(FundData fund, FundData holding) {

    checkArgument(!adjacencyList.containsEntry(fund, holding),
        "Parralled edges not allowed /n " + " FUND [ " + fund + " ] "
            + " HOLDING [ " + holding + " ] ");
  }

  private void checkRelationship(FundData fund, FundData holding) {

    /*
     * checkArgument(holding.level.isChild(fund.level),
     * "holding must be child level of fund  /n " + " FUND [ " + fund + ", "
     * + fund.level + " ] " + " HOLDING [ " + holding + ", "
     * + holding.level + " ] ");
     */
  }


  private static void printMarked(Set<FundData> marked) {

    System.out.println("CAN BE REACHED FROM");
    for (FundData m : marked) {
      System.out.println("marked with fund->vertex path : " + m);
    }
  }

  private static void printDistTo(Map<FundData, Integer> distTo) {

    System.out.println("DISTANCE TO");
    for (Map.Entry<FundData, Integer> d : distTo.entrySet()) {
      System.out.println(d.getKey() + " has shortest length " + d.getValue());
    }
  }

  private static void printEdgeTo(Map<FundData, FundData> edgeTo) {

    System.out.println("EDGES TO");
    for (Map.Entry<FundData, FundData> d : edgeTo.entrySet()) {
      System.out.println(d.getKey()
          + " length of shortest fund->vertex path is " + d.getValue());
    }
  }

  public void print() {

    System.out.println("");
    System.out.println("=============== FoF Graph ======================");

    Deque<FundData> stack = new ArrayDeque<>(edges());
    for (FundData f : rootFunds) {
      stack.push(f);
    }

    while (!stack.isEmpty()) {

      FundData fund = stack.pop();
      List<FundData> holdings = (List<FundData>) adjacencyList.get(fund);
      print(fund, holdings.isEmpty());
      for (FundData holding : holdings) {
        stack.push(holding);
      }
    }

    System.out.println("");
  }

  private static void print(FundData fund, boolean isLeaf) {

    String prefix = "";
    if (fund.level.equals(FundLevel.TAX.name())) {
      prefix = " ";
    } else if (fund.level.equals(FundLevel.PRIMARY.name())) {
      prefix = "  ";
    } else if (fund.level.equals(FundLevel.INVESTING.name())) {
      prefix = "   ";
    }

    System.out.println(prefix + (isLeaf ? "|- " : "|+ ") + fund.fundId);
  }

}


