package com.ilim.forecast.domain;

import com.ilim.forecast.domain.model.ForecastModelAlloc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Forecast Model Domain (Entity, Event) creation factory.
 * 
 * @author alan larkin
 */
public class ModelFactory {
  
  /** Creates a ForecastModelAlloc. */
  public static ForecastModelAlloc createNewForecastModelAlloc(
      LocalDate forecastDate, int instrId, int fundId, int holdingId,
      BigDecimal committedUnits, BigDecimal price, BigDecimal mix,
      BigDecimal cash) {

    int modelId = 0; // zero indicates an unsaved alloc.
    BigDecimal recordedCash = BigDecimal.ZERO; // TODO: is this correct ?
    LocalDateTime creationOn = LocalDateTime.now();

    return new ForecastModelAlloc(modelId, forecastDate, instrId, fundId,
        holdingId, committedUnits, price, mix, cash, recordedCash, creationOn);
  }

}
