package com.ilim.forecast.domain;

import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.ProcessingForecastInstruction;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Forecast Model Domain (Entity, Event) creation factory.
 * 
 * @author alan larkin
 */
public class ModelFactory {

  /** Creates a ForecastModelAlloc. */
  public static ForecastModelAlloc createModelledForecastModelAlloc(
      ProcessingForecastInstruction instr, int fundId, int holdingId,
      BigDecimal committedUnits, BigDecimal committedHeldUnits,
      BigDecimal forecastCommittedUnits, BigDecimal forecastCommittedHeldUnits,
      BigDecimal price, BigDecimal mix, BigDecimal cash) {

    int allocId = -1; // indicates an unsaved alloc.
    LocalDateTime creationOn = LocalDateTime.now();

    return new ForecastModelAlloc(allocId, instr.instrId, fundId, holdingId,
        committedUnits, committedHeldUnits, forecastCommittedUnits,
        forecastCommittedHeldUnits, price, mix, cash, creationOn);
  }
}
