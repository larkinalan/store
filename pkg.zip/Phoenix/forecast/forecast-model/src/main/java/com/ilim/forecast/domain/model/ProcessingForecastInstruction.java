package com.ilim.forecast.domain.model;

import com.ilim.commons.domain.IEvent;
import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.domain.model.MoneyNotificationType;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Processing Forecast Instruction Event.
 * 
 * @author Michael Cunningham
 */
public class ProcessingForecastInstruction
    implements IEvent<ProcessingForecastInstruction> {

  public final int instrId;
  public final LocalDate forecastDate;
  public final ForecastType forecastType;
  public final int fundId;
  public final MoneyNotificationType moneyType;
  public final BigDecimal cash;

  /** Processing Forecast Instruction Event. */
  public ProcessingForecastInstruction(int instrId, LocalDate forecastDate,
      ForecastType forecastType, int fundId, MoneyNotificationType moneyType,
      BigDecimal cash) {

    this.instrId = instrId;
    this.forecastDate = forecastDate;
    this.forecastType = forecastType;
    this.fundId = fundId;
    this.moneyType = moneyType;
    this.cash = cash;
    this.occuredOn = LocalDateTime.now();
  }

  public final LocalDateTime occuredOn;

  @Override
  public LocalDateTime occuredOn() {
    return occuredOn;
  }

  /** Returns a String representation of this Forecast Instruction Event. */
  public String toString() {

    return MoreObjects.toStringHelper(this).add("instrId", instrId)
        .add("forecastDate", forecastDate).add("forecastType", forecastType)
        .add("fundId", fundId).add("moneyType", moneyType).add("cash", cash)
        .add("occuredOn", occuredOn).toString();
  }

}
