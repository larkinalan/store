package com.ilim.forecast.app.service;

import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.FundOfFundsGraph;
import com.ilim.forecast.domain.model.PendingInstruction;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import com.google.common.collect.ImmutableMap;

import java.math.BigDecimal;
import java.util.List;

public class ForecastModeller implements IForecastModeller {

  private final ImmutableMap<Integer, FundData> funds;
  private final ImmutableMap<Integer, BigDecimal> prices;
  private final ImmutableMap<String, FundHoldingData> positions;

  public ForecastModeller(List<FundData> funds, List<FundPriceData> prices,
      List<FundHoldingData> positions) {

    this.funds = mapOfFunds(funds).build();
    this.prices = mapOfPrices(prices).build();
    this.positions = mapOfPositions(positions).build();
  }

  public static ImmutableMap.Builder<Integer, FundData> mapOfFunds(
      List<FundData> funds) {

    ImmutableMap.Builder<Integer, FundData> builder = ImmutableMap.builder();

    for (FundData f : funds) {
      builder.put(f.fundId, f);
    }
    return builder;
  }

  public static ImmutableMap.Builder<Integer, BigDecimal> mapOfPrices(
      List<FundPriceData> prices) {

    ImmutableMap.Builder<Integer, BigDecimal> builder = ImmutableMap.builder();

    for (FundPriceData p : prices) {
      builder.put(p.fundId, p.price);
    }
    return builder;
  }

  public static ImmutableMap.Builder<String, FundHoldingData> mapOfPositions(
      List<FundHoldingData> positions) {

    ImmutableMap.Builder<String, FundHoldingData> builder =
        ImmutableMap.builder();

    for (FundHoldingData pos : positions) {
      String key = pos.fundId + ":" + pos.holdingId;
      builder.put(key, pos);
    }
    return builder;
  }

  @Override
  public List<ForecastModelAlloc> model(PendingInstruction instr) {

    FundOfFundsGraph fof = new FundOfFundsGraph(funds, prices, positions);
    // fof.print();
    return fof.modelDFS(instr);
  }

}
