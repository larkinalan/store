package com.ilim.forecast.app.service;

import com.ilim.commons.domain.IEvent;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.FundOfFundsGraph;
import com.ilim.forecast.domain.model.ProcessingForecastInstruction;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class ForecastModeller implements IForecastModeller {

  private final Map<Integer, FundData> funds;
  private final Map<Integer, BigDecimal> prices;
  private final Map<String, FundHoldingData> positions;

  public ForecastModeller(Map<Integer, FundData> funds,
      Map<Integer, BigDecimal> prices, Map<String, FundHoldingData> positions) {

    this.funds = funds;
    this.prices = prices;
    this.positions = positions;
  }

  @Override
  public List<ForecastModelAlloc> model(
      IEvent<ProcessingForecastInstruction> instr) {

    FundOfFundsGraph fof = new FundOfFundsGraph(funds, prices, positions);
    return fof.modelDFS((ProcessingForecastInstruction) instr);
  }

}
