package com.ilim.forecast.domain.model;

import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_CASH;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_MIX;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_PRICE;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_UNITS;
import static java.math.RoundingMode.HALF_EVEN;

import com.ilim.commons.domain.IEntity;

import com.google.common.base.MoreObjects;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Forecast Model Allocation Entity.
 * 
 * <p>This represents the modeled allocation for a forecasted instruction.
 * 
 * @author alan larkin
 */
public final class ForecastModelAlloc
    implements IEntity<ForecastModelAlloc.Id> {

  private final ForecastModelAlloc.Id id;
  private final LocalDate forecastDate;
  private final BigDecimal committedUnits;
  private final BigDecimal price;
  private final BigDecimal mix;
  private final BigDecimal cash;
  private final BigDecimal recordedCash;
  private final LocalDateTime creationTime;

  /** Creates a ForecastModelAlloc domain Entity. */
  public ForecastModelAlloc(int modelId, LocalDate forecastDate, int instrId,
      int fundId, int holdingId, BigDecimal committedUnits, BigDecimal price,
      BigDecimal mix, BigDecimal cash, BigDecimal recordedCash,
      LocalDateTime creationTime) {

    this.id = new ForecastModelAlloc.Id(modelId, instrId, fundId, holdingId);
    this.forecastDate = forecastDate;
    this.committedUnits = committedUnits;
    this.price = price;
    this.mix = mix;
    this.cash = cash;
    this.recordedCash = recordedCash;
    this.creationTime = creationTime;
  }

  @Override
  public ForecastModelAlloc.Id getId() {
    return id;
  }

  public LocalDate getForecastDate() {
    return forecastDate;
  }

  public boolean isSaved() {
    return id.getModelId() != 0;
  }

  public BigDecimal getCommittedUnits() {
    return committedUnits.setScale(ROUND_UNITS.scale(), HALF_EVEN);
  }

  public BigDecimal getPrice() {
    return price.setScale(ROUND_PRICE.scale(), HALF_EVEN);
  }

  public BigDecimal getMix() {
    return mix.setScale(ROUND_MIX.scale(), HALF_EVEN);
  }

  public BigDecimal getCash() {
    return cash.setScale(ROUND_CASH.scale(), HALF_EVEN);
  }

  public BigDecimal getUnits() {
    return cash.multiply(price).setScale(ROUND_UNITS.scale(), HALF_EVEN);
  }

  public BigDecimal getRecordedCash() {
    return recordedCash.setScale(ROUND_CASH.scale(), HALF_EVEN);
  }

  public LocalDateTime getCreationTime() {
    return creationTime;
  }

  /** Unique Id of a ForecastModelAlloc. */
  public static class Id implements Serializable {

    private static final long serialVersionUID = -53268885398934967L;

    private final int modelId;
    private final int instrId;
    private final int fundId;
    private final int holdingId;

    /** Creates Id. */
    public Id(int modelId, int instrId, int fundId, int holdingId) {

      this.modelId = modelId;
      this.instrId = instrId;
      this.fundId = fundId;
      this.holdingId = holdingId;
    }

    public int getModelId() {
      return modelId;
    }

    public int getInstrId() {
      return instrId;
    }

    public int getFundId() {
      return fundId;
    }

    public int getHoldingId() {
      return holdingId;
    }

    @Override
    public boolean equals(Object obj) {

      if (obj == null) {
        return false;
      }
      if (getClass() != obj.getClass()) {
        return false;
      }
      final Id other = (Id) obj;
      return Objects.equals(this.getModelId(), other.getModelId())
          && Objects.equals(this.getInstrId(), other.getInstrId())
          && Objects.equals(this.getFundId(), other.getFundId())
          && Objects.equals(this.getHoldingId(), other.getHoldingId());
    }

    @Override
    public int hashCode() {

      return Objects.hash(modelId, instrId, fundId, holdingId);
    }

    @Override
    public String toString() {

      return MoreObjects.toStringHelper(this).add("modelId", modelId)
          .add("instrId", instrId).add("fundId", fundId)
          .add("holdingId", this.getHoldingId()).toString();
    }
  }

}
