package com.ilim.forecast.domain.model;

import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_CASH;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_MIX;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_PRICE;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_UNITS;
import static java.math.RoundingMode.HALF_EVEN;

import com.ilim.commons.domain.IEntity;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Forecast Model Allocation Entity.
 * 
 * <p>This represents the modelled allocation for a forecasted instruction.
 * 
 * @author alan larkin
 */
public final class ForecastModelAlloc implements IEntity<Integer> {

  private final int allocId;
  private final int instrId;
  private final int fundId;
  private final int holdingId;
  private final BigDecimal committedUnits;
  private final BigDecimal committedHeldUnits;
  private final BigDecimal forecastCommittedUnits;
  private final BigDecimal forecastCommittedHeldUnits;
  private final BigDecimal price;
  private final BigDecimal mix;
  private final BigDecimal cash;
  private final LocalDateTime creationTime;

  /** Creates a ForecastModelAlloc domain Entity. */
  public ForecastModelAlloc(int allocId, int instrId, int fundId, int holdingId,
      BigDecimal committedUnits, BigDecimal committedHeldUnits,
      BigDecimal forecastCommittedUnits, BigDecimal forecastCommittedHeldUnits,
      BigDecimal price, BigDecimal mix, BigDecimal cash,
      LocalDateTime creationTime) {

    this.allocId = allocId;
    this.instrId = instrId;
    this.fundId = fundId;
    this.holdingId = holdingId;
    this.committedUnits = committedUnits;
    this.committedHeldUnits = committedHeldUnits;
    this.forecastCommittedUnits = forecastCommittedUnits;
    this.forecastCommittedHeldUnits = forecastCommittedHeldUnits;
    this.price = price;
    this.mix = mix;
    this.cash = cash;
    this.creationTime = creationTime;
  }

  @Override
  public Integer getId() {
    return allocId;
  }

  public int getInstrId() {
    return instrId;
  }

  public int getFundId() {
    return fundId;
  }

  public int getHoldingId() {
    return holdingId;
  }

  public BigDecimal getCommittedUnits() {
    return committedUnits.setScale(ROUND_UNITS.scale(), HALF_EVEN);
  }

  public BigDecimal getCommittedHeldUnits() {
    return committedHeldUnits.setScale(ROUND_UNITS.scale(), HALF_EVEN);
  }

  public BigDecimal getForecastCommittedUnits() {
    return forecastCommittedUnits.setScale(ROUND_UNITS.scale(), HALF_EVEN);
  }

  public BigDecimal getForecastCommittedHeldUnits() {
    return forecastCommittedHeldUnits.setScale(ROUND_UNITS.scale(), HALF_EVEN);
  }

  public BigDecimal getPrice() {
    return price.setScale(ROUND_PRICE.scale(), HALF_EVEN);
  }

  public BigDecimal getMix() {
    return mix.setScale(ROUND_MIX.scale(), HALF_EVEN);
  }

  public BigDecimal getCash() {
    return cash.setScale(ROUND_CASH.scale(), HALF_EVEN);
  }

  public BigDecimal getUnits() {
    return cash.multiply(price).setScale(ROUND_UNITS.scale(), HALF_EVEN);
  }

  public LocalDateTime getCreationTime() {
    return creationTime;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final ForecastModelAlloc other = (ForecastModelAlloc) obj;
    return Objects.equals(this.getId(), other.getId());
  }

  @Override
  public int hashCode() {

    return Objects.hash(allocId);
  }

  @Override
  public String toString() {

    return MoreObjects.toStringHelper(this).add("allocId", getId())
        .add("instrId", instrId).add("fundId", getFundId())
        .add("holdingId", getHoldingId())
        .add("committedUnits", getCommittedUnits())
        .add("committedHeldUnits", getCommittedHeldUnits())
        .add("forecastCommittedUnits", getForecastCommittedUnits())
        .add("forecastCommittedHeldUnits", getForecastCommittedHeldUnits())
        .add("price", getPrice()).add("mix", getMix()).add("cash", getCash())
        .add("units", getUnits()).toString();
  }

}
