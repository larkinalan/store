package com.ilim.forecast.domain.model;

import java.math.BigDecimal;

public class PendingInstruction {

  public final int id;
  public final int type;
  public final int fundId;
  public final BigDecimal cash;

  public PendingInstruction(int instrId, int typeId, int fundId,
      BigDecimal cash) {

    this.id = instrId;
    this.type = typeId;
    this.fundId = fundId;
    this.cash = cash;
  }
}
