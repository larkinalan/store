package com.ilim.forecast.domain.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class PendingInstruction {

  public final int id;
  public final LocalDate forecastDate;
  public final int type;
  public final int fundId;
  public final BigDecimal cash;

  public PendingInstruction(int instrId, LocalDate forecastDate, int typeId,
      int fundId, BigDecimal cash) {

    this.id = instrId;
    this.forecastDate = forecastDate;
    this.type = typeId;
    this.fundId = fundId;
    this.cash = cash;
  }
}
