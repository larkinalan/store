package com.ilim.forecast.app.service;

import com.ilim.commons.domain.IEvent;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.ProcessingForecastInstruction;

import java.util.List;

@FunctionalInterface
public interface IForecastModeller {

  List<ForecastModelAlloc> model(IEvent<ProcessingForecastInstruction> instr);

}
