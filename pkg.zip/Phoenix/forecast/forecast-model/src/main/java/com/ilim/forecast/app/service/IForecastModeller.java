package com.ilim.forecast.app.service;

import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.PendingInstruction;

import java.util.List;

@FunctionalInterface
public interface IForecastModeller {

  List<ForecastModelAlloc> model(PendingInstruction instr);

}
