Forecast modeller
=================
*This is the Phoenix project forecast modelling calculator*

This is where all the calcs for forecast modelling live.
Everything is done in memory, you must pass the inputs to the API and 
it will output a forecast model as a result.
  - file IO is managed in units test.
  - DB persistance is managed by the forecast-service

build
-----
   
`mvn clean install`

*requires* 
* [Java8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)   
* [Maven3](https://maven.apache.org/)

test
----
All tests  

`mvn clean test`

Single test 

`mvn -Dtest=FundOfFundsTest test`  

deploy
------

`mvn clean deploy`

typically you will add this jar to a war then deploy to a jboss app server 

libs
----

`mvn dependency:tree`

docs
----
* [Architecture](L:\ITUNIT\PROJECTS\Strategy\FMA_Phoenix\System Architecture\phoenix-architecture.docx)  
* [confluence](http://ilm12807:7090/).
