package com.ilim.forecast.domain;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/*
 * Fund Holding Data Type
 */
public class FundHolding {

  public final Fund fund;
  public final Fund holding;
  public final BigDecimal unitsHeld;

  public FundHolding(Fund fund, Fund holding, BigDecimal unitsHeld) {

    this.fund = fund;
    this.holding = holding;
    this.unitsHeld = unitsHeld;
  }
  
  public BigDecimal cash(BigDecimal price) {
    return unitsHeld.multiply(price);
  }

  public BigDecimal units() {
    return unitsHeld;
  }
  
  @Override
  public boolean equals(Object obj) {

    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;

    final FundHolding other = (FundHolding) obj;
    return Objects.equals(this.fund, other.fund)
        && Objects.equals(this.holding, other.holding);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.fund, this.holding);
  }

  public String toString() {
    return MoreObjects.toStringHelper(this).addValue(fund).addValue(holding)
        .toString();
  }

}
