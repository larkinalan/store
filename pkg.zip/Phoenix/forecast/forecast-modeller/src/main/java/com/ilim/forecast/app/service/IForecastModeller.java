package com.ilim.forecast.app.service;

import com.ilim.forecast.domain.PendingInstruction;
import com.ilim.forecast.domain.ForecastModelAllocation;

import java.util.List;

@FunctionalInterface
public interface IForecastModeller {

  List<ForecastModelAllocation> model(PendingInstruction instr);

}
