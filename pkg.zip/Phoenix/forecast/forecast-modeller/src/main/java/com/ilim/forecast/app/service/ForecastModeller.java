package com.ilim.forecast.app.service;

import com.ilim.forecast.domain.ForecastModelAllocation;
import com.ilim.forecast.domain.FundHolding;
import com.ilim.forecast.domain.FundOfFundsGraph;
import com.ilim.forecast.domain.PendingInstruction;

import com.google.common.collect.ImmutableMap;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class ForecastModeller implements IForecastModeller {

  private final ImmutableMap<String, FundHolding> positions;
  private final ImmutableMap<Integer, BigDecimal> prices;

  public ForecastModeller(List<FundHolding> fundHoldingPositions,
      Map<Integer, BigDecimal> prices) {

    this.positions = mapOf(fundHoldingPositions).build();
    this.prices = ImmutableMap.copyOf(prices);
  }

  @Override
  public List<ForecastModelAllocation> model(PendingInstruction instr) {

    FundOfFundsGraph fof = new FundOfFundsGraph(positions, prices);
    //fof.print();
    // TODO: this may take some time ??? might want a q + futures etc...
    return fof.modelDFS(instr);
  }
  
  public static ImmutableMap.Builder<String, FundHolding> mapOf(
      List<FundHolding> fundHoldingPositions) {

    ImmutableMap.Builder<String, FundHolding> builder = ImmutableMap.builder();

    for (FundHolding fh : fundHoldingPositions) {
      String key = fh.fund.id + ":" + fh.holding.id;
      builder.put(key, fh);
    }
    return builder;
  }

}
