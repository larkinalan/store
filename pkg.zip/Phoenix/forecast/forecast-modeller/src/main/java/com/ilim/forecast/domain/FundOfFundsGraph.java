package com.ilim.forecast.domain;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkState;

import static com.ilim.forecast.domain.ForecastCalculator.cashValue;
import static com.ilim.forecast.domain.ForecastCalculator.unitPositionMove;

import com.ilim.forecast.domain.Fund.Level;

import static com.ilim.forecast.domain.ForecastCalculator.cashMove;
import static com.ilim.forecast.domain.ForecastCalculator.latestMix;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;

/**
 *  A FundModel, implemented using an adjacency list.
 *  Parallel edges and self-loops are permitted. 
 *  TODO: disable these! 
 *
 *  <p>example 1:
 *  13 vertices, 22 edges
 *  0: 5 1 
 *  1: 
 *  2: 0 3 
 *  3: 5 2 
 *  4: 3 2 
 *  5: 4 
 *  6: 9 4 8 0 
 *  7: 6 9
 *  8: 6 
 *  9: 11 10 
 *  10: 12 
 *  11: 4 12 
 *  12: 9   
 *  
 *  <p>example 2:
 *  3 vertices, 5 edges
 *  101: 201
 *  201: 301
 *  301: 401 402, 403 
 *  
 */
public class FundOfFundsGraph {

  private final ImmutableMap<Integer, BigDecimal> prices;
  private final ImmutableMap<String, FundHolding> positions;
  private final ImmutableSet<Fund> rootFunds;
  private final Multimap<Fund, Fund> adjacencyList;
  
  public FundOfFundsGraph(ImmutableMap<String, FundHolding> positions,
      Map<Integer, BigDecimal> prices) {

    // cache of prices
    checkArgument(prices != null && prices.size() != 0, "Missing prices");
    this.prices = ImmutableMap.copyOf(prices);

    // cache of current positions
    checkArgument(positions != null && positions.size() != 0,
        "Missing positions!");
    this.positions = ImmutableMap.copyOf(positions);

    // build graph
    Set<Fund> clients = new HashSet<>();
    // Using linked  list maintain order
    this.adjacencyList =
        MultimapBuilder.linkedHashKeys().arrayListValues().build(); 
    for (FundHolding fh : positions.values()) {
      
      addEdge(fh.fund, fh.holding);
      
      if (fh.fund.level.equals(Level.CLIENT)) {
        clients.add(fh.fund);
      }
    }
    this.rootFunds = ImmutableSet.copyOf(clients);
  }

  /**
   * Adds the directed edge f->h to.
   *
   * @param  fund the tail vertex
   * @param  holding the head vertex
   * @throws IllegalArgumentException
   */
  public void addEdge(Fund fund, Fund holding) {

    checkSelfloop(fund, holding);
    checkParallelEdge(fund, holding);
    checkRelationship(fund, holding);

    adjacencyList.put(fund, holding);
  }

  /* Returns number of Fund vertices */
  public int vertices() {

    return adjacencyList.keySet().size();
  }

  /* Returns number of Holding edges */
  public int edges() {

    return adjacencyList.entries().size();
  }

  /* Returns indegree of fund vertex f */
  public int indegree(Fund f) {

    return adjacencyList.get(f).size();
  }

  /*
   *  //System.out.println(prefix + (isLeaf() ? "|- " : "|+ ") + this + " with " + fund.asString());
      
      System.out.println(a.fundHolding.fund);
      System.out.println("|  " + a.fundHolding.holding);
   */
 
  /** Breath First Search */
  public List<ForecastModelAllocation> modelOld(PendingInstruction instr) {

    final List<ForecastModelAllocation> allocs = new ArrayList<>();
    Queue<Fund> q = new ArrayDeque<>(edges());
    Set<String> visited = new HashSet<>();

    BigDecimal cashToAllocate = instr.cash; // cash to model

    q.offer(instr.fund); // client fund
    while (!q.isEmpty()) {

      Fund fund = q.poll();
      List<Fund> holdings = (List<Fund>) adjacencyList.get(fund);
      final BigDecimal currentValue = cashValue(fund, price(fund.id));
      BigDecimal allocatedCash = BigDecimal.ZERO;

      for (Fund holding : holdings) {

        // TODO: this will break for multiple tax, we need to store the parents.  
        final String fundHolding = makeKey(fund.id, holding.id);
        
        if (!visited.contains(fundHolding)) {

          final FundHolding currentPostion = position(fund.id, holding.id);
          final BigDecimal price = price(holding.id);
          
          ForecastModelAllocation alloc =
              allocateLatestMix(fund, holding, holdings.size(), cashToAllocate,
                  currentValue, currentPostion, price, instr.id, instr.type);
          
          allocatedCash = allocatedCash.add(alloc.cash);

          allocs.add(alloc);
          visited.add(fundHolding); 
          q.offer(holding);
        }
      }

      validate(fund, cashToAllocate, allocatedCash);
      cashToAllocate = allocatedCash; // allocate the cash to holdings
    }

    return allocs;
  }
  
  /** Breath First Search */
  public List<ForecastModelAllocation> modelBFS(PendingInstruction instr) {

    final List<ForecastModelAllocation> allocs = new ArrayList<>();

    Map<Fund, BigDecimal> fundCash =
        memoize(instr.fund, instr.cash, new HashMap<>());

    Set<Fund> visited = new HashSet<>();
    Queue<Fund> q = new ArrayDeque<>(edges());
    q.offer(instr.fund);
    
    while (!q.isEmpty()) {

      Fund fund = q.poll();
      final BigDecimal cashToAllocate = fundCash.get(fund);
      final BigDecimal fundValue = cashValue(fund, price(fund.id));
      List<Fund> holdings = (List<Fund>) adjacencyList.get(fund);

      for (Fund holding : holdings) {

        FundHolding currentPostion = position(fund.id, holding.id);

        ForecastModelAllocation alloc =
            allocateLatestMix(fund, holding, cashToAllocate, fundValue,
                currentPostion, price(holding.id), instr.id, instr.type);
        
        if (!visited.contains(holding)) {
          memoize(holding, alloc.cash, fundCash);
        }
        
        allocs.add(alloc);
        visited.add(holding);
        q.offer(holding);
      }
    }

    print(); 
    return allocs;
  }
  
  /** Depth First Search */
  public List<ForecastModelAllocation> modelDFS(PendingInstruction instr) {

    final List<ForecastModelAllocation> allocs = new ArrayList<>();

    Map<Fund, BigDecimal> fundCash =
        memoize(instr.fund, instr.cash, new HashMap<>());

    Set<Fund> visited = new HashSet<>();
    Deque<Fund> stack = new ArrayDeque<>(edges());
    stack.push(instr.fund);
    
    while (!stack.isEmpty()) {

      Fund fund = stack.pop();
      final BigDecimal cashToAllocate = fundCash.get(fund);
      final BigDecimal fundValue = cashValue(fund, price(fund.id));
      List<Fund> holdings = (List<Fund>) adjacencyList.get(fund);

      for (Fund holding : holdings) {

        FundHolding currentPostion = position(fund.id, holding.id);

        ForecastModelAllocation alloc =
            allocateLatestMix(fund, holding, cashToAllocate, fundValue,
                currentPostion, price(holding.id), instr.id, instr.type);
        
        if (!visited.contains(holding)) {
          memoize(holding, alloc.cash, fundCash);
        }
        
        allocs.add(alloc);
        visited.add(holding);
        stack.push(holding);
      }
    }

    print();
    return allocs;
  }
  
  private Map<Fund, BigDecimal> memoize(Fund fund, BigDecimal cash,
      Map<Fund, BigDecimal> fundCash) {

    BigDecimal allocatedCash = fundCash.get(fund);
    if (allocatedCash == null) {
      fundCash.put(fund, cash);
    } else {
      fundCash.put(fund, allocatedCash.add(cash));
    }
    return fundCash;
  }

  /**
   * Calculates a fund -> holding allocation using latest mix
   * 
   * @param fund the parent fund
   * @param holding the child holding or underlying fund
   * @param holdings the number of holdings in the fund
   * @param cash to allocate
   * @param currentValue f the fund (cash)
   * @param currentPostioncurrent unit position of the fund->holding
   * @param price the latest price
   * @param instrId instruction id
   * @param instrType instruction type  
   * 
   * @author Alan Larkin
   */
  public ForecastModelAllocation allocateLatestMix(Fund fund, Fund holding,
      int holdings, BigDecimal totalCash, BigDecimal currentValue,
      FundHolding currentPostion, BigDecimal price, int instrId,
      int instrType) {

    final BigDecimal mix =
        latestMix(fund, holding, holdings, price, currentValue);
    final BigDecimal cashMove = cashMove(totalCash, mix);
    final FundHolding newPosition = new FundHolding(fund, holding,
        unitPositionMove(currentPostion, cashMove, price));

    return new ForecastModelAllocation(newPosition, instrId, instrType, mix,
        cashMove);
  }
  
  public ForecastModelAllocation allocateLatestMix(Fund fund, Fund holding, 
      BigDecimal cashToAllocate, BigDecimal fundValue,
      FundHolding currentPostion, BigDecimal price,
      int instrId, int instrType) {

    final BigDecimal holdingValue = cashValue(currentPostion.unitsHeld, price);
    final BigDecimal mix = latestMix(fundValue, holdingValue);
    final BigDecimal cashMove = cashMove(cashToAllocate, mix);
    System.out.println(fund + ", " + holding + ",  cashToAllocate "
        + cashToAllocate + ",  mix " + mix + ", cashMove " + cashMove);

    final FundHolding newPosition = new FundHolding(fund, holding,
        unitPositionMove(currentPostion, cashMove, price));

    return new ForecastModelAllocation(newPosition, instrId, instrType, mix,
        cashMove);
  }


  public void validate(Fund fund, BigDecimal cashToAllocate,
      BigDecimal allocatedCash) {

    if (!fund.level.equals(Fund.Level.INVESTING)) {

      checkState(allocatedCash.compareTo(cashToAllocate) != -1,
          "Under allocated " + fund + " , cashToAllocate=" + cashToAllocate
              + " , allocatedCash=" + allocatedCash + " , diff="
              + cashToAllocate.subtract(allocatedCash));
      
      checkState(allocatedCash.compareTo(cashToAllocate) != 1,
          "Over allocated " + fund + " , cashToAllocate=" + cashToAllocate
              + " , allocatedCash=" + allocatedCash + " , diff="
              + cashToAllocate.subtract(allocatedCash));
    }
  }

  public FundHolding position(int fundId, int holdingId) {

    return positions.get(makeKey(fundId, holdingId));
  }
  
  public String makeKey(int fundId, int holdingId) {
    return fundId + ":" + holdingId;
  }

  public BigDecimal price(int fundId) {

    return prices.getOrDefault(fundId, BigDecimal.ZERO).setScale(6,
        RoundingMode.HALF_EVEN);
  }

  public void breathFirstSearch(Fund fund) {

    Queue<Fund> q = new ArrayBlockingQueue<>(edges());
    Set<Fund> marked = new HashSet<>(); // is there an fund->vertex path?
    Map<Fund, Integer> distTo = new HashMap<>(); // last edge on shortest fund->vertex path
    Map<Fund, Fund> edgeTo = new HashMap<>(); // length of shortest fund->vertex path

    q.offer(fund);

    while (!q.isEmpty()) {

      Fund vertex = q.poll();
      List<Fund> edges = (List<Fund>) adjacencyList.get(vertex);

      for (Fund f : edges) {

        if (!marked.contains(f)) {

          edgeTo.put(f, vertex);
          distTo.put(f, distTo.getOrDefault(vertex, 0) + 1);
          marked.add(f);
          q.offer(f);
        }
      }
    }

    printMarked(marked);
    printDistTo(distTo);
    printEdgeTo(edgeTo);

  }

  // Multiple soruces
  public void breathFirstSearch(Fund... funds) {

    Queue<Fund> q = new ArrayDeque<>(edges());
    Set<Fund> marked = new HashSet<>(); // is there an fund->vertex path?
    Map<Fund, Integer> distTo = new HashMap<>(); // last edge on shortest fund->vertex path
    Map<Fund, Fund> edgeTo = new HashMap<>(); // length of shortest fund->vertex path

    for (Fund f : funds) {
      q.offer(f);
    }

    while (!q.isEmpty()) {

      Fund vertex = q.poll();

      List<Fund> edges = (List<Fund>) adjacencyList.get(vertex);
      for (Fund e : edges) {

        if (!marked.contains(e)) {

          edgeTo.put(e, vertex);
          distTo.put(e, distTo.getOrDefault(vertex, 0) + 1);
          marked.add(e);
          q.offer(e);
        }
      }
    }

    printMarked(marked);
    printDistTo(distTo);
    printEdgeTo(edgeTo);
  }

  private void checkSelfloop(Fund fund, Fund holding) {

    checkArgument(fund.id != holding.id, "Self loops are not allowed /n "
        + " FUND [ " + fund + " ] " + " HOLDING [ " + holding + " ] ");
  }

  private void checkParallelEdge(Fund fund, Fund holding) {

    checkArgument(!adjacencyList.containsEntry(fund, holding),
        "Parralled edges not allowed /n " + " FUND [ " + fund + " ] "
            + " HOLDING [ " + holding + " ] ");
  }

  private void checkRelationship(Fund fund, Fund holding) {

    checkArgument(holding.level.isChild(fund.level),
        "holding must be child level of fund  /n " + " FUND [ " + fund + ", "
            + fund.level + " ] " + " HOLDING [ " + holding + ", "
            + holding.level + " ] ");
  }


  private static void printMarked(Set<Fund> marked) {

    System.out.println("CAN BE REACHED FROM");
    for (Fund m : marked) {
      System.out.println("marked with fund->vertex path : " + m);
    }
  }

  private static void printDistTo(Map<Fund, Integer> distTo) {

    System.out.println("DISTANCE TO");
    for (Map.Entry<Fund, Integer> d : distTo.entrySet()) {
      System.out.println(d.getKey() + " has shortest length " + d.getValue());
    }
  }

  private static void printEdgeTo(Map<Fund, Fund> edgeTo) {

    System.out.println("EDGES TO");
    for (Map.Entry<Fund, Fund> d : edgeTo.entrySet()) {
      System.out.println(d.getKey()
          + " length of shortest fund->vertex path is " + d.getValue());
    }
  }
  
  /*
  public void print() {

    Queue<Fund> q = new ArrayDeque<>(edges());

    // Add all clients
    for (Fund f : rootFunds) {
      q.offer(f);
    }

    System.out.println("FundOfFunds");
    String prefix = "";
    while (!q.isEmpty()) {

      Fund fund = q.poll();
      List<Fund> holdings = (List<Fund>) adjacencyList.get(fund);
      
      if (holdings.isEmpty()) {
        System.out.println("|- " + fund.id);
      } else {
        System.out.println("|+ " + fund.id);
      }

      prefix += "|  ";
      for (Fund holding : holdings) {
        System.out.println(prefix + holding.id);
        q.offer(holding);
      }
    }
  }
  */
  
  public void print() {
    
    System.out.println("");
    System.out.println("=============== FoF Graph ======================");

    Deque<Fund> stack = new ArrayDeque<>(edges());
    for (Fund f : rootFunds) {
      stack.push(f);
    }

    while (!stack.isEmpty()) {

      Fund fund = stack.pop();
      List<Fund> holdings = (List<Fund>) adjacencyList.get(fund);
      print(fund, holdings.isEmpty());
      for (Fund holding : holdings) {
        stack.push(holding);
      }
    }

    System.out.println("");
  }
   
  private static void print(Fund fund, boolean isLeaf) {
    
    String prefix = "";
    if (fund.level.equals(Level.TAX)) {
      prefix = " ";
    } else if (fund.level.equals(Level.PRIMARY)) {
      prefix = "  ";
    } else if (fund.level.equals(Level.INVESTING)) {
      prefix = "   ";
    }
    
    System.out.println(prefix + (isLeaf ? "|- " : "|+ ") + fund.id);
      //  + ", " + fund.level.name());
  }

}


