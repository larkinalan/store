package com.ilim.forecast.domain;

import java.math.BigDecimal;

public class PendingInstruction {

  public final int id;
  public final int type;
  public final Fund fund;
  public final BigDecimal cash;

  public PendingInstruction(int instrId, int typeId, Fund fund,
      BigDecimal cash) {
    
    this.id = instrId;
    this.type = typeId;
    this.fund = fund;
    this.cash = cash;
  }
}
