package com.ilim.forecast.domain;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

public class Fund {

  public final int id;
  public final Fund.Level level;
  public final BigDecimal unitsInIssue;

  public Fund(int fundId, Fund.Level level, BigDecimal unitsInIssue) {

    this.id = fundId;
    this.level = level;
    this.unitsInIssue = unitsInIssue;
  }
  
  public BigDecimal cash(BigDecimal price) {
      return unitsInIssue.multiply(price);
  }
  
  public BigDecimal units() {
    return unitsInIssue;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;

    final Fund other = (Fund) obj;
    return Objects.equals(this.id, other.id);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(this.id);
  }

  public String toString() {
    return MoreObjects.toStringHelper(this).add("id", id).toString();
  }
  
  public enum Level {

    CLIENT(1), TAX(2), PRIMARY(3), INVESTING(4);

    private int id;

    Level(int id) {
      this.id = id;
    }

    public int id() {
      return id;
    }
    
    // Assumes order */
    public boolean isChild(Fund.Level parent) {
      return id > parent.id() && (id - parent.id()) == 1;
    }

  }

}
