package com.ilim.forecast.domain;

import com.google.common.collect.ImmutableMap;

import java.math.BigDecimal;
import java.util.Map;

// Very simple thread safe singleton of prices;
public enum FundPrices {

  INSTANCE; 

  private ImmutableMap<Integer, BigDecimal> prices;

  private FundPrices() {}
  
  private ImmutableMap<Integer, BigDecimal> prices() {

    return prices;
  }

  public void load(Map<Integer, BigDecimal> prices) {
    
    prices = ImmutableMap.copyOf(prices);
  }
 
  public static BigDecimal price(Integer fundId) {

    //TODO: make default one in dev unless config is set
    return INSTANCE.prices().getOrDefault(fundId, BigDecimal.ZERO);
  }
}
