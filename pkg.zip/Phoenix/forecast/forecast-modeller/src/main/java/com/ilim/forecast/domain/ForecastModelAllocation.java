package com.ilim.forecast.domain;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/*
 * Modeled position values of a fund;
 */
public class ForecastModelAllocation {

  public final FundHolding fundHolding;
  public final int instrId;
  public final int typeId;
  public final BigDecimal mix;
  public final BigDecimal cash;

  public ForecastModelAllocation(FundHolding fundHolding, int instrId,
      int typeId, BigDecimal mix, BigDecimal cash) {

    this.fundHolding = fundHolding;
    this.instrId = instrId;
    this.typeId = typeId;
    this.mix = mix;
    this.cash = cash;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;

    final ForecastModelAllocation other = (ForecastModelAllocation) obj;
    return Objects.equals(this.fundHolding, other.fundHolding)
        && Objects.equals(this.instrId, other.instrId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.fundHolding, this.instrId);
  }

  public String toString() {
    return MoreObjects.toStringHelper(this).addValue(fundHolding)
        .add("instr", instrId).add("typeId", typeId).add("mix", mix)
        .add("cash", cash).toString();
  }

}
