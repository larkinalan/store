package com.ilim.forecast;

import static com.ilim.forecast.domain.Fund.Level.CLIENT;
import static com.ilim.forecast.domain.Fund.Level.INVESTING;
import static com.ilim.forecast.domain.Fund.Level.PRIMARY;
import static com.ilim.forecast.domain.Fund.Level.TAX;

import com.ilim.forecast.domain.Fund;
import com.ilim.forecast.domain.FundHolding;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestData {


  // FUND DATA
  public static final Fund C101 = new Fund(101, CLIENT, new BigDecimal("100"));
  
  public static final Fund T201 = new Fund(201, TAX, new BigDecimal("100"));
  public static final Fund T202 = new Fund(202, TAX, new BigDecimal("100"));
  
  public static final Fund P301 = new Fund(301, PRIMARY, new BigDecimal("100"));
  public static final Fund P302 = new Fund(302, PRIMARY, new BigDecimal("100"));
  
  public static final Fund I401 =
      new Fund(401, INVESTING, new BigDecimal("100"));
  public static final Fund I402 =
      new Fund(402, INVESTING, new BigDecimal("100"));
  public static final Fund I403 =
      new Fund(403, INVESTING, new BigDecimal("100"));
  public static final Fund I404 =
      new Fund(404, INVESTING, new BigDecimal("100"));
  public static final Fund I405 =
      new Fund(405, INVESTING, new BigDecimal("100"));
  

  public static List<FundHolding> fundHoldings() {

    List<FundHolding> fundHoldings = new ArrayList<>();
    // client -> tax
    fundHoldings.add(new FundHolding(C101, T201, new BigDecimal("50")));
    fundHoldings.add(new FundHolding(C101, T202, new BigDecimal("50")));
    
    // tax -> primary
    fundHoldings.add(new FundHolding(T201, P301, new BigDecimal("100")));
    fundHoldings.add(new FundHolding(T202, P301, new BigDecimal("50"))); //complex
    fundHoldings.add(new FundHolding(T202, P302, new BigDecimal("50")));
    
    // primary -> investing
    fundHoldings.add(new FundHolding(P301, I401, new BigDecimal("100")));
    fundHoldings.add(new FundHolding(P301, I402, new BigDecimal("50")));
    fundHoldings.add(new FundHolding(P301, I403, new BigDecimal("25")));
    fundHoldings.add(new FundHolding(P302, I404, new BigDecimal("25")));
    fundHoldings.add(new FundHolding(P302, I405, new BigDecimal("25")));

    /*
    // tax -> primary
    fundHoldings.add(new FundHolding(T201, P301, new BigDecimal("50")));
    fundHoldings.add(new FundHolding(T202, P301, new BigDecimal("25")));
    fundHoldings.add(new FundHolding(T202, P302, new BigDecimal("25")));
    // primary -> investing
    fundHoldings.add(new FundHolding(P301, I401, new BigDecimal("50")));
    fundHoldings.add(new FundHolding(P301, I402, new BigDecimal("20")));
    fundHoldings.add(new FundHolding(P301, I403, new BigDecimal("5")));
    fundHoldings.add(new FundHolding(P302, I404, new BigDecimal("15")));
    fundHoldings.add(new FundHolding(P302, I405, new BigDecimal("10")));
    */
    return fundHoldings;
  }

  
  // simple fund AAQ
  public static final Fund C_AAQ = new Fund(37881, CLIENT, new BigDecimal("8076976"));
  public static final Fund T_TRIA = new Fund(37707, TAX, new BigDecimal("24349721.528"));
  public static final Fund P_TRIA = new Fund(37708, PRIMARY, new BigDecimal("24349721.538"));
  public static final Fund I_AAAMBF = new Fund(35647, INVESTING, new BigDecimal("24349721.538"));
  
  public static final Fund C_T186 = new Fund(57592, CLIENT, new BigDecimal("11020"));
  public static final Fund T_T186 = new Fund(57593, TAX, new BigDecimal("11019.999"));
  public static final Fund P_T186 = new Fund(57594, PRIMARY, new BigDecimal("11019.999"));
  public static final Fund I_TRAN186 = new Fund(57612, INVESTING, new BigDecimal("11019.999"));
  
  public static List<FundHolding> AAQ_fundHoldings() {
  
    List<FundHolding> fundHoldings = new ArrayList<>();
    fundHoldings.add(new FundHolding(C_AAQ, T_TRIA, new BigDecimal("7947409.393")));
    fundHoldings.add(new FundHolding(T_TRIA, P_TRIA, new BigDecimal("24349721.538")));
    fundHoldings.add(new FundHolding(P_TRIA, I_AAAMBF, new BigDecimal("24349737.373")));
    
    fundHoldings.add(new FundHolding(C_T186, T_T186, new BigDecimal("11019.999")));
    fundHoldings.add(new FundHolding(T_T186, P_T186, new BigDecimal("11019.999")));
    fundHoldings.add(new FundHolding(P_T186, I_TRAN186, new BigDecimal("11019.999")));
    
    return fundHoldings;
  }
  
  
  // multi tax fund AGBP
  public static final Fund C_AGBP = new Fund(59151, CLIENT, new BigDecimal("6508015"));
  public static final Fund T_AGFA = new Fund(57414, TAX, new BigDecimal("57866900.468"));
  public static final Fund T_IPRP = new Fund(17772, TAX, new BigDecimal("479822938.396"));
  public static final Fund P_AGFA = new Fund(57415, PRIMARY, new BigDecimal("57866900.468"));
  public static final Fund P_IPRP = new Fund(200, PRIMARY, new BigDecimal("479822938.21"));
  public static final Fund I_MINVOL = new Fund(42005, INVESTING, new BigDecimal("140378335.309"));
  public static final Fund I_EMERGMKT = new Fund(18911, INVESTING, new BigDecimal("112954383.864"));
  public static final Fund I_IPAIBM = new Fund(8828, INVESTING, new BigDecimal("241642804.247"));
  public static final Fund I_IPAIPE = new Fund(209, INVESTING, new BigDecimal("660310422.448"));
  public static final Fund I_IPAINA = new Fund(208, INVESTING, new BigDecimal("617536855.955"));
  public static final Fund I_ILIMRAFI = new Fund(43865, INVESTING, new BigDecimal("19445629.563"));
  public static final Fund I_IPAIEE = new Fund(203, INVESTING, new BigDecimal("351146383.167"));
  public static final Fund I_IPAIEN = new Fund(4633, INVESTING, new BigDecimal("835688283.838"));
  public static final Fund I_IPAIUF = new Fund(6815, INVESTING, new BigDecimal("555130528.342"));
  public static final Fund I_IPRP = new Fund(7, INVESTING, new BigDecimal("1374088823.942"));
  public static final Fund I_IPAIJE = new Fund(207, INVESTING, new BigDecimal("5150956439.475"));
  
  
  public static List<FundHolding> AGBP_fundHoldings() {
  
    List<FundHolding> fundHoldings = new ArrayList<>();
    fundHoldings.add(new FundHolding(C_AGBP, T_AGFA, new BigDecimal("5839460.084")));
    fundHoldings.add(new FundHolding(C_AGBP, T_IPRP, new BigDecimal("488218.314")));
    
    fundHoldings.add(new FundHolding(T_AGFA, P_AGFA, new BigDecimal("57866900.468")));
    fundHoldings.add(new FundHolding(T_IPRP, P_IPRP, new BigDecimal("479588106.556")));
    
    fundHoldings.add(new FundHolding(P_AGFA, I_MINVOL, new BigDecimal("9362112.861")));
    fundHoldings.add(new FundHolding(P_AGFA, I_EMERGMKT, new BigDecimal("1468688.914")));
    fundHoldings.add(new FundHolding(P_AGFA, I_IPAIBM, new BigDecimal("1026537.014")));
    fundHoldings.add(new FundHolding(P_AGFA, I_IPAIPE, new BigDecimal("2596699.385")));
    fundHoldings.add(new FundHolding(P_AGFA, I_IPAINA, new BigDecimal("1329591.074")));
    fundHoldings.add(new FundHolding(P_AGFA, I_ILIMRAFI, new BigDecimal("9966657.978")));
    fundHoldings.add(new FundHolding(P_AGFA, I_IPAIEE, new BigDecimal("345857.749")));
    fundHoldings.add(new FundHolding(P_AGFA, I_IPAIEN, new BigDecimal("2963682.021")));
    fundHoldings.add(new FundHolding(P_AGFA, I_IPAIUF, new BigDecimal("831038.645")));
    fundHoldings.add(new FundHolding(P_AGFA, I_IPAIJE, new BigDecimal("8913758.411")));
    
    fundHoldings.add(new FundHolding(P_IPRP, I_IPRP, new BigDecimal("653808022.282")));
    
    return fundHoldings;
  }
  
  

  public static Map<Integer, BigDecimal> prices() {

    Map<Integer, BigDecimal> prices = new HashMap<>();
    prices.put(C101.id, new BigDecimal("1.0"));
  //  prices.put(C102.id, new BigDecimal("1.0"));
    prices.put(T201.id, new BigDecimal("1.0"));
    prices.put(T202.id, new BigDecimal("1.0"));
    prices.put(P301.id, new BigDecimal("1.0"));
    prices.put(P302.id, new BigDecimal("1.0"));
    prices.put(I401.id, new BigDecimal("1.0"));
    prices.put(I402.id, new BigDecimal("1.0"));
    prices.put(I403.id, new BigDecimal("1.0"));
    prices.put(I404.id, new BigDecimal("1.0"));
    prices.put(I405.id, new BigDecimal("1.0"));
    
    // simple fund AAQ
    prices.put(C_AAQ.id, new BigDecimal("1.577068"));
    prices.put(T_TRIA.id, new BigDecimal("1.602779"));
    prices.put(P_TRIA.id, new BigDecimal("1.602779"));
    prices.put(I_AAAMBF.id, new BigDecimal("1.602778"));
    
    prices.put(C_T186.id, new BigDecimal("1.353322"));
    prices.put(T_T186.id, new BigDecimal("1.353322"));
    prices.put(P_T186.id, new BigDecimal("1.353322"));
    prices.put(I_TRAN186.id, new BigDecimal("1.353322"));
    
    // multi tax fund AGBP
    prices.put(C_AGBP.id, new BigDecimal("0.949007"));
    prices.put(T_AGFA.id, new BigDecimal("0.95032"));
    prices.put(T_IPRP.id, new BigDecimal("1.283844"));
    prices.put(P_AGFA.id, new BigDecimal("0.95032"));
    prices.put(P_IPRP.id, new BigDecimal("1.283844"));
    prices.put(I_MINVOL.id, new BigDecimal("1.660951"));
    prices.put(I_EMERGMKT.id, new BigDecimal("5.353279"));
    prices.put(I_IPAIBM.id, new BigDecimal("0.312063"));
    prices.put(I_IPAIPE.id, new BigDecimal("0.472092"));
    prices.put(I_IPAINA.id, new BigDecimal("6.919622"));
    prices.put(I_ILIMRAFI.id, new BigDecimal("1.565051"));
    prices.put(I_IPAIEE.id, new BigDecimal("4.962743"));
    prices.put(I_IPAIEN.id, new BigDecimal("0.298778"));
    prices.put(I_IPAIUF.id, new BigDecimal("1.38963"));
    prices.put(I_IPRP.id, new BigDecimal("0.941739"));
    prices.put(I_IPAIJE.id, new BigDecimal("0.165835"));
    
    return prices;
  }


}
