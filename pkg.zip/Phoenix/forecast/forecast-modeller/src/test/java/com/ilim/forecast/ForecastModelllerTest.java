package com.ilim.forecast;

import static org.junit.Assert.*;

import com.ilim.forecast.app.service.ForecastModeller;
import com.ilim.forecast.app.service.IForecastModeller;
import com.ilim.forecast.domain.ForecastModelAllocation;
import com.ilim.forecast.domain.PendingInstruction;

import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

public class ForecastModelllerTest {

  @Test
  public void process() {

    IForecastModeller modeller =
        new ForecastModeller(TestData.fundHoldings(), TestData.prices());

    PendingInstruction instr = new PendingInstruction(1, 1,
        TestData.C101, new BigDecimal("15"));

    List<ForecastModelAllocation> model = modeller.model(instr);
    assertTrue(model.size() > 0);
  }
  
  
  @Test
  public void process_AAQ() {

    IForecastModeller modeller =
        new ForecastModeller(TestData.AAQ_fundHoldings(), TestData.prices());

    PendingInstruction instr = new PendingInstruction(1, 1,
        TestData.C_AAQ, new BigDecimal("2362985.46"));

    List<ForecastModelAllocation> model = modeller.model(instr);
    assertTrue(model.size() > 0);
  }
  
  
  @Test
  public void process_AGBP() {

    IForecastModeller modeller =
        new ForecastModeller(TestData.AGBP_fundHoldings(), TestData.prices());

    PendingInstruction instr = new PendingInstruction(1, 1,
        TestData.C_AGBP, new BigDecimal("1000"));

    List<ForecastModelAllocation> model = modeller.model(instr);
    assertTrue(model.size() > 0);
  }
  
}
  