package com.ilim.forecast;

import static com.ilim.forecast.domain.Fund.Level.PRIMARY;
import static org.junit.Assert.assertEquals;

import com.ilim.forecast.app.service.ForecastModeller;
import com.ilim.forecast.domain.Fund;
import com.ilim.forecast.domain.FundHolding;
import com.ilim.forecast.domain.FundOfFundsGraph;

import com.google.common.collect.ImmutableMap;

import org.junit.Test;

import java.math.BigDecimal;

public class FundOfFundsGraphTest {

  @Test
  public void createFundGraph() {

    FundOfFundsGraph graph = new FundOfFundsGraph(fundHoldings(),TestData.prices());

    assertEquals(4, graph.vertices());
    assertEquals(7, graph.edges());

    Fund f = new Fund(301, PRIMARY, new BigDecimal("100"));
    assertEquals(3, graph.indegree(f));
  }

  @Test
  public void bfs() {

    FundOfFundsGraph graph = new FundOfFundsGraph(fundHoldings(),TestData.prices());

    graph.breathFirstSearch(TestData.T201);
  }

  @Test
  public void bfsMultipleSources() {

    //TODO:
    //FundOfFundsGraph graph = new FundOfFundsGraph(ForecastModellerfundHoldingsData());
    //graph.breathFirstSearch(C101, C102);
  }
  
  private ImmutableMap<String, FundHolding> fundHoldings() {
    return ForecastModeller.mapOf(TestData.fundHoldings()).build();
  }
  
  
   
 

}
