package com.ilim.forecast;

import com.ilim.forecast.app.conf.SpringTestConfig;
import com.ilim.forecast.web.conf.JerseyConfig;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.io.IOException;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.ProcessingException;


/**
 * Simple stand alone HTTP Server.
 * 
 * <p>Embeds http grizzly server <a><href>https://grizzly.java.net/</href></a>
 * {@code mvn exec:java}
 * 
 * <p>Note: Some versions of eclipse seem to have class path issues. 
 * 
 * @author alan larkin
 *
 */
public class Application {

  private static final URI BASE_URI =
      URI.create("http://localhost:9998/forecasts/");

  /**
   * Application main.
   */
  public static void main(final String[] args) {

    try {

      System.out.println("ILIM Standalone Forecasts Application");

      final JerseyConfig resources = configureJerseyWithSpring();
      final HttpServer server = configureHttpServer(resources);
      server.start();

      System.out.println(String.format(
          "Application started.\nTry out %s\nStop the application using CTRL+C",
          BASE_URI));

      Thread.currentThread().join();

    } catch (IOException | InterruptedException | ProcessingException ex) {
      Logger.getLogger(Application.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  private static JerseyConfig configureJerseyWithSpring() {

    final JerseyConfig resourceConfig = new JerseyConfig();
    resourceConfig.property("contextConfig",
        new AnnotationConfigApplicationContext(SpringTestConfig.class));
    
    return resourceConfig;
  }

  private static HttpServer configureHttpServer(ResourceConfig resourceConfig) {

    final HttpServer server = GrizzlyHttpServerFactory
        .createHttpServer(BASE_URI, resourceConfig, false);
    Runtime.getRuntime().addShutdownHook(new Thread(() -> {
      server.shutdownNow();
    }));
    
    return server;
  }

}
