package com.ilim.forecast.app.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.forecast.TestData;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import org.junit.Test;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class FundServiceIT extends AppServiceTestSupport {

  @Inject
  private IFundService fundService;

  @Test
  public void lookupFundsUnitPositonsAndPrices() throws IOException {

    int fundId = TestData.PCF;

    Map<String, FundHoldingData> positions =
        fundService.findRecordedPositions(fundId);
    assertThat(positions).isNotNull().isNotEmpty();

    List<Integer> fundIds = fundService.flatMapToFundIds(positions.values());
    assertThat(fundIds).isNotNull().isNotEmpty();

    Map<Integer, FundData> funds = fundService.findFunds(fundIds);
    assertThat(funds).isNotNull().isNotEmpty();

    Map<Integer, BigDecimal> prices = fundService.findPrices(fundIds);
    assertThat(prices).isNotNull().isNotEmpty();
  }

}
