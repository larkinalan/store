package com.ilim.forecast.app.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.forecast.TestData;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import org.junit.Test;

import java.io.IOException;
import java.util.List;

import javax.inject.Inject;

public class FundServiceIT extends AppServiceTestSupport {

  @Inject
  private IFundService fundService;

  @Test
  public void lookupFundsUnitPositonsAndPrices() throws IOException {

    int fundId = TestData.PCF;
    
    List<FundHoldingData> positions =
        fundService.findUnitPositions(fundId);
    assertThat(positions).isNotNull().isNotEmpty();
    
    List<Integer> fundIds = fundService.toFundIds(positions);
    assertThat(fundIds).isNotNull().isNotEmpty();

    List<FundData> funds = fundService.findFunds(fundIds);
    assertThat(funds).isNotNull().isNotEmpty();
    
    List<FundPriceData> prices = fundService.findPrices(fundIds);
    assertThat(prices).isNotNull().isNotEmpty();
  }

}
