package com.ilim.forecast;

import static com.ilim.commons.domain.model.ForecastType.NEW_MONEY;
import static com.ilim.commons.domain.model.ForecastType.ZAP;
import static com.ilim.commons.domain.model.MoneyNotificationType.CASH;
import static com.ilim.commons.domain.model.MoneyNotificationType.UNIT;
import static java.math.BigDecimal.ZERO;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.domain.model.MoneyNotificationType;
import com.ilim.forecast.domain.IForecastInstructionRepository;
import com.ilim.forecast.domain.IForecastModelRepository;
import com.ilim.forecast.domain.InstructionFactory;
import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModelAlloc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/*
 * Simple test data holder.
 */
public class TestData {

  // TODO: make this nice, e.g. fund codes prices etc...
  /* PCF a small slice */
  public static final int PCF = 17444; // Pension Consensus Fund Client
  public static final int T_PCF = 17803; // PCF Tax
  public static final int P_PCF = 133; // PCF Primary
  public static final int IPAICP = 202; // PCF Investing
  public static final int IPAIEE = 203; // PCF Investing

  // Some random clients
  public static final int RGE = 23677; // RTE Global Equities - Passive
  public static final int AUWPD = 52463; // CLE GER UWP ASSET
  public static final int SGEP = 46878; // Setanta Global Equity Fund Pension


  // TODO: FIXME: remove when we integrate with existing source id.
  public static final AtomicLong eventId = new AtomicLong(999L);

  /** Creates new test date in db. */
  public static void setupInstrData(IForecastInstructionRepository dao) {

    createInstr(dao, newInstr(NEW_MONEY, PCF, CASH, "100.01"));
    createInstr(dao, newInstr(NEW_MONEY, RGE, CASH, "200.01"));
    createInstr(dao, newInstr(ZAP, AUWPD, CASH, "-150"));
    createInstr(dao, newInstr(ZAP, AUWPD, UNIT, "-150"));
    createInstr(dao, newInstr(NEW_MONEY, SGEP, CASH, "10000"));
  }

  /** Creates new test model data in db. */
  public static int setupModelData(IForecastInstructionRepository instrDao,
      IForecastModelRepository modelDao) {

    // instr
    int forecastMoneyId =
        instrDao.create(newInstr(NEW_MONEY, PCF, CASH, "100.01"));
    ForecastInstruction instr = instrDao.findById(forecastMoneyId);

    List<ForecastModelAlloc> model =
        newModelList(instr.getId(), instr.getForecastDate(), modelDao);

    return modelDao.create(model);
  }

  /** Build a list of ForecastModelAlloc objects. */
  public static List<ForecastModelAlloc> newModelList(int forecastMoneyId,
      LocalDate forecastDate, IForecastModelRepository modelDao) {

    // model
    // TODO: update with values
    List<ForecastModelAlloc> model = new ArrayList<>();
    LocalDateTime created = LocalDateTime.now();
    model.add(new ForecastModelAlloc(0, forecastDate, forecastMoneyId, PCF,
        T_PCF, ZERO, ZERO, ZERO, ZERO, ZERO, created));
    model.add(new ForecastModelAlloc(0, forecastDate, forecastMoneyId, T_PCF,
        P_PCF, ZERO, ZERO, ZERO, ZERO, ZERO, created));
    model.add(new ForecastModelAlloc(0, forecastDate, forecastMoneyId, P_PCF,
        IPAICP, ZERO, ZERO, ZERO, ZERO, ZERO, created));
    model.add(new ForecastModelAlloc(0, forecastDate, forecastMoneyId, P_PCF,
        IPAIEE, ZERO, ZERO, ZERO, ZERO, ZERO, created));

    int modelId = modelDao.create(model);

    return modelDao.findByModelId(modelId);
  }

  /** Creates a ForecastInstruction. */
  public static ForecastInstruction newInstr(ForecastType forecastType,
      int fundId, MoneyNotificationType moneyType, String amt) {

    return InstructionFactory.createNewForecastInstruction(LocalDate.now(),
        forecastType, fundId, moneyType, new BigDecimal(amt),
        TestData.eventId.getAndIncrement());
  }

  /** Creates a DB ForecastInstruction. */
  public static int createInstr(IForecastInstructionRepository instrDao,
      ForecastInstruction instr) {

    return instrDao.create(instr);
  }

  public static int createNewInstrData(IForecastInstructionRepository dao) {

    return createInstr(dao, newInstr(NEW_MONEY, PCF, CASH, "100.01"));
  }

  /** Asserts 2 ForecastInstruction are similar.  */
  public static void assertSameAs(ForecastInstruction actual,
      ForecastInstruction expected) {

    assertThat(actual).isEqualToIgnoringGivenFields(expected, "id",
        "creationTime");
    assertThat(actual.getCreationTime())
        .isEqualToIgnoringSeconds(expected.getCreationTime());
  }

}
