package com.ilim.forecast;

import static com.ilim.commons.domain.model.ForecastType.NEW_MONEY;
import static com.ilim.commons.domain.model.MoneyNotificationType.UNITS;

import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModel;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.ForecastStatus;

import com.google.common.collect.ImmutableList;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/*
 * Simple test data holder.
 */
public class TestData {

  /** Fund test data. */
  public static class Funds {

    // Funds
    public static final int BPL = 26320;
    public static final int TBPL = 26321;
    public static final int PBPL = 26322;
    public static final int MGIEUCSH = 26339;

    // COLLECTORS
    public static final List<Integer> list =
        ImmutableList.of(BPL, TBPL, PBPL, MGIEUCSH);
  }

  /** Instruction test data. */
  public static class Events {

    // FIXME: this row must exist in the db.
    // need away to create events for testing ?.
    public static final int dummyId = 1;
  }

  /** Instruction test data. */
  public static class Instructions {

    // Client instructions
    public static final ForecastInstruction BPL = new ForecastInstruction(-1,
        LocalDate.now(), ForecastStatus.NEW, NEW_MONEY, Funds.BPL, UNITS,
        new BigDecimal("100"), LocalDateTime.now(), Events.dummyId);

    // COLLECTORS
    public static final List<ForecastInstruction> list = ImmutableList.of(BPL);

  }

  /** Model Allocs test data. */
  public static class ModelAllocs {

    // ALLOCS
    public static final ForecastModelAlloc BPL_TBPL = new ForecastModelAlloc(-1,
        -1, Funds.BPL, Funds.TBPL, new BigDecimal("100"), new BigDecimal("1"),
        new BigDecimal("1"), new BigDecimal("100"), LocalDateTime.now());
    public static final ForecastModelAlloc TBPL_PBPL =
        new ForecastModelAlloc(-1, -1, Funds.TBPL, Funds.PBPL,
            new BigDecimal("100"), new BigDecimal("1"), new BigDecimal("1"),
            new BigDecimal("100"), LocalDateTime.now());
    public static final ForecastModelAlloc PBPL_MGIEUCSH =
        new ForecastModelAlloc(-1, -1, Funds.PBPL, Funds.MGIEUCSH,
            new BigDecimal("100"), new BigDecimal("1"), new BigDecimal("1"),
            new BigDecimal("100"), LocalDateTime.now());

    // COLLECTORS
    public static final List<ForecastModelAlloc> list =
        ImmutableList.of(BPL_TBPL, TBPL_PBPL, PBPL_MGIEUCSH);

    public static Builder but() {
      return new Builder();
    }

    public static class Builder {

      int instrId;

      private Builder() {};

      public Builder withInstrId(int instrId) {
        this.instrId = instrId;
        return this;
      }

      public List<ForecastModelAlloc> build() {

        final List<ForecastModelAlloc> copy = new ArrayList<>();
        for (ForecastModelAlloc a : list) {
          copy.add(new ForecastModelAlloc(a.getId(), instrId, a.getFundId(),
              a.getHoldingId(), a.getCommittedUnits(), a.getPrice(), a.getMix(),
              a.getCash(), a.getCreationTime()));
        }
        return copy;
      }
    }
  }

  /** Model test data. */
  public static class Models {

    // MODELS
    public static final ForecastModel BPL =
        new ForecastModel(Instructions.BPL, ModelAllocs.list);

    // COLLECTORS
    public static final List<ForecastModel> list = ImmutableList.of(BPL);
  }

}
