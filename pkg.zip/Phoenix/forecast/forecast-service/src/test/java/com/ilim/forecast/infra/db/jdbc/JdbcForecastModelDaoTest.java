package com.ilim.forecast.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.domain.model.ForecastStatus;
import com.ilim.forecast.TestData;
import com.ilim.forecast.app.AppTestSupport;
import com.ilim.forecast.domain.IForecastModelView;
import com.ilim.forecast.domain.model.ForecastModel;
import com.ilim.forecast.domain.model.ForecastModelAlloc;

import org.junit.Test;

import java.time.LocalDate;
import java.util.List;

import javax.inject.Inject;

/**
 * Tests for JdbcForecastModelDao.
 *
 * @author alan larkin
 */
public class JdbcForecastModelDaoTest extends AppTestSupport {

  @Inject
  protected IForecastModelView modelDao;


  @Test
  public void findByInstrId() throws Exception {

    // setup data
    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<ForecastModelAlloc> allocs =
        TestData.ModelAllocs.but().withInstrId(instrId).build();
    modelAllocDao.create(allocs);

    // test
    ForecastModel actual = modelDao.findByInstrId(instrId);

    // verify
    assertThat(actual.getInstruction().getId()).isEqualTo(instrId);
    assertThat(actual.getModelAllocs()).hasSize(allocs.size());
    assertThat(actual.getModelAllocs()).extracting("instrId")
        .containsOnly(instrId);
    assertThat(actual.getInstruction().getFundId())
        .isEqualTo(TestData.Instructions.BPL.getFundId());
    assertThat(actual.getInstruction().getForecastType())
        .isEqualTo(TestData.Instructions.BPL.getForecastType());
  }

  @Test(expected = AppSqlException.class)
  public void findByInstrIdException() throws Exception {

    // test
    modelDao.findByInstrId(-10);
  }

  @Test
  public void findByForecastDate() throws Exception {

    // setup data
    LocalDate forecastDate = TestData.Instructions.BPL.getForecastDate();
    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<ForecastModelAlloc> allocs =
        TestData.ModelAllocs.but().withInstrId(instrId).build();
    modelAllocDao.create(allocs);

    // test
    List<ForecastModel> actual = modelDao.findByForecastDate(forecastDate);

    // verify
    assertThat(actual.size()).isGreaterThan(0);
    for (ForecastModel m : actual) {
      assertThat(m.getInstruction().getForecastDate()).isEqualTo(forecastDate);
      assertThat(m.getInstruction().getFundId())
          .isEqualTo(TestData.Instructions.BPL.getFundId());
      assertThat(m.getInstruction().getForecastType())
          .isEqualTo(TestData.Instructions.BPL.getForecastType());
    }
  }

  @Test
  public void findByForecastDateAndFundId() throws Exception {

    // setup
    int fundId = TestData.Funds.BPL;
    LocalDate forecastDate = TestData.Instructions.BPL.getForecastDate();
    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<ForecastModelAlloc> allocs =
        TestData.ModelAllocs.but().withInstrId(instrId).build();
    modelAllocDao.create(allocs);

    // test
    List<ForecastModel> actual =
        modelDao.findByForecastDateAndFundId(forecastDate, fundId);

    // verify
    assertThat(actual.size()).isGreaterThan(0);
    actual.stream().forEach(
        m -> assertThat(m.getInstruction().getForecastDate()).isEqualTo(
            forecastDate));
    actual.stream().forEach(
        m -> m.getModelAllocs().stream()
            .forEach(a -> assertThat(a.getFundId()).isEqualTo(fundId)));
  }

  @Test
  public void findByStatus() throws Exception {

    // setup
    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<ForecastModelAlloc> allocs =
        TestData.ModelAllocs.but().withInstrId(instrId).build();
    modelAllocDao.create(allocs);

    // test
    List<ForecastModel> actual = modelDao.findByStatus(ForecastStatus.NEW);

    // verify
    assertThat(actual.size()).isGreaterThan(0);
    for (ForecastModel m : actual) {
      assertThat(m.getInstruction().getStatus().id())
          .isEqualTo(ForecastStatus.NEW.id());
      assertThat(m.getInstruction().getFundId())
          .isEqualTo(TestData.Instructions.BPL.getFundId());
    }
  }

}
