package com.ilim.forecast.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.ilim.forecast.TestData;
import com.ilim.forecast.domain.IForecastInstructionRepository;
import com.ilim.forecast.domain.IForecastModelRepository;
import com.ilim.forecast.domain.model.ForecastModelAlloc;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.inject.Inject;

/**
 * Tests for JdbcForecastModelDao.
 *
 * @author michael cunningham
 */
public class JdbcForecastModelDaoTest extends JdbcDaoTestSupport {

  @Rule
  @Inject
  public TestRule logger;

  @Inject
  private IForecastModelRepository modelDao;

  @Inject
  private IForecastInstructionRepository instrDao;

  @Test
  public void createAndFindById() throws Exception {

    int modelId = TestData.setupModelData(instrDao, modelDao);
    assertTrue(modelId > 0);
    List<ForecastModelAlloc> actual = modelDao.findByModelId(modelId);
    assertThat(actual.size()).isEqualTo(4);
  }

  @Test
  public void findByUnknownId() throws Exception {

    assertTrue(modelDao.findByModelId(-10).isEmpty());
  }

  @Test
  public void findByForecastDate() throws Exception {

    TestData.setupModelData(instrDao, modelDao);

    LocalDate forecastDate = LocalDate.now();
    List<ForecastModelAlloc> actual =
        modelDao.findByForecastDate(forecastDate);

    assertThat(actual).isNotNull();
    assertThat(actual).extracting("forecastDate").containsOnly(forecastDate);
  }

  @Test
  public void findByFundIdAndForecastDate() throws Exception {

    // setup
    TestData.setupModelData(instrDao, modelDao);
    int expectedId = TestData.PCF;
    LocalDate expectedDate = LocalDate.now();
    
    //test
    List<ForecastModelAlloc> actual =
        modelDao.findByFundIdAndForecastDate(expectedId, expectedDate);

    // verify
    assertThat(actual).isNotNull();
    assertThat(actual).extracting("id.fundId").containsOnly(expectedId);
    assertThat(actual).extracting("forecastDate").containsOnly(expectedDate);
  }

  @Test
  public void findAll() throws Exception {

    TestData.setupModelData(instrDao, modelDao);

    List<ForecastModelAlloc> modelList = modelDao.findAll();
    assertThat(modelList.size()).isGreaterThan(0);
  }

  @Test
  public void deleteModel() throws Exception {

    int modelId = TestData.setupModelData(instrDao, modelDao);
    modelDao.delete(modelId);
    assertThat(modelDao.findByModelId(modelId)).isEmpty();
  }

  @Test
  public void deleteModelById() throws Exception {

    int modelId = TestData.setupModelData(instrDao, modelDao);
    List<ForecastModelAlloc> modelList = modelDao.findByModelId(modelId);
    assertThat(modelList.size()).isEqualTo(4);

    ForecastModelAlloc.Id id = modelList.get(0).getId(); // first one will do
    modelDao.deleteById(id);

    List<ForecastModelAlloc> actual = modelDao.findByModelId(modelId);
    assertThat(actual.size()).isEqualTo(3);
    assertThat(actual).extracting("id").doesNotContain(id);
  }

  @Test
  public void update() throws Exception {

    int modelId = TestData.setupModelData(instrDao, modelDao);
    List<ForecastModelAlloc> modelList = modelDao.findByModelId(modelId);
    assertThat(modelList.size()).isGreaterThan(0);
    ForecastModelAlloc modelEntry = modelList.get(0);
    ForecastModelAlloc.Id id = modelEntry.getId();
    BigDecimal expectedRecordedCash = new BigDecimal("100.00");

    modelDao.update(id, expectedRecordedCash);

    ForecastModelAlloc actual = modelDao.findById(id);
    assertThat(actual.getRecordedCash()).isEqualTo(expectedRecordedCash);
  }
}
