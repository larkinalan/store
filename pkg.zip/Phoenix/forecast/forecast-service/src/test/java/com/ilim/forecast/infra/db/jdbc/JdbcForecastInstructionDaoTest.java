package com.ilim.forecast.infra.db.jdbc;

import static com.ilim.forecast.domain.model.ForecastStatus.NEW;
import static com.ilim.forecast.domain.model.ForecastStatus.PROCESSING;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.ilim.commons.db.AppSqlException;
import com.ilim.forecast.TestData;
import com.ilim.forecast.app.AppTestSupport;
import com.ilim.forecast.domain.model.ForecastInstruction;

import org.junit.Test;
import org.springframework.test.annotation.Rollback;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


/**
 * Tests for JdbcForecastInstructionDao.
 *
 * @author Alan Larkin
 */
public class JdbcForecastInstructionDaoTest extends AppTestSupport {

  @Test
  @Rollback(true)
  public void createAndFindById() throws Exception {

    // create
    ForecastInstruction expected = TestData.Instructions.BPL;

    // test
    int id = instrDao.create(expected);
    ForecastInstruction actual = instrDao.findById(id);
    
    // verify
    assertThat(actual).isNotNull();
    assertThat(actual).isEqualToIgnoringGivenFields(expected, "id",
        "creationTime");
    assertThat(actual.getCreationTime())
        .isEqualToIgnoringSeconds(expected.getCreationTime());
  }

  @Test(expected = AppSqlException.class)
  public void findByIdException() throws Exception {

    instrDao.findById(-10);
  }

  @Test
  public void findAll() throws Exception {

    // setup data
    List<Integer> expectedIds = new ArrayList<Integer>();
    List<ForecastInstruction> expected = TestData.Instructions.list;
    for (ForecastInstruction e : expected) {
      expectedIds.add(instrDao.create(e));
    }

    // test
    List<ForecastInstruction> actual = instrDao.findAll();

    // verify
    assertThat(actual.size()).isGreaterThanOrEqualTo(1);
    assertThat(actual).extracting("id").contains(expectedIds.toArray());
  }

  @Test
  public void findByStatus() throws Exception {

    // setup data
    List<Integer> expectedIds = new ArrayList<Integer>();
    List<ForecastInstruction> expected = TestData.Instructions.list;
    for (ForecastInstruction e : expected) {
      expectedIds.add(instrDao.create(e));
    }

    // test
    List<ForecastInstruction> actual = instrDao.findByStatus(NEW);

    // verify
    assertThat(actual).extracting("id").contains(expectedIds.toArray());
    assertThat(actual).extracting("status").containsOnly(NEW);
  }

  @Test
  public void findByStatusForPeriod() throws Exception {

    // setup data
    List<Integer> expectedIds = new ArrayList<Integer>();
    List<ForecastInstruction> expected = TestData.Instructions.list;
    for (ForecastInstruction e : expected) {
      expectedIds.add(instrDao.create(e));
    }

    // test
    LocalDate to = LocalDate.now();
    LocalDate from = to.minusDays(30);
    List<ForecastInstruction> actual =
        instrDao.findByStatusForPeriod(NEW, from, to);

    // verify
    assertThat(actual).extracting("id").contains(expectedIds.toArray());
    assertTrue(actual.stream()
        .allMatch(i -> i.getStatus().equals(NEW)
            && !i.getForecastDate().isBefore(from)
            && !i.getForecastDate().isAfter(to)));
  }

  @Test
  public void updateStatus() throws Exception {

    // setup data
    ForecastInstruction expected = TestData.Instructions.BPL;

    // test
    int id = instrDao.create(expected);
    ForecastInstruction newInstr = instrDao.findById(id);
    assertThat(newInstr.getStatus()).isEqualTo(NEW);

    instrDao.updateStatus(id, PROCESSING);
    ForecastInstruction actual = instrDao.findById(id);
    
    // verify
    assertThat(actual.getStatus()).isEqualTo(PROCESSING);
    assertThat(actual).isEqualToIgnoringGivenFields(expected, "id",
        "status", "creationTime");
  }

}

