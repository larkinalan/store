package com.ilim.forecast.infra.db.jdbc;

import static com.ilim.forecast.TestData.assertSameAs;
import static com.ilim.forecast.domain.model.ForecastStatus.NEW;
import static com.ilim.forecast.domain.model.ForecastStatus.PROCESSING;
import static com.ilim.forecast.domain.model.ForecastType.NEW_MONEY;
import static com.ilim.forecast.domain.model.MoneyNotificationType.CASH;
import static com.ilim.forecast.domain.model.MoneyNotificationType.UNITS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.ilim.commons.db.AppSqlException;
import com.ilim.forecast.TestData;
import com.ilim.forecast.app.conf.SpringTestConfig;
import com.ilim.forecast.domain.IForecastInstructionRepository;
import com.ilim.forecast.domain.model.ForecastInstruction;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import java.time.LocalDate;
import java.util.List;

import javax.inject.Inject;


/**
 * Tests for JdbcForecastInstructionDao.
 *
 * @author Alan Larkin
 */
@ContextConfiguration(classes = SpringTestConfig.class)
public class JdbcForecastInstructionDaoTest
    extends AbstractTransactionalJUnit4SpringContextTests {

  @Rule
  @Inject
  public TestRule logger;

  @Inject
  private IForecastInstructionRepository dao;

  @Test
  @Rollback(true)
  public void createAndFindById() throws Exception {

    ForecastInstruction expected =
        TestData.newInstr(NEW_MONEY, TestData.PCF, CASH, "5000.01");
    int id = dao.create(expected);
    assertTrue(id > 0);
    ForecastInstruction actual = dao.findById(id);
    assertSameAs(actual, expected);
  }

  @Test(expected = AppSqlException.class)
  public void findByIdException() throws Exception {

    dao.findById(-1);
  }

  @Test
  public void findAll() throws Exception {

    TestData.setupInstrData(dao);

    List<ForecastInstruction> instrs = dao.findAll();
    assertThat(instrs).isNotNull();
    assertThat(instrs.size()).isGreaterThan(0);
  }

  @Test
  public void findByStatus() throws Exception {

    TestData.setupInstrData(dao);

    List<ForecastInstruction> instrs = dao.findByStatus(NEW);
    assertThat(instrs).isNotNull();
    assertThat(instrs.size()).isGreaterThan(0);

    assertThat(instrs).extracting("status").containsOnly(NEW);
  }

  @Test
  public void findByStatusForPeriod() throws Exception {

    TestData.setupInstrData(dao);

    LocalDate to = LocalDate.now();
    LocalDate from = to.minusDays(30);
    List<ForecastInstruction> instrs = dao.findByStatusForPeriod(NEW, from, to);

    assertThat(instrs).isNotNull();
    assertThat(instrs.size()).isGreaterThan(0);
    // check all forecasts are new and within the specified time period
    // for (ForecastInstruction i : instrs) {
    // assertThat(i.getStatus()).isEqualTo(NEW);
    // assertThat(i.getForecastDate()).isAfterOrEqualTo(from);
    // assertThat(i.getForecastDate()).isBeforeOrEqualTo(to);
    // }

    // check all forecasts are new and within the specified time period (Lambda)
    assertTrue(instrs.stream()
        .allMatch(i -> i.getStatus().equals(NEW)
            && !i.getForecastDate().isBefore(from)
            && !i.getForecastDate().isAfter(to)));
  }

  @Test
  public void updateStatus() throws Exception {

    int id = dao
        .create(TestData.newInstr(NEW_MONEY, TestData.PCF, UNITS, "5000.01"));
    ForecastInstruction actual = dao.findById(id);
    assertThat(actual.getStatus()).isEqualTo(NEW);

    dao.updateStatus(id, PROCESSING);
    ForecastInstruction expected = dao.findById(id);
    assertThat(expected.getStatus()).isEqualTo(PROCESSING);
  }

}

