package com.ilim.forecast.infra.db.jdbc;


import com.ilim.forecast.app.conf.SpringTestConfig;

import org.junit.Rule;
import org.junit.rules.TestRule;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import javax.inject.Inject;

@ContextConfiguration(classes = SpringTestConfig.class)
public abstract class JdbcDaoTestSupport
    extends AbstractTransactionalJUnit4SpringContextTests {

  @Rule
  @Inject
  public TestRule logger;

}
