package com.ilim.forecast.app.conf;

import com.ilim.commons.eventbus.AppEventBus;
import com.ilim.commons.eventbus.IEventSubscriber;
import com.ilim.commons.logging.TestLogger;
import com.ilim.forecast.app.service.TestSubscriber;

import org.junit.rules.TestRule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Spring component test config.
 *
 * @author Alan Larkin
 */
@Configuration
@EnableTransactionManagement
@Import({SpringConfig.class})
public class SpringTestConfig {

  /** Bean that listens to TestEventBus. */
  @Bean
  public IEventSubscriber testInstructionSubscriber(AppEventBus eventBus) {

    return new TestSubscriber(eventBus);
  }

  /** TestLogger bean. helps log root cause of errors.  */
  @Bean
  public TestRule testLogger() {
    return new TestLogger();
  }

}
