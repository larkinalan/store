package com.ilim.forecast.app;

import com.ilim.forecast.app.conf.SpringTestConfig;
import com.ilim.forecast.app.service.TestSubscriber;
import com.ilim.forecast.domain.IForecastInstructionRepository;
import com.ilim.forecast.domain.IForecastModelAllocRepository;

import org.junit.Rule;
import org.junit.rules.TestRule;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import javax.inject.Inject;

@ContextConfiguration(classes = SpringTestConfig.class)
public abstract class AppTestSupport
    extends AbstractTransactionalJUnit4SpringContextTests {

  @Rule
  @Inject
  public TestRule logger;

  @Inject
  public TestSubscriber testSubscriber;

  @Inject
  protected IForecastInstructionRepository instrDao;

  @Inject
  protected IForecastModelAllocRepository modelAllocDao;

}
