package com.ilim.forecast.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.ilim.commons.db.AppSqlException;
import com.ilim.forecast.TestData;
import com.ilim.forecast.app.AppTestSupport;
import com.ilim.forecast.domain.model.ForecastModelAlloc;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

/**
 * Tests for JdbcForecastModelAllocDao.
 *
 * @author michael cunningham
 */
public class JdbcForecastModelAllocDaoTest extends AppTestSupport {

  @Test
  public void createAndFindById() throws Exception {

    // setup data
    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<ForecastModelAlloc> allocs =
        TestData.ModelAllocs.but().withInstrId(instrId).build();

    // test
    List<Integer> ids = modelAllocDao.create(allocs);
    assertThat(ids).hasSize(allocs.size());

    // verify
    int i = 0;
    for (Integer id : ids) {
      ForecastModelAlloc actual = modelAllocDao.findById(id);
      assertThat(actual).isEqualToIgnoringGivenFields(allocs.get(i++),
          "allocId", "creationTime");
    }
  }

  @Test
  public void findAll() throws Exception {

    // setup data
    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<ForecastModelAlloc> allocs =
        TestData.ModelAllocs.but().withInstrId(instrId).build();
    List<Integer> ids = modelAllocDao.create(allocs);

    // test
    List<ForecastModelAlloc> actual = modelAllocDao.findAll();
    assertThat(actual.size()).isGreaterThan(0);
    assertThat(actual).extracting("instrId").containsOnly(instrId);
    assertThat(actual).extracting("allocId").containsExactly(ids.toArray());
  }

  @Test(expected = AppSqlException.class)
  public void findByUnknownId() throws Exception {

    assertThat(modelAllocDao.findById(-10));
  }

  @Test
  public void findByInstrId() throws Exception {

    // setup data
    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<ForecastModelAlloc> allocs =
        TestData.ModelAllocs.but().withInstrId(instrId).build();
    List<Integer> ids = modelAllocDao.create(allocs);

    // test
    List<ForecastModelAlloc> actual =
        modelAllocDao.findByInstrId(Arrays.asList(instrId));
    
    // verify
    assertThat(actual).extracting("instrId").containsOnly(instrId);
    assertThat(actual).extracting("allocId").containsExactly(ids.toArray());
  }

  @Test
  public void findByInstrIdAndFundId() throws Exception {

    // setup data
    int fundId = TestData.Funds.BPL;
    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<ForecastModelAlloc> allocs =
        TestData.ModelAllocs.but().withInstrId(instrId).build();
    modelAllocDao.create(allocs);

    // test
    List<ForecastModelAlloc> actual =
        modelAllocDao.findByInstrIdAndFundId(instrId, fundId);

    // verify
    assertThat(actual).hasSize(1);
    assertThat(actual).extracting("instrId").containsOnly(instrId);
    assertThat(actual).extracting("fundId").containsOnly(fundId);
  }

  @Test
  public void deleteModel() throws Exception {

    // setup data
    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<ForecastModelAlloc> allocs =
        TestData.ModelAllocs.but().withInstrId(instrId).build();
    List<Integer> ids = modelAllocDao.create(allocs);
    
    // test
    modelAllocDao.delete(ids);
    
    // verify
    for (Integer id : ids) {

      assertThatThrownBy(() -> {
        modelAllocDao.findById(id);
      }).isInstanceOf(AppSqlException.class).hasMessageContaining(
          "Error in findById!");
    }
  }

}
