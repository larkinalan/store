package com.ilim.forecast.app.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.eventbus.AppEventBus;
import com.ilim.commons.eventbus.TestEventSubscriber;
import com.ilim.forecast.domain.event.FailedForecastInstruction;
import com.ilim.forecast.domain.event.ModelledForecastInstruction;
import com.ilim.forecast.domain.event.PendingForecastInstruction;
import com.ilim.forecast.domain.event.ProcessingForecastInstruction;

import java.util.Set;

public class TestSubscriber extends TestEventSubscriber {

  /** Listens to test event bus.
   *  Creates in memory store of raised events that can be verified. 
   **/
  public TestSubscriber(AppEventBus eventBus) {
    super(eventBus);
  }

  /** Assert pending event was raised. */
  public void assertPendingEvent(int instrId) {

    Set<PendingForecastInstruction> pendingEvents =
        filterEventStore(PendingForecastInstruction.class);

    assertThat(pendingEvents).filteredOn(
        e -> e.instrId == instrId).hasSize(1);
  }

  /** Assert processing event was raised. */
  public void assertProcessingEvent(int instrId) {

    Set<ProcessingForecastInstruction> processingEvents =
        filterEventStore(ProcessingForecastInstruction.class);

    assertThat(processingEvents)
        .filteredOn(e -> e.instrId == instrId).hasSize(1);;
  }

  /** Assert modelled event was raised. */
  public void assertModelledEvent(int modelId, int instrId) {

    Set<ModelledForecastInstruction> modelledEvents =
        filterEventStore(ModelledForecastInstruction.class);

    assertThat(modelledEvents)
        .filteredOn(e -> e.modelId == modelId)
        .filteredOn(e -> e.instrId == instrId).hasSize(1);;
  }

  /** Assert failed event was raised. */
  public void assertFailedEvent(int instrId) {

    Set<FailedForecastInstruction> failedEvents =
        filterEventStore(FailedForecastInstruction.class);

    assertThat(failedEvents).filteredOn(
        e -> e.instrId == instrId).hasSize(1);;
  }

  /** Assert number of events raised. */
  public void assertSize(int expected) {

    assertThat(eventStore()).hasSize(expected);
  }
  
}
