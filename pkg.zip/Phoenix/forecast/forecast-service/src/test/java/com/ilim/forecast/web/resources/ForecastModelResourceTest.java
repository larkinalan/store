package com.ilim.forecast.web.resources;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.forecast.TestData;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.forecast.web.api.ForecastModelAllocIdData;

import org.junit.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

/**
 * Testing our web service.
 *
 * @author Michael Cunningham
 */
public class ForecastModelResourceTest extends JerseySpringTestSupport {

  protected WebTarget forecastModelResource() {
    return target("models");
  }

  @Test
  public void findByModelId() throws Exception {

    int modelId = 3382; // FIXME: should look this up

    List<ForecastModelAllocData> model =
        forecastModelResource().path(Integer.toString(modelId)).request()
            .get(new GenericType<List<ForecastModelAllocData>>() {});
    assertThat(model.size()).isEqualTo(4);
  }

  @Test
  public void findAll() throws Exception {

    TestData.setupModelData(instrDao, modelDao);

    List<ForecastModelAllocData> model = forecastModelResource().request()
        .get(new GenericType<List<ForecastModelAllocData>>() {});
    assertThat(model.size()).isGreaterThan(0);
  }

  @Test
  public void updateRecordedCash() throws Exception {

    int modelId = 3382; // FIXME: should look this up

    // find existing model
    List<ForecastModelAllocData> modelAllocs =
        forecastModelResource().path(Integer.toString(modelId)).request()
            .get(new GenericType<List<ForecastModelAllocData>>() {});
    assertThat(modelAllocs.size()).isEqualTo(4);

    // PUT Update cash of first model instr row
    ForecastModelAllocIdData allocId = modelAllocs.get(0).id;
    BigDecimal expectedCash = new BigDecimal("100.00");

    Response response = forecastModelResource().request()
        .put(Entity.json(Arrays.asList(allocId, expectedCash)));
    assertThat(response.getStatus()).isEqualTo(Status.ACCEPTED.getStatusCode());

    // GET again
    List<ForecastModelAllocData> updatedAllocs =
        forecastModelResource().path(Integer.toString(modelId)).request()
            .get(new GenericType<List<ForecastModelAllocData>>() {});
    assertThat(updatedAllocs.size()).isEqualTo(4);

    // verify we update the correct row
    for (ForecastModelAllocData alloc : updatedAllocs) {
      if (isEqual(alloc.id, allocId)) {
        assertThat(alloc.recordedCash).isEqualTo(expectedCash);
      }
    }
  }

  /* Return true if both ForecastModelAllocData.Id's are equal */
  private boolean isEqual(ForecastModelAllocIdData id1,
      ForecastModelAllocIdData id2) {

    return (id1.fundId == id2.fundId && id1.holdingId == id2.holdingId
        && id1.instrId == id2.instrId && id1.modelId == id2.modelId);
  }

}
