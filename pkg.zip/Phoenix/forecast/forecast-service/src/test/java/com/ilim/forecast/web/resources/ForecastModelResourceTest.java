package com.ilim.forecast.web.resources;

import static com.ilim.forecast.web.resources.ForecastDataMapper.toNewForecastInstructionData;
import static java.util.stream.Collectors.toList;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.TestData;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.ForecastModelData;

import org.junit.Test;

import java.time.LocalDate;
import java.util.List;

import javax.ws.rs.core.GenericType;

/**
 * Testing our web service.
 *
 * @author Michael Cunningham
 */
public class ForecastModelResourceTest extends AppResourceTestSupport {

  @Test
  public void findTodaysForecast() throws Exception {

    // setup data
    ForecastInstructionData instr = findInstrById(
        createInstr(toNewForecastInstructionData(TestData.Instructions.BPL)));

    // test
    List<ForecastModelData> model = forecastModelResource().request()
        .get(new GenericType<List<ForecastModelData>>() {});

    // verify model
    assertThat(model.size()).isGreaterThan(0);
    // verify model instr
    assertThat(model.stream().filter(m -> m.instruction.id == instr.id)
        .collect(toList())).hasSize(1);
    model.stream().filter(m -> m.instruction.id == instr.id)
        .forEach(m -> assertThat(m.instruction.forecastDate)
            .isEqualTo(instr.forecastDate));
    // verify model allocs
    model.stream().filter(m -> m.instruction.id == instr.id)
        .forEach(m -> assertThat(m.modelledAllocs).hasSize(13));
  }

  @Test
  public void findByForecastDate() throws Exception {

    ForecastInstructionData instr = findInstrById(
        createInstr(toNewForecastInstructionData(TestData.Instructions.BPL)));
    String forecastDate = LocalDate.now().format(DateUtils.DATE_FMT);

    List<ForecastModelData> model =
        forecastModelResource().queryParam("forecastDate", forecastDate)
            .request().get(new GenericType<List<ForecastModelData>>() {});

    // verify model
    assertThat(model.size()).isGreaterThan(0);
    // verify model instr
    assertThat(model.stream().filter(m -> m.instruction.id == instr.id)
        .collect(toList())).hasSize(1);
    model.stream().filter(m -> m.instruction.id == instr.id)
        .forEach(m -> assertThat(m.instruction.forecastDate)
            .isEqualTo(instr.forecastDate));
    // verify model allocs
    model.stream().filter(m -> m.instruction.id == instr.id)
        .forEach(m -> assertThat(m.modelledAllocs).hasSize(13));
  }

  @Test
  public void findByForecastDateAndFundId() throws Exception {

    // setup
    ForecastInstructionData instr = findInstrById(
        createInstr(toNewForecastInstructionData(TestData.Instructions.BPL)));
    String forecastDate = LocalDate.now().format(DateUtils.DATE_FMT);
    int fundId = instr.fundId;

    // test
    List<ForecastModelData> model = forecastModelResource()
        .queryParam("forecastDate", forecastDate).queryParam("fundId", fundId)
        .request().get(new GenericType<List<ForecastModelData>>() {});

    // verify model
    List<ForecastModelData> modelledInstr = model.stream()
        .filter(m -> m.instruction.id == instr.id).collect(toList());
    assertThat(modelledInstr).hasSize(1);
    modelledInstr.forEach(m -> assertThat(m.instruction.forecastDate)
        .isEqualTo(instr.forecastDate));
    modelledInstr.forEach(m -> m.modelledAllocs.stream()
        .forEach(a -> assertThat(a.fundId).isIn(TestData.Funds.list)));
  }

  @Test
  public void findByStatus() throws Exception {

    ForecastInstructionData instr = findInstrById(
        createInstr(toNewForecastInstructionData(TestData.Instructions.BPL)));

    List<ForecastModelData> model =
        forecastModelResource().queryParam("status", instr.status).request()
            .get(new GenericType<List<ForecastModelData>>() {});

    // verify model
    assertThat(model.size()).isGreaterThan(0);
    // verify model instr
    assertThat(model.stream().filter(m -> m.instruction.id == instr.id)
        .collect(toList())).hasSize(1);
    model.stream().filter(m -> m.instruction.id == instr.id)
        .forEach(m -> assertThat(m.instruction.status).isEqualTo(instr.status));
    // verify model allocs
    model.stream().filter(m -> m.instruction.id == instr.id)
        .forEach(m -> assertThat(m.modelledAllocs).hasSize(13));
  }

}
