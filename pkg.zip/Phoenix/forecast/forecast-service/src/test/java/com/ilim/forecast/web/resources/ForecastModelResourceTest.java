package com.ilim.forecast.web.resources;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.TestData;
import com.ilim.forecast.web.api.ForecastModelAllocData;

import org.junit.Test;

import java.time.LocalDate;
import java.util.List;

import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;

/**
 * Testing our web service.
 *
 * @author Michael Cunningham
 */
public class ForecastModelResourceTest extends AppResourceTestSupport {

  protected WebTarget forecastModelResource() {
    return target("models");
  }

  @Test
  public void findByModelId() throws Exception {

    int modelId = 9; // FIXME: should look this up

    List<ForecastModelAllocData> model =
        forecastModelResource().path(Integer.toString(modelId)).request()
            .get(new GenericType<List<ForecastModelAllocData>>() {});
    assertThat(model.size()).isEqualTo(4);
  }

  @Test
  public void findByForecastDate() throws Exception {

    TestData.setupModelData(instrDao, modelDao);

    String forecastDate = LocalDate.now().format(DateUtils.DATE_FMT);

    List<ForecastModelAllocData> actual =
        forecastModelResource().queryParam("forecastDate", forecastDate)
            .request().get(new GenericType<List<ForecastModelAllocData>>() {});

    assertThat(actual).extracting("forecastDate").containsOnly(forecastDate);
  }

  @Test
  public void findByFundIdForForecastDate() throws Exception {

    TestData.setupModelData(instrDao, modelDao);

    int fundId = TestData.PCF;
    String forecastDate = LocalDate.now().format(DateUtils.DATE_FMT);

    List<ForecastModelAllocData> actual =
        forecastModelResource().queryParam("fundId", fundId)
            .queryParam("forecastDate", forecastDate).request()
            .get(new GenericType<List<ForecastModelAllocData>>() {});

    assertThat(actual).extracting("id.fundId").containsOnly(fundId);
    assertThat(actual).extracting("forecastDate").containsOnly(forecastDate);
  }

  @Test
  public void findAll() throws Exception {

    TestData.setupModelData(instrDao, modelDao);

    List<ForecastModelAllocData> model = forecastModelResource().request()
        .get(new GenericType<List<ForecastModelAllocData>>() {});
    
    assertThat(model.size()).isGreaterThan(0);
  }

}
