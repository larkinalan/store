package com.ilim.forecast.web.resources;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.TestData;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.forecast.web.api.ForecastModelAllocIdData;
import com.ilim.forecast.web.api.RecordedCashData;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

/**
 * Testing our web service.
 *
 * @author Michael Cunningham
 */
public class ForecastModelResourceTest extends JerseySpringTestSupport {

  protected WebTarget forecastModelResource() {
    return target("models");
  }

  @Test
  public void findByModelId() throws Exception {

    int modelId = 3382; // FIXME: should look this up

    List<ForecastModelAllocData> model =
        forecastModelResource().path(Integer.toString(modelId)).request()
            .get(new GenericType<List<ForecastModelAllocData>>() {});
    assertThat(model.size()).isEqualTo(4);
  }

  @Test
  public void findByForecastDate() throws Exception {

    TestData.setupModelData(instrDao, modelDao);

    String forecastDate = LocalDate.now().format(DateUtils.DATE_FMT);

    List<ForecastModelAllocData> actual =
        forecastModelResource().queryParam("forecastDate", forecastDate)
            .request().get(new GenericType<List<ForecastModelAllocData>>() {});

    assertThat(actual).extracting("forecastDate").containsOnly(forecastDate);
  }

  @Test
  public void findByFundIdForForecastDate() throws Exception {

    TestData.setupModelData(instrDao, modelDao);

    int fundId = TestData.PCF;
    String forecastDate = LocalDate.now().format(DateUtils.DATE_FMT);

    List<ForecastModelAllocData> actual =
        forecastModelResource().queryParam("fundId", fundId)
            .queryParam("forecastDate", forecastDate).request()
            .get(new GenericType<List<ForecastModelAllocData>>() {});

    assertThat(actual).extracting("id.fundId").containsOnly(fundId);
    assertThat(actual).extracting("forecastDate").containsOnly(forecastDate);
  }

  @Test
  public void findAll() throws Exception {

    TestData.setupModelData(instrDao, modelDao);

    List<ForecastModelAllocData> model = forecastModelResource().request()
        .get(new GenericType<List<ForecastModelAllocData>>() {});
    
    assertThat(model.size()).isGreaterThan(0);
  }

  @Test
  public void updateRecordedCash() throws Exception {

    int modelId = 3382; // FIXME: should look this up

    // find existing model
    List<ForecastModelAllocData> modelAllocs =
        forecastModelResource().path(Integer.toString(modelId)).request()
            .get(new GenericType<List<ForecastModelAllocData>>() {});
    assertThat(modelAllocs).hasSize(4);

    // PUT Update cash of first model instr row
    RecordedCashData expected =
        new RecordedCashData(modelAllocs.get(0).id, new BigDecimal("100.00"));

    Response response =
        forecastModelResource().request().put(Entity.json(expected));
    assertThat(response.getStatus()).isEqualTo(Status.ACCEPTED.getStatusCode());

    // GET again
    List<ForecastModelAllocData> updatedAllocs =
        forecastModelResource().path(Integer.toString(modelId)).request()
            .get(new GenericType<List<ForecastModelAllocData>>() {});
    assertThat(modelAllocs).hasSize(4);

    // verify we update the correct row
    for (ForecastModelAllocData alloc : updatedAllocs) {
      if (isEqual(alloc.id, expected.id)) {
        assertThat(alloc.recordedCash).isEqualTo(expected.cash);
      }
    }
  }

  /* Return true if both ForecastModelAllocData.Id's are equal */
  private boolean isEqual(ForecastModelAllocIdData id1,
      ForecastModelAllocIdData id2) {

    return (id1.fundId == id2.fundId && id1.holdingId == id2.holdingId
        && id1.instrId == id2.instrId && id1.modelId == id2.modelId);
  }

}
