package com.ilim.forecast.web.resources;

import static com.ilim.commons.domain.model.ForecastType.NEW_MONEY;
import static com.ilim.commons.domain.model.MoneyNotificationType.CASH;
import static com.ilim.commons.time.DateUtils.DATE_FMT;
import static com.ilim.forecast.domain.model.ForecastStatus.MODELLED;
import static com.ilim.forecast.domain.model.ForecastStatus.NEW;
import static com.ilim.forecast.domain.model.ForecastStatus.PROCESSING;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.domain.model.MoneyNotificationType;
import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.TestData;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


/**
 * Testing our web service. 
 *
 * @author Alan Larkin
 */
public class ForecastInstructionResourceTest extends JerseySpringTestSupport {


  protected WebTarget forecastInstructionResource() {
    return target("instructions");
  }

  @Test
  public void createAndFindById() throws Exception {

    NewForecastInstructionData expected =
        createNewInstrData(NEW_MONEY, TestData.PCF, CASH, "5000.01");
    String resource = create(expected);
    ForecastInstructionData actual = findById(resource);
    assertSameAs(actual, expected);
  }

  @Test
  public void findAll() throws Exception {

    TestData.setupInstrData(instrDao);

    List<ForecastInstructionData> instrs =
        forecastInstructionResource().request().get(
            new GenericType<List<ForecastInstructionData>>() {});

    assertThat(instrs.size()).isGreaterThan(0);
  }

  @Test
  public void findByStatus() throws Exception {

    TestData.setupInstrData(instrDao);

    List<ForecastInstructionData> instrs =
        forecastInstructionResource().queryParam("status", NEW.name())
            .request().get(new GenericType<List<ForecastInstructionData>>() {});

    assertThat(instrs.size()).isGreaterThan(0);
    assertThat(instrs).extracting("status").containsOnly(NEW.name());
  }

  @Test
  public void findByStatusForPeriodLastMonth() throws Exception {

    TestData.setupInstrData(instrDao);

    // last month
    String from = LocalDate.now().minusMonths(1).format(DateUtils.DATE_FMT);
    String to = LocalDate.now().plusDays(1).format(DateUtils.DATE_FMT);
    List<ForecastInstructionData> instrs =
        forecastInstructionResource().queryParam("status", NEW.name())
            .queryParam("from", from).queryParam("to", to).request()
            .get(new GenericType<List<ForecastInstructionData>>() {});

    assertThat(instrs.size()).isGreaterThan(0);

    for (ForecastInstructionData i : instrs) {
      assertThat(i.status).isEqualTo(NEW.name());
      LocalDate actualDate =
          LocalDate.parse(i.forecastDate, DateUtils.DATE_FMT);
      assertThat(actualDate).isAfterOrEqualTo(
          LocalDate.parse(from, DateUtils.DATE_FMT));
      assertTrue(actualDate.isBefore(LocalDate.parse(to, DateUtils.DATE_FMT)));
    }
  }

  @Test
  public void updateStatus() throws Exception {

    NewForecastInstructionData expected =
        createNewInstrData(NEW_MONEY, TestData.PCF, CASH, "10000.01");

    String resourcePath = create(expected);
    Response response =
        target(resourcePath).request().put(Entity.json(PROCESSING.name()));
    assertThat(response.getStatus()).isEqualTo(Status.ACCEPTED.getStatusCode());

    ForecastInstructionData actual = findById(resourcePath);
    assertThat(actual.status).isEqualTo(PROCESSING.name());
  }

  private String create(NewForecastInstructionData instr) {

    Response response =
        forecastInstructionResource().request(APPLICATION_JSON).post(
            Entity.json(instr));
    assertThat(response.getStatus()).isEqualTo(Status.CREATED.getStatusCode());

    return response.getLocation().getPath();
  }

  private ForecastInstructionData findById(String path) {

    return target(path).request().get(ForecastInstructionData.class);
  }

  private static NewForecastInstructionData createNewInstrData(
      ForecastType forecastType, int fundId, MoneyNotificationType moneyType,
      String amt) {

    String forecastDate = LocalDate.now().format(DATE_FMT);
    return new NewForecastInstructionData(forecastDate, forecastType.name(),
        fundId, moneyType.name(), new BigDecimal(amt),
        TestData.eventId.getAndIncrement());
  }

  private static void assertSameAs(ForecastInstructionData actual,
      NewForecastInstructionData expected) {

    assertThat(actual).isNotNull();
    assertThat(expected).isNotNull();
    assertThat(actual.forecastDate).isEqualTo(expected.forecastDate);
    assertThat(actual.status).isEqualTo(MODELLED.name());
    assertThat(actual.forecastType).isEqualTo(expected.forecastType);
    assertThat(actual.moneyType).isEqualTo(expected.moneyType);
    assertThat(actual.fundId).isEqualTo(expected.fundId);
    assertThat(actual.amount).isEqualTo(expected.amount);
    assertThat(actual.eventSourceId).isEqualTo(expected.eventSourceId);
  }

}
