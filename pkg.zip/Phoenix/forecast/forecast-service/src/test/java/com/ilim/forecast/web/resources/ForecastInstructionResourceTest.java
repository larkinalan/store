package com.ilim.forecast.web.resources;

import static com.ilim.forecast.domain.model.ForecastStatus.MODELLED;
import static com.ilim.forecast.domain.model.ForecastStatus.PROCESSING;
import static com.ilim.forecast.web.resources.ForecastDataMapper.toNewForecastInstructionData;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.TestData;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import org.junit.Test;

import java.time.LocalDate;
import java.util.List;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


/**
 * Testing our web service. 
 *
 * @author Alan Larkin
 */
public class ForecastInstructionResourceTest extends AppResourceTestSupport {

  @Test
  public void createAndFindById() throws Exception {

    // set up test data
    NewForecastInstructionData expected =
        toNewForecastInstructionData(TestData.Instructions.BPL);

    // test
    String resource = createInstr(expected);
    ForecastInstructionData actual = findInstrById(resource);

    // verify
    assertThat(actual).isNotNull();
    assertThat(actual.forecastDate).isEqualTo(expected.forecastDate);
    assertThat(actual.status).isEqualTo(MODELLED.name());
    assertThat(actual.forecastType).isEqualTo(expected.forecastType);
    assertThat(actual.moneyType).isEqualTo(expected.moneyType);
    assertThat(actual.fundId).isEqualTo(expected.fundId);
    assertThat(actual.amount).isEqualTo(expected.amount);
    assertThat(actual.eventSourceId).isEqualTo(expected.eventSourceId);
  }

  @Test
  public void findAll() throws Exception {

    // set up test data
    NewForecastInstructionData newInstr =
        toNewForecastInstructionData(TestData.Instructions.BPL);
    String resource = createInstr(newInstr);
    ForecastInstructionData expected = findInstrById(resource);

    // test
    List<ForecastInstructionData> instrs = forecastInstructionResource()
        .request().get(new GenericType<List<ForecastInstructionData>>() {});

    // verify
    assertThat(instrs.size()).isGreaterThan(0);
    assertThat(instrs).contains(expected);
  }

  @Test
  public void findByStatus() throws Exception {

    // set up test data
    NewForecastInstructionData newInstr =
        toNewForecastInstructionData(TestData.Instructions.BPL);
    String resource = createInstr(newInstr);
    ForecastInstructionData expected = findInstrById(resource);

    // test
    List<ForecastInstructionData> instrs =
        forecastInstructionResource().queryParam("status", MODELLED.name())
            .request().get(new GenericType<List<ForecastInstructionData>>() {});

    assertThat(instrs.size()).isGreaterThan(0);
    assertThat(instrs).extracting("status").containsOnly(MODELLED.name());
    assertThat(instrs).extracting("id").contains(expected.id);
  }

  @Test
  public void findByStatusForPeriodLastMonth() throws Exception {

    // set up test data
    NewForecastInstructionData newInstr =
        toNewForecastInstructionData(TestData.Instructions.BPL);
    String resource = createInstr(newInstr);
    ForecastInstructionData expected = findInstrById(resource);

    // test
    String from = LocalDate.now().minusMonths(1).format(DateUtils.DATE_FMT);
    String to = LocalDate.now().plusDays(1).format(DateUtils.DATE_FMT);
    List<ForecastInstructionData> instrs =
        forecastInstructionResource().queryParam("status", MODELLED.name())
            .queryParam("from", from).queryParam("to", to).request()
            .get(new GenericType<List<ForecastInstructionData>>() {});

    // verify
    assertThat(instrs.size()).isGreaterThan(0);
    assertThat(instrs).extracting("id").contains(expected.id);
    for (ForecastInstructionData i : instrs) {
      assertThat(i.status).isEqualTo(MODELLED.name());
      LocalDate actualDate =
          LocalDate.parse(i.forecastDate, DateUtils.DATE_FMT);
      assertThat(actualDate)
          .isAfterOrEqualTo(LocalDate.parse(from, DateUtils.DATE_FMT));
      assertTrue(actualDate.isBefore(LocalDate.parse(to, DateUtils.DATE_FMT)));
    }
  }

  @Test
  public void updateStatus() throws Exception {

    // set up test data
    NewForecastInstructionData newInstr =
        toNewForecastInstructionData(TestData.Instructions.BPL);
    String resource = createInstr(newInstr);

    // test
    Response response =
        target(resource).request().put(Entity.json(PROCESSING.name()));
    assertThat(response.getStatus()).isEqualTo(Status.ACCEPTED.getStatusCode());

    // verify
    ForecastInstructionData actual = findInstrById(resource);
    assertThat(actual.status).isEqualTo(PROCESSING.name());
  }

}
