package com.ilim.forecast.app.service;

import static com.ilim.forecast.domain.model.ForecastStatus.FAILED;
import static com.ilim.forecast.domain.model.ForecastStatus.MODELLED;
import static com.ilim.forecast.domain.model.ForecastStatus.PENDING;
import static com.ilim.forecast.domain.model.ForecastStatus.PROCESSING;
import static com.ilim.forecast.domain.model.ForecastStatus.RECORDED;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.forecast.TestData;
import com.ilim.forecast.app.AppTestSupport;
import com.ilim.forecast.domain.model.ForecastInstruction;

import org.junit.Test;

import javax.inject.Inject;

public class ForecastInstructionServiceTest extends AppTestSupport {

  @Inject
  private IForecastInstructionService service;

  @Test
  public void newInstructionGetsModelled() {

    // setup
    int instrId = instrDao.create(TestData.Instructions.BPL);

    // test
    service.pending(instrId);

    // verify
    testSubscriber.assertPendingEvent(instrId);
    testSubscriber.assertProcessingEvent(instrId);
    testSubscriber.assertModelledEvent(instrId);
    ForecastInstruction instr = service.findById(instrId);
    assertThat(instr.getStatus()).isEqualTo(MODELLED);
  }

  @Test
  public void processingStateChange() {

    // setup
    int instrId = instrDao.create(TestData.Instructions.BPL);;
    service.updateStatus(instrId, PENDING);

    // test
    service.processing(instrId);

    // verify
    ForecastInstruction actual = service.findById(instrId);
    assertThat(actual.getStatus()).isEqualTo(PROCESSING);
  }

  @Test
  public void modelledStateChange() {

    // setup
    int instrId = instrDao.create(TestData.Instructions.BPL);
    service.updateStatus(instrId, PROCESSING);

    // test
    service.modelled(instrId);

    // verify
    ForecastInstruction actual = service.findById(instrId);
    assertThat(actual.getStatus()).isEqualTo(MODELLED);
  }

  @Test
  public void recordedStateChange() {

    // setup
    int instrId = instrDao.create(TestData.Instructions.BPL);
    service.updateStatus(instrId, MODELLED);

    // test
    service.recorded(instrId);

    // verify
    ForecastInstruction actual = service.findById(instrId);
    assertThat(actual.getStatus()).isEqualTo(RECORDED);
  }

  @Test
  public void failedStateChange() {

    // setup
    int instrId = instrDao.create(TestData.Instructions.BPL);
    service.updateStatus(instrId, MODELLED);

    // test
    service.failed(instrId);

    // verify
    ForecastInstruction actual = service.findById(instrId);
    assertThat(actual.getStatus()).isEqualTo(FAILED);
  }
}
