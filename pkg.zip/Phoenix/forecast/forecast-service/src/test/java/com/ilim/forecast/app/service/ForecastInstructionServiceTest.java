package com.ilim.forecast.app.service;

import static com.ilim.forecast.domain.model.ForecastStatus.FAILED;
import static com.ilim.forecast.domain.model.ForecastStatus.MODELLED;
import static com.ilim.forecast.domain.model.ForecastStatus.PENDING;
import static com.ilim.forecast.domain.model.ForecastStatus.PROCESSING;
import static com.ilim.forecast.domain.model.ForecastStatus.RECORDED;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.forecast.TestData;
import com.ilim.forecast.app.conf.SpringTestConfig;
import com.ilim.forecast.domain.IForecastInstructionRepository;
import com.ilim.forecast.domain.model.ForecastInstruction;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import javax.inject.Inject;

@ContextConfiguration(classes = SpringTestConfig.class)
public class ForecastInstructionServiceTest
    extends AbstractTransactionalJUnit4SpringContextTests {

  @Inject
  private IForecastInstructionRepository dao;
  @Inject
  private IForecastInstructionService service;
  @Inject
  private TestSubscriber testSubscriber;

  @Test
  public void newInstructionGetsModelled() {

    int instrId = TestData.createNewInstrData(dao);
    service.pending(instrId);
    testSubscriber.assertPendingEvent(instrId);
    testSubscriber.assertProcessingEvent(instrId);
    testSubscriber.assertModelledEvent(-1, instrId);

    ForecastInstruction instr = dao.findById(instrId);
    assertThat(instr.getStatus()).isEqualTo(MODELLED);
  }

  @Test
  public void processingStateChange() {

    int instrId = TestData.createNewInstrData(dao);
    service.updateStatus(instrId, PENDING);

    service.processing(instrId);

    ForecastInstruction actual = service.findById(instrId);
    assertThat(actual.getStatus()).isEqualTo(PROCESSING);
  }

  @Test
  public void modelledStateChange() {

    int instrId = TestData.createNewInstrData(dao);
    service.updateStatus(instrId, PROCESSING);

    service.modelled(instrId);

    ForecastInstruction actual = service.findById(instrId);
    assertThat(actual.getStatus()).isEqualTo(MODELLED);
  }

  @Test
  public void recordedStateChange() {

    int instrId = TestData.createNewInstrData(dao);
    service.updateStatus(instrId, MODELLED);

    service.recorded(instrId);

    ForecastInstruction actual = service.findById(instrId);
    assertThat(actual.getStatus()).isEqualTo(RECORDED);
  }

  @Test
  public void failedStateChange() {

    int instrId = TestData.createNewInstrData(dao);
    service.updateStatus(instrId, MODELLED);

    service.failed(instrId);

    ForecastInstruction actual = service.findById(instrId);
    assertThat(actual.getStatus()).isEqualTo(FAILED);
  }
}
