package com.ilim.forecast.web.resources;

import com.ilim.forecast.app.conf.SpringTestConfig;
import com.ilim.forecast.domain.IForecastInstructionRepository;
import com.ilim.forecast.domain.IForecastModelAllocRepository;
import com.ilim.forecast.web.conf.JerseyConfig;

import com.codahale.metrics.MetricRegistry;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.test.JerseyTest;
import org.glassfish.jersey.test.TestProperties;
import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;

import javax.ws.rs.core.Application;


/**
 * Support class for Testing our jersey services with spring transactions.
 * 
 * <p>Extend this class instead of JerseyTest.
 *
 * @author Alan Larkin
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringTestConfig.class)
@Transactional
@Rollback
public class AppResourceTestSupport extends JerseyTest {

  private JerseyConfig jerseyTestConfig;
  private ApplicationContext springTestConfig;
  
  @Override
  protected Application configure() {

    enable(TestProperties.LOG_TRAFFIC);
    enable(TestProperties.DUMP_ENTITY);
    forceSet(TestProperties.CONTAINER_PORT, "0");

    jerseyTestConfig = new JerseyConfig();
    springTestConfig =
        new AnnotationConfigApplicationContext(SpringTestConfig.class);
    jerseyTestConfig.property("contextConfig", springTestConfig);
   
    getBeans(springTestConfig);
    return jerseyTestConfig;
  }

  @Override
  protected void configureClient(ClientConfig config) {

    config.register(JacksonFeature.class);
  }
  
  protected JerseyConfig jerseyConfig() {
    return jerseyTestConfig;
  }
  
  protected ApplicationContext springConfig() {
    return springTestConfig;
  }
  
  protected MetricRegistry metrics() {
    return jerseyTestConfig.metrics();
  }
  
  /* Get beans all beans you need to use in tests here  */
  protected void getBeans(ApplicationContext ctx) {
    
    logger = ctx.getBean(TestRule.class);
    
    instrDao = ctx.getBean(IForecastInstructionRepository.class);
    modelDao = ctx.getBean(IForecastModelAllocRepository.class);
    
  }

  @Rule
  public TestRule logger;
  
  protected IForecastInstructionRepository instrDao;
  protected IForecastModelAllocRepository modelDao;
  
  
  protected void setRollback(boolean enable) {
    
    if (enable) {
      
      // TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
      
      PlatformTransactionManager txnMgr =
          springTestConfig.getBean(PlatformTransactionManager.class);
      TransactionStatus currentTxn = txnMgr.getTransaction(null);
      currentTxn.setRollbackOnly();
      txnMgr.commit(currentTxn);
    }
  }
}


