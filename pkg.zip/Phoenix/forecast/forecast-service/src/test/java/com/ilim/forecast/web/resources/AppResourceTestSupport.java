package com.ilim.forecast.web.resources;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.forecast.app.conf.SpringTestConfig;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.NewForecastInstructionData;
import com.ilim.forecast.web.conf.JerseyConfig;

import com.codahale.metrics.MetricRegistry;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.test.JerseyTest;
import org.glassfish.jersey.test.TestProperties;
import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


/**
 * Support class for Testing our jersey services with spring transactions.
 * 
 * <p>Extend this class instead of JerseyTest.
 *
 * @author Alan Larkin
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringTestConfig.class)
@Transactional
@Rollback
public class AppResourceTestSupport extends JerseyTest {

  private JerseyConfig jerseyTestConfig;
  private ApplicationContext springTestConfig;

  @Override
  protected Application configure() {

    enable(TestProperties.LOG_TRAFFIC);
    enable(TestProperties.DUMP_ENTITY);
    forceSet(TestProperties.CONTAINER_PORT, "0");

    jerseyTestConfig = new JerseyConfig();
    springTestConfig =
        new AnnotationConfigApplicationContext(SpringTestConfig.class);
    jerseyTestConfig.property("contextConfig", springTestConfig);

    return jerseyTestConfig;
  }

  @Override
  protected void configureClient(ClientConfig config) {

    config.register(JacksonFeature.class);
  }

  protected JerseyConfig jerseyConfig() {
    return jerseyTestConfig;
  }

  protected ApplicationContext springConfig() {
    return springTestConfig;
  }

  protected MetricRegistry metrics() {
    return jerseyTestConfig.metrics();
  }

  @Rule
  public TestRule logger;


  protected WebTarget forecastInstructionResource() {
    return target("instructions");
  }

  protected WebTarget forecastModelResource() {
    return target("models");
  }

  protected String createInstr(NewForecastInstructionData instr) {

    Response response = forecastInstructionResource().request(APPLICATION_JSON)
        .post(Entity.json(instr));
    assertThat(response.getStatus()).isEqualTo(Status.CREATED.getStatusCode());

    return response.getLocation().getPath();
  }

  protected ForecastInstructionData findInstrById(String path) {

    return target(path).request().get(ForecastInstructionData.class);
  }

}


