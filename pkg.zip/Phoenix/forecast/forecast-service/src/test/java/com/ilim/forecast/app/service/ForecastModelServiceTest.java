package com.ilim.forecast.app.service;

import static com.ilim.forecast.domain.model.ForecastStatus.MODELLED;
import static com.ilim.forecast.domain.model.ForecastStatus.PENDING;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.forecast.TestData;
import com.ilim.forecast.app.AppTestSupport;
import com.ilim.forecast.domain.InstructionFactory;
import com.ilim.forecast.domain.event.PendingForecastInstruction;
import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModel;
import com.ilim.forecast.domain.model.ForecastModelAlloc;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

public class ForecastModelServiceTest extends AppTestSupport {

  @Inject
  private IForecastModelService modelService;

  @Test
  public void model() {

    // setup instr in db and fabricate and event
    int instrId = instrDao.create(TestData.Instructions.BPL);
    instrDao.updateStatus(instrId, PENDING);
    PendingForecastInstruction pendingEvent =
        (PendingForecastInstruction) InstructionFactory
            .createPendingEvent(instrDao.findById(instrId));

    // test
    modelService.model(pendingEvent);

    // verify instr
    ForecastInstruction instr = instrDao.findById(instrId);
    assertThat(instr.getStatus()).isEqualTo(MODELLED);
    testSubscriber.assertProcessingEvent(instrId);
    testSubscriber.assertModelledEvent(instrId);

    // verify model instr
    ForecastModel model = modelService.findByInstrId(instrId);
    assertThat(model.getInstruction().getId()).isEqualTo(instrId);
    assertThat(model.getInstruction().getForecastDate())
        .isEqualTo(TestData.Instructions.BPL.getForecastDate());
    assertThat(model.getInstruction().getFundId())
        .isEqualTo(TestData.Instructions.BPL.getFundId());
    assertThat(model.getInstruction().getForecastType())
        .isEqualTo(TestData.Instructions.BPL.getForecastType());
    
    // verify model allocs
    model.getModelAllocs().stream()
        .forEach(a -> assertThat(a.getFundId()).isIn(TestData.Funds.list));
    // TODO: validate allocs ?
  }

  @Test
  public void saveNew() {

    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<ForecastModelAlloc> expected =
        TestData.ModelAllocs.but().withInstrId(instrId).build();
    List<Integer> allocIds = modelService.save(expected);

    // test
    List<ForecastModelAlloc> actual =
        modelAllocDao.findByInstrId(Arrays.asList(instrId));

    // verify
    assertThat(actual).extracting("allocId").containsOnly(allocIds.toArray());
  }

  @Test
  public void saveExisting() {

    // set up data
    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<Integer> save1 = modelService
        .save(TestData.ModelAllocs.but().withInstrId(instrId).build());
    List<ForecastModelAlloc> allocs =
        modelAllocDao.findByInstrId(Arrays.asList(instrId));
    assertThat(allocs).extracting("allocId").containsOnly(save1.toArray());

    // test & verify we delete and recreate the allocs
    List<Integer> save2 = modelService.save(allocs);
    allocs = modelAllocDao.findByInstrId(Arrays.asList(instrId));
    assertThat(allocs).extracting("allocId").containsOnly(save2.toArray());
    assertThat(allocs).extracting("allocId").doesNotContain(save1);
  }

  @Test
  public void delete() {

    // set up data
    int instrId = instrDao.create(TestData.Instructions.BPL);
    List<Integer> ids = modelService
        .save(TestData.ModelAllocs.but().withInstrId(instrId).build());
    List<ForecastModelAlloc> allocs =
        modelAllocDao.findByInstrId(Arrays.asList(instrId));
    assertThat(allocs).extracting("allocId").containsOnly(ids.toArray());

    // test
    modelService.delete(allocs);
    // verify
    allocs = modelAllocDao.findByInstrId(Arrays.asList(instrId));
    assertThat(allocs).hasSize(0);
  }

}
