package com.ilim.forecast.app.service;

import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_CASH;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_MIX;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_PRICE;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_UNITS;
import static com.ilim.forecast.domain.model.ForecastStatus.MODELLED;
import static com.ilim.forecast.domain.model.ForecastStatus.PENDING;

import static java.math.RoundingMode.HALF_EVEN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.domain.model.MoneyNotificationType;
import com.ilim.forecast.TestData;
import com.ilim.forecast.domain.IForecastInstructionRepository;
import com.ilim.forecast.domain.IForecastModelRepository;
import com.ilim.forecast.domain.event.PendingForecastInstruction;
import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModelAlloc;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class ForecastModelServiceTest extends AppServiceTestSupport {

  @Inject
  private IForecastModelRepository modelDao;
  @Inject
  private IForecastInstructionRepository instrDao;
  @Inject
  private IForecastModelService modelService;

  @Test
  public void model() {

    int instrId = TestData.createNewInstrData(instrDao);
    instrDao.updateStatus(instrId, PENDING);

    PendingForecastInstruction pendingEvent = new PendingForecastInstruction(
        instrId, LocalDate.now(), ForecastType.NEW_MONEY.id(), TestData.PCF,
        MoneyNotificationType.CASH.id(), new BigDecimal("100"));

    modelService.model(pendingEvent);

    ForecastInstruction instr = instrDao.findById(instrId);
    assertThat(instr.getStatus()).isEqualTo(MODELLED);

    testSubscriber.assertProcessingEvent(instrId);
    testSubscriber.assertModelledEvent(instrId);
  }

  @Test
  public void saveNew() {

    int instrId = TestData.createNewInstrData(instrDao);
    List<ForecastModelAlloc> expected =
        TestData.newModelList(instrId, LocalDate.now(), modelDao);
    int modelId = modelService.save(expected);
    assertTrue(modelId > 0);

    List<ForecastModelAlloc> actual = modelDao.findByModelId(modelId);
    assertThat(actual).hasSize(4);
  }

  @Test
  public void saveExisting() {

    int instrId = TestData.createNewInstrData(instrDao);
    List<ForecastModelAlloc> model =
        TestData.newModelList(instrId, LocalDate.now(), modelDao);
    int modelId = modelService.save(model);
    assertTrue(modelId > 0);

    List<ForecastModelAlloc> actual = modelDao.findByModelId(modelId);
    assertThat(actual).hasSize(4);

    BigDecimal updatedUnitsInIssue =
        new BigDecimal("100.01").setScale(ROUND_UNITS.scale(), HALF_EVEN);
    BigDecimal updatedPrice =
        new BigDecimal("101.02").setScale(ROUND_PRICE.scale(), HALF_EVEN);
    BigDecimal updatedMix =
        new BigDecimal("101.03").setScale(ROUND_MIX.scale(), HALF_EVEN);
    BigDecimal updatedCash =
        new BigDecimal("101.04").setScale(ROUND_CASH.scale(), HALF_EVEN);
    BigDecimal updatedRecordedCash =
        new BigDecimal("101.05").setScale(ROUND_CASH.scale(), HALF_EVEN);

    List<ForecastModelAlloc> expectedModel = new ArrayList<>();
    LocalDateTime created = LocalDateTime.now();
    for (ForecastModelAlloc alloc : actual) {

      LocalDate forecastDate = alloc.getForecastDate();
      int fundId = alloc.getId().getFundId();
      int holdingId = alloc.getId().getHoldingId();

      expectedModel.add(new ForecastModelAlloc(modelId, forecastDate, instrId,
          fundId, holdingId, updatedUnitsInIssue, updatedPrice, updatedMix,
          updatedCash, updatedRecordedCash, created));
    }

    int updatedModelId = modelService.save(expectedModel);
    assertTrue(updatedModelId > 0);

    List<ForecastModelAlloc> updatedModel =
        modelDao.findByModelId(updatedModelId);
    assertThat(updatedModel).hasSize(4);
    for (ForecastModelAlloc actualModel : updatedModel) {
      assertThat(updatedUnitsInIssue)
          .isEqualTo(actualModel.getCommittedUnits());
      assertThat(updatedPrice).isEqualTo(actualModel.getPrice());
      assertThat(updatedMix).isEqualTo(actualModel.getMix());
      assertThat(updatedCash).isEqualTo(actualModel.getCash());
      assertThat(updatedRecordedCash).isEqualTo(actualModel.getRecordedCash());
    }
  }

  @Test
  public void deleteModel() {

    int modelId = TestData.setupModelData(instrDao, modelDao);
    assertTrue(modelId > 0);
    List<ForecastModelAlloc> model = modelDao.findByModelId(modelId);
    assertThat(model).hasSize(4);

    modelService.delete(model);

    List<ForecastModelAlloc> modelAfterDeleted =
        modelDao.findByModelId(modelId);
    assertThat(modelAfterDeleted).hasSize(0);
  }

}
