package com.ilim.forecast.app.service;

import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_CASH;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_MIX;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_PRICE;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_UNITS;
import static com.ilim.forecast.domain.model.ForecastStatus.MODELLED;
import static com.ilim.forecast.domain.model.ForecastStatus.PENDING;

import static java.math.RoundingMode.HALF_EVEN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.domain.model.MoneyNotificationType;
import com.ilim.forecast.TestData;
import com.ilim.forecast.app.AppTestSupport;
import com.ilim.forecast.domain.IForecastInstructionRepository;
import com.ilim.forecast.domain.IForecastModelAllocRepository;
import com.ilim.forecast.domain.event.PendingForecastInstruction;
import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModelAlloc;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class ForecastModelServiceTest extends AppTestSupport {

  @Inject
  private IForecastModelAllocRepository modelDao;
  @Inject
  private IForecastInstructionRepository instrDao;
  @Inject
  private IForecastModelService modelService;

  @Test
  public void model() {

    int instrId = instrDao.create(TestData.Instructions.BPL);
    instrDao.updateStatus(instrId, PENDING);

    PendingForecastInstruction pendingEvent = new PendingForecastInstruction(
        instrId, LocalDate.now(), ForecastType.NEW_MONEY, TestData.Funds.BPL,
        MoneyNotificationType.CASH, new BigDecimal("100"));

    modelService.model(pendingEvent);

    ForecastInstruction instr = instrDao.findById(instrId);
    assertThat(instr.getStatus()).isEqualTo(MODELLED);

    testSubscriber.assertProcessingEvent(instrId);
    testSubscriber.assertModelledEvent(instrId);
  }

  @Test
  public void saveNew() {

    int instrId = TestData.createNewInstrData(instrDao);
    List<ForecastModelAlloc> expected =
        TestData.newModelList(instrId, LocalDate.now(), modelDao);
    int modelId = modelService.save(expected);
    assertTrue(modelId > 0);

    List<ForecastModelAlloc> actual = modelDao.findById(modelId);
    assertThat(actual.size()).isGreaterThan(0);
  }

  @Test
  public void saveExisting() {

    int instrId = TestData.createNewInstrData(instrDao);
    List<ForecastModelAlloc> model =
        TestData.newModelList(instrId, LocalDate.now(), modelDao);
    int modelId = modelService.save(model);
    assertTrue(modelId > 0);

    List<ForecastModelAlloc> actual = modelDao.findById(modelId);
    assertThat(actual).hasSize(4);

    BigDecimal updatedUnitsInIssue =
        new BigDecimal("100.01").setScale(ROUND_UNITS.scale(), HALF_EVEN);
    BigDecimal updatedPrice =
        new BigDecimal("101.02").setScale(ROUND_PRICE.scale(), HALF_EVEN);
    BigDecimal updatedMix =
        new BigDecimal("101.03").setScale(ROUND_MIX.scale(), HALF_EVEN);
    BigDecimal updatedCash =
        new BigDecimal("101.04").setScale(ROUND_CASH.scale(), HALF_EVEN);

    List<ForecastModelAlloc> expectedModel = new ArrayList<>();
    LocalDateTime created = LocalDateTime.now();
    for (ForecastModelAlloc alloc : actual) {

      int fundId = alloc.getFundId();
      int holdingId = alloc.getHoldingId();

      expectedModel.add(new ForecastModelAlloc(modelId, instrId,
          fundId, holdingId, updatedUnitsInIssue, updatedPrice, updatedMix,
          updatedCash, created));
    }

    int updatedModelId = modelService.save(expectedModel);
    assertTrue(updatedModelId > 0);

    List<ForecastModelAlloc> updatedModel =
        modelDao.findById(updatedModelId);
    assertThat(updatedModel).hasSize(4);
    for (ForecastModelAlloc actualModel : updatedModel) {
      assertThat(updatedUnitsInIssue)
          .isEqualTo(actualModel.getCommittedUnits());
      assertThat(updatedPrice).isEqualTo(actualModel.getPrice());
      assertThat(updatedMix).isEqualTo(actualModel.getMix());
      assertThat(updatedCash).isEqualTo(actualModel.getCash());
    }
  }

  @Test
  public void delete() {

    int modelId = TestData.setupModelData(instrDao, modelDao);
    assertTrue(modelId > 0);
    List<ForecastModelAlloc> model = modelDao.findById(modelId);
    assertThat(model).hasSize(4);

    modelService.delete(model);

    List<ForecastModelAlloc> modelAfterDeleted =
        modelDao.findById(modelId);
    assertThat(modelAfterDeleted).hasSize(0);
  }

}
