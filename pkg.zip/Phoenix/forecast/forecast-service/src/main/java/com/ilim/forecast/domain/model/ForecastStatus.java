package com.ilim.forecast.domain.model;

/**
 * Forecast states.
 * 
 * @author michael cunnigham
 *
 */
public enum ForecastStatus {

  UNKNOWN(0), 
  NEW(1), 
  PENDING(2), 
  PROCESSING(3), 
  MODELLED(4), 
  AWAITING_RECORD(5), 
  RECORDED(6), 
  FAILED(7);

  private final int id;

  ForecastStatus(int id) {
    this.id = id;
  }

  public int id() {
    return id;
  }

  /** Returns the enum for an id. */
  public static ForecastStatus from(int id) {

    for (ForecastStatus type : ForecastStatus.values()) {
      if (type.id() == id) {
        return type;
      }
    }
    return UNKNOWN;
  }

  /** Returns the enum for a name. */
  public static ForecastStatus from(String name) {

    for (ForecastStatus type : ForecastStatus.values()) {
      if (type.name().equalsIgnoreCase(name)) {
        return type;
      }
    }
    return UNKNOWN;
  }
}
