package com.ilim.forecast.domain;

import com.ilim.forecast.domain.model.ForecastModelAlloc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Forecast Model Repository.
 * 
 * <p>persistence api for forecast model dao.
 *
 * @author michael cunnigham
 */
public interface IForecastModelRepository {

  ForecastModelAlloc findById(ForecastModelAlloc.Id id);

  List<ForecastModelAlloc> findByModelId(int modelId);

  List<ForecastModelAlloc> findByForecastDate(LocalDate forecastDate);

  List<ForecastModelAlloc> findByFundIdAndForecastDate(int fundId,
      LocalDate forecastDate);

  List<ForecastModelAlloc> findAll();

  int create(List<ForecastModelAlloc> model);

  void delete(int modelId);

  void deleteById(ForecastModelAlloc.Id id);

  void update(ForecastModelAlloc.Id id, BigDecimal recordedCash);

}
