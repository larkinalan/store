package com.ilim.forecast.web.conf;

import com.ilim.forecast.web.filter.CorsResponseFilter;
import com.ilim.forecast.web.filter.LoggingResponseFilter;
import com.ilim.forecast.web.resources.AppExceptionMapper.AppConfigExceptionMapper;
import com.ilim.forecast.web.resources.AppExceptionMapper.AppDataExceptionMapper;
import com.ilim.forecast.web.resources.AppExceptionMapper.DateTimeExceptionMapper;
import com.ilim.forecast.web.resources.AppExceptionMapper.IllegalArgumentExceptionMapper;
import com.ilim.forecast.web.resources.AppExceptionMapper.IllegalStateExceptionMapper;
import com.ilim.forecast.web.resources.AppExceptionMapper.NoSuchElementExceptionMapper;
import com.ilim.forecast.web.resources.AppExceptionMapper.NullPointerExceptionMapper;
import com.ilim.forecast.web.resources.AppExceptionMapper.UnsupportedOperationExceptionMapper;
import com.ilim.forecast.web.resources.ForecastInstructionResource;
import com.ilim.forecast.web.resources.ForecastModelResource;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.jersey2.InstrumentedResourceMethodApplicationListener;

import org.glassfish.jersey.filter.LoggingFilter;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.spring.scope.RequestContextFilter;
import org.springframework.stereotype.Component;

/**
 * Jersey resource config.
 *
 * @author Michael Cunningham
 */
@Component
public class JerseyConfig extends ResourceConfig {

  private final MetricRegistry metrics = new MetricRegistry();

  /** Register JAX-RS application components. */
  public JerseyConfig() {

    // resources
    register(ForecastInstructionResource.class);
    register(ForecastModelResource.class);

    // filters
    register(RequestContextFilter.class); // jersey spring
    register(CorsResponseFilter.class); // cross origin
    register(LoggingFilter.class); // default logging
    register(LoggingResponseFilter.class); // custom logging

    // exceptions
    register(AppConfigExceptionMapper.class);
    register(AppDataExceptionMapper.class);
    register(DateTimeExceptionMapper.class);
    register(NoSuchElementExceptionMapper.class);
    register(NullPointerExceptionMapper.class);
    register(IllegalArgumentExceptionMapper.class);
    register(IllegalStateExceptionMapper.class);
    register(UnsupportedOperationExceptionMapper.class);

    // Jackson
    register(JacksonFeature.class);

    // metrics
    register(new InstrumentedResourceMethodApplicationListener(metrics));
  }

  public MetricRegistry metrics() {
    return metrics;
  }

}
