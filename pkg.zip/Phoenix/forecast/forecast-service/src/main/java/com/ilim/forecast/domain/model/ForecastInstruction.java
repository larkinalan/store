package com.ilim.forecast.domain.model;

import static com.ilim.commons.domain.model.MoneyNotificationType.CASH;
import static com.ilim.commons.domain.model.MoneyNotificationType.UNITS;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_CASH;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_PRICE;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_UNITS;
import static java.math.RoundingMode.HALF_EVEN;

import com.ilim.commons.domain.IEntity;
import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.domain.model.MoneyNotificationType;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;

/**
 * Forecast Instruction Entity.
 * 
 * <p>This represents the instructions orders that come into the system from
 * eclipps and fusion.
 *
 * @author Michael Cunningham
 */
public class ForecastInstruction implements IEntity<Integer> {

  private final int id;
  private final LocalDate forecastDate;
  private final ForecastStatus status;
  private final ForecastType forecastType;
  private final int fundId;
  private final MoneyNotificationType moneyType;
  private final BigDecimal amount;
  private final LocalDateTime creationTime;
  private final long eventSourceId;

  /** Creates a ForecastInstruction domain entity. */
  public ForecastInstruction(int id, LocalDate forecastDate,
      ForecastStatus status, ForecastType forecastType, int fundId,
      MoneyNotificationType moneyType, BigDecimal amount,
      LocalDateTime creationTime, long eventSourceId) {

    this.id = id;
    this.forecastDate = forecastDate;
    this.status = status;
    this.forecastType = forecastType;
    this.fundId = fundId;
    this.moneyType = moneyType;
    this.amount = amount;
    this.creationTime = creationTime;
    this.eventSourceId = eventSourceId;

  }

  public Integer getId() {
    return id;
  }

  public LocalDate getForecastDate() {
    return forecastDate;
  }

  public ForecastStatus getStatus() {
    return status;
  }

  public ForecastType getForecastType() {
    return forecastType;
  }

  public int getFundId() {
    return fundId;
  }

  public MoneyNotificationType getMoneyType() {
    return moneyType;
  }

  /** Returns amount rounded by moneyType and ForecastRounding. */
  public BigDecimal getAmount() {

    if (moneyType == CASH) {
      return amount.setScale(ROUND_CASH.scale(), HALF_EVEN);
    } else {
      return amount.setScale(ROUND_UNITS.scale(), HALF_EVEN);
    }
  }

  /** 
   * Calculates cash. 
   * 
   * <p>cash = units * price.
   *  uses ForecastRounding.
   * 
   * @param latestPrice     latest price
   * @return cash.  
   * 
   */
  public BigDecimal cash(Optional<BigDecimal> latestPrice) {

    final BigDecimal cash;

    if (moneyType == CASH) {

      cash = amount;

    } else {

      if (latestPrice.isPresent()) {

        // cash = units * price
        BigDecimal price =
            latestPrice.get().setScale(ROUND_PRICE.scale(), HALF_EVEN);
        cash = units(latestPrice).multiply(price);

      } else {
        throw new IllegalArgumentException(
            "Price missing for cash calc of forecast instruction " + id);
      }
    }

    return cash.setScale(ROUND_CASH.scale(), HALF_EVEN);
  }

  /** 
   * Calculates units. 
   * 
   * <p>units = cash / price.
   * uses ForecastRounding.
   * 
   * @param latestPrice     latest price
   * @return units.  
   * 
   */
  public BigDecimal units(Optional<BigDecimal> latestPrice) {

    final BigDecimal units;

    if (moneyType == UNITS) {

      units = amount;

    } else {

      if (latestPrice.isPresent()) {

        // units = cash / price
        BigDecimal price =
            latestPrice.get().setScale(ROUND_PRICE.scale(), HALF_EVEN);
        units = cash(latestPrice).divide(price);

      } else {
        throw new IllegalArgumentException(
            "Price missing for units calc of forecast instruction " + id);
      }
    }

    return units.setScale(ROUND_UNITS.scale(), HALF_EVEN);
  }

  public LocalDateTime getCreationTime() {
    return creationTime;
  }

  public long getEventSourceId() {
    return eventSourceId;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final ForecastInstruction other = (ForecastInstruction) obj;
    return Objects.equals(this.getId(), other.getId());
  }

  @Override
  public int hashCode() {

    return Objects.hashCode(this.getId());
  }

  @Override
  public String toString() {

    return MoreObjects.toStringHelper(this).add("id", id)
        .add("forecastDate", forecastDate).add("status", status)
        .add("forecastType", forecastType).add("moneyType", moneyType)
        .add("fundId", getFundId()).add("amount", this.amount)
        .add("creationTime", this.getCreationTime())
        .add("eventSourceId", eventSourceId).toString();
  }

}
