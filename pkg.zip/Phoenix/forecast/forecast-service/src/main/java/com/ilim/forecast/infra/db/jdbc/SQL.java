package com.ilim.forecast.infra.db.jdbc;

/*
 *  Sql statements used in Dao
 *  
 *  <p>Formatted and wrapped using TOAD. 
 *  
 *  @author Alan Larkin
 *  
 *  @formatter:off
 *  CHECKSTYLE:OFF
 */
public class SQL {

  /*******************************************
   * T_FORECAST_INSTRUCTION sql statements
   *******************************************/
  
  public static final String select_from_forecast_instr =
      "SELECT forecast_instruction_id " +
      "     , forecast_dt " +
      "     , forecast_status_id " +
      "     , forecast_type_id " +
      "     , money_notification_type_id " +
      "     , ilim_id " +
      "     , amount " +
      "     , creation_ts " +
      "     , event_id " +
      "  FROM forecast_instruction "; 
  
  public static final String select_from_forecast_instr_by_id =        
      "SELECT forecast_instruction_id " +
      "     , forecast_dt " +
      "     , forecast_status_id " +
      "     , forecast_type_id " +
      "     , money_notification_type_id " +
      "     , ilim_id " +
      "     , amount " +
      "     , creation_ts " +
      "     , event_id " +
      "  FROM forecast_instruction " +
      " WHERE forecast_instruction_id = :id "; 
  
  public static final String select_from_forecast_instr_by_status =   
      "SELECT forecast_instruction_id " +
      "     , forecast_dt " +
      "     , forecast_status_id " +
      "     , forecast_type_id " +
      "     , money_notification_type_id " +
      "     , ilim_id " +
      "     , amount " +
      "     , creation_ts " +
      "     , event_id " +
      "  FROM forecast_instruction " +
      " WHERE forecast_status_id = :statusId  " ; 
  
  public static final String select_from_forecast_instr_by_status_for_period =
      "SELECT forecast_instruction_id " +
      "     , forecast_dt " +
      "     , forecast_status_id " +
      "     , forecast_type_id " +
      "     , money_notification_type_id " +
      "     , ilim_id " +
      "     , amount " +
      "     , creation_ts " +
      "     , event_id " +
      "  FROM forecast_instruction " +
      " WHERE forecast_status_id = :statusId " +
      "   AND forecast_dt BETWEEN :from AND :to ";
  
  public static final String select_from_forecast_instr_seq =
      "SELECT forecast_instr_seq.NEXTVAL as id " +
      "  FROM DUAL"; 
  
  public static final String insert_into_forecast_instr =
      "INSERT INTO forecast_instruction( forecast_instruction_id " +
      "                          , forecast_dt " +
      "                          , forecast_status_id " +
      "                          , forecast_type_id " +
      "                          , ilim_id " +
      "                          , money_notification_type_id " +
      "                          , amount " +
      "                          , creation_ts " +
      "                          , event_id ) " +
      "VALUES ( :id " +
      "       , :forecastDate " +
      "       , :statusId " +
      "       , :forecastTypeId " +
      "       , :fundId " +
      "       , :moneyTypeId " +
      "       , :amount " +
      "       , :creationTime " +
      "       , :eventSourceId ) "; 
  
  public static final String update_forecast_instr_status =
      "UPDATE forecast_instruction " +
      "   SET forecast_status_id = :statusId " +
      " WHERE forecast_instruction_id = :id "; 
  
  
  /*******************************************
   * T_FORECAST_MODEL sql statements
   *******************************************/

  public static final String select_from_forecast_model =
      "SELECT forecast_model_id " +
      "     , forecast_dt " +
      "     , forecast_instruction_id " +
      "     , ilim_id " +
      "     , underlying_ilim_id " +
      "     , committed_units_in_issue_qty " +
      "     , committed_txn_price " +
      "     , mix_pct " +
      "     , cash_amt " +
      "     , recorded_amt " +
      "     , creation_ts " +
      "  FROM forecast_model ";
  
  public static final String select_from_forecast_model_by_id =  
      "SELECT forecast_model_id " +
      "     , forecast_dt " +
      "     , forecast_instruction_id " +
      "     , ilim_id " +
      "     , underlying_ilim_id " +
      "     , committed_units_in_issue_qty " +
      "     , committed_txn_price " +
      "     , mix_pct " +
      "     , cash_amt " +
      "     , recorded_amt " +
      "     , creation_ts " +
      "  FROM forecast_model " +
      " WHERE forecast_model_id = :modelId " +
      "   AND forecast_instruction_id = :instrId " +
      "   AND ilim_id = :fundId " +
      "   AND underlying_ilim_id = :holdingId " ; 
  
  public static final String select_from_forecast_model_by_modelid =        
      "SELECT forecast_model_id " +
      "     , forecast_dt " +
      "     , forecast_instruction_id " +
      "     , ilim_id " +
      "     , underlying_ilim_id " +
      "     , committed_units_in_issue_qty " +
      "     , committed_txn_price " +
      "     , mix_pct " +
      "     , cash_amt " +
      "     , recorded_amt " +
      "     , creation_ts " +
      "  FROM forecast_model " +
      " WHERE forecast_model_id = :modelId "; 
  
  public static final String select_from_forecast_model_by_forecastdate =        
	      "SELECT forecast_model_id " +
	      "     , forecast_dt " +
	      "     , forecast_instruction_id " +
	      "     , ilim_id " +
	      "     , underlying_ilim_id " +
	      "     , committed_units_in_issue_qty " +
	      "     , committed_txn_price " +
	      "     , mix_pct " +
	      "     , cash_amt " +
	      "     , recorded_amt " +
	      "     , creation_ts " +
	      "  FROM forecast_model " +
	      " WHERE forecast_dt = :forecastDate "; 

  public static final String select_from_forecast_model_by_fundid_and_forecastdate =        
	      "SELECT forecast_model_id " +
	      "     , forecast_dt " +
	      "     , forecast_instruction_id " +
	      "     , ilim_id " +
	      "     , underlying_ilim_id " +
	      "     , committed_units_in_issue_qty " +
	      "     , committed_txn_price " +
	      "     , mix_pct " +
	      "     , cash_amt " +
	      "     , recorded_amt " +
	      "     , creation_ts " +
	      "  FROM forecast_model " +
	      " WHERE ilim_id = :fundId " +
	      "   AND forecast_dt = :forecastDate "; 
  
  public static final String select_from_forecast_model_seq =
      "SELECT forecast_model_seq.NEXTVAL as modelId " +
      "  FROM DUAL"; 
  
  public static final String insert_into_forecast_model =
      "INSERT INTO forecast_model( forecast_model_id " +
      "                          , forecast_dt " +
      "                          , forecast_instruction_id " +
      "                          , ilim_id " +
      "                          , underlying_ilim_id " +
      "                          , committed_units_in_issue_qty " +
      "                          , committed_txn_price " +
      "                          , mix_pct " +
      "                          , cash_amt " +
      "                          , recorded_amt " +
      "                          , creation_ts ) " +
      "VALUES ( :modelId " +
      "       , :forecastDate " +
      "       , :instrId " +
      "       , :fundId " +
      "       , :holdingId " +
      "       , :unitsInIssue " +
      "       , :price " +
      "       , :mix " +
      "       , :cash " +
      "       , :recordedCash " +
      "       , :creationTime ) "; 

  public static final String update_forecast_model_recorded_amt = 
      "UPDATE forecast_model " +
      "   SET recorded_amt = :recordedCash " +
      " WHERE forecast_model_id = :modelId " +
      "   AND forecast_instruction_id = :instrId " +
      "   AND ilim_id = :fundId " +
      "   AND underlying_ilim_id = :holdingId "; 
   
  public static final String delete_from_forecast_model_by_modelid = 
      "DELETE FROM forecast_model  " +
      " WHERE forecast_model_id = :modelId  "; 

  public static final String delete_from_forecast_model_by_id = 
      "DELETE FROM forecast_model " +
      " WHERE forecast_model_id = :modelId " +
      "   AND forecast_instruction_id = :instrId " +
      "   AND ilim_id = :fundId " +
      "   AND underlying_ilim_id = :holdingId "; 
}