package com.ilim.forecast.infra.db.jdbc;

import static com.ilim.commons.time.DateUtils.asLocalDate;
import static com.ilim.commons.time.DateUtils.asLocalDateTime;
import static com.ilim.commons.time.DateUtils.asUtilDate;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.domain.model.MoneyNotificationType;
import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.domain.IForecastInstructionRepository;
import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastStatus;
import com.ilim.forecast.infra.db.SQL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;

/**
 * Database operations for Forecast Instructions. 
 *
 * @author Michael Cunningham
 */
@Repository
public class JdbcForecastInstructionDao extends NamedParameterJdbcDaoSupport
    implements IForecastInstructionRepository {

  private static final Logger log =
      LoggerFactory.getLogger(JdbcForecastInstructionDao.class);

  @Inject
  public JdbcForecastInstructionDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  /**
   * Find all ForecastInstruction.
   * 
   * @return List of ForecastInstruction
   * @throws AppSqlException on db error
   */
  @Override
  public List<ForecastInstruction> findAll() {

    log.info("findAll ()");

    final String sql = SQL.select_from_forecast_instr;

    final List<ForecastInstruction> result = new ArrayList<>();
    try {

      result.addAll(getNamedParameterJdbcTemplate().query(sql, (rs, rowNum) -> {
        return toForecastInstruction(rs);
      }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findAll!", ex);
    }

    return result;
  }

  /**
   * Find an ForecastInstruction by id.
   * 
   * @param id forecast_money_id  
   * @return ForecastInstruction
   * @throws AppSqlException on db error
   */
  @Override
  public ForecastInstruction findById(int id) {

    log.info("findById " + id);

    final String sql = SQL.select_from_forecast_instr_by_id;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("id", id);

    final ForecastInstruction result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toForecastInstruction(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findById!" + id, ex);
    }

    return result;
  }

  /**
   * Find by status.
   * 
   * @param status ForecastStatus 
   * @return List of ForecastInstruction
   * @throws AppSqlException  on db error
   */
  @Override
  public List<ForecastInstruction> findByStatus(ForecastStatus status) {

    log.info("findByStatus ({})", status);

    final String sql = SQL.select_from_forecast_instr_by_status;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("statusId", status.id());

    final List<ForecastInstruction> result = new ArrayList<>();
    try {

      result.addAll(
          getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
            return toForecastInstruction(rs);
          }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByStatus!" + status, ex);
    }

    return result;
  }

  /**
   * Find by status for period.
   * 
   * @param from LocalDate
   * @param to LocalDate  
   * @return List of ForecastInstruction
   * @throws AppSqlException on db error
   */
  @Override
  public List<ForecastInstruction> findForPeriod(LocalDate from, LocalDate to) {

    log.info("findByStatusForPeriod ({}, {})", from, to);

    final String sql = SQL.select_from_forecast_instr_for_period;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("from", DateUtils.asUtilDate(from))
            .addValue("to", DateUtils.asUtilDate(to));

    final List<ForecastInstruction> result = new ArrayList<>();
    try {

      result.addAll(
          getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
            return toForecastInstruction(rs);
          }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByStatusForPeriod!", ex);
    }

    return result;
  }

  /**
   * Find by status for period.
   * 
   * @param status ForecastStatus
   * @param from LocalDate
   * @param to LocalDate  
   * @return List of ForecastInstruction
   * @throws AppSqlException on db error
   */
  @Override
  public List<ForecastInstruction> findByStatusForPeriod(ForecastStatus status,
      LocalDate from, LocalDate to) {

    log.info("findByStatusForPeriod ({}, {}, {})", status, from, to);

    final String sql = SQL.select_from_forecast_instr_by_status_for_period;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("statusId", status.id())
            .addValue("from", DateUtils.asUtilDate(from))
            .addValue("to", DateUtils.asUtilDate(to));

    final List<ForecastInstruction> result = new ArrayList<>();
    try {

      result.addAll(
          getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
            return toForecastInstruction(rs);
          }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByStatusForPeriod!", ex);
    }

    return result;
  }

  /**
   * Create a new forecast instruction.
   *
   * @param instr ForecastInstruction
   * @return int id
   * @throws AppSqlException on db error
   */
  @Override
  public int create(ForecastInstruction instr) {

    log.info("Insert ForecastInstruction ({})", instr);

    final String sql = SQL.insert_into_forecast_instr;

    final int id = nextId();
    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("id", id)
            .addValue("forecastDate", asUtilDate(instr.getForecastDate()))
            .addValue("statusId", instr.getStatus().id())
            .addValue("forecastTypeId", instr.getForecastType().id())
            .addValue("fundId", instr.getFundId())
            .addValue("moneyTypeId", instr.getMoneyType().id())
            .addValue("amount", instr.getAmount())
            .addValue("creationTime", asUtilDate(instr.getCreationTime()))
            .addValue("eventSourceId", instr.getEventSourceId());

    try {

      getNamedParameterJdbcTemplate().update(sql, params);

    } catch (DataAccessException ex) {

      throw new AppSqlException("Error inserting ForecastInstruction!", ex);
    }

    return id;
  }

  /**
   * Update status of a existing forecast instruction.
   * 
   * @param  id of instruction
   * @param  status to move to
   * @throws AppSqlException on db error
   */
  @Override
  public void updateStatus(int id, ForecastStatus status) {

    log.info("Updating ForecastInstruction ({}, {})", id, status);

    final String sql = SQL.update_forecast_instr_status;

    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("id", id).addValue("statusId", status.id());

    try {

      getNamedParameterJdbcTemplate().update(sql, params);

    } catch (DataAccessException ex) {

      throw new AppSqlException("Error updating ForecastInstruction!", ex);
    }
  }

  /** Returns next sequence id from forecast_instr_seq . */
  private int nextId() {

    log.info("nextId ()");

    final String sql = SQL.select_from_forecast_instr_seq;

    final int result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql,
          new MapSqlParameterSource(), (rs, rowNum) -> {
            return rs.getInt("id");
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in sequence!", ex);
    }

    return result;
  }

  protected static ForecastInstruction toForecastInstruction(ResultSet rs) {

    try {

      int id = rs.getInt("forecast_instruction_id");
      LocalDate forecastDate = asLocalDate(rs.getDate("forecast_dt"));
      ForecastStatus status =
          ForecastStatus.from(rs.getInt("forecast_status_id"));
      ForecastType forecastType =
          ForecastType.from(rs.getInt("forecast_type_id"));
      MoneyNotificationType moneyType =
          MoneyNotificationType.from(rs.getInt("money_notification_type_id"));
      int fundId = rs.getInt("ilim_id");
      BigDecimal amount = rs.getBigDecimal("amount");
      LocalDateTime creationTime = asLocalDateTime(rs.getDate("creation_ts"));
      int eventId = rs.getInt("event_id");

      return new ForecastInstruction(id, forecastDate, status, forecastType,
          fundId, moneyType, amount, creationTime, eventId);

    } catch (SQLException ex) {
      throw new AppSqlException(
          "Error mapping sql result set to forecast instruction!", ex);
    }
  }
}
