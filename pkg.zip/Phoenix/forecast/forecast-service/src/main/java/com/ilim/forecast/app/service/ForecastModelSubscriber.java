package com.ilim.forecast.app.service;

import com.ilim.commons.eventbus.AppEventBus;
import com.ilim.commons.eventbus.IEventSubscriber;
import com.ilim.forecast.domain.event.PendingForecastInstruction;

import com.google.common.eventbus.Subscribe;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

/**
 * Forecast Subscriber that handles all Instruction events.
 * 
 * <p>Subscribes to forecast event bus.
 * Decouple instruction service from the model service. 
 *
 * @author Michael Cunningham
 *      
 */
public class ForecastModelSubscriber implements IEventSubscriber {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastModelSubscriber.class);

  private AppEventBus eventBus;
  private IForecastModelService service;

  /**
   * Subscribe to Bus.
   * 
   * <p>These are typically injected in by spring.
   * 
   * @param eventBus guava bus
   * @param service model service
   */
  @Inject
  public ForecastModelSubscriber(AppEventBus eventBus,
      IForecastModelService service) {

    this.eventBus = eventBus;
    this.service = service;
    this.eventBus.subscribe(this);
  }

  /** Returns the bus that this class is listening to. */
  @Override
  public AppEventBus subscribedTo() {
    return eventBus;
  }

  /**
   * Handles instruction processing events.
   * 
   * @param event  instruction processing event
   */
  @Subscribe
  public void onPending(PendingForecastInstruction event) {

    log.info("Recieved event : " + event);

    service.model(event);
  }


}
