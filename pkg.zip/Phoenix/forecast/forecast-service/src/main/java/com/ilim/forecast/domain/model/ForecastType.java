package com.ilim.forecast.domain.model;

/**
 * Forecast type.
 * 
 * @author michael cunnigham
 *
 */
public enum ForecastType {

  UNKNOWN(0), NEW_MONEY(1), ZAP(2), MGMT_CHARGE(3);

  private final int id;

  ForecastType(int id) {
    this.id = id;
  }

  public int id() {
    return id;
  }

  /** Returns the enum for an id. */
  public static ForecastType from(int id) {

    for (ForecastType type : ForecastType.values()) {
      if (type.id() == id) {
        return type;
      }
    }
    return UNKNOWN;
  }

  /** Returns the enum for a name. */
  public static ForecastType from(String name) {

    for (ForecastType type : ForecastType.values()) {
      if (type.name().equalsIgnoreCase(name)) {
        return type;
      }
    }
    return UNKNOWN;
  }
}
