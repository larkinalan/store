package com.ilim.forecast.app.service;

import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastStatus;

import java.time.LocalDate;
import java.util.List;


public interface IForecastInstructionService {

  ForecastInstruction findById(int id);

  List<ForecastInstruction> findAll();

  List<ForecastInstruction> findByStatus(ForecastStatus status);

  List<ForecastInstruction> findByStatusForPeriod(ForecastStatus status,
      LocalDate from, LocalDate to);

  int create(ForecastInstruction instr);

  void updateStatus(int id, ForecastStatus status);

  void pending(int id);

  void processing(int id);

  void modelled(int id);

  void recorded(int id);

  void failed(int id);

}

