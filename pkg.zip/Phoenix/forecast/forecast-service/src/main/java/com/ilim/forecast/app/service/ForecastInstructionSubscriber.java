package com.ilim.forecast.app.service;

import com.ilim.commons.eventbus.AppEventBus;
import com.ilim.commons.eventbus.IEventSubscriber;
import com.ilim.forecast.domain.event.FailedForecastInstruction;
import com.ilim.forecast.domain.event.ModelledForecastInstruction;
import com.ilim.forecast.domain.model.ProcessingForecastInstruction;

import com.google.common.eventbus.AllowConcurrentEvents;
import com.google.common.eventbus.Subscribe;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

/**
 * Forecast Subscriber that handles all Modelling events.
 * 
 * <p>Subscribes to forecast event bus.
 * Decouple model service from the instruction service.
 *
 * @author Michael Cunningham
 *      
 */
public class ForecastInstructionSubscriber implements IEventSubscriber {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastInstructionSubscriber.class);

  private AppEventBus eventBus;
  private IForecastInstructionService service;

  /**
   * Subscribe to Bus.
   * 
   * <p>These are typically injected in by spring.
   * 
   * @param eventBus guava bus
   * @param service instr service
   */
  @Inject
  public ForecastInstructionSubscriber(AppEventBus eventBus,
      IForecastInstructionService service) {

    this.eventBus = eventBus;
    this.service = service;
    this.eventBus.subscribe(this);
  }

  /** Returns the bus that this class is listening to. */
  @Override
  public AppEventBus subscribedTo() {
    return eventBus;
  }

  /**
   * Handles instruction processing events.
   * 
   * @param event  instruction processing event
   */
  @Subscribe
  @AllowConcurrentEvents
  public void onProcessing(ProcessingForecastInstruction event) {

    log.info("Received event : " + event);

    service.processing(event.instrId);
  }

  /**
   * Handles instruction modelled events.
   * 
   * @param event  instruction modelled event
   */
  @Subscribe
  @AllowConcurrentEvents
  public void onModelled(ModelledForecastInstruction event) {

    log.info("Received event : " + event);

    service.modelled(event.instrId);
  }

  /**
   * Handles instruction failed events.
   * 
   * @param event  instruction failed event
   */
  @Subscribe
  @AllowConcurrentEvents
  public void onFailed(FailedForecastInstruction event) {

    log.info("Received event : " + event);

    service.failed(event.instrId);
  }

}
