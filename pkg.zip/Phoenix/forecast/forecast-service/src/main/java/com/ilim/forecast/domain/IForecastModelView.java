package com.ilim.forecast.domain;

import com.ilim.commons.domain.model.ForecastStatus;
import com.ilim.forecast.domain.model.ForecastModel;

import java.time.LocalDate;
import java.util.List;

/**
 * Forecast Instruction Model View.
 * 
 * <p>readonly persistence api for forecast model dao.
 *
 * @author alan larkin
 */
public interface IForecastModelView {

  ForecastModel findByInstrId(int instrId);

  List<ForecastModel> findByForecastDate(LocalDate date);

  List<ForecastModel> findByForecastDateAndFundId(LocalDate date, int fundId);

  List<ForecastModel> findByStatus(ForecastStatus status);

}
