package com.ilim.forecast.app.service;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;

import static com.ilim.forecast.domain.model.ForecastStatus.FAILED;
import static com.ilim.forecast.domain.model.ForecastStatus.MODELLED;
import static com.ilim.forecast.domain.model.ForecastStatus.NEW;
import static com.ilim.forecast.domain.model.ForecastStatus.PENDING;
import static com.ilim.forecast.domain.model.ForecastStatus.PROCESSING;
import static com.ilim.forecast.domain.model.ForecastStatus.RECORDED;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.domain.IEvent;
import com.ilim.forecast.domain.IForecastInstructionRepository;
import com.ilim.forecast.domain.InstructionFactory;
import com.ilim.forecast.domain.event.PendingForecastInstruction;
import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastStatus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

import javax.inject.Inject;

/**
 * Forecast Instruction Service.
 * 
 * <p>This manages all the app use cases for forecast instruction actions.
 *
 * @author Michael Cunningham
 */
@Service
public class ForecastInstructionService implements IForecastInstructionService {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastInstructionService.class);

  private IForecastInstructionRepository dao;

  private ForecastInstructionPubisher publisher;

  /**
   * Initalize ForecastInstructionService.
   * 
   * <p>These are typically injected in by spring.
   * 
   * @param dao persistence layer
   * @param publisher of instr events
   */
  @Inject
  public ForecastInstructionService(IForecastInstructionRepository dao,
      ForecastInstructionPubisher publisher) {

    this.dao = dao;
    this.publisher = publisher;
  }

  /**
   * Finds instruction.
   * 
   * <p>Instruction id must exist.
   * 
   * @param id instr pk
   * @return ForecastInstruction instr
   * @throws IllegalArgumentException, AppSqlException
   */
  @Transactional
  @Override
  public ForecastInstruction findById(int id) {

    log.info("findById ({})", id);
    
    checkArgument(id > 0, "invalid id!");
    return dao.findById(id);
  }

  /**
   * Finds all instruction.
   * 
   * @return List of ForecastInstruction.
   * @throws AppSqlException if id does not exist
   */
  @Transactional
  @Override
  public List<ForecastInstruction> findAll() {

    log.info("findAll ()");
    return dao.findAll();
  }

  /**
   * Finds instructions by status.
   *
   * @param status forecast status to search on.
   * @return {@code List<ForecastInstruction>}
   * @throws AppSqlException
   *  
   */
  @Transactional
  @Override
  public List<ForecastInstruction> findByStatus(ForecastStatus status) {

    log.info("findByStatus ({}) ", status);
    return dao.findByStatus(status);
  }

  /**
   * Finds instructions by status between two forecast dates.
   * 
   * @return List of ForecastInstruction.
   * @throws IllegalArgumentException, NullPointerException, AppSqlException
   */
  @Transactional
  @Override
  public List<ForecastInstruction> findByStatusForPeriod(ForecastStatus status,
      LocalDate from, LocalDate to) {

    log.info("findByStatusForPeriod ({}, {}, {})", status, from, to);

    checkArgument(status != ForecastStatus.UNKNOWN, "invalid status!");
    checkNotNull(from, " from date cannot be empty");
    checkNotNull(to, " to date cannot be empty");
    checkArgument(from.isBefore(to), "'from' date must be before 'to' date");

    return dao.findByStatusForPeriod(status, from, to);
  }

  /**
   * Creates a new ForecastInstruction.
   * 
   * @param instr ForecastInstruction at status of NEW
   * @return int instruction id.
   * @throws IllegalStateException, AppSqlException
   */
  @Transactional
  @Override
  public int create(ForecastInstruction instr) {

    log.info("create ({})", instr);

    checkState(instr.getStatus().equals(NEW), "Instr status must equal NEW!");

    // save
    int id = dao.create(instr);
    // move to pending state
    pending(id);

    return id;
  }

  /**
   * Update status for a instruction.
   * 
   * <p>Instruction id MUST exist
   * 
   * @param id instr id.
   * @param status to be updated to.
   * @throws AppSqlException
   * 
   */
  @Transactional
  @Override
  public void updateStatus(int id, ForecastStatus status) {

    log.info("updateStatus ({}) to ({})", id, status);

    checkState(status != ForecastStatus.UNKNOWN,
        "Invalid status " + status + " for instr " + id);
    dao.findById(id); // throws ex if NOT EXISTS.
    dao.updateStatus(id, status);
  }

  /**
   * Moves instruction status from NEW to PENDING.
   *  
   * <p>Raises an PendingForecastInstruction event.
   * Subscribers:  
   *    ForecastModelService.
   * 
   * @param id  instruction id
   */
  @Transactional
  @Override
  public void pending(int id) {

    log.info("Moving instr " + id + " to PENDING");

    ForecastInstruction instr = dao.findById(id);
    checkState(instr.getStatus().equals(NEW), "Instr status must equal NEW!");

    dao.updateStatus(id, PENDING);
    IEvent<PendingForecastInstruction> event =
        InstructionFactory.createPendingEvent(dao.findById(id));
    publisher.pending(event);
  }

  /**
   * Moves instruction status from PENDING to PROCESSING.
   * 
   * @param id  instruction id
   */
  @Transactional
  @Override
  public void processing(int id) {

    log.info("Moving instr " + id + " to PROCESSING");

    ForecastInstruction instr = dao.findById(id);
    checkState(instr.getStatus().equals(PENDING),
        "Instr status must equal PENDING!");

    dao.updateStatus(id, PROCESSING);
  }

  /**
   * Moves instruction status from PROCESSING to MODELLED.
   * 
   * @param id  instruction id
   */
  @Transactional
  @Override
  public void modelled(int id) {

    log.info("Moving instr " + id + " to MODELLED");

    ForecastInstruction instr = dao.findById(id);
    checkState(instr.getStatus().equals(PROCESSING),
        "Instr status must equal PROCESSING!");

    dao.updateStatus(id, MODELLED);
  }

  /**
   * Moves instruction status from MODELLED to RECORDED.
   * 
   * @param id  instruction id
   */
  @Transactional
  @Override
  public void recorded(int id) {

    log.info("Moving instr " + id + " to RECORDED");

    ForecastInstruction instr = dao.findById(id);
    checkState(instr.getStatus().equals(MODELLED),
        "Instr status must equal MODELLED!");

    dao.updateStatus(id, RECORDED);
  }

  /**
   * Moves instruction status from PROCESSING or MODELLED to FAILED.
   * 
   * @param id  instruction id
   */
  @Transactional
  @Override
  public void failed(int id) {

    log.info("Moving instr " + id + " to FAILED");

    ForecastInstruction instr = dao.findById(id);

    ForecastStatus status = instr.getStatus();
    checkState(status.equals(PROCESSING) || status.equals(MODELLED),
        "Instr status must equal PROCESSING or MODELLED!");

    dao.updateStatus(id, FAILED);
  }

}
