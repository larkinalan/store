package com.ilim.forecast.domain.event;

import com.ilim.commons.domain.IEvent;

import com.google.common.base.MoreObjects;

import java.time.LocalDateTime;

/**
 * Modelled Forecast Instruction Event.
 * 
 * @author Michael Cunningham
 */
public class ModelledForecastInstruction
    implements IEvent<ModelledForecastInstruction> {

  public final int modelId;
  public final int instrId;
  public final LocalDateTime occuredOn;

  /** Modelled Forecast Instruction Event. */
  public ModelledForecastInstruction(int modelId, int instrId) {

    this.modelId = modelId;
    this.instrId = instrId;
    this.occuredOn = LocalDateTime.now();
  }

  @Override
  public LocalDateTime occuredOn() {
    return occuredOn;
  }

  /** Returns a String representation of this Forecast Instruction Event. */ 
  public String toString() {

    return MoreObjects.toStringHelper(this).add("modelId", modelId)
        .add("instrId", instrId).add("occuredOn", occuredOn).toString();
  }

}
