package com.ilim.forecast.web.resources;

import static com.ilim.forecast.web.resources.ForecastDataMapper.toForecastInstructionData;
import static com.ilim.forecast.web.resources.ForecastDataMapper.toForecastInstructionDataList;
import static com.ilim.forecast.web.resources.ForecastDataMapper.toNewForecastInstruction;

import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.app.service.IForecastInstructionService;
import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastStatus;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import com.codahale.metrics.annotation.Timed;
import com.google.common.base.Strings;

import org.springframework.stereotype.Service;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

/**
 * Forecast Instruction rest service.
 * 
 * <p>This manages all the http request for forecasts instructions.
 * Exception are mapped to HTTP error codes @see AppExceptionMapper .
 * 
 * <p>Consumes/Produces MediaType.APPLICATION_JSON only. 
 * 
 * <p>Requests and Reponses will automatically get logged by filters.
 *
 * @author Michael Cunningham, Alan Larkin
 */
@Singleton
@Service
@Path("instructions")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class ForecastInstructionResource {

  @Inject
  private IForecastInstructionService instrService;

  /**
   * Find the Forecast Instruction by path param id.
   * 
   * @param id instruction id
   * @return ForecastInstructionData data type
   */
  @GET
  @Path("{id}")
  @Timed
  public ForecastInstructionData findById(@PathParam("id") int id) {

    return toForecastInstructionData(instrService.findById(id));
  }

  /**
   * Find all Forecast Instructions at status
   * 
   * <p>If no query parameters 
   *    then {@link IForecastInstructionService#findAll()}
   *     
   * <p>If status and date range 
   *    then {@link IForecastInstructionService#findByStatusForPeriod(
   *                    ForecastStatus, LocalDate, LocalDate)}
   *    Else {@link IForecastInstructionService#findByStatus(ForecastStatus)}
   *    
   * @param uriInfo OPTIONAL query params. (status, from, to)
   * @return {@code List<ForecastInstructionData>}
   */
  @GET
  @Timed
  public List<ForecastInstructionData> find(@Context UriInfo uriInfo) {

    MultivaluedMap<String, String> queryParams = uriInfo.getQueryParameters();

    final List<ForecastInstruction> instrs;


    if (queryParams == null || queryParams.isEmpty()) {

      // FIND ALL
      instrs = instrService.findAll();

    } else {

      String status = queryParams.getFirst("status");
      String from = queryParams.getFirst("from");
      String to = queryParams.getFirst("to");

      if (!Strings.isNullOrEmpty(status) && !Strings.isNullOrEmpty(from)
          && !Strings.isNullOrEmpty(to)) {

        // FIND BY STATUS FOR PERIOD
        instrs = instrService.findByStatusForPeriod(ForecastStatus.from(status),
            LocalDate.parse(from, DateUtils.DATE_FMT),
            LocalDate.parse(to, DateUtils.DATE_FMT));

      } else {

        // FIND BY STATUS
        instrs = instrService.findByStatus(ForecastStatus.from(status));

      }
    }

    return toForecastInstructionDataList(instrs);
  }

  /**
   * Create a new Forecast Instruction.
   * 
   * @param instr NewForecastInstructionData instruction.
   */
  @POST
  @Timed
  public Response create(@Context UriInfo uriInfo,
      NewForecastInstructionData instr) {

    int id = instrService.create(toNewForecastInstruction(instr));

    UriBuilder uriBuilder = uriInfo.getAbsolutePathBuilder();
    URI uri = uriBuilder.path(String.valueOf(id)).build();

    return Response.created(uri).build();
  }

  /**
   * Updates the status of an existing Forecast Instruction.
   * 
   * @param id identifier
   * @param status new state.
   */
  @PUT
  @Path("{id}")
  @Timed
  public Response updateStatus(@PathParam("id") int id, String status) {

    instrService.updateStatus(id, ForecastStatus.from(status));
    return Response.accepted().build();
  }

}
