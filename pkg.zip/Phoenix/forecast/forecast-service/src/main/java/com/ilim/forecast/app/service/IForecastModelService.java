package com.ilim.forecast.app.service;

import com.ilim.forecast.domain.event.PendingForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModelAlloc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public interface IForecastModelService {

  List<ForecastModelAlloc> findByModelId(int modelId);

  List<ForecastModelAlloc> findByForecastDate(LocalDate forecastDate);

  List<ForecastModelAlloc> findByFundIdAndForecastDate(int fundId,
      LocalDate forecastDate);

  List<ForecastModelAlloc> findAll();

  void model(PendingForecastInstruction event);

  int save(List<ForecastModelAlloc> model);

  void delete(List<ForecastModelAlloc> model);

  void updateRecordedCash(ForecastModelAlloc.Id id, BigDecimal recordedCash);

}
