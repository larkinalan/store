package com.ilim.forecast.app.service;

import static java.util.stream.Collectors.toList;

import com.ilim.commons.domain.model.ForecastStatus;
import com.ilim.forecast.domain.event.PendingForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModel;
import com.ilim.forecast.domain.model.ForecastModelAlloc;

import java.time.LocalDate;
import java.util.List;

public interface IForecastModelService {

  ForecastModel findByInstrId(int instrId);

  List<ForecastModel> findByForecastDate(LocalDate forecastDate);

  List<ForecastModel> findByForecastDateAndFundId(LocalDate forecastDate,
      int fundId);
  
  List<ForecastModel> findByStatus(ForecastStatus status);

  void model(PendingForecastInstruction event);

  List<Integer> save(List<ForecastModelAlloc> model);

  void delete(List<ForecastModelAlloc> model);

  /** Get all the ids from a list of instrs. */
  default List<Integer> toIds(List<ForecastModelAlloc> allocs) {

    return allocs.stream().mapToInt(ForecastModelAlloc::getId).boxed()
        .collect(toList());
  }

}
