package com.ilim.forecast.web.resources;

import static com.ilim.forecast.web.resources.ForecastDataMapper.toForecastModelAllocDataList;
import static com.ilim.forecast.web.resources.ForecastDataMapper.toId;

import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.app.service.IForecastModelService;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.forecast.web.api.RecordedCashData;

import com.codahale.metrics.annotation.Timed;
import com.google.common.base.Strings;

import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/**
 * Forecast Model rest service.
 * 
 * <p>This manages all the http request for forecast modelling.
 * Exception are mapped to HTTP error codes @see AppExceptionMapper .
 * 
 * <p>Consumes/Produces MediaType.APPLICATION_JSON only. 
 * 
 * <p>Requests and Responses will automatically get logged by filters.
 *
 * @author Michael Cunningham
 */
@Singleton
@Service
@Path("models")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class ForecastModelResource {

  @Inject
  private IForecastModelService modelService;

  /**
   * Find the Forecast Model by path model id.
   * 
   * @param modelId model id
   * @return {@code List<ForecastModelData>} data type
   */
  @GET
  @Path("{modelId}")
  @Timed
  public List<ForecastModelAllocData> findByModelId(
      @PathParam("modelId") int modelId) {

    return toForecastModelAllocDataList(modelService.findByModelId(modelId));
  }

  /**
   * Find all Forecast Models.
   * 
   * <p>If no query parameters 
   *    then {@link IForecastModelService#findAll()}
   *     
   * <p>If status and date range 
   *    then {@link IForecastModelService#findByForecastDate(LocalDate)}
   *    
   * @param uriInfo OPTIONAL query params. (forecastDate)
   * @return {@code List<ForecastModelData>}
   */
  @GET
  @Timed
  public List<ForecastModelAllocData> find(@Context UriInfo uriInfo) {

    MultivaluedMap<String, String> queryParams = uriInfo.getQueryParameters();

    List<ForecastModelAlloc> modelList = new ArrayList<ForecastModelAlloc>();

    if (queryParams == null || queryParams.isEmpty()) {

      // FIND ALL
      modelList = modelService.findAll();

    } else {

      // FIND BY FUND & DATE
      String fundId = queryParams.getFirst("fundId");
      String forecastDate = queryParams.getFirst("forecastDate");

      if (!Strings.isNullOrEmpty(fundId)
          && !Strings.isNullOrEmpty(forecastDate)) {

        modelList =
            modelService.findByFundIdAndForecastDate(Integer.valueOf(fundId),
                LocalDate.parse(forecastDate, DateUtils.DATE_FMT));

      } else {

        // FIND BY DATE
        modelList = modelService.findByForecastDate(
            LocalDate.parse(forecastDate, DateUtils.DATE_FMT));
      }
    }

    return toForecastModelAllocDataList(modelList);
  }

  /**
   * Updates the recorded cash amt of an existing forecast model alloc.
   * 
   * @param recordedCash cash amt    
   */
  @PUT
  @Timed
  public Response updateRecordedCash(RecordedCashData recordedCash) {

    modelService.updateRecordedCash(toId(recordedCash.id), recordedCash.cash);
    return Response.accepted().build();
  }

}
