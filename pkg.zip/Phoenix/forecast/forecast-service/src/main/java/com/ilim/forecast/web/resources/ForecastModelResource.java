package com.ilim.forecast.web.resources;

import static com.ilim.forecast.web.resources.ForecastDataMapper.toForecastModelAllocDataList;
import static com.ilim.forecast.web.resources.ForecastDataMapper.toId;

import com.ilim.forecast.app.service.IForecastModelService;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.forecast.web.api.ForecastModelAllocIdData;

import com.codahale.metrics.annotation.Timed;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Forecast Model rest service.
 * 
 * <p>This manages all the http request for forecast modelling.
 * Exception are mapped to HTTP error codes @see AppExceptionMapper .
 * 
 * <p>Consumes/Produces MediaType.APPLICATION_JSON only. 
 * 
 * <p>Requests and Responses will automatically get logged by filters.
 *
 * @author Michael Cunningham
 */
@Singleton
@Service
@Path("models")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class ForecastModelResource {

  @Inject
  private IForecastModelService modelService;

  /**
   * Find the Forecast Model by path model id.
   * 
   * @param modelId model id
   * @return {@code List<ForecastModelData>} data type
   */
  @GET
  @Path("{modelId}")
  @Timed
  public List<ForecastModelAllocData> findByModelId(
      @PathParam("modelId") int modelId) {

    return toForecastModelAllocDataList(modelService.findByModelId(modelId));
  }

  /**
  * Find all Forecast Models.
  *
  * @return {@code List<ForecastModelData>}
  */
  @GET
  @Timed
  public List<ForecastModelAllocData> findAll() {

    return toForecastModelAllocDataList(modelService.findAll());
  }

  /**
   * Updates the recorded cash amt of an existing forecast model alloc.
   * 
   * @param id ForecastModelAlloc id
   * @param recordedCash amount.
   */
  @PUT
  @Timed
  public Response updateRecordedCash(ForecastModelAllocIdData id,
      BigDecimal recordedCash) {

    modelService.updateRecordedCash(toId(id), recordedCash);
    return Response.accepted().build();
  }

}
