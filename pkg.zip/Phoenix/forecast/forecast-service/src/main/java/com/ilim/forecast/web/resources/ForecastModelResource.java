package com.ilim.forecast.web.resources;

import static com.ilim.forecast.web.resources.ForecastDataMapper.toForecastModelDataList;

import com.ilim.commons.domain.model.ForecastStatus;
import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.app.service.IForecastModelService;
import com.ilim.forecast.domain.model.ForecastModel;
import com.ilim.forecast.web.api.ForecastModelData;

import com.codahale.metrics.annotation.Timed;
import com.google.common.base.Strings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

/**
 * Forecast Model rest service.
 * 
 * <p>This manages all the http request for forecast modelling.
 * Exception are mapped to HTTP error codes @see AppExceptionMapper .
 * 
 * <p>Consumes/Produces MediaType.APPLICATION_JSON only. 
 * 
 * <p>Requests and Responses will automatically get logged by filters.
 *
 * @author Michael Cunningham
 */
@Singleton
@Service
@Path("models")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class ForecastModelResource {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastModelResource.class);

  @Inject
  private IForecastModelService modelService;

  /**
   * Query Forecast Models.
   * 
   * <p>If no query parameters 
   *    then {@link IForecastModelService#findByForecastDate(LocalDate.now())}
   *     
   * <p>If status
   *    then {@link IForecastModelService#findByStatus(ForecastStatus)}
   *    
   * <p>If forecastDate and fundId
   *    then {@link IForecastModelService#findByForecastDateAndFundId(LocalDate,Integer)}
   *    
   * <p>If forecastDate and fundId
   *    then {@link IForecastModelService#findByForecastDate(LocalDate)}
   *    
   * @param uriInfo OPTIONAL query params. (status, forecastDate, fundId)
   * @return {@code List<ForecastModelData>}
   */
  @GET
  @Timed
  public List<ForecastModelData> find(@Context UriInfo uriInfo) {

    MultivaluedMap<String, String> queryParams = uriInfo.getQueryParameters();

    List<ForecastModel> model = new ArrayList<>();

    if (queryParams == null || queryParams.isEmpty()) {

      // DEFAULT TO TODAYS FORECAST
      model = modelService.findByForecastDate(LocalDate.now());

    } else {

      String status = queryParams.getFirst("status");
      String forecastDate = queryParams.getFirst("forecastDate");
      String fundId = queryParams.getFirst("fundId");

      if (!Strings.isNullOrEmpty(status)) {

        // FIND BY STATUS
        model = modelService.findByStatus(ForecastStatus.from(status));

      } else if (!Strings.isNullOrEmpty(forecastDate)
          && !Strings.isNullOrEmpty(fundId)) {

        // FIND BY DATE & FUND
        model = modelService.findByForecastDateAndFundId(
            LocalDate.parse(forecastDate, DateUtils.DATE_FMT),
            Integer.valueOf(fundId));

      } else if (!Strings.isNullOrEmpty(forecastDate)) {

        // FIND BY DATE
        model = modelService.findByForecastDate(
            LocalDate.parse(forecastDate, DateUtils.DATE_FMT));

      } else {

        String msg = "Invalid query params!";
        log.error(msg);
        throw new IllegalArgumentException(msg);
      }
    }

    return toForecastModelDataList(model);
  }

}
