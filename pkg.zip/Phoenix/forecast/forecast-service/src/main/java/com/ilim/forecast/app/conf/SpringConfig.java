package com.ilim.forecast.app.conf;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.eventbus.AppEventBus;
import com.ilim.forecast.app.service.ForecastInstructionPubisher;
import com.ilim.forecast.app.service.ForecastInstructionService;
import com.ilim.forecast.app.service.ForecastInstructionSubscriber;
import com.ilim.forecast.app.service.ForecastModelPubisher;
import com.ilim.forecast.app.service.ForecastModelService;
import com.ilim.forecast.app.service.ForecastModelSubscriber;
import com.ilim.forecast.app.service.IForecastInstructionService;
import com.ilim.forecast.app.service.IForecastModelService;
import com.ilim.forecast.app.service.IFundService;
import com.ilim.forecast.domain.IForecastInstructionRepository;
import com.ilim.forecast.domain.IForecastModelAllocRepository;
import com.ilim.forecast.domain.IForecastModelView;
import com.ilim.forecast.infra.db.jdbc.JdbcForecastInstructionDao;
import com.ilim.forecast.infra.db.jdbc.JdbcForecastModelAllocDao;
import com.ilim.forecast.infra.db.jdbc.JdbcForecastModelDao;
import com.ilim.forecast.infra.fund.FundServiceAdapter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.jta.JtaTransactionManager;

import java.sql.SQLException;

import javax.sql.DataSource;

/**
 * Spring component config.
 *
 * @author Michael Cunningham
 */
@Configuration
public class SpringConfig {

  private static final Logger log = LoggerFactory.getLogger(SpringConfig.class);

  private static boolean standaloneServer =
      settings().getBoolean("server.standalone");

  /** The jdbc Datasource. */
  @Bean
  public DataSource dataSource() {

    final DataSource dataSource;

    if (standaloneServer) {

      // standalone or testing
      dataSource = oracleConnection(new DriverManagerDataSource());

    } else {

      // assume jboss container
      final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
      dsLookup.setResourceRef(true);
      dataSource =
          dsLookup.getDataSource(settings().getString("jndi.datasource.fm"));
    }

    testConnection(dataSource);
    return dataSource;
  }

  /** The spring DataSourceTransactionManager. */
  @Bean
  public PlatformTransactionManager transactionManager(DataSource dataSource) {

    final PlatformTransactionManager txnMgr;

    if (standaloneServer) {

      // simple datasoource for testing
      txnMgr = new DataSourceTransactionManager(dataSource);

    } else {

      // assume jboss container
      txnMgr = jbossTransactionManager();
    }

    return txnMgr;
  }

  /** Create conn to oracle using conf file. */
  private DataSource oracleConnection(DriverManagerDataSource dataSource) {

    dataSource
        .setDriverClassName(settings().getString("db.jdbc.oracle.driver"));
    dataSource.setUrl(settings().getString("db.fm.url"));
    dataSource.setUsername(settings().getString("db.fm.user"));
    dataSource.setPassword(settings().getString("db.fm.pass"));

    return dataSource;
  }

  /** Simple test of of db connection. */
  private void testConnection(DataSource dataSource) {

    try {
      log.info("Testing database connection to "
          + dataSource.getConnection().getMetaData().getURL());
    } catch (SQLException ex) {
      throw new AppSqlException("Failed to connect to database!", ex);
    }
  }

  /** Jboss container JtaTransactionManager bean. */
  private PlatformTransactionManager jbossTransactionManager() {

    JtaTransactionManager txnMgr = new JtaTransactionManager();
    txnMgr.setTransactionManagerName(settings().getString("jndi.txnmanager"));
    return txnMgr;
  }

  /** AppEventBus bean. */
  @Bean
  public AppEventBus eventBus() {

    AppEventBus eventBus = new AppEventBus("ForecastEventBus");
    return eventBus;
  }

  /** JdbcForecastInstructionDao spring bean. */
  @Bean
  public IForecastInstructionRepository instructionDao(DataSource dataSource) {

    return new JdbcForecastInstructionDao(dataSource);
  }

  /** JdbcForecastModelDao spring bean. */
  @Bean
  public IForecastModelAllocRepository modelAllocDao(DataSource dataSource) {

    return new JdbcForecastModelAllocDao(dataSource);
  }

  /** JdbcForecastModelDao spring bean. */
  @Bean
  public IForecastModelView modelDao(DataSource dataSource) {

    return new JdbcForecastModelDao(dataSource);
  }

  /** ForecastInstructionPubisher spring bean. */
  @Bean
  public ForecastInstructionPubisher instructionPubisher(AppEventBus eventBus) {

    return new ForecastInstructionPubisher(eventBus);
  }

  /** ForecastInstructionService spring bean. */
  @Bean
  public IForecastInstructionService instructionService(
      IForecastInstructionRepository dao,
      ForecastInstructionPubisher pubisher) {

    return new ForecastInstructionService(dao, pubisher);
  }

  /** ForecastInstructionSubscriber spring bean. */
  @Bean
  public ForecastInstructionSubscriber instructionSubscriber(
      AppEventBus eventBus, IForecastInstructionService service) {

    return new ForecastInstructionSubscriber(eventBus, service);
  }

  /** ForecastInstructionPubisher spring bean. */
  @Bean
  public ForecastModelPubisher modelPubisher(AppEventBus eventBus) {

    return new ForecastModelPubisher(eventBus);
  }

  /** FundServiceAdpater spring bean. */
  @Bean
  public IFundService fundService() {

    return new FundServiceAdapter();
  }

  /** ForecastModelService spring bean. */
  @Bean
  public IForecastModelService modelService(
      IForecastModelAllocRepository modelAllocDao, IForecastModelView modelDao,
      ForecastModelPubisher pubisher, IFundService fundService) {

    return new ForecastModelService(modelAllocDao, modelDao, pubisher,
        fundService);
  }

  /** ForecastInstructionSubscriber spring bean. */
  @Bean
  public ForecastModelSubscriber modelSubscriber(AppEventBus eventBus,
      IForecastModelService service) {

    return new ForecastModelSubscriber(eventBus, service);
  }

}
