package com.ilim.forecast.infra.db.jdbc;

import static com.ilim.commons.time.DateUtils.asLocalDateTime;
import static com.ilim.commons.time.DateUtils.asUtilDate;

import com.ilim.commons.db.AppSqlException;
import com.ilim.forecast.domain.IForecastModelAllocRepository;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.infra.db.SQL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;

/**
 * Database operations for Forecast Model Alloc. 
 *
 * @author Michael Cunningham
 */
@Repository
public class JdbcForecastModelAllocDao extends NamedParameterJdbcDaoSupport
    implements IForecastModelAllocRepository {

  private static final Logger log =
      LoggerFactory.getLogger(JdbcForecastModelAllocDao.class);

  @Inject
  public JdbcForecastModelAllocDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  /**
   * Select * from FORECAST_MODEL_ALLOC.
   * 
   * @return List of ForecastModelAlloc
   * @throws AppSqlException on db error
   */
  @Override
  public List<ForecastModelAlloc> findAll() {

    log.info("findAll ()");

    final String sql = SQL.select_from_forecast_model_alloc;

    final List<ForecastModelAlloc> result = new ArrayList<>();
    try {

      result.addAll(getNamedParameterJdbcTemplate().query(sql, (rs, rowNum) -> {
        return toForecastModelAlloc(rs);
      }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findAll!", ex);
    }

    return result;
  }

  /**
   * Select from FORECAST_MODEL_ALLOC by id.
   * 
   * @param id forecast_model_alloc_id
   * @return ForecastModelAlloc
   * @throws AppSqlException on db error
   */
  @Override
  public ForecastModelAlloc findById(int id) {

    log.info("findById ({})", id);

    final String sql = SQL.select_from_forecast_model_alloc_by_id;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("allocId", id);

    final ForecastModelAlloc result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toForecastModelAlloc(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findById!", ex);
    }

    return result;
  }

  /**
   * Select from FORECAST_MODEL_ALLOC by instrId.
   * 
   * @param instrIds instruction ids
   * @return List of ForecastModelAlloc
   * @throws AppSqlException on db error
   */
  @Override
  public List<ForecastModelAlloc> findByInstrId(List<Integer> instrIds) {

    log.info("findByInstrId ({...})");

    final String sql = SQL.select_from_forecast_model_alloc_by_instrid;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("instrId", instrIds);

    final List<ForecastModelAlloc> result = new ArrayList<>();
    try {

      result.addAll(
          getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
            return toForecastModelAlloc(rs);
          }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByInstrId!", ex);
    }

    return result;
  }

  /**
   * Select from FORECAST_MODEL_ALLOC by instrId and fundId.
   * 
   * @param instrId instruction id
   * @param fundId ilimId
   * @return List of ForecastModelAlloc
   * @throws AppSqlException on db error
   */
  @Override
  public List<ForecastModelAlloc> findByInstrIdAndFundId(int instrId,
      int fundId) {

    log.info("findByInstrIdAndFundId ({}, {})", instrId, fundId);

    final String sql =
        SQL.select_from_forecast_model_alloc_by_instrid_and_fundid;

    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("instrId", instrId).addValue("fundId", fundId);

    final List<ForecastModelAlloc> result = new ArrayList<>();
    try {

      result.addAll(
          getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
            return toForecastModelAlloc(rs);
          }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByInstrIdAndFundId!", ex);
    }

    return result;
  }

  /**
   * Inserts into FORECAST_MODEL_ALLOC with batch insert.
   *
   * @param model allocs
   * @return List of Integer ids of the newly created allocations
   * @throws AppSqlException on db error
   */
  @Override
  public List<Integer> create(List<ForecastModelAlloc> modelAllocs) {

    log.info("create (...)");

    if (modelAllocs == null || modelAllocs.size() == 0) {
      throw new AppSqlException("Error in create",
          new IllegalArgumentException("cannot be null empty!"));
    }

    final String sql = SQL.insert_into_forecast_model_alloc;
    SqlParameterSource[] params = new SqlParameterSource[modelAllocs.size()];

    final List<Integer> result = new ArrayList<>();
    for (int i = 0; i < params.length; i++) {
      
      final int allocId = nextId();
      ForecastModelAlloc alloc = modelAllocs.get(i);
      params[i] = new MapSqlParameterSource().addValue("allocId", allocId)
          .addValue("instrId", alloc.getInstrId())
          .addValue("fundId", alloc.getFundId())
          .addValue("holdingId", alloc.getHoldingId())
          .addValue("unitsInIssue", alloc.getCommittedUnits())
          .addValue("price", alloc.getPrice()).addValue("mix", alloc.getMix())
          .addValue("cash", alloc.getCash())
          .addValue("creationTime", asUtilDate(alloc.getCreationTime()));
      result.add(allocId);
    }

    try {

      getNamedParameterJdbcTemplate().batchUpdate(sql, params);

    } catch (DataAccessException ex) {

      throw new AppSqlException("Error in create!", ex);
    }

    return result;
  }

  /**
   * Deletes from FORECAST_MODEL_ALLOC for the given id.
   * 
   * @param id forecast_model_alloc_id  
   * @throws AppSqlException on db error
   */
  @Override
  public void delete(List<Integer> ids) {

    log.info("delete ({})", ids);

    final String sql = SQL.delete_from_forecast_model_alloc_by_id;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("allocIds", ids);

    try {

      getNamedParameterJdbcTemplate().update(sql, params);

    } catch (DataAccessException ex) {

      throw new AppSqlException("Error in delete!", ex);
    }
  }


  /** Returns next sequence id from forecast_model_alloc_seq . */
  private int nextId() {

    log.info("nextId ()");

    final String sql = SQL.select_from_forecast_model_alloc_seq;

    final int result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql,
          new MapSqlParameterSource(), (rs, rowNum) -> {
            return rs.getInt("allocId");
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in sequence!", ex);
    }

    return result;
  }

  /** Converts jdbc resultset to entity . */
  protected static ForecastModelAlloc toForecastModelAlloc(ResultSet rs) {

    try {

      int allocId = rs.getInt("forecast_model_alloc_id");
      int instrId = rs.getInt("forecast_instruction_id");
      int fundId = rs.getInt("ilim_id");
      int holdingId = rs.getInt("underlying_ilim_id");
      BigDecimal unitsInIssue =
          rs.getBigDecimal("committed_units_in_issue_qty");
      BigDecimal price = rs.getBigDecimal("price");
      BigDecimal mix = rs.getBigDecimal("mix_pct");
      BigDecimal cashAmt = rs.getBigDecimal("cash_amt");
      LocalDateTime creationTime = asLocalDateTime(rs.getDate("creation_dt"));

      return new ForecastModelAlloc(allocId, instrId, fundId, holdingId,
          unitsInIssue, price, mix, cashAmt, creationTime);

    } catch (SQLException ex) {
      throw new AppSqlException(
          "Error mapping sql result set to ForecastModelAlloc!", ex);
    }
  }

}
