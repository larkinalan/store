package com.ilim.forecast.infra.db;

/*
 *  Sql statements used in Dao
 *  
 *  <p>Formatted and wrapped using TOAD. 
 *  
 *  @author Alan Larkin
 *  
 *  @formatter:off
 *  CHECKSTYLE:OFF
 */
public class SQL {

  /*******************************************
   * T_FORECAST_INSTRUCTION sql statements
   *******************************************/
  
  public static final String select_from_forecast_instr =
      "SELECT forecast_instruction_id " +
      "     , forecast_dt " +
      "     , forecast_status_id " +
      "     , forecast_type_id " +
      "     , money_notification_type_id " +
      "     , ilim_id as instr_ilim_id " +
      "     , amount " +
      "     , creation_dt as instr_creation_ts " +
      "     , event_id " +
      "  FROM forecast_instruction "; 
  
  public static final String select_from_forecast_instr_by_id =        
      "SELECT forecast_instruction_id " +
      "     , forecast_dt " +
      "     , forecast_status_id " +
      "     , forecast_type_id " +
      "     , money_notification_type_id " +
      "     , ilim_id as instr_ilim_id " +
      "     , amount " +
      "     , creation_dt as instr_creation_ts " +
      "     , event_id " +
      "  FROM forecast_instruction " +
      " WHERE forecast_instruction_id = :id "; 
  
  public static final String select_from_forecast_instr_by_status =   
      "SELECT forecast_instruction_id " +
      "     , forecast_dt " +
      "     , forecast_status_id " +
      "     , forecast_type_id " +
      "     , money_notification_type_id " +
      "     , ilim_id as instr_ilim_id " +
      "     , amount " +
      "     , creation_dt as instr_creation_ts " +
      "     , event_id " +
      "  FROM forecast_instruction " +
      " WHERE forecast_status_id = :statusId  " ; 
  
  public static final String select_from_forecast_instr_for_period =
      "SELECT forecast_instruction_id " +
      "     , forecast_dt " +
      "     , forecast_status_id " +
      "     , forecast_type_id " +
      "     , money_notification_type_id " +
      "     , ilim_id as instr_ilim_id " +
      "     , amount " +
      "     , creation_dt as instr_creation_ts " +
      "     , event_id " +
      "  FROM forecast_instruction " +
      " WHERE forecast_dt BETWEEN :from AND :to ";
  
  public static final String select_from_forecast_instr_by_status_for_period =
      "SELECT forecast_instruction_id " +
      "     , forecast_dt " +
      "     , forecast_status_id " +
      "     , forecast_type_id " +
      "     , money_notification_type_id " +
      "     , ilim_id as instr_ilim_id " +
      "     , amount " +
      "     , creation_dt as instr_creation_ts " +
      "     , event_id " +
      "  FROM forecast_instruction " +
      " WHERE forecast_status_id = :statusId " +
      "   AND forecast_dt BETWEEN :from AND :to ";
  
  public static final String select_from_forecast_instr_seq =
      "SELECT forecast_instr_seq.NEXTVAL as id " +
      "  FROM DUAL"; 
  
  public static final String insert_into_forecast_instr =
      "INSERT INTO forecast_instruction( forecast_instruction_id " +
      "                          , forecast_dt " +
      "                          , forecast_status_id " +
      "                          , forecast_type_id " +
      "                          , ilim_id " +
      "                          , money_notification_type_id " +
      "                          , amount " +
      "                          , creation_dt " +
      "                          , event_id ) " +
      "VALUES ( :id " +
      "       , :forecastDate " +
      "       , :statusId " +
      "       , :forecastTypeId " +
      "       , :fundId " +
      "       , :moneyTypeId " +
      "       , :amount " +
      "       , :creationTime " +
      "       , :eventSourceId ) "; 
  
  public static final String update_forecast_instr_status =
      "UPDATE forecast_instruction " +
      "   SET forecast_status_id = :statusId " +
      " WHERE forecast_instruction_id = :id "; 
  
  
  /*******************************************
   * T_FORECAST_MODEL_ALLOC sql statements
   *******************************************/

  public static final String select_from_forecast_model_alloc =
      "SELECT forecast_model_alloc_id " +
      "     , forecast_instruction_id " +
      "     , ilim_id " +
      "     , underlying_ilim_id " +
      "     , committed_units_in_issue_qty " +
      "     , price " +
      "     , mix_pct " +
      "     , cash_amt " +
      "     , creation_dt " +
      "  FROM forecast_model_alloc ";
  
  public static final String select_from_forecast_model_alloc_by_id =  
      "SELECT forecast_model_alloc_id " +
      "     , forecast_instruction_id " +
      "     , ilim_id " +
      "     , underlying_ilim_id " +
      "     , committed_units_in_issue_qty " +
      "     , price " +
      "     , mix_pct " +
      "     , cash_amt " +
      "     , creation_dt " +
      "  FROM forecast_model_alloc " +
      " WHERE forecast_model_alloc_id = :allocId "; 
  
  public static final String select_from_forecast_model_alloc_by_instrid =        
	  "SELECT forecast_model_alloc_id " +
	  "     , forecast_instruction_id " +
	  "     , ilim_id " +
	  "     , underlying_ilim_id " +
	  "     , committed_units_in_issue_qty " +
	  "     , price " +
	  "     , mix_pct " +
	  "     , cash_amt " +
	  "     , creation_dt " +
	  "  FROM forecast_model_alloc " +
	  " WHERE forecast_instruction_id IN (:instrId) "; 

  public static final String select_from_forecast_model_alloc_by_instrid_and_fundid =
      "SELECT forecast_model_alloc_id " +
	  "     , forecast_instruction_id " +
	  "     , ilim_id " +
	  "     , underlying_ilim_id " +
	  "     , committed_units_in_issue_qty " +
	  "     , price " +
	  "     , mix_pct " +
	  "     , cash_amt " +
	  "     , creation_dt " +
	  "  FROM forecast_model_alloc " +
	  " WHERE forecast_instruction_id = :instrId " +
	  "   AND ilim_id = :fundId "; 
  
  public static final String select_from_forecast_model_alloc_seq =
      "SELECT forecast_model_alloc_seq.NEXTVAL as allocId " +
      "  FROM DUAL"; 
  
  public static final String insert_into_forecast_model_alloc =
      "INSERT INTO forecast_model_alloc( forecast_model_alloc_id " +
      "                          , forecast_instruction_id " +
      "                          , ilim_id " +
      "                          , underlying_ilim_id " +
      "                          , committed_units_in_issue_qty " +
      "                          , price " +
      "                          , mix_pct " +
      "                          , cash_amt " +
      "                          , creation_dt ) " +
      "VALUES ( :allocId " +
      "       , :instrId " +
      "       , :fundId " +
      "       , :holdingId " +
      "       , :unitsInIssue " +
      "       , :price " +
      "       , :mix " +
      "       , :cash " +
      "       , :creationTime ) "; 
   
  public static final String delete_from_forecast_model_alloc_by_id = 
      "DELETE FROM forecast_model_alloc  " +
      " WHERE forecast_model_alloc_id IN (:allocIds)  "; 
  
 
  /**********************************************************************
   * T_FORECAST_INSTRUCTION join T_FORECAST_MODEL_ALLOC sql statements
   **********************************************************************/

  public static final String select_from_forecast_instr_model_alloc_by_instrid =
      "SELECT i.forecast_instruction_id " +
      "     , i.forecast_dt " +
      "     , i.forecast_status_id " +
      "     , i.forecast_type_id " +
      "     , i.money_notification_type_id " +
      "     , i.ilim_id as instr_ilim_id " +
      "     , i.amount " +
      "     , i.creation_dt as instr_creation_ts " +
      "     , i.event_id " +
      "     , m.forecast_model_alloc_id " +
      "     , m.ilim_id " +
      "     , m.underlying_ilim_id " +
      "     , m.committed_units_in_issue_qty " +
      "     , m.price " +
      "     , m.mix_pct " +
      "     , m.cash_amt " +
      "     , m.creation_dt " +
      "  FROM forecast_instruction i, forecast_model_alloc m " +
      " WHERE i.forecast_instruction_id =  m.forecast_instruction_id " +
      "   AND i.forecast_instruction_id = :instrId " +
      " ORDER BY i.forecast_instruction_id, m.forecast_model_alloc_id ";
  
  public static final String select_from_forecast_instr_model_alloc_by_forecastdate =
      "SELECT i.forecast_instruction_id " +
      "     , i.forecast_dt " +
      "     , i.forecast_status_id " +
      "     , i.forecast_type_id " +
      "     , i.money_notification_type_id " +
      "     , i.ilim_id as instr_ilim_id " +
      "     , i.amount " +
      "     , i.creation_dt as instr_creation_ts " +
      "     , i.event_id " +
      "     , m.forecast_model_alloc_id " +
      "     , m.ilim_id " +
      "     , m.underlying_ilim_id " +
      "     , m.committed_units_in_issue_qty " +
      "     , m.price " +
      "     , m.mix_pct " +
      "     , m.cash_amt " +
      "     , m.creation_dt " +
      "  FROM forecast_instruction i, forecast_model_alloc m " +
      " WHERE i.forecast_instruction_id =  m.forecast_instruction_id " +
      "   AND i.forecast_dt = :date " +
      " ORDER BY i.forecast_instruction_id, m.forecast_model_alloc_id ";
  
  public static final String select_from_forecast_instr_model_alloc_by_forecastdate_and_fundid =
      "SELECT i.forecast_instruction_id " +
      "     , i.forecast_dt " +
      "     , i.forecast_status_id " +
      "     , i.forecast_type_id " +
      "     , i.money_notification_type_id " +
      "     , i.ilim_id as instr_ilim_id " +
      "     , i.amount " +
      "     , i.creation_dt as instr_creation_ts " +
      "     , i.event_id " +
      "     , m.forecast_model_alloc_id " +
      "     , m.ilim_id " +
      "     , m.underlying_ilim_id " +
      "     , m.committed_units_in_issue_qty " +
      "     , m.price " +
      "     , m.mix_pct " +
      "     , m.cash_amt " +
      "     , m.creation_dt " +
      "  FROM forecast_instruction i, forecast_model_alloc m " +
      " WHERE i.forecast_instruction_id =  m.forecast_instruction_id " +
      "   AND i.forecast_dt = :date " +
      "   AND m.ilim_id = :fundId " +
      " ORDER BY i.forecast_instruction_id, m.forecast_model_alloc_id ";

  public static final String select_from_forecast_instr_model_alloc_by_statusid =
      "SELECT i.forecast_instruction_id " +
      "     , i.forecast_dt " +
      "     , i.forecast_status_id " +
      "     , i.forecast_type_id " +
      "     , i.money_notification_type_id " +
      "     , i.ilim_id as instr_ilim_id " +
      "     , i.amount " +
      "     , i.creation_dt as instr_creation_ts " +
      "     , i.event_id " +
      "     , m.forecast_model_alloc_id " +
      "     , m.ilim_id " +
      "     , m.underlying_ilim_id " +
      "     , m.committed_units_in_issue_qty " +
      "     , m.price " +
      "     , m.mix_pct " +
      "     , m.cash_amt " +
      "     , m.creation_dt " +
      "  FROM forecast_instruction i, forecast_model_alloc m " +
      " WHERE i.forecast_instruction_id =  m.forecast_instruction_id " +
      "   AND i.forecast_status_id = :statusId " +
      " ORDER BY i.forecast_instruction_id, m.forecast_model_alloc_id ";
  
}