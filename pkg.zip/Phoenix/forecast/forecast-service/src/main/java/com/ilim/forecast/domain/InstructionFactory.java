package com.ilim.forecast.domain;

import com.ilim.commons.domain.IEvent;
import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.domain.model.MoneyNotificationType;
import com.ilim.forecast.domain.event.FailedForecastInstruction;
import com.ilim.forecast.domain.event.ModelledForecastInstruction;
import com.ilim.forecast.domain.event.PendingForecastInstruction;
import com.ilim.forecast.domain.event.ProcessingForecastInstruction;
import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastStatus;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

/**
 * Forecast Instruction Domain (Entity, Event) creation factory.
 * 
 * @author alan larkin
 */
public class InstructionFactory {

  /** Creates a ForecastIntsruction with a New Status. */
  public static ForecastInstruction createNewForecastInstruction(
      LocalDate forecastDate, ForecastType forecastType, int fundId,
      MoneyNotificationType moneyType, BigDecimal amount, long eventId) {

    return new ForecastInstruction(-1, forecastDate, ForecastStatus.NEW,
        forecastType, fundId, moneyType, amount, LocalDateTime.now(), eventId);
  }

  /** Creates a PendingForecastIntsruction event. */
  public static IEvent<PendingForecastInstruction> createPendingEvent(
      ForecastInstruction instr) {

    return new PendingForecastInstruction(instr.getId(),
        instr.getForecastDate(), instr.getForecastType().id(),
        instr.getFundId(), instr.getMoneyType().id(), instr.getAmount());
  }

  /** Creates a ProcessingForecastInstruction event. */
  public static IEvent<ProcessingForecastInstruction> createProcessingEvent(
      int instrId) {

    return new ProcessingForecastInstruction(instrId);
  }

  /** Creates a ModelledForecastInstruction event. */
  public static IEvent<ModelledForecastInstruction> createModelledEvent(
      int modelId, int instrId) {

    return new ModelledForecastInstruction(modelId, instrId);
  }

  /** Creates a FailedForecastInstruction event. */
  public static IEvent<FailedForecastInstruction> createFailedEvent(int instrId,
      Optional<Integer> modelId, String error) {

    return new FailedForecastInstruction(instrId, modelId, error);
  }

}
