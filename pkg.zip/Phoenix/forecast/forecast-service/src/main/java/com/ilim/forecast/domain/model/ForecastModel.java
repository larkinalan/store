package com.ilim.forecast.domain.model;

import static com.google.common.base.Preconditions.checkNotNull;

import com.ilim.commons.domain.IEntity;

import com.google.common.base.MoreObjects;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

/**
 * Forecast Model Aggregate.
 * 
 * <p>This represents the whole model instruction and modelled allocations.
 *
 * @author Alan Larkin
 */
public class ForecastModel implements IEntity<Integer> {

  private final ForecastInstruction instr;
  private final List<ForecastModelAlloc> modelAllocs;

  /** Creates a ForecastInstruction domain entity. */
  public ForecastModel(ForecastInstruction instr,
      List<ForecastModelAlloc> modelAllocs) {

    checkNotNull(instr, " instr cannot be null!");
    checkNotNull(modelAllocs, " modelAllocs cannot be null!");

    this.instr = instr;
    this.modelAllocs = modelAllocs;
  }

  public Integer getId() {
    return instr.getId();
  }

  public LocalDate getForecastDate() {
    return instr.getForecastDate();
  }

  public ForecastStatus getStatus() {
    return instr.getStatus();
  }

  public ForecastInstruction getInstruction() {
    return instr;
  }

  public List<ForecastModelAlloc> getModelAllocs() {
    return modelAllocs;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final ForecastModel other = (ForecastModel) obj;
    return Objects.equals(this.getId(), other.getId());
  }

  @Override
  public int hashCode() {

    return Objects.hashCode(this.getId());
  }

  @Override
  public String toString() {

    return MoreObjects.toStringHelper(this).add("instr", instr.toString())
        .add("modelAllocs", modelAllocs.size()).toString();
  }

}
