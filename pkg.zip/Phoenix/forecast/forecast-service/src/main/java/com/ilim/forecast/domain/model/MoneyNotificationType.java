package com.ilim.forecast.domain.model;

/**
 * Money type of cash or units. 
 * 
 * @author michael cunnigham
 *
 */
public enum MoneyNotificationType {

  UNKNOWN(0), CASH(1), UNITS(2);

  private final int id;

  MoneyNotificationType(int id) {
    this.id = id;
  }

  public int id() {
    return id;
  }

  /** Returns the enum for an id. */
  public static MoneyNotificationType from(int id) {

    for (MoneyNotificationType type : MoneyNotificationType.values()) {
      if (type.id() == id) {
        return type;
      }
    }
    return UNKNOWN;
  }

  /** Returns the enum for a name. */
  public static MoneyNotificationType from(String name) {

    for (MoneyNotificationType type : MoneyNotificationType.values()) {
      if (type.name().equalsIgnoreCase(name)) {
        return type;
      }
    }
    return UNKNOWN;
  }
}
