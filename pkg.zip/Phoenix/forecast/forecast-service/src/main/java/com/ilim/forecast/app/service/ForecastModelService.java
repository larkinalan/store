package com.ilim.forecast.app.service;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_CASH;
import static java.math.RoundingMode.HALF_EVEN;

import com.ilim.forecast.domain.IForecastModelRepository;
import com.ilim.forecast.domain.InstructionFactory;
import com.ilim.forecast.domain.event.PendingForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.PendingInstruction;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

import javax.inject.Inject;

/**
 * Forecast Model Service.
 * 
 * <p>This manages all the app use cases for forecast model actions.
 *
 * @author Michael Cunningham
 *
 */
@Service
public class ForecastModelService implements IForecastModelService {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastModelService.class);

  private IForecastModelRepository dao;
  private ForecastModelPubisher publisher;
  private IFundService fundService;

  /**
   * Initalize ForecastModelService.
   * 
   * <p>These are typically injected in by spring.
   * 
   * @param dao persistence layer
   * @param publisher events
   * @param fundService fund service client adapter
   */
  @Inject
  public ForecastModelService(IForecastModelRepository dao,
      ForecastModelPubisher publisher, IFundService fundService) {

    this.dao = dao;
    this.publisher = publisher;
    this.fundService = fundService;
  }

  /**
   * Finds a ForecastModel with the given model id.
   * 
   * <p>Model id must exist.
   * 
   * @param modelId model pk
   * @return List of ForecastModel.
   * @throws IllegalArgumentException, AppSqlException
   */
  @Transactional
  @Override
  public List<ForecastModelAlloc> findByModelId(int modelId) {

    log.info("Service findByModelId " + modelId);

    checkArgument(modelId > 0, "invalid modelId!");
    return dao.findByModelId(modelId);
  }

  /**
   * Finds all models.
   * 
   * @return List of ForecastModel.
   */
  @Transactional
  @Override
  public List<ForecastModelAlloc> findAll() {

    log.info("Service findAll ");

    return dao.findAll();
  }

  /**
   * Models an instruction
   * 
   * @param instr PendingForecastInstruction.
   */
  @Transactional
  @Override
  public void model(PendingForecastInstruction instr) {

    log.info("model ({})", instr);

    publisher
        .processing(InstructionFactory.createProcessingEvent(instr.instrId));

    // Lookup the funds, positions and prices
    List<FundHoldingData> positions =
        fundService.findUnitPositions(instr.fundId);
    List<Integer> fundIds = fundService.toFundIds(positions);
    List<FundData> funds = fundService.findFunds(fundIds);
    List<FundPriceData> prices = fundService.findPrices(fundIds);

    // generate forecast model
    final IForecastModeller modeller =
        new ForecastModeller(funds, prices, positions);
    List<ForecastModelAlloc> modelAllocs =
        modeller.model(toPendingInstruction(instr));
    int modelId = save(modelAllocs);

    publisher.modelled(
        InstructionFactory.createModelledEvent(modelId, instr.instrId));
  }

  /**
   * Saves new ForecastModel.
   * 
   * <p>delete if EXISTS then create.
   * 
   * @param model List of ForecastModel
   * @return int model id.
   * @throws NullPointerException, AppSqlException
   */
  @Transactional
  @Override
  public int save(List<ForecastModelAlloc> model) {

    log.info("Service save ForecastModel : " + model);

    checkNotNull(model, " model cannot be null");
    checkArgument(model.size() > 0, " model cannot be empty");

    delete(model);
    return dao.create(model);
  }

  /**
   * Deletes a ForecastModel with the given id.
   * 
   * @param model List of  ForecastModel
   * @throws IllegalArgumentException, AppSqlException
   */
  public void delete(List<ForecastModelAlloc> model) {

    log.info("Service delete.");

    // FIXME: this will delete prev instr i think :-(
    for (ForecastModelAlloc alloc : model) {

      ForecastModelAlloc.Id id = alloc.getId();

      if (alloc.isSaved()) {

        // delete existing model allocs
        log.info("Service delete model by Id " + id);
        dao.deleteById(id);
      }
    }
  }

  /**
   * Update the record cash amt for a model row.
   * 
   * @param id ForecastModelAlloc.Id
   * @param recordedCash cash amt
   * @throws IllegalArgumentException, AppSqlException
   */
  @Transactional
  @Override
  public void updateRecordedCash(ForecastModelAlloc.Id id,
      BigDecimal recordedCash) {

    log.info("Service updateRecordedCash id: " + id + " recordedCash: "
        + recordedCash);

    checkNotNull(id, "invalid forecast model id!");

    // TODO: do we need to validate recordedCash ???
    dao.update(id, recordedCash.setScale(ROUND_CASH.scale(), HALF_EVEN));
  }

  private static PendingInstruction toPendingInstruction(
      PendingForecastInstruction instr) {

    return new PendingInstruction(instr.instrId, instr.moneyTypeId,
        instr.fundId, instr.amt);
  }

}
