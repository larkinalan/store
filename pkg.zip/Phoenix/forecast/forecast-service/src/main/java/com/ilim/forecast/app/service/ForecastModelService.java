package com.ilim.forecast.app.service;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.ilim.forecast.domain.model.ForecastRounding.ROUND_CASH;
import static java.math.RoundingMode.HALF_EVEN;

import com.ilim.forecast.domain.IForecastModelRepository;
import com.ilim.forecast.domain.InstructionFactory;
import com.ilim.forecast.domain.event.PendingForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.Instruction;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

/**
 * Forecast Model Service.
 * 
 * <p>This manages all the app use cases for forecast model actions.
 *
 * @author Michael Cunningham
 *
 */
@Service
public class ForecastModelService implements IForecastModelService {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastModelService.class);

  private IForecastModelRepository dao;
  private ForecastModelPubisher publisher;
  private IFundService fundService;

  /**
   * Initalize ForecastModelService.
   * 
   * <p>These are typically injected in by spring.
   * 
   * @param dao persistence layer
   * @param publisher events
   * @param fundService fund service client adapter
   */
  @Inject
  public ForecastModelService(IForecastModelRepository dao,
      ForecastModelPubisher publisher, IFundService fundService) {

    this.dao = dao;
    this.publisher = publisher;
    this.fundService = fundService;
  }

  /**
   * Finds a ForecastModel with the given model id.
   * 
   * <p>Model id must exist.
   * 
   * @param modelId model pk
   * @return List of ForecastModel.
   * @throws IllegalArgumentException, AppSqlException
   */
  @Transactional
  @Override
  public List<ForecastModelAlloc> findByModelId(int modelId) {

    log.info("findByModelId ({})", modelId);

    checkArgument(modelId > 0, "invalid modelId!");

    return dao.findByModelId(modelId);
  }

  /**
   * Find all Forecast Models for a specified forecast date.
   * 
   * @param forecastDate forecast date
   * @return List of ForecastModel.
   * @throws NullPointerException if forecastDate is empty.
   */
  @Transactional
  @Override
  public List<ForecastModelAlloc> findByForecastDate(LocalDate forecastDate) {

    log.info("findByForecastDate ({})", forecastDate);

    checkNotNull(forecastDate, " forecast date cannot be empty");

    return dao.findByForecastDate(forecastDate);
  }

  /**
   * Find all Forecast Models for a specified fundId and forecast date.
   * 
   * @param fundId          fund id
   * @param forecastDate    forecast date
   * @return List of ForecastModel.
   * @throws NullPointerException if fundId or forecastDate is empty.
   */
  @Transactional
  @Override
  public List<ForecastModelAlloc> findByFundIdAndForecastDate(int fundId,
      LocalDate forecastDate) {

    log.info("findByFundIdAndForecastDate ({}, {})", fundId, forecastDate);

    checkArgument(fundId > 0, "invalid fundId!");
    checkNotNull(forecastDate, " forecast date cannot be empty");

    return dao.findByFundIdAndForecastDate(fundId, forecastDate);
  }

  /**
   * Finds all models.
   * 
   * @return List of ForecastModel.
   */
  @Transactional
  @Override
  public List<ForecastModelAlloc> findAll() {

    log.info("findAll ()");

    return dao.findAll();
  }

  /**
   * Models an instruction
   * 
   * @param instr PendingForecastInstruction.
   */
  @Transactional
  @Override
  public void model(PendingForecastInstruction instr) {

    log.info("model ({})", instr);

    publisher.publish(InstructionFactory.createProcessingEvent(instr.instrId));

    // Lookup the funds, positions and prices
    Map<String, FundHoldingData> positions = findPositions(instr);
    List<Integer> fundIds = fundService.flatMapToFundIds(positions.values());
    Map<Integer, FundData> funds = fundService.findFunds(fundIds);
    Map<Integer, BigDecimal> prices = fundService.findPrices(fundIds);

    // generate forecast model
    final IForecastModeller modeller =
        new ForecastModeller(funds, prices, positions);
    List<ForecastModelAlloc> modelAllocs =
        modeller.model(toInstruction(instr));
    int modelId = save(modelAllocs);

    publisher.publish(
        InstructionFactory.createModelledEvent(modelId, instr.instrId));
  }

  private Map<String, FundHoldingData> findPositions(
      PendingForecastInstruction instr) {

    // get latest FM committed positions.
    Map<String, FundHoldingData> recordedPositions =
        fundService.findRecordedPositions(instr.fundId);

    // get this dates forecasted positions
    List<ForecastModelAlloc> forecast = findByForecastDate(instr.forecastDate);
    // sort by creation time, so that we have the latest positions at the end.
    List<ForecastModelAlloc> chronologicalForecast =
        forecast.stream()
            .sorted((a1,
                a2) -> (a1.getCreationTime().compareTo(a2.getCreationTime())))
            .collect(Collectors.toList());

    // update recorded positions with forecast positions.
    // NOTE: assuming forecast has the most up to date positions.
    Map<String, FundHoldingData> positions = new HashMap<>();
    for (ForecastModelAlloc alloc : chronologicalForecast) {

      FundHoldingData forecastPosition =
          new FundHoldingData(alloc.getId().getFundId(),
              alloc.getId().getHoldingId(), alloc.getCommittedUnits());

      String key =
          alloc.getId().getFundId() + ":" + alloc.getId().getHoldingId();
      FundHoldingData recordedPosition = recordedPositions.get(key);

      // replace
      if (recordedPosition != null) {
        positions.put(key, forecastPosition);
      }
    }

    return positions;
  }

  /**
   * Saves new ForecastModel.
   * 
   * <p>delete if EXISTS then create.
   * 
   * @param model List of ForecastModel
   * @return int model id.
   * @throws NullPointerException, AppSqlException
   */
  @Transactional
  @Override
  public int save(List<ForecastModelAlloc> model) {

    log.info("save ({}) ", model);

    checkNotNull(model, " model cannot be null");
    checkArgument(model.size() > 0, " model cannot be empty");

    delete(model);
    return dao.create(model);
  }

  /**
   * Deletes a ForecastModel with the given id.
   * 
   * @param model List of  ForecastModel
   * @throws IllegalArgumentException, AppSqlException
   */
  public void delete(List<ForecastModelAlloc> model) {

    log.info("delete (...)");

    // FIXME: this will delete prev instr i think :-(
    for (ForecastModelAlloc alloc : model) {

      ForecastModelAlloc.Id id = alloc.getId();

      if (alloc.isSaved()) {

        // delete existing model allocs
        log.info("delete ({})", id);
        dao.deleteById(id);
      }
    }
  }

  /**
   * Update the record cash amt for a model row.
   * 
   * @param id ForecastModelAlloc.Id
   * @param recordedCash cash amt
   * @throws IllegalArgumentException, AppSqlException
   */
  @Transactional
  @Override
  public void updateRecordedCash(ForecastModelAlloc.Id id,
      BigDecimal recordedCash) {

    log.info("updateRecordedCash ({}, {})", id, recordedCash);

    checkNotNull(id, "invalid forecast model id!");

    // TODO: do we need to validate recordedCash ???
    dao.update(id, recordedCash.setScale(ROUND_CASH.scale(), HALF_EVEN));
  }

  private static Instruction toInstruction(
      PendingForecastInstruction instr) {

    return new Instruction(instr.instrId, instr.forecastDate,
        instr.moneyTypeId, instr.fundId, instr.amt);
  }

}
