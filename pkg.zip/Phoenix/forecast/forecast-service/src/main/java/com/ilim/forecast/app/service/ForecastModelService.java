package com.ilim.forecast.app.service;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static java.util.stream.Collectors.toList;

import com.ilim.commons.domain.IEvent;
import com.ilim.commons.domain.model.ForecastStatus;
import com.ilim.forecast.domain.IForecastModelAllocRepository;
import com.ilim.forecast.domain.IForecastModelView;
import com.ilim.forecast.domain.InstructionFactory;
import com.ilim.forecast.domain.event.PendingForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModel;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.ProcessingForecastInstruction;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;

/**
 * Forecast Model Service.
 * 
 * <p>This manages all the app use cases for forecast model actions.
 *
 * @author Michael Cunningham
 *
 */
@Service
public class ForecastModelService implements IForecastModelService {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastModelService.class);

  private IForecastModelAllocRepository modelAllocDao;
  private IForecastModelView modelDao;
  private ForecastModelPubisher publisher;
  private IFundService fundService;

  /**
   * Initalize ForecastModelService.
   * 
   * <p>These are typically injected in by spring.
   * 
   * @param modelAllocDao persistence layer
   * @param instrDao persistence layer
   * @param publisher events
   * @param fundService fund service client adapter
   */
  @Inject
  public ForecastModelService(IForecastModelAllocRepository modelAllocDao,
      IForecastModelView modelDao, ForecastModelPubisher publisher,
      IFundService fundService) {

    this.modelAllocDao = modelAllocDao;
    this.modelDao = modelDao;
    this.publisher = publisher;
    this.fundService = fundService;
  }

  /**
   * Find Forecast Models for an instruction id.
   * 
   * @param instrId instruction
   * @return ForecastModel.
   * @throws NullPointerException if forecastDate is empty.
   */
  @Transactional
  @Override
  public ForecastModel findByInstrId(int instrId) {

    log.info("findByInstrId ({})", instrId);

    return modelDao.findByInstrId(instrId);
  }

  /**
   * Find Forecast Models for a forecast date.
   * 
   * @param forecastDate forecast date
   * @return List of ForecastModel.
   * @throws NullPointerException if forecastDate is empty.
   */
  @Transactional
  @Override
  public List<ForecastModel> findByForecastDate(LocalDate forecastDate) {

    log.info("findByForecastDate ({})", forecastDate);

    checkNotNull(forecastDate, "Forecast date cannot be empty!");

    return modelDao.findByForecastDate(forecastDate);
  }

  /**
   * Find Forecast Models for a forecast date.
   * 
   * @param forecastDate forecast date
   * @return List of ForecastModel.
   * @throws NullPointerException if forecastDate is empty.
   */
  @Transactional
  @Override
  public List<ForecastModel> findByForecastDateAndFundId(LocalDate forecastDate,
      int fundId) {

    log.info("findByForecastDateAndFundId ({},{})", forecastDate, fundId);

    checkNotNull(forecastDate, "Forecast date cannot be empty!");

    return modelDao.findByForecastDate(forecastDate);
  }

  /**
   * Find Forecast Models by status.
   * 
   * @param status forecastStatus
   * @return List of ForecastModel.
   * @throws NullPointerException if forecastDate is empty.
   */
  @Override
  public List<ForecastModel> findByStatus(ForecastStatus status) {

    log.info("findByStatus ({})", status);

    checkState(status != ForecastStatus.UNKNOWN, "Invalid status " + status);

    return modelDao.findByStatus(status);
  }

  /**
   * Models an instruction
   * 
   * @param instr PendingForecastInstruction.
   */
  @Transactional
  @Override
  public void model(PendingForecastInstruction instr) {

    log.info("model ({})", instr);

    IEvent<ProcessingForecastInstruction> processingInstr =
        InstructionFactory.createProcessingEvent(instr);
    publisher.publish(processingInstr);

    // Lookup the funds, positions and prices
    Map<String, FundHoldingData> positions = findPositions(instr);
    List<Integer> fundIds = fundService.flatMapToFundIds(positions.values());
    Map<Integer, FundData> funds = fundService.findFunds(fundIds);
    Map<Integer, BigDecimal> prices = fundService.findPrices(fundIds);

    // generate forecast model
    final IForecastModeller modeller =
        new ForecastModeller(funds, prices, positions);
    List<ForecastModelAlloc> modelAllocs = modeller.model(processingInstr);
    save(modelAllocs);

    publisher.publish(InstructionFactory.createModelledEvent(instr.instrId));
  }

  /**
   * Saves new ForecastModel.
   * 
   * <p>delete if EXISTS then create.
   * 
   * @param model List of ForecastModel
   * @return int model id.
   * @throws NullPointerException, AppSqlException
   */
  @Transactional
  @Override
  public List<Integer> save(List<ForecastModelAlloc> modelAllocs) {

    log.info("save ({..}) ");

    checkNotNull(modelAllocs, "Model allocs cannot be null!");
    checkArgument(modelAllocs.size() > 0, "Model allocs cannot be empty!");

    delete(modelAllocs);
    return modelAllocDao.create(modelAllocs);
  }

  /**
   * Deletes ForecastModel with the given id.
   * 
   * @param model List of  ForecastModel
   * @throws IllegalArgumentException, AppSqlException
   */
  public void delete(List<ForecastModelAlloc> modelAllocs) {

    log.info("delete (...)");

    List<Integer> ids = modelAllocs.stream().flatMap(a -> Stream.of(a.getId()))
        .collect(Collectors.toList());
    modelAllocDao.delete(ids);
  }

  /** Merges latest forecast with latest FM positions. */
  private Map<String, FundHoldingData> findPositions(
      PendingForecastInstruction instr) {

    // get latest FM committed positions.
    Map<String, FundHoldingData> recordedPositions =
        fundService.findRecordedPositions(instr.fundId);
    checkState(recordedPositions.size() > 0,
        "Missing positions for client fund " + instr.fundId);

    // get the forecasted model and its positions
    List<ForecastModel> forecastModel = findByForecastDate(instr.forecastDate);

    return mergePositions(recordedPositions, forecastModel);
  }

  private Map<String, FundHoldingData> mergePositions(
      Map<String, FundHoldingData> recordedPositions,
      List<ForecastModel> forecastModel) {

    if (forecastModel.size() == 0) {
      return recordedPositions;
    }

    // sort by creation, so that we have the latest forecast at the end.
    List<ForecastModelAlloc> chronologically =
        forecastModel.stream().flatMap(m -> m.getModelAllocs().stream())
            .sorted((a1,
                a2) -> (a1.getCreationTime().compareTo(a2.getCreationTime())))
        .collect(toList());

    // Finally update recorded positions with latest forecast positions.
    Map<String, FundHoldingData> positions = new HashMap<>();
    for (ForecastModelAlloc alloc : chronologically) {

      FundHoldingData forecastPosition = new FundHoldingData(alloc.getFundId(),
          alloc.getHoldingId(), alloc.getCommittedUnits());

      String key = alloc.getFundId() + ":" + alloc.getHoldingId();
      FundHoldingData recordedPosition = recordedPositions.get(key);

      // replace
      if (recordedPosition != null) {
        positions.put(key, forecastPosition);
      }
    }

    return positions;
  }

}
