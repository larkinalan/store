package com.ilim.forecast.app.service;

import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface IFundService {

  Map<Integer, FundData> findFunds(List<Integer> fundIds);

  Map<Integer, BigDecimal> findPrices(List<Integer> fundIds);

  Map<String, FundHoldingData> findRecordedPositions(int rootFundId);

  List<Integer> flatMapToFundIds(Collection<FundHoldingData> positions);

}
