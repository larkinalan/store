package com.ilim.forecast.app.service;

import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import java.util.List;

public interface IFundService {

  List<FundData> findFunds(List<Integer> fundIds);

  List<FundPriceData> findPrices(List<Integer> fundIds);

  List<FundHoldingData> findUnitPositions(int rootFundId);

  List<Integer> toFundIds(List<FundHoldingData> positions);

}
