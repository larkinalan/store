package com.ilim.forecast.web.resources;

import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.domain.model.MoneyNotificationType;
import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.domain.InstructionFactory;
import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModel;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.ForecastStatus;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.forecast.web.api.ForecastModelData;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Error DataType Mapper.
 * 
 * @author Alan Larkin
 */
public final class ForecastDataMapper {

  private ForecastDataMapper() {}

  /** Converts List ForecastInstruction to List ForecastInstructionData. */
  public static List<ForecastInstructionData> toForecastInstructionDataList(
      final List<ForecastInstruction> entityList) {

    final List<ForecastInstructionData> dataList = new ArrayList<>();
    for (ForecastInstruction entity : entityList) {
      dataList.add(toForecastInstructionData(entity));
    }
    return dataList;
  }

  /** Converts ForecastInstruction to ForecastInstructionData. */
  public static ForecastInstructionData toForecastInstructionData(
      final ForecastInstruction entity) {

    final int id = entity.getId();
    final String forecastDate =
        entity.getForecastDate().format(DateUtils.DATE_FMT);
    final String status = entity.getStatus().name();
    final String forecastType = entity.getForecastType().name();
    final int fundId = entity.getFundId();
    final String moneyType = entity.getMoneyType().name();
    final BigDecimal amount = entity.getAmount();
    final String creationTime =
        entity.getCreationTime().format(DateUtils.DATE_TIME_FMT);
    final long eventSourceId = entity.getEventSourceId();

    return new ForecastInstructionData(id, forecastDate, status, forecastType,
        fundId, moneyType, amount, creationTime, eventSourceId);
  }

  /** Converts List ForecastInstructionData to List ForecastInstruction. */
  public static List<ForecastInstruction> toForecastInstructionList(
      final List<ForecastInstructionData> dataList) {

    final List<ForecastInstruction> entityList = new ArrayList<>();
    for (ForecastInstructionData entity : dataList) {
      entityList.add(toForecastInstruction(entity));
    }
    return entityList;
  }

  /** Converts ForecastInstructionData to ForecastInstruction. */
  public static ForecastInstruction toForecastInstruction(
      final ForecastInstructionData data) {

    final int id = data.id;
    final LocalDate forecastDate =
        LocalDate.parse(data.forecastDate, DateUtils.DATE_FMT);
    final ForecastStatus status = ForecastStatus.from(data.status);
    final ForecastType forecastType = ForecastType.from(data.forecastType);
    final int fundId = data.fundId;
    final MoneyNotificationType moneyType =
        MoneyNotificationType.from(data.moneyType);
    final BigDecimal amount = data.amount;
    final LocalDateTime creationTime =
        LocalDateTime.parse(data.creationTime, DateUtils.DATE_TIME_FMT);
    final long eventSourceId = data.eventSourceId;

    return new ForecastInstruction(id, forecastDate, status, forecastType,
        fundId, moneyType, amount, creationTime, eventSourceId);
  }

  /** Converts List NewForecastInstructionData to List ForecastInstruction. */
  public static List<ForecastInstruction> toNewForecastInstructionList(
      final List<NewForecastInstructionData> dataList) {

    final List<ForecastInstruction> entityList = new ArrayList<>();
    for (NewForecastInstructionData data : dataList) {
      entityList.add(toNewForecastInstruction(data));
    }
    return entityList;
  }

  /** Converts NewForecastInstructionData to ForecastInstruction. */
  public static ForecastInstruction toNewForecastInstruction(
      final NewForecastInstructionData data) {

    final LocalDate forecastDate =
        LocalDate.parse(data.forecastDate, DateUtils.DATE_FMT);
    final ForecastType forecastType = ForecastType.from(data.forecastType);
    final int fundId = data.fundId;
    final MoneyNotificationType moneyType =
        MoneyNotificationType.from(data.moneyType);
    final BigDecimal amount = data.amount;
    final long eventSourceId = data.eventSourceId;

    return InstructionFactory.createNewForecastInstruction(forecastDate,
        forecastType, fundId, moneyType, amount, eventSourceId);
  }

  /** Converts List ForecastModelAlloc to List ForecastModelAllocData. */
  public static List<ForecastModelAllocData> toForecastModelAllocDataList(
      List<ForecastModelAlloc> entityList) {

    final List<ForecastModelAllocData> dataList = new ArrayList<>();
    for (ForecastModelAlloc entity : entityList) {
      dataList.add(toForecastModelAllocData(entity));
    }
    return dataList;
  }

  /** Converts ForecastModelAlloc to ForecastModelAllocData. */
  public static ForecastModelAllocData toForecastModelAllocData(
      ForecastModelAlloc entity) {

    final int allocId = entity.getId();
    final int instrId = entity.getInstrId();
    final int fundId = entity.getFundId();
    final int holdingId = entity.getHoldingId();
    final BigDecimal unitsInIssue = entity.getCommittedUnits();
    final BigDecimal price = entity.getPrice();
    final BigDecimal mix = entity.getMix();
    final BigDecimal cash = entity.getCash();
    final String creationTime =
        entity.getCreationTime().format(DateUtils.DATE_TIME_FMT);

    return new ForecastModelAllocData(allocId, instrId, fundId, holdingId,
        unitsInIssue, price, mix, cash, creationTime);
  }

  /** Converts List ForecastModel to List ForecastModelData. */
  public static List<ForecastModelData> toForecastModelDataList(
      List<ForecastModel> entityList) {

    final List<ForecastModelData> dataList = new ArrayList<>();
    for (ForecastModel entity : entityList) {
      dataList.add(toForecastModelData(entity));
    }
    return dataList;
  }

  /** Converts ForecastModel to ForecastModelData. */
  public static ForecastModelData toForecastModelData(ForecastModel entity) {

    return new ForecastModelData(
        toForecastInstructionData(entity.getInstruction()),
        toForecastModelAllocDataList(entity.getModelAllocs()));
  }


}
