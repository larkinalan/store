package com.ilim.forecast.web.resources;

import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.domain.InstructionFactory;
import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.domain.model.ForecastStatus;
import com.ilim.forecast.domain.model.ForecastType;
import com.ilim.forecast.domain.model.MoneyNotificationType;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.forecast.web.api.ForecastModelAllocIdData;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Error DataType Mapper.
 * 
 * @author Alan Larkin
 */
public final class ForecastDataMapper {

  private ForecastDataMapper() {}

  /** Converts List ForecastInstruction to List ForecastInstructionData. */
  public static List<ForecastInstructionData> toForecastInstructionDataList(
      final List<ForecastInstruction> entityList) {

    final List<ForecastInstructionData> dataList = new ArrayList<>();
    for (ForecastInstruction entity : entityList) {
      dataList.add(toForecastInstructionData(entity));
    }
    return dataList;
  }

  /** Converts ForecastInstruction to ForecastInstructionData. */
  public static ForecastInstructionData toForecastInstructionData(
      final ForecastInstruction entity) {

    final int id = entity.getId();
    final String forecastDate =
        entity.getForecastDate().format(DateUtils.DATE_FMT);
    final String status = entity.getStatus().name();
    final String forecastType = entity.getForecastType().name();
    final int fundId = entity.getFundId();
    final String moneyType = entity.getMoneyType().name();
    final BigDecimal amount = entity.getAmount();
    final String creationTime =
        entity.getCreationTime().format(DateUtils.DATE_TIME_FMT);
    final long eventSourceId = entity.getEventSourceId();

    return new ForecastInstructionData(id, forecastDate, status, forecastType,
        fundId, moneyType, amount, creationTime, eventSourceId);
  }

  /** Converts List ForecastInstructionData to List ForecastInstruction. */
  public static List<ForecastInstruction> toForecastInstructionList(
      final List<ForecastInstructionData> dataList) {

    final List<ForecastInstruction> entityList = new ArrayList<>();
    for (ForecastInstructionData entity : dataList) {
      entityList.add(toForecastInstruction(entity));
    }
    return entityList;
  }

  /** Converts ForecastInstructionData to ForecastInstruction. */
  public static ForecastInstruction toForecastInstruction(
      final ForecastInstructionData data) {

    final int id = data.id;
    final LocalDate forecastDate =
        LocalDate.parse(data.forecastDate, DateUtils.DATE_FMT);
    final ForecastStatus status = ForecastStatus.from(data.status);
    final ForecastType forecastType = ForecastType.from(data.forecastType);
    final int fundId = data.fundId;
    final MoneyNotificationType moneyType =
        MoneyNotificationType.from(data.moneyType);
    final BigDecimal amount = data.amount;
    final LocalDateTime creationTime =
        LocalDateTime.parse(data.creationTime, DateUtils.DATE_TIME_FMT);
    final long eventSourceId = data.eventSourceId;

    return new ForecastInstruction(id, forecastDate, status, forecastType,
        fundId, moneyType, amount, creationTime, eventSourceId);
  }

  /** Converts List NewForecastInstructionData to List ForecastInstruction. */
  public static List<ForecastInstruction> toNewForecastInstructionList(
      final List<NewForecastInstructionData> dataList) {

    final List<ForecastInstruction> entityList = new ArrayList<>();
    for (NewForecastInstructionData data : dataList) {
      entityList.add(toNewForecastInstruction(data));
    }
    return entityList;
  }

  /** Converts NewForecastInstructionData to ForecastInstruction. */
  public static ForecastInstruction toNewForecastInstruction(
      final NewForecastInstructionData data) {

    final LocalDate forecastDate =
        LocalDate.parse(data.forecastDate, DateUtils.DATE_FMT);
    final ForecastType forecastType = ForecastType.from(data.forecastType);
    final int fundId = data.fundId;
    final MoneyNotificationType moneyType =
        MoneyNotificationType.from(data.moneyType);
    final BigDecimal amount = data.amount;
    final long eventSourceId = data.eventSourceId;

    return InstructionFactory.createNewForecastInstruction(forecastDate,
        forecastType, fundId, moneyType, amount, eventSourceId);
  }

  /** Converts List ForecastModelAlloc to List ForecastModelAllocData. */
  public static List<ForecastModelAllocData> toForecastModelAllocDataList(
      List<ForecastModelAlloc> entityList) {

    final List<ForecastModelAllocData> dataList = new ArrayList<>();
    for (ForecastModelAlloc entity : entityList) {
      dataList.add(toForecastModelAllocData(entity));
    }
    return dataList;
  }

  /** Converts ForecastModelAlloc to ForecastModelAllocData. */
  public static ForecastModelAllocData toForecastModelAllocData(
      ForecastModelAlloc entity) {

    final ForecastModelAllocIdData id = toDataId(entity.getId());
    final String forecastDate =
        entity.getForecastDate().format(DateUtils.DATE_FMT);
    final BigDecimal unitsInIssue = entity.getCommittedUnits();
    final BigDecimal price = entity.getPrice();
    final BigDecimal mix = entity.getMix();
    final BigDecimal cash = entity.getCash();
    final BigDecimal recordedCash = entity.getRecordedCash();

    return new ForecastModelAllocData(id, forecastDate, unitsInIssue, price,
        mix, cash, recordedCash);
  }

  /** Converts (ForecastModelAlloc.Id to ForecastModelAllocIdData. */
  public static ForecastModelAllocIdData toDataId(ForecastModelAlloc.Id id) {

    final int modelId = id.getModelId();
    final int instrId = id.getInstrId();
    final int fundId = id.getFundId();
    final int holdingId = id.getHoldingId();

    return new ForecastModelAllocIdData(modelId, instrId, fundId, holdingId);
  }

  /** Converts ForecastModelAllocIdData to ForecastModelAlloc.Id. */
  public static ForecastModelAlloc.Id toId(ForecastModelAllocIdData id) {

    final int modelId = id.modelId;
    final int instrId = id.instrId;
    final int fundId = id.fundId;
    final int holdingId = id.holdingId;

    return new ForecastModelAlloc.Id(modelId, instrId, fundId, holdingId);
  }

}
