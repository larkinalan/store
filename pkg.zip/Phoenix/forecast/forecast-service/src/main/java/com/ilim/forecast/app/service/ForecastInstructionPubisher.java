package com.ilim.forecast.app.service;

import static com.google.common.base.Preconditions.checkArgument;

import com.ilim.commons.domain.IEvent;
import com.ilim.commons.eventbus.AppEventBus;
import com.ilim.commons.eventbus.IEventPublisher;
import com.ilim.forecast.domain.event.PendingForecastInstruction;

import javax.inject.Inject;

/**
 * Forecast Publisher of instruction related events.
 * 
 * @author Michael Cunningham
 *      
 */
public class ForecastInstructionPubisher implements IEventPublisher {

  private AppEventBus eventBus;

  /**
   * Publishes to EventBus.
   * 
   * @param eventBus guava bus
   */
  @Inject
  public ForecastInstructionPubisher(AppEventBus eventBus) {

    this.eventBus = eventBus;
  }

  /** Returns the bus that this class is publishing to. */
  @Override
  public AppEventBus publishingTo() {
    return eventBus;
  }

  /**
   * Publish forecast instruction events.
   * 
   * @param event instr
   */
  @Override
  public void publish(IEvent<?> event) {

    checkArgument(event instanceof PendingForecastInstruction,
        "Invalid event type for forecasting instructions! " + event);

    eventBus.publish(event);
  }

}
