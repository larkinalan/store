package com.ilim.forecast.app.service;

import com.ilim.commons.domain.IEvent;
import com.ilim.commons.eventbus.AppEventBus;
import com.ilim.commons.eventbus.IEventPublisher;

import javax.inject.Inject;

/**
 * Forecast Publisher of instruction related events.
 * 
 * @author Michael Cunningham
 *      
 */
public class ForecastInstructionPubisher implements IEventPublisher {

  private AppEventBus eventBus;

  /**
   * Publishes to EventBus.
   * 
   * @param eventBus guava bus
   */
  @Inject
  public ForecastInstructionPubisher(AppEventBus eventBus) {

    this.eventBus = eventBus;
  }

  /** Returns the bus that this class is publishing to. */
  @Override
  public AppEventBus publishingTo() {
    return eventBus;
  }

  /**
   * Publish pending instruction events.
   * 
   * @param event  pending instr
   */
  public void pending(IEvent event) {

    eventBus.publish(event);
  }

}
