package com.ilim.forecast.app.service;

import com.ilim.commons.domain.IEvent;
import com.ilim.commons.eventbus.AppEventBus;
import com.ilim.commons.eventbus.IEventPublisher;
import com.ilim.forecast.domain.event.FailedForecastInstruction;
import com.ilim.forecast.domain.event.ModelledForecastInstruction;
import com.ilim.forecast.domain.event.ProcessingForecastInstruction;

import javax.inject.Inject;

/**
 * Forecast Publisher of model related events.
 * 
 * @author Michael Cunningham
 *      
 */
public class ForecastModelPubisher implements IEventPublisher {

  private AppEventBus eventBus;

  /**
   * Publishes to EventBus.
   * 
   * @param eventBus guava bus
   */
  @Inject
  public ForecastModelPubisher(AppEventBus eventBus) {

    this.eventBus = eventBus;
  }
  
  /** Returns the bus that this class is publishing to. */
  @Override
  public AppEventBus publishingTo() {
    return eventBus;
  }
  
  /**
   * Publish events to app event bus.
   * 
   * @param event instr
   */
  @Override
  public void publish(IEvent<?> event) {
    
    eventBus.publish(event);
  }

  /**
   * Publish model processing events.
   * 
   * @param event instr being processed
   */
  public void processing(IEvent<ProcessingForecastInstruction> event) {

    eventBus.publish(event);
  }

  /**
   * Publish model complete event.
   * 
   * @param event instr thats has finished modelling.
   */
  public void modelled(IEvent<ModelledForecastInstruction> event) {

    eventBus.publish(event);
  }

  /**
   * Publish model failed event.
   * 
   * @param event instr thats has failed to model.
   */
  public void failed(IEvent<FailedForecastInstruction> event) {

    eventBus.publish(event);
  }



}
