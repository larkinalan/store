package com.ilim.forecast.app.service;

import static com.google.common.base.Preconditions.checkArgument;

import com.ilim.commons.domain.IEvent;
import com.ilim.commons.eventbus.AppEventBus;
import com.ilim.commons.eventbus.IEventPublisher;
import com.ilim.forecast.domain.event.FailedForecastInstruction;
import com.ilim.forecast.domain.event.ModelledForecastInstruction;
import com.ilim.forecast.domain.model.ProcessingForecastInstruction;

import javax.inject.Inject;

/**
 * Forecast Publisher of model related events.
 * 
 * @author Michael Cunningham
 *      
 */
public class ForecastModelPubisher implements IEventPublisher {

  private AppEventBus eventBus;

  /**
   * Publishes to EventBus.
   * 
   * @param eventBus guava bus
   */
  @Inject
  public ForecastModelPubisher(AppEventBus eventBus) {

    this.eventBus = eventBus;
  }

  /** Returns the bus that this class is publishing to. */
  @Override
  public AppEventBus publishingTo() {
    return eventBus;
  }

  /**
   * Publish forecast modelling events.
   * 
   * @param event instr
   */
  @Override
  public void publish(IEvent<?> event) {

    checkArgument(
        (event instanceof ProcessingForecastInstruction
            || event instanceof ModelledForecastInstruction
            || event instanceof FailedForecastInstruction),
        "Invalid event type for forecast modelling! " + event);

    eventBus.publish(event);
  }

}
