package com.ilim.forecast.app.service;

import com.ilim.commons.domain.IEvent;
import com.ilim.commons.eventbus.AppEventBus;
import com.ilim.commons.eventbus.IEventPublisher;

import javax.inject.Inject;

/**
 * Forecast Publisher of model related events.
 * 
 * @author Michael Cunningham
 *      
 */
public class ForecastModelPubisher implements IEventPublisher {

  private AppEventBus eventBus;

  /**
   * Publishes to EventBus.
   * 
   * @param eventBus guava bus
   */
  @Inject
  public ForecastModelPubisher(AppEventBus eventBus) {

    this.eventBus = eventBus;
  }

  /** Returns the bus that this class is publishing to. */
  @Override
  public AppEventBus publishingTo() {
    return eventBus;
  }

  /**
   * Publish model processing events.
   * 
   * @param event instr being processed
   */
  public void processing(IEvent event) {

    eventBus.publish(event);
  }

  /**
   * Publish model complete event.
   * 
   * @param event instr thats has finished modelling.
   */
  public void modelled(IEvent event) {

    eventBus.publish(event);
  }

  /**
   * Publish model failed event.
   * 
   * @param event instr thats has failed to model.
   */
  public void failed(IEvent event) {

    eventBus.publish(event);
  }

}
