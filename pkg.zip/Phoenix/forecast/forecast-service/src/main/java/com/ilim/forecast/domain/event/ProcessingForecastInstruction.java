package com.ilim.forecast.domain.event;

import com.ilim.commons.domain.IEvent;

import com.google.common.base.MoreObjects;

import java.time.LocalDateTime;

/**
 * Processing Forecast Instruction Event.
 * 
 * @author Michael Cunningham
 */
public class ProcessingForecastInstruction
    implements IEvent<ProcessingForecastInstruction> {

  public final int instrId;
  public final LocalDateTime occuredOn;

  /** Processing Forecast Instruction Event. */
  public ProcessingForecastInstruction(int instrId) {

    this.instrId = instrId;
    this.occuredOn = LocalDateTime.now();
  }

  @Override
  public LocalDateTime occuredOn() {
    return occuredOn;
  }

  /** Returns a String representation of this Forecast Instruction Event. */ 
  public String toString() {

    return MoreObjects.toStringHelper(this)
        .add("instrId", instrId).add("occuredOn", occuredOn).toString();
  }

}
