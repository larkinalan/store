package com.ilim.forecast.domain.event;

import com.ilim.commons.domain.IEvent;

import com.google.common.base.MoreObjects;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * Failed Forecast Instruction Event.
 * 
 * @author Michael Cunningham
 */
public class FailedForecastInstruction implements IEvent {

  public final int instrId;
  public final Optional<Integer> modelId;
  public final String error;
  public final LocalDateTime occuredOn;

  /** Failed Forecast Instruction Event. */
  public FailedForecastInstruction(int instrId, Optional<Integer> modelId,
      String error) {

    this.instrId = instrId;
    this.modelId = modelId;
    this.error = error;
    this.occuredOn = LocalDateTime.now();
  }

  @Override
  public LocalDateTime occuredOn() {
    return occuredOn;
  }

  /** Returns a String representation of this Forecast Instruction Event. */ 
  public String toString() {

    // leaving error off, to avoid repeat print of error stack.
    return MoreObjects.toStringHelper(this).add("instrId", instrId)
        .add("modelId", modelId).add("occuredOn", occuredOn).toString();
  }

}
