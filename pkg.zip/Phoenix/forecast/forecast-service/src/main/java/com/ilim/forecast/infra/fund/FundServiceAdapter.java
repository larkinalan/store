package com.ilim.forecast.infra.fund;

import com.ilim.commons.web.client.AppClientException;
import com.ilim.forecast.app.service.IFundService;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;
import com.ilim.fund.web.client.FundClient;

import com.google.common.collect.ImmutableMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import retrofit2.Response;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Fund Service client adapter.
 * 
 * @author Alan Larkin
 */
@Service
public class FundServiceAdapter implements IFundService {

  private static final Logger log =
      LoggerFactory.getLogger(FundServiceAdapter.class);

  private final FundClient fundClient;

  /**Creates adapter to remote fund service. */
  public FundServiceAdapter() {

    this.fundClient = new FundClient();
  }

  /** Lookup funds. */
  @Override
  public Map<Integer, FundData> findFunds(List<Integer> fundIds) {

    log.info("findFunds (...)");

    final Map<Integer, FundData> funds;
    try {

      Response<List<FundData>> response =
          fundClient.api().findFunds(fundIds).execute();

      if (response.isSuccess()) {
        funds = mapOfFunds(response.body());

      } else {
        log.error("findFunds failed!");
        throw new AppClientException(
            fundClient.adapter().toErrorData(response));
      }
    } catch (IOException ex) {
      log.error("findFunds failed!");
      throw new AppClientException(ex);
    }

    return funds;
  }

  /** Lookup latest prices for funds. */
  @Override
  public Map<Integer, BigDecimal> findPrices(List<Integer> fundIds) {

    log.info("findPrices (...)");

    final Map<Integer, BigDecimal> prices;
    try {

      Response<List<FundPriceData>> response =
          fundClient.api().findPrices(fundIds).execute();

      if (response.isSuccess()) {
        prices = mapOfPrices(response.body());

      } else {
        log.error("findPrices failed!");
        throw new AppClientException(
            fundClient.adapter().toErrorData(response));
      }
    } catch (IOException ex) {
      log.error("findPrices failed!");
      throw new AppClientException(ex);
    }

    return prices;
  }

  /** Lookup committed (i.e recorded) unit positions of a funds holdings. */
  @Override
  public Map<String, FundHoldingData> findRecordedPositions(int rootFundId) {

    log.info("findRecordedPositions ({})", rootFundId);

    final Map<String, FundHoldingData> positions;
    try {

      Response<List<FundHoldingData>> response =
          fundClient.api().fundHoldingsLookthru(rootFundId).execute();

      if (response.isSuccess()) {
        positions = mapOfPositions(response.body());

      } else {
        log.error("findRecordedPositions ({}) failed!", rootFundId);
        throw new AppClientException(
            fundClient.adapter().toErrorData(response));
      }
    } catch (IOException ex) {
      log.error("findRecordedPositions ({} )failed!", rootFundId);
      throw new AppClientException(ex);
    }

    return positions;
  }

  /** Gets all the unique fundIds and HoldingIds. */
  @Override
  public List<Integer> flatMapToFundIds(Collection<FundHoldingData> positions) {

    log.info("flatMapToFundIds (...)");

    return positions.stream().flatMap(p -> Stream.of(p.fundId, p.holdingId))
        .distinct().collect(Collectors.toList());
  }

  /** builds a map of fundId to Fund. */
  public static Map<Integer, FundData> mapOfFunds(List<FundData> funds) {

    ImmutableMap.Builder<Integer, FundData> builder = ImmutableMap.builder();
    for (FundData f : funds) {
      builder.put(f.fundId, f);
    }
    return builder.build();
  }

  /** builds a map of fundId to price. */
  public static Map<Integer, BigDecimal> mapOfPrices(
      List<FundPriceData> prices) {

    ImmutableMap.Builder<Integer, BigDecimal> builder = ImmutableMap.builder();
    for (FundPriceData p : prices) {
      builder.put(p.fundId, p.price);
    }
    return builder.build();
  }

  /** builds a map of fundId:holdingId to position. */
  public static Map<String, FundHoldingData> mapOfPositions(
      List<FundHoldingData> positions) {

    ImmutableMap.Builder<String, FundHoldingData> builder =
        ImmutableMap.builder();
    for (FundHoldingData pos : positions) {
      String key = pos.fundId + ":" + pos.holdingId;
      builder.put(key, pos);
    }
    return builder.build();
  }

}
