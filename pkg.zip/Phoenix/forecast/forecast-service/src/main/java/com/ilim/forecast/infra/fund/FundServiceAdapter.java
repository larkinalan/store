package com.ilim.forecast.infra.fund;

import com.ilim.forecast.app.service.IFundService;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;
import com.ilim.fund.web.client.FundClient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Fund Service client adapter.
 * 
 * @author Alan Larkin
 */
@Service
public class FundServiceAdapter implements IFundService {

  private static final Logger log =
      LoggerFactory.getLogger(FundServiceAdapter.class);

  private final FundClient fundClient;

  /**Creates adapter to remote fund service. */
  public FundServiceAdapter() {

    this.fundClient = new FundClient();
  }

  /** Find funds. */
  @Override
  public List<FundData> findFunds(List<Integer> fundIds) {

    log.info("findFunds (...)");

    final List<FundData> funds;
    try {

      funds = fundClient.api().findFunds(fundIds).execute().body();

    } catch (IOException ex) {

      throw new UncheckedIOException("findFunds failed!", ex);
    }

    return funds;
  }

  /** Lookup latest prices for funds. */
  @Override
  public List<FundPriceData> findPrices(List<Integer> fundIds) {

    log.info("findPrices (...)");

    final List<FundPriceData> prices;
    try {

      prices = fundClient.api().findPrices(fundIds).execute().body();

    } catch (IOException ex) {

      throw new UncheckedIOException("findPrices failed!", ex);
    }

    return prices;
  }

  /** Lookup unit positions of a funds holdings. */
  @Override
  public List<FundHoldingData> findUnitPositions(int rootFundId) {

    log.info("findUnitPositions ({})", rootFundId);

    final List<FundHoldingData> positions;
    try {

      positions =
          fundClient.api().fundHoldingsLookthru(rootFundId).execute().body();

    } catch (IOException ex) {

      throw new UncheckedIOException(
          "findPositions failed on fundId " + rootFundId, ex);
    }

    return positions;
  }

  /** Converts positions to fundIds. */
  @Override
  public List<Integer> toFundIds(List<FundHoldingData> positions) {

    log.info("toFundIds (...)");

    final Set<Integer> fundIds = new HashSet<>();

    for (FundHoldingData pos : positions) {
      fundIds.add(pos.fundId);
      fundIds.add(pos.holdingId);
    }

    return new ArrayList<>(fundIds);
  }


}
