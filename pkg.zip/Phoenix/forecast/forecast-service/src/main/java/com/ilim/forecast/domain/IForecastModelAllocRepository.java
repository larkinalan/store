package com.ilim.forecast.domain;

import com.ilim.forecast.domain.model.ForecastModelAlloc;

import java.util.List;

/**
 * Forecast Model Alloc Repository.
 * 
 * <p>persistence api for forecast model alloc dao.
 *
 * @author michael cunnigham
 */
public interface IForecastModelAllocRepository {

  List<ForecastModelAlloc> findAll();

  ForecastModelAlloc findById(int id);

  List<ForecastModelAlloc> findByInstrId(List<Integer> instrIds);

  List<ForecastModelAlloc> findByInstrIdAndFundId(int instrId, int fundId);

  List<Integer> create(List<ForecastModelAlloc> model);

  void delete(List<Integer> ids);

}
