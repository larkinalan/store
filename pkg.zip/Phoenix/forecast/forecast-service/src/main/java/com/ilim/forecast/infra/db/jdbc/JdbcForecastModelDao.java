package com.ilim.forecast.infra.db.jdbc;

import static com.ilim.commons.time.DateUtils.asLocalDate;
import static com.ilim.commons.time.DateUtils.asLocalDateTime;
import static com.ilim.commons.time.DateUtils.asUtilDate;

import com.ilim.commons.db.AppSqlException;
import com.ilim.forecast.domain.IForecastModelRepository;
import com.ilim.forecast.domain.model.ForecastModelAlloc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;

/**
 * Database operations for Forecast Model. 
 *
 * @author Michael Cunningham
 */
@Repository
public class JdbcForecastModelDao extends NamedParameterJdbcDaoSupport
    implements IForecastModelRepository {

  private static final Logger log =
      LoggerFactory.getLogger(JdbcForecastModelDao.class);

  @Inject
  public JdbcForecastModelDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }


  /**
   * Select from FORECAST_MODEL by id.
   * 
   * @param id forecast_model_id, forecast_instruction_id, ilim_id, 
   *            underlying_ilim_id
   * @return ForecastModelAlloc
   * @throws AppSqlException
   * 
   */
  @Override
  public ForecastModelAlloc findById(ForecastModelAlloc.Id id) {

    log.info("findById " + id);

    final String sql = SQL.select_from_forecast_model_by_id;

    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("modelId", id.getModelId())
        .addValue("instrId", id.getInstrId()).addValue("fundId", id.getFundId())
        .addValue("holdingId", id.getHoldingId());

    final ForecastModelAlloc result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toForecastModel(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findById " + id, ex);
    }

    return result;
  }

  /**
   * Select from FORECAST_MODEL by modelId.
   * 
   * @param modelId forecast_model_id  
   * @return List of ForecastModel
   * @throws AppSqlException
   * 
   */
  @Override
  public List<ForecastModelAlloc> findByModelId(int modelId) {

    log.info("findByModelId " + modelId);

    final String sql = SQL.select_from_forecast_model_by_modelid;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("modelId", modelId);

    final List<ForecastModelAlloc> result = new ArrayList<>();
    try {

      result.addAll(
          getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
            return toForecastModel(rs);
          }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByModelId " + modelId, ex);
    }

    return result;
  }

  /**
   * Select * from FORECAST_MODEL.
   * 
   * @return List of ForecastModelAlloc
   * @throws AppSqlException
   * 
   */
  @Override
  public List<ForecastModelAlloc> findAll() {

    log.info("findAll");

    final String sql = SQL.select_from_forecast_model;

    final List<ForecastModelAlloc> result = new ArrayList<>();
    try {

      result.addAll(getNamedParameterJdbcTemplate().query(sql, (rs, rowNum) -> {
        return toForecastModel(rs);
      }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findAll", ex);
    }

    return result;
  }

  /**
   * Inserts into FORECAST_MODEL with batch insert.
   *
   * @param model allocs
   * @return int id of the newly created model
   * @throws AppSqlException
   * 
   */
  @Override
  public int create(List<ForecastModelAlloc> model) {

    log.info("Insert into ForecastModel");

    if (model == null || model.size() == 0) {
      throw new AppSqlException("Error insert ForecastModel",
          new IllegalArgumentException("cannot be null empty!"));
    }

    final String sql = SQL.insert_into_forecast_model;
    SqlParameterSource[] params = new SqlParameterSource[model.size()];

    final int modelId = nextModelId();

    for (int i = 0; i < params.length; i++) {

      ForecastModelAlloc alloc = model.get(i);
      params[i] = new MapSqlParameterSource().addValue("modelId", modelId)
          .addValue("forecastDate", asUtilDate(alloc.getForecastDate()))
          .addValue("instrId", alloc.getId().getInstrId())
          .addValue("fundId", alloc.getId().getFundId())
          .addValue("holdingId", alloc.getId().getHoldingId())
          .addValue("unitsInIssue", alloc.getCommittedUnits())
          .addValue("price", alloc.getPrice()).addValue("mix", alloc.getMix())
          .addValue("cash", alloc.getCash())
          .addValue("recordedCash", alloc.getRecordedCash())
          .addValue("creationTime", asUtilDate(alloc.getCreationTime()));
    }

    try {

      getNamedParameterJdbcTemplate().batchUpdate(sql, params);

    } catch (DataAccessException ex) {

      throw new AppSqlException(
          "Error Insert ForecastModel size=" + model.size(), ex);
    }

    return modelId;
  }

  /**
   * Deletes from FORECAST_MODEL for the given model id.
   * 
   * @param modelId forecast_model_id  
   * @throws AppSqlException
   * 
   */
  @Override
  public void delete(int modelId) {

    log.info("delete ForecastModel " + modelId);

    final String sql = SQL.delete_from_forecast_model_by_modelid;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("modelId", modelId);

    try {

      getNamedParameterJdbcTemplate().update(sql, params);

    } catch (DataAccessException ex) {

      throw new AppSqlException("Error in delete : " + modelId, ex);
    }
  }

  /**
  * Deletes from FORECAST_MODEL for the given id.
  * 
  * @param id forecast_model_id, forecast_instruction_id, ilim_id, 
  *             underlying_ilim_id
  * @throws AppSqlException
  * 
  */
  @Override
  public void deleteById(ForecastModelAlloc.Id id) {

    log.info("deleteById " + id);

    final String sql = SQL.delete_from_forecast_model_by_id;

    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("modelId", id.getModelId())
        .addValue("instrId", id.getInstrId()).addValue("fundId", id.getFundId())
        .addValue("holdingId", id.getHoldingId());

    try {

      getNamedParameterJdbcTemplate().update(sql, params);

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in deleteById " + id, ex);
    }
  }

  /**
   * Updates FORECAST_MODEL.RECORDED_AMT for the given ID.
   * 
   * @param id ForecastModel.Id 
   * @param recordedCash recorded_amt to be saved  
   * @throws AppSqlException
   * 
   */
  @Override
  public void update(ForecastModelAlloc.Id id, BigDecimal recordedCash) {

    log.info("Update ForecastModel " + id + " recordedCash: " + recordedCash);

    final String sql = SQL.update_forecast_model_recorded_amt;

    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("modelId", id.getModelId())
        .addValue("instrId", id.getInstrId()).addValue("fundId", id.getFundId())
        .addValue("holdingId", id.getHoldingId())
        .addValue("recordedCash", recordedCash);

    try {

      getNamedParameterJdbcTemplate().update(sql, params);

    } catch (DataAccessException ex) {

      throw new AppSqlException("Error updating ForecastModel " + id
          + " recordedCash: " + recordedCash, ex);
    }

  }

  /** Returns next sequence id from forecast_model_seq . */
  private int nextModelId() {

    log.info("nextModelId");

    final String sql = SQL.select_from_forecast_model_seq;

    final int result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql,
          new MapSqlParameterSource(), (rs, rowNum) -> {
            return rs.getInt("modelId");
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in nextModelId.", ex);
    }

    return result;
  }

  /** Converts jdbc resultset to entity . */
  private ForecastModelAlloc toForecastModel(ResultSet rs) {

    try {

      int id = rs.getInt("forecast_model_id");
      LocalDate forecastDate = asLocalDate(rs.getDate("forecast_dt"));
      int instrId = rs.getInt("forecast_instruction_id");
      int fundId = rs.getInt("ilim_id");
      int holdingId = rs.getInt("underlying_ilim_id");
      BigDecimal unitsInIssue =
          rs.getBigDecimal("committed_units_in_issue_qty");
      BigDecimal price = rs.getBigDecimal("committed_txn_price");
      BigDecimal mix = rs.getBigDecimal("mix_pct");
      BigDecimal cashAmt = rs.getBigDecimal("cash_amt");
      BigDecimal recordedAmt = rs.getBigDecimal("recorded_amt");
      LocalDateTime creationTime = asLocalDateTime(rs.getDate("creation_ts"));

      return new ForecastModelAlloc(id, forecastDate, instrId, fundId,
          holdingId, unitsInIssue, price, mix, cashAmt, recordedAmt,
          creationTime);

    } catch (SQLException ex) {
      throw new AppSqlException(
          "Error mapping sql result set to ForecastModel!", ex);
    }
  }

}
