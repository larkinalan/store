package com.ilim.forecast.infra.db.jdbc;

import static com.ilim.forecast.infra.db.jdbc.JdbcForecastInstructionDao.toForecastInstruction;
import static com.ilim.forecast.infra.db.jdbc.JdbcForecastModelAllocDao.toForecastModelAlloc;
import static java.util.stream.Collectors.toList;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.domain.model.ForecastStatus;
import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.domain.IForecastModelView;
import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastModel;
import com.ilim.forecast.domain.model.ForecastModelAlloc;
import com.ilim.forecast.infra.db.SQL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.sql.DataSource;

/**
 * Read only database operations for Forecast Instruction and Model Allocs. 
 *
 * @author alan larkin
 */
@Repository
public class JdbcForecastModelDao extends NamedParameterJdbcDaoSupport
    implements IForecastModelView {

  private static final Logger log =
      LoggerFactory.getLogger(JdbcForecastModelDao.class);

  @Inject
  public JdbcForecastModelDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  /**
   * Selects from FORECAST_INSTRUCTION and FORECAST_MODEL_ALLOC by instrId.
   * 
   * @param instrId instruction id
   * @return ForecastModel
   * @throws AppSqlException on db error
   */
  @Override
  public ForecastModel findByInstrId(int instrId) {

    log.info("findByInstrId ({})", instrId);

    final String sql = SQL.select_from_forecast_instr_model_alloc_by_instrid;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("instrId", instrId);

    List<ForecastModel> result = new ArrayList<>();
    try {

      final Set<ForecastInstruction> instrs = new HashSet<>();
      final Set<ForecastModelAlloc> allocs = new HashSet<>();

      getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
        instrs.add(toForecastInstruction(rs));
        allocs.add(toForecastModelAlloc(rs));
        return null;
      });

      result = toModel(instrs, allocs);

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByInstrId!", ex);
    }

    if (result.isEmpty()) {
      throw new AppSqlException("Error in findByInstrId!",
          new IllegalArgumentException("instrId was not found!"));
    }

    return result.get(0);
  }

  /**
   * Selects from FORECAST_INSTRUCTION and FORECAST_MODEL_ALLOC by forecastDate.
   * 
   * @param date forecast date
   * @return List of ForecastModel
   * @throws AppSqlException on db error
   */
  @Override
  public List<ForecastModel> findByForecastDate(LocalDate date) {

    log.info("findByForecastDate ({})", date);

    final String sql =
        SQL.select_from_forecast_instr_model_alloc_by_forecastdate;

    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("date", DateUtils.asUtilDate(date));

    List<ForecastModel> result = new ArrayList<>();
    try {

      final Set<ForecastInstruction> instrs = new HashSet<>();
      final Set<ForecastModelAlloc> allocs = new HashSet<>();

      getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {

        instrs.add(toForecastInstruction(rs));
        allocs.add(toForecastModelAlloc(rs));
        return null;
      });

      result = toModel(instrs, allocs);

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByForecastDate!", ex);
    }

    return result;
  }

  /**
   * Selects from FORECAST_INSTRUCTION and FORECAST_MODEL_ALLOC by forecastDate
   * and ilim id.
   * 
   * @param date forecast date
   * @return List of ForecastModel
   * @throws AppSqlException on db error
   */
  @Override
  public List<ForecastModel> findByForecastDateAndFundId(LocalDate date,
      int fundId) {

    log.info("findByForecastDateAndFundId ({},{})", date, fundId);

    final String sql =
        SQL.select_from_forecast_instr_model_alloc_by_forecastdate_and_fundid;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("date", DateUtils.asUtilDate(date))
            .addValue("fundId", fundId);

    List<ForecastModel> result = new ArrayList<>();
    try {

      final Set<ForecastInstruction> instrs = new HashSet<>();
      final Set<ForecastModelAlloc> allocs = new HashSet<>();

      getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {

        instrs.add(toForecastInstruction(rs));
        allocs.add(toForecastModelAlloc(rs));
        return null;
      });

      result = toModel(instrs, allocs);

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByForecastDateAndFundId!", ex);
    }

    return result;
  }

  /**
   * Selects from FORECAST_INSTRUCTION and FORECAST_MODEL_ALLOC by status.
   * 
   * @param status forecast status
   * @return List of ForecastModel
   * @throws AppSqlException on db error
   */
  @Override
  public List<ForecastModel> findByStatus(ForecastStatus status) {

    log.info("findByStatus ({})", status);

    final String sql = SQL.select_from_forecast_instr_model_alloc_by_statusid;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("statusId", status.id());

    List<ForecastModel> result = new ArrayList<>();
    try {

      final Set<ForecastInstruction> instrs = new HashSet<>();
      final Set<ForecastModelAlloc> allocs = new HashSet<>();

      getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {

        instrs.add(toForecastInstruction(rs));
        allocs.add(toForecastModelAlloc(rs));
        return null;
      });

      result = toModel(instrs, allocs);

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByStatus!", ex);
    }

    return result;
  }

  private List<ForecastModel> toModel(Set<ForecastInstruction> instrs,
      Set<ForecastModelAlloc> allocs) {

    final List<ForecastModel> model = new ArrayList<>();

    for (ForecastInstruction instr : instrs) {

      // filter by instrId
      List<ForecastModelAlloc> allocsByInstr = allocs.stream()
          .filter(a -> a.getInstrId() == instr.getId()).collect(toList());
      model.add(new ForecastModel(instr, allocsByInstr));
    }

    return model;
  }

}
