package com.ilim.forecast.domain;

import com.ilim.forecast.domain.model.ForecastInstruction;
import com.ilim.forecast.domain.model.ForecastStatus;

import java.time.LocalDate;
import java.util.List;

/**
 * Forecast Instruction Repository.
 * 
 * <p>persistence api for forecast instructions.
 *
 * @author michael cunnigham
 */
public interface IForecastInstructionRepository {

  List<ForecastInstruction> findAll();

  ForecastInstruction findById(int id);

  List<ForecastInstruction> findByStatus(ForecastStatus status);

  List<ForecastInstruction> findForPeriod(LocalDate from, LocalDate to);

  List<ForecastInstruction> findByStatusForPeriod(ForecastStatus status,
      LocalDate from, LocalDate to);

  int create(ForecastInstruction instr);

  void updateStatus(int id, ForecastStatus status);

}

