package com.ilim.forecast.web.api;

import retrofit.Call;
import retrofit.http.Body;
import retrofit.http.POST;

/**
 * Forecast API providing access to client calls to Forecast Service.
 * 
 * @author Michael Cunningham
 *
 */
public interface ForecastApi {

  /**
   * Create a Forecast Instruction via a client call to the Forecast Service.
   * 
   * @param instr       forecast instruction to be created
   */
  @POST("instructions")
  Call<Void> create(@Body NewForecastInstructionData instr);

}
