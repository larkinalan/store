package com.ilim.forecast.web.api;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

import java.time.LocalDate;
import java.util.List;

/**
 * Forecast API providing access to client calls to Forecast Service.
 * 
 * @author Michael Cunningham
 *
 */
public interface ForecastApi {

  /************************* Forecast Instruction API. ********************/

  /**
   * Find all Forecast Instructions by instrId.
   * 
   * @param instrId instrId to search on
   * @return {@code List<ForecastInstructionData>}
   */
  @GET("instructions/{instrId}")
  public Call<ForecastInstructionData> findInstrById(
      @Path("instrId") int instrId);

  /**
   * Find all Forecast Instructions.
   * 
   * @return {@code List<ForecastInstructionData>}
   */
  @GET("instructions")
  public Call<List<ForecastInstructionData>> findAllInstructions();

  /**
   * Find all Forecast Instructions by status.
   * 
   * @param status status to search on
   * @return {@code List<ForecastInstructionData>}
   */
  @GET("instructions")
  public Call<List<ForecastInstructionData>> findInstrsByStatus(
      @Query("status") String status);

  /**
   * Find all Forecast Instructions by status for a forecast date range.
   * 
   * @param status status to search on
   * @param from start date for search
   * @param to end date for date range
   * @return {@code List<ForecastInstructionData>}
   */
  @GET("instructions")
  public Call<List<ForecastInstructionData>> findInstrsByStatusForPeriod(
      @Query("status") String status, @Query("from") String from,
      @Query("to") String to);

  /**
   * Create a Forecast Instruction via a client call to the Forecast Service.
   * 
   * @param instr       forecast instruction to be created
   */
  @POST("instructions")
  public Call<Void> create(@Body NewForecastInstructionData instr);


  /**
   * Updates the states of a Forecast Instruction.
   * 
   * @param instrId   instruction id
   * @param status    forecast status
   */
  @PUT("instructions/{instrId}")
  public Call<Void> updateStatus(@Path("instrId") int instrId,
      @Body String status);


  /***************** Forecast Model API. *****************************/

  /**
   * Find all Forecast Model Alloc by forecast date.
   * 
   * @param forecastDate forecast date to search on
   * @return {@code List<ForecastModelData>}
   */
  @GET("models")
  public Call<List<ForecastModelData>> findModelByForecastDate(
      @Query("forecastDate") LocalDate forecastDate);

  /**
   * Find all Forecast Model Alloc by fundId for a given forecast date.
   * 
   * @param forecastDate forecast date to search on
   * @param fundId fund id to search on
   * @return {@code List<ForecastModelData>}
   */
  @GET("models")
  public Call<List<ForecastModelData>> findModelByForecastDateAndFundId(
      @Query("forecastDate") LocalDate forecastDate,
      @Query("fundId") int fundId);

  /**
   * Find all Forecast Model Alloc by status.
   * 
   * @param status forecast status 
   * @return {@code List<ForecastModelData>}
   */
  @GET("models")
  public Call<List<ForecastModelData>> findModelByStatus(
      @Query("status") String status);

}
