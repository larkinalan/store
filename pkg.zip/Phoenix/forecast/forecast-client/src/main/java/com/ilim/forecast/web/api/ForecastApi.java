package com.ilim.forecast.web.api;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

import java.util.List;

/**
 * Forecast API providing access to client calls to Forecast Service.
 * 
 * @author Michael Cunningham
 *
 */
public interface ForecastApi {

  /** Forecast Instruction API. */

  /**
   * Create a Forecast Instruction via a client call to the Forecast Service.
   * 
   * @param instr       forecast instruction to be created
   */
  @POST("instructions")
  public Call<Void> create(@Body NewForecastInstructionData instr);

  /**
   * Find all Forecast Instructions by instrId.
   * 
   * @param instrId instrId to search on
   * @return {@code List<ForecastInstructionData>}
   */
  @GET("instructions/{instrId}")
  public Call<ForecastInstructionData> findInstrById(
      @Path("instrId") int instrId);

  /**
   * Find all Forecast Instructions by status.
   * 
   * @param status status to search on
   * @return {@code List<ForecastInstructionData>}
   */
  @GET("instructions")
  public Call<List<ForecastInstructionData>> findInstrsByStatus(
      @Query("status") String status);

  /**
   * Find all Forecast Instructions by status for a forecast date range.
   * 
   * @param status status to search on
   * @param from start date for search
   * @param to end date for date range
   * @return {@code List<ForecastInstructionData>}
   */
  @GET("instructions")
  public Call<List<ForecastInstructionData>> findInstrsByStatusForPeriod(
      @Query("status") String status, @Query("from") String from,
      @Query("to") String to);

  /**
   * Find all Forecast Instructions.
   * 
   * @return {@code List<ForecastInstructionData>}
   */
  @GET("instructions")
  public Call<List<ForecastInstructionData>> findAllInstructions();


  /** Forecast Model API. */

  /**
   * Find all Forecast Model Alloc by modelId.
   * 
   * @param modelId model id to search on
   * @return {@code List<ForecastModelAllocData>}
   */
  @GET("models/{modelId}")
  public Call<List<ForecastModelAllocData>> findModelByModelId(
      @Path("modelId") int modelId);

  /**
   * Find all Forecast Model Alloc by forecast date.
   * 
   * @param forecastDate forecast date to search on
   * @return {@code List<ForecastModelAllocData>}
   */
  @GET("models")
  public Call<List<ForecastModelAllocData>> findModelByForecastDate(
      @Query("forecastDate") String forecastDate);

  /**
   * Find all Forecast Model Alloc by fundId for a given forecast date.
   * 
   * @param fundId fund id to search on
   * @param forecastDate forecast date to search on
   * @return {@code List<ForecastModelAllocData>}
   */
  @GET("models")
  public Call<List<ForecastModelAllocData>> findModelByFundIdAndForecastDate(
      @Query("fundId") int fundId, @Query("forecastDate") String forecastDate);
  
  /**
   * Find all unrecorded ForecastModelAllocDatas for the given fundId and 
   * forecastDate.
   * 
   * @param fundId fund id to search on
   * @param forecastDate forecast date to search on
   * @return {@code List<ForecastModelAllocData>}
   */
  @GET("models")
  public Call<List<ForecastModelAllocData>> findUnrecordedModelsByFundIdAndDate(
      @Query("fundId") int fundId, @Query("forecastDate") String forecastDate);

  /**
   * Find all Forecast Model Alloc.
   * 
   * @return {@code List<ForecastModelAllocData>}
   */
  @GET("models")
  public Call<List<ForecastModelAllocData>> findAllModels();

}
