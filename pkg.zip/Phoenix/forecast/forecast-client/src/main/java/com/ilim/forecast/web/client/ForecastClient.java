package com.ilim.forecast.web.client;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkState;
import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.domain.model.ForecastStatus;
import com.ilim.commons.time.DateUtils;
import com.ilim.commons.web.client.AppClientException;
import com.ilim.commons.web.client.RetrofitClient;
import com.ilim.forecast.web.api.ForecastApi;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.ForecastModelData;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import com.google.common.base.Strings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit2.JacksonConverterFactory;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;


/**
 * ForecastClient SDK for jax-rs forecast-service. 
 * 
 * @author alan larkin
 */
public final class ForecastClient {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastClient.class);

  private final RetrofitClient retrofitClient;
  private final ForecastApi forecastApi;


  /** Default constructor (uses conf file). */
  public ForecastClient() {

    this(settings().getString("forecast.service.baseurl"));
  }

  /** Configures client using ForecastApi. */
  public ForecastClient(String baseUrl) {

    // Create retrofit http client with jackson converter
    retrofitClient = RetrofitClient.newBuilder(baseUrl).witLogger(log)
        .withConverter(JacksonConverterFactory.create()).build();

    // Generate forecastApi api
    this.forecastApi = retrofitClient.adapter().create(ForecastApi.class);
  }

  /**
   * Find forecast instruction by id.
   * 
   * @param id instruction id
   * @return {@code ForecastInstructionData} instruction
   * @throws AppClientException client error
   */
  public ForecastInstructionData findInstrById(int id) {

    log.info("findInstrById ({})", id);

    final ForecastInstructionData instr;
    try {

      Response<ForecastInstructionData> response =
          forecastApi.findInstrById(id).execute();

      if (response.isSuccess()) {
        instr = response.body();

      } else {
        log.error("findInstrById failed!");
        throw new AppClientException(retrofitClient.toErrorData(response));
      }
    } catch (IOException ex) {
      log.error("findInstrById failed!");
      throw new AppClientException(ex);
    }

    return instr;
  }

  /**
   * Find forecast instructions by status.
   * 
   * @param status forecast status name
   * @return {@code List<ForecastInstructionData>} instructions
   * @throws AppClientException client error
   */
  public List<ForecastInstructionData> findInstrsByStatus(
      ForecastStatus status) {

    log.info("findInstrByStatus ({})", status);

    final List<ForecastInstructionData> instrs;
    try {

      Response<List<ForecastInstructionData>> response =
          forecastApi.findInstrsByStatus(status.name()).execute();

      if (response.isSuccess()) {
        instrs = response.body();

      } else {
        log.error("findInstrByStatus failed!");
        throw new AppClientException(retrofitClient.toErrorData(response));
      }
    } catch (IOException ex) {
      log.error("findInstrByStatus failed!");
      throw new AppClientException(ex);
    }

    return instrs;
  }

  /**
   * Find forecast instructions by status for period.
   * 
   * @param status forecast status
   * @param fromDate period
   * @param toDate period
   * @return {@code List<ForecastInstructionData>} instructions
   * @throws AppClientException client error
   */
  public List<ForecastInstructionData> findInstrByStatusForPeriod(
      ForecastStatus status, LocalDate fromDate, LocalDate toDate) {

    log.info("findInstrByStatusForPeriod ({},{},{}) ", status, fromDate,
        toDate);

    final List<ForecastInstructionData> instrs;
    try {

      String from = fromDate.format(DateUtils.DATE_FMT);
      String to = toDate.format(DateUtils.DATE_FMT);
      Response<List<ForecastInstructionData>> response = forecastApi
          .findInstrsByStatusForPeriod(status.name(), from, to).execute();

      if (response.isSuccess()) {
        instrs = response.body();

      } else {
        log.error("findInstrByStatusForPeriod failed!");
        throw new AppClientException(retrofitClient.toErrorData(response));
      }
    } catch (IOException ex) {
      log.error("findInstrByStatusForPeriod failed!");
      throw new AppClientException(ex);
    }

    return instrs;
  }

  /** 
   * Creates a new forecast instruction.
   *
   * @param instr new forecast instruction
   * @return instrId on success
   * @throws AppClientException client error
   */
  public int create(NewForecastInstructionData instr) {

    log.info("create ({})", instr);

    int instrId = 0;
    try {

      Response<Void> response = forecastApi.create(instr).execute();

      if (response.isSuccess()) {
        instrId = parseId(response.headers().get("Location"));

      } else {
        log.error("create failed!");
        throw new AppClientException(retrofitClient.toErrorData(response));
      }
    } catch (IOException ex) {
      log.error("create failed!");
      throw new AppClientException(ex);
    }

    return instrId;
  }

  /** 
   * Creates a new forecast instruction.
   *
   * @param instrId instruction id
   * @param status forecast status name
   * @throws AppClientException client error
   */
  public void updateStatus(int instrId, ForecastStatus status) {

    log.info("updateStatus ({}, {})", instrId, status);

    try {

      Response<Void> response =
          forecastApi.updateStatus(instrId, status.name()).execute();

      if (response.isSuccess()) {
        log.info("update status success!");

      } else {
        log.error("create failed!");
        throw new AppClientException(retrofitClient.toErrorData(response));
      }
    } catch (IOException ex) {
      log.error("create failed!");
      throw new AppClientException(ex);
    }
  }

  /**
   * Find forecast model for a given forecast date.
   * 
   * @param forecastDate date
   * @return {@code List<ForecastModelData>} model
   * @throws AppClientException client error
   */
  public List<ForecastModelData> findModelByForecastDate(
      LocalDate forecastDate) {

    log.info("findModelByForecastDate ({}) ", forecastDate);

    final List<ForecastModelData> model;
    try {

      Response<List<ForecastModelData>> response =
          forecastApi.findModelByForecastDate(forecastDate).execute();

      if (response.isSuccess()) {
        model = response.body();

      } else {
        log.error("findModelByForecastDate failed!");
        throw new AppClientException(retrofitClient.toErrorData(response));
      }
    } catch (IOException ex) {
      log.error("findModelByForecastDate failed!");
      throw new AppClientException(ex);
    }

    return model;
  }

  /**
   * Find model allocs by forecastDate and fundId.
   *  
   * @param forecastDate date
   * @param fundId ilimId
   * @return {@code List<ForecastModelData>} model
   * @throws AppClientException client error
   */
  public List<ForecastModelData> findModelByForecastDateAndFundId(
      LocalDate forecastDate, int fundId) {

    log.info("findModelByForecastDateAndFundId ({},{})", forecastDate, fundId);

    final List<ForecastModelData> model;
    try {

      Response<List<ForecastModelData>> response = forecastApi
          .findModelByForecastDateAndFundId(forecastDate, fundId).execute();

      if (response.isSuccess()) {
        model = response.body();

      } else {
        log.error("findModelByForecastDateAndFundId failed!");
        throw new AppClientException(retrofitClient.toErrorData(response));
      }
    } catch (IOException ex) {
      log.error("findModelByForecastDateAndFundId failed!");
      throw new AppClientException(ex);
    }

    return model;
  }

  /**
   * Find forecast model for a given forecast status.
   * 
   * @param status forecast status
   * @return {@code List<ForecastModelData>} model
   * @throws AppClientException client error
   */
  public List<ForecastModelData> findModelByStatus(ForecastStatus status) {

    log.info("findModelByStatus ({}) ", status);

    final List<ForecastModelData> model;
    try {

      Response<List<ForecastModelData>> response =
          forecastApi.findModelByStatus(status.name()).execute();

      if (response.isSuccess()) {
        model = response.body();

      } else {
        log.error("findModelByStatus failed!");
        throw new AppClientException(retrofitClient.toErrorData(response));
      }
    } catch (IOException ex) {
      log.error("findModelByStatus failed!");
      throw new AppClientException(ex);
    }

    return model;
  }

  /** Extracts id from end of url. */
  private static int parseId(String url) {

    checkArgument(!Strings.isNullOrEmpty(url), "Invalid URL!");

    // Parse out id from end of url.
    // (e.g) gets 189 from http://localhost:9988/forecast/instructions/189
    String id = url.substring(url.lastIndexOf("/") + 1, url.length());
    checkState(!Strings.isNullOrEmpty(id), "Missing ID from end of " + url);

    try {
      return Integer.parseInt(id.trim());

    } catch (NumberFormatException ex) {
      throw new AppClientException("Failed to parse instr id from header!\n"
          + "WARN: request may have completed on the serverside.", ex);
    }
  }

}
