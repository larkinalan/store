package com.ilim.forecast.web.client;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.time.DateUtils;
import com.ilim.commons.web.client.AppClientException;
import com.ilim.commons.web.client.RetrofitClient;
import com.ilim.forecast.web.api.ForecastApi;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit2.JacksonConverterFactory;
import retrofit2.Response;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

/**
 * ForecastClient SDK for jax-rs forecast-service. 
 * 
 * @author alan larkin
 */
public class ForecastClient {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastClient.class);

  private final RetrofitClient retrofitClient;
  private final ForecastApi forecastApi;

  /** Default constructor (uses conf file). */
  public ForecastClient() {

    this(settings().getString("forecast.service.baseurl"));
  }

  /** Configures client using ForecastApi. */
  public ForecastClient(String baseUrl) {

    // Create retrofit http client with jackson converter
    retrofitClient = RetrofitClient.newBuilder(baseUrl).witLogger(log)
        .withConverter(JacksonConverterFactory.create()).build();

    // Generate forecastApi api
    this.forecastApi = retrofitClient.adapter().create(ForecastApi.class);
  }

  /** 
   * Creates a new forecast instruction.
   *
   * @param instr new forecast instruction
   * @return true on success
   * @throws AppClientException client error
   */
  public boolean create(NewForecastInstructionData instr) {

    log.info("create ({})", instr);

    try {

      Response<Void> response = forecastApi.create(instr).execute();

      if (response.isSuccess()) {
        // FIXME: new instr URL and ID is in the response header
        // shouldn't we be returning this ?
        System.out.println(response.headers());

      } else {
        log.error("create ({}) failed!", instr);
        throw new AppClientException(response, retrofitClient.adapter());
      }
    } catch (IOException ex) {
      log.error("create ({}) failed!", instr);
      throw new AppClientException(ex);
    }

    return true;
  }

  /**
   * Find forecast instruction by id.
   * 
   * @param id instruction id
   * @return {@code ForecastInstructionData} instruction
   * @throws AppClientException client error
   */
  public ForecastInstructionData findInstrById(int id) {

    log.info("findInstrById ({})", id);

    final ForecastInstructionData instr;
    try {

      Response<ForecastInstructionData> response =
          forecastApi.findInstrById(id).execute();

      if (response.isSuccess()) {
        instr = response.body();

      } else {
        log.error("findInstrById ({}) failed!", id);
        throw new AppClientException(response, retrofitClient.adapter());
      }
    } catch (IOException ex) {
      log.error("findInstrById ({}) failed!", id);
      throw new AppClientException(ex);
    }

    return instr;
  }

  /**
   * Find forecast instructions by status.
   * 
   * @param status forecast status name
   * @return {@code List<ForecastInstructionData>} instructions
   * @throws AppClientException client error
   */
  public List<ForecastInstructionData> findInstrsByStatus(String status) {

    log.info("findInstrByStatus ({})", status);

    final List<ForecastInstructionData> instrs;
    try {

      Response<List<ForecastInstructionData>> response =
          forecastApi.findInstrsByStatus(status).execute();

      if (response.isSuccess()) {
        instrs = response.body();

      } else {
        log.error("findInstrByStatus ({}) failed!", status);
        throw new AppClientException(response, retrofitClient.adapter());
      }
    } catch (IOException ex) {
      log.error("findInstrByStatus ({}) failed!", status);
      throw new AppClientException(ex);
    }

    return instrs;
  }

  /**
   * Find forecast instructions by status for period.
   * 
   * @param status forecast status
   * @param from period
   * @param to period
   * @return {@code List<ForecastInstructionData>} instructions
   * @throws AppClientException client error
   */
  public List<ForecastInstructionData> findInstrByStatusForPeriod(String status,
      LocalDate from, LocalDate to) {

    log.info("findInstrByStatusForPeriod ({},{},{}) ", status, from, to);

    final List<ForecastInstructionData> instrs;
    try {

      Response<List<ForecastInstructionData>> response = forecastApi
          .findInstrsByStatusForPeriod(status, from.format(DateUtils.DATE_FMT),
              to.format(DateUtils.DATE_FMT))
          .execute();

      if (response.isSuccess()) {
        instrs = response.body();

      } else {
        log.error("findInstrByStatusForPeriod ({},{},{}) failed!", status, from,
            to);
        throw new AppClientException(response, retrofitClient.adapter());
      }
    } catch (IOException ex) {
      log.error("findInstrByStatusForPeriod ({},{},{}) failed!", status, from,
          to);
      throw new AppClientException(ex);
    }

    return instrs;
  }

  /**
   * Find model allocations by modelId.
   * 
   * @param modelId model id
   * @return {@code List<ForecastModelAllocData>} model allocations
   * @throws AppClientException client error
   */
  public List<ForecastModelAllocData> findModelByModelId(int modelId) {

    log.info("findModelByModelId ({}) ", modelId);

    final List<ForecastModelAllocData> modelAllocs;
    try {

      Response<List<ForecastModelAllocData>> response =
          forecastApi.findModelByModelId(modelId).execute();

      if (response.isSuccess()) {
        modelAllocs = response.body();

      } else {
        log.error("findModelByModelId ({}) failed! ", modelId);
        throw new AppClientException(response, retrofitClient.adapter());
      }
    } catch (IOException ex) {
      log.error("findModelByModelId ({}) failed!", modelId);
      throw new AppClientException(ex);
    }

    return modelAllocs;
  }

  /**
   * Find model allocations by forecastDate.
   *                        
   * @param forecastDate forecast date
   * @return {@code List<ForecastModelAllocData>} model allocations
   * @throws AppClientException client error
   */
  public List<ForecastModelAllocData> findModelByForecastDate(
      LocalDate forecastDate) {

    log.info("findByForecastDate ({}) ", forecastDate);

    final List<ForecastModelAllocData> modelAllocs;
    try {

      String date = forecastDate.format(DateUtils.DATE_FMT);
      Response<List<ForecastModelAllocData>> response =
          forecastApi.findModelByForecastDate(date).execute();

      if (response.isSuccess()) {
        modelAllocs = response.body();

      } else {
        log.error("findByForecastDate ({}) failed! ", forecastDate);
        throw new AppClientException(response, retrofitClient.adapter());
      }
    } catch (IOException ex) {
      log.error("findByForecastDate ({}) failed!", forecastDate);
      throw new AppClientException(ex);
    }

    return modelAllocs;
  }

  /**
   * Find model allocs by fundId and forecastDate.
   *  
   * @param fundId ilimId
   * @param forecastDate date
   * @return {@code List<ForecastModelAllocData>} model allocations
   * @throws AppClientException client error
   */
  public List<ForecastModelAllocData> findModelByFundIdAndForecastDate(
      int fundId, LocalDate forecastDate) {

    log.info("findModelByFundIdAndForecastDate ({},{})", fundId, forecastDate);

    final List<ForecastModelAllocData> modelAllocs;
    try {

      String date = forecastDate.format(DateUtils.DATE_FMT);
      Response<List<ForecastModelAllocData>> response =
          forecastApi.findModelByFundIdAndForecastDate(fundId, date).execute();

      if (response.isSuccess()) {
        modelAllocs = response.body();

      } else {
        log.error("findModelByFundIdAndForecastDate ({},{}) failed!", fundId,
            forecastDate);
        throw new AppClientException(response, retrofitClient.adapter());
      }
    } catch (IOException ex) {
      log.error("findModelByFundIdAndForecastDate ({},{}) failed!", fundId,
          forecastDate);
      throw new AppClientException(ex);
    }

    return modelAllocs;
  }

  /**
   * Find all moel allocations.
   *  
   * @return {@code List<ForecastModelAllocData>} model allocations
   * @throws AppClientException client error
   */
  public List<ForecastModelAllocData> findAllModels() {

    log.info("findAllModels ()");

    final List<ForecastModelAllocData> models;
    try {

      Response<List<ForecastModelAllocData>> response =
          forecastApi.findAllModels().execute();

      if (response.isSuccess()) {
        models = response.body();

      } else {
        log.error("findAllModels () failed!");
        throw new AppClientException(response, retrofitClient.adapter());
      }
    } catch (IOException ex) {
      log.error("findAllModels () failed!");
      throw new AppClientException(ex);
    }

    return models;
  }

}
