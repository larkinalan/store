package com.ilim.forecast.web.client;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.forecast.web.api.ForecastApi;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.logging.HttpLoggingInterceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit.JacksonConverterFactory;
import retrofit.Retrofit;

import java.io.IOException;

public class ForecastClient {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastClient.class);

  private final Retrofit retrofitAdapter;
  private final ForecastApi forecastApi;

  /** Default constructor (uses conf file). */
  public ForecastClient() {

    this(settings().getString("forecast.service.baseurl"));
  }

  /** Configures client using ForecastApi. */
  public ForecastClient(String baseUrl) {

    log.debug("Creating ForecastServiceApi for " + baseUrl);

    // create http client with logging
    OkHttpClient client = new OkHttpClient();
    HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
    interceptor.setLevel(HttpLoggingInterceptor.Level.BASIC);
    client.interceptors().add(interceptor);

    // Create retrofit with json converter
    this.retrofitAdapter =
        new Retrofit.Builder().baseUrl(baseUrl).client(client)
            .addConverterFactory(JacksonConverterFactory.create()).build();

    // Generate forecastApi api
    this.forecastApi = retrofitAdapter.create(ForecastApi.class);
  }

  /** Creates forecast instruction via a client call to the forecaster.
  *
  * @param instrData        forecast instruction data
  * @return true on success
  */
  public boolean create(NewForecastInstructionData instrData) {

    log.info("create " + instrData);

    boolean isSuccess = false;
    try {

      isSuccess = forecastApi.create(instrData).execute().isSuccess();

    } catch (IOException ex) {
      log.error("create communication error! " + ex.getMessage());
    }
    return isSuccess;
  }

}
