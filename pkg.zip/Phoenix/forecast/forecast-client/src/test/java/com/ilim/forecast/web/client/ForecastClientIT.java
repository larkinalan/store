package com.ilim.forecast.web.client;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;

import com.ilim.commons.web.client.AppClientException;
import com.ilim.forecast.TestData;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import org.junit.Test;

public class ForecastClientIT {

  private static final ForecastClient client = new ForecastClient();

  @Test
  public void createForecastInstr() throws Exception {

    NewForecastInstructionData instr =
        TestData.toNewForecastInstructionData(TestData.Instructions.BPL);

    int result = client.create(instr);

    assertThat(result).isGreaterThan(0);
  }

  @Test(expected = AppClientException.class)
  public void failTocreateForecastInstr() throws Exception {

    NewForecastInstructionData instr =
        new NewForecastInstructionData("06/15/2015",
            TestData.Instructions.BPL.forecastType,
            TestData.Instructions.BPL.fundId,
            TestData.Instructions.BPL.moneyType,
            TestData.Instructions.BPL.amount,
            TestData.Instructions.BPL.eventSourceId);

    client.create(instr);

    fail("Test should have thrown an error!");
  }

}
