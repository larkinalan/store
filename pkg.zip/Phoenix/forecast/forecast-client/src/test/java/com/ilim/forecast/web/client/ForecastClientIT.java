package com.ilim.forecast.web.client;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.time.DateUtils;
import com.ilim.commons.web.client.AppClientException;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import org.junit.Assert;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicLong;

public class ForecastClientIT {

  private static final AtomicLong eventId = new AtomicLong(999L);
  private static final ForecastClient client = new ForecastClient();

  @Test
  public void createForecastInstrSuccess() throws Exception {

    NewForecastInstructionData instr = newInstr(LocalDate.now());

    int result = client.create(instr);

    assertThat(result).isGreaterThan(0);
  }

  @Test(expected = AppClientException.class)
  public void createForecastInstrFail() throws Exception {

    NewForecastInstructionData instr = newInstr("06/15/2015");

    client.create(instr);

    Assert.fail("Test should have thrown an error!");
  }

  private static NewForecastInstructionData newInstr(LocalDate forecastDate) {

    return newInstr(forecastDate.format(DateUtils.DATE_FMT));
  }

  private static NewForecastInstructionData newInstr(String forecastDate) {

    return new NewForecastInstructionData(forecastDate, "NEW_MONEY", 17444,
        "CASH", new BigDecimal("2000.01"), eventId.getAndIncrement());
  }


}
