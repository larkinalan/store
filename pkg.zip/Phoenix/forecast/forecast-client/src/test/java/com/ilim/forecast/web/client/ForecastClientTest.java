package com.ilim.forecast.web.client;

import static com.ilim.commons.time.DateUtils.DATE_FMT;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.forecast.web.api.NewForecastInstructionData;

import com.squareup.okhttp.HttpUrl;
import com.squareup.okhttp.mockwebserver.MockResponse;
import com.squareup.okhttp.mockwebserver.MockWebServer;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicLong;

public class ForecastClientTest {

  private MockWebServer server;
  private ForecastClient client;
  private HttpUrl baseUrl;

  public static final AtomicLong eventId = new AtomicLong(999L);

  /** Create client against mock web server. */
  @Before
  public void setUp() throws Exception {

    server = new MockWebServer();
    server.start();
    baseUrl = server.url("/mock/");
    client = new ForecastClient(baseUrl.toString());
  }

  @After
  public void tearDown() throws Exception {

    server.shutdown();
  }

  @Test
  public void createForecastInstrSuccess() throws Exception {

    server.enqueue(new MockResponse().setResponseCode(201));

    NewForecastInstructionData instr = newInstr(LocalDate.now());
    boolean result = client.create(instr);

    assertThat(result).isTrue();
  }

  @Test
  public void createForecastInstrFail() throws Exception {

    server.enqueue(new MockResponse().setResponseCode(400));

    NewForecastInstructionData instr = newInstr(LocalDate.now());
    boolean result = client.create(instr);

    assertThat(result).isFalse();
  }

  private static NewForecastInstructionData newInstr(LocalDate forecastDate) {

    String forecastDt = forecastDate.format(DATE_FMT);
    return new NewForecastInstructionData(forecastDt, "NEW_MONEY", 17444,
        "CASH", new BigDecimal("2000.01"), eventId.getAndIncrement());
  }
}
