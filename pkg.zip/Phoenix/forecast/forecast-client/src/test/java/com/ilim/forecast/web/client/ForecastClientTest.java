package com.ilim.forecast.web.client;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.time.DateUtils;
import com.ilim.commons.web.client.AppClientException;
import com.ilim.forecast.TestData;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import okhttp3.HttpUrl;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.util.List;

public class ForecastClientTest {

  private MockWebServer server;
  private ForecastClient client;
  private HttpUrl baseUrl;

  /** Create client against mock web server. */
  @Before
  public void setUp() throws Exception {

    server = new MockWebServer();
    server.start();
    baseUrl = server.url("/mock/");
    client = new ForecastClient(baseUrl.toString());
  }

  @After
  public void tearDown() throws Exception {

    server.shutdown();
  }

  @Test
  public void createForecastInstrSuccess() throws Exception {

    server.enqueue(new MockResponse().setResponseCode(201));

    NewForecastInstructionData instr = TestData.newInstr(LocalDate.now());
    boolean result = client.create(instr);

    assertThat(result).isTrue();
  }

  @Test(expected = AppClientException.class)
  public void createForecastInstrFail() throws Exception {

    server.enqueue(new MockResponse().setResponseCode(400));

    NewForecastInstructionData instr = TestData.newInstr(LocalDate.now());
    client.create(instr);
    Assert.fail("Should have thrown error!");
  }

  @Test
  public void findInstrById() throws Exception {

    ForecastInstructionData expected = TestData.mockForecastInstructionData();
    server.enqueue(TestData.mockJsonResponse(expected));

    ForecastInstructionData actual = client.findInstrById(expected.id);
    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findInstrsByStatus() throws Exception {

    List<ForecastInstructionData> expected =
        TestData.mockForecastInstructionDataList(2);
    server.enqueue(TestData.mockJsonResponse(expected));

    List<ForecastInstructionData> actual =
        client.findInstrsByStatus(expected.get(0).status);
    assertThat(actual).isNotEmpty();
    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findInstrByStatusForPeriod() throws Exception {

    List<ForecastInstructionData> expected =
        TestData.mockForecastInstructionDataList(2);
    server.enqueue(TestData.mockJsonResponse(expected));

    String status = expected.get(0).status;
    LocalDate from =
        LocalDate.parse(expected.get(0).forecastDate, DateUtils.DATE_FMT);
    LocalDate to =
        LocalDate.parse(expected.get(0).forecastDate, DateUtils.DATE_FMT);

    List<ForecastInstructionData> actual =
        client.findInstrByStatusForPeriod(status, from, to);
    assertThat(actual).isNotEmpty();
    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findModelByModelId() throws Exception {

    List<ForecastModelAllocData> expected = TestData.mockModelAllocData();
    server.enqueue(TestData.mockJsonResponse(expected));

    int modelId = expected.get(0).id.modelId;
    List<ForecastModelAllocData> actual = client.findModelByModelId(modelId);
    assertThat(actual).containsOnlyElementsOf(expected);
  }

  @Test
  public void findModelByForecastDate() throws Exception {

    List<ForecastModelAllocData> expected = TestData.mockModelAllocData();
    server.enqueue(TestData.mockJsonResponse(expected));

    LocalDate date =
        LocalDate.parse(expected.get(0).forecastDate, DateUtils.DATE_FMT);
    List<ForecastModelAllocData> actual = client.findModelByForecastDate(date);
    assertThat(actual).containsOnlyElementsOf(expected);
  }

  @Test
  public void findModelByFundIdForForecastDate() throws Exception {

    List<ForecastModelAllocData> expected = TestData.mockModelAllocData();
    server.enqueue(TestData.mockJsonResponse(expected));

    int fundId = expected.get(0).id.fundId;
    LocalDate date =
        LocalDate.parse(expected.get(0).forecastDate, DateUtils.DATE_FMT);
    List<ForecastModelAllocData> actual =
        client.findModelByFundIdAndForecastDate(fundId, date);
    assertThat(actual).containsOnlyElementsOf(expected);
  }

  @Test
  public void findAllModels() throws Exception {

    List<ForecastModelAllocData> expected = TestData.mockModelAllocData();
    server.enqueue(TestData.mockJsonResponse(expected));

    List<ForecastModelAllocData> actual = client.findAllModels();
    assertThat(actual).containsOnlyElementsOf(expected);
  }

}
