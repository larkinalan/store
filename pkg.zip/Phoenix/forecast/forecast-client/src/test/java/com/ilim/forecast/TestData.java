package com.ilim.forecast;

import static com.ilim.commons.time.DateUtils.DATE_FMT;

import com.ilim.commons.domain.model.ForecastType;
import com.ilim.commons.domain.model.MoneyNotificationType;
import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.forecast.web.api.ForecastModelAllocIdData;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.mockwebserver.MockResponse;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class TestData {

  private static final ObjectMapper jsonMapper = new ObjectMapper();

  public static final AtomicLong eventId = new AtomicLong(999L);

  /**
   * Helper method to create a MockResponse containing the given data
   * object as JSON within the body.
   * 
   * @param data data to be mocked as the json response body
   * @return mockResponse
   * @throws JsonProcessingException exception while writing json
   */
  public static MockResponse mockJsonResponse(Object data)
      throws JsonProcessingException {

    return new MockResponse().addHeader("Content-Type", "application/json")
        .addHeader("Cache-Control", "no-cache")
        .setBody(jsonMapper.writeValueAsString(data));
  }

  /**
   * Helper method to create a ForecastInstrucitonData content for testing.
   * 
   * @return {@code ForecastInstructionData} data type
   */
  public static ForecastInstructionData mockForecastInstructionData() {

    final int id = 10000;
    final String forecastDate = LocalDate.now().format(DateUtils.DATE_FMT);
    final String status = "NEW";
    final String forecastType = ForecastType.NEW_MONEY.name();
    final int fundId = 17444;
    final String moneyType = MoneyNotificationType.CASH.name();
    final BigDecimal amount = new BigDecimal("1000.00");
    final String creationTime =
        LocalDateTime.now().format(DateUtils.DATE_TIME_FMT);
    final long eventSourceId = eventId.getAndIncrement();

    return new ForecastInstructionData(id, forecastDate, status, forecastType,
        fundId, moneyType, amount, creationTime, eventSourceId);
  }

  /**
   * Helper method to create a list of mock ForecastInstrucitonData content for
   * testing.
   * 
   * @param numberInstrs number of entries to mock
   * @return {@code List<ForecastInstructionData>} data type
   */
  public static List<ForecastInstructionData> mockForecastInstructionDataList(
      int numberInstrs) {

    List<ForecastInstructionData> instrList =
        new ArrayList<ForecastInstructionData>();

    for (int i = 0; i < numberInstrs; i++) {
      instrList.add(mockForecastInstructionData());
    }

    return instrList;
  }

  /**
   * Helper method to create a ModelAllocData content for testing.
   * 
   * @return {@code List<ForecastModelAllocData>} data type
   */
  public static List<ForecastModelAllocData> mockModelAllocData() {

    final int modelId = 1000;
    final int instrId = 2000;
    final int fundId = 17444;
    final int holdingId = 29004;

    List<ForecastModelAllocData> model =
        new ArrayList<ForecastModelAllocData>();

    final ForecastModelAllocIdData id =
        new ForecastModelAllocIdData(modelId, instrId, fundId, holdingId);
    final String forecastDate = LocalDate.now().format(DateUtils.DATE_FMT);
    final BigDecimal unitsInIssue = new BigDecimal("100.01");
    final BigDecimal price = new BigDecimal("50.02");
    final BigDecimal mix = new BigDecimal("20");
    final BigDecimal cash = new BigDecimal("2000.03");
    final BigDecimal recordedCash = new BigDecimal("1000.00");

    model.add(new ForecastModelAllocData(id, forecastDate, unitsInIssue, price,
        mix, cash, recordedCash));

    return model;
  }

  /**
   * Helper method to create a NewForecastInstructionData content for
   * testing.
   * 
   * @param forecastDate forecast date to be part of test data
   * @return {@code List<ForecastModelAllocData>} data type
   */
  public static NewForecastInstructionData newInstr(LocalDate forecastDate) {

    String forecastDt = forecastDate.format(DATE_FMT);
    return new NewForecastInstructionData(forecastDt, "NEW_MONEY", 17444,
        "CASH", new BigDecimal("2000.01"), eventId.getAndIncrement());
  }
}
