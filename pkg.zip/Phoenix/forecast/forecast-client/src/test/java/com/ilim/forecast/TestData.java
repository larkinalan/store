package com.ilim.forecast;

import static com.ilim.commons.domain.model.ForecastStatus.NEW;
import static com.ilim.commons.domain.model.ForecastType.NEW_MONEY;
import static com.ilim.commons.domain.model.MoneyNotificationType.UNIT;

import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.forecast.web.api.ForecastModelData;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;

import okhttp3.mockwebserver.MockResponse;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class TestData {

  private static final ObjectMapper jsonMapper = new ObjectMapper();

  public static final AtomicLong eventId = new AtomicLong(999L);


  /** Fund test data. */
  public static class Funds {

    // Funds
    public static final int BPL = 26320;
    public static final int TBPL = 26321;
    public static final int PBPL = 26322;
    public static final int MGIEUCSH = 26339;

    // COLLECTORS
    public static final List<Integer> list =
        ImmutableList.of(BPL, TBPL, PBPL, MGIEUCSH);
  }

  /** Instruction test data. */
  public static class Events {

    // FIXME: this row must exist in the db.
    // need away to create events for testing ?.
    public static final int dummyId = 1;
  }

  /** Instruction test data. */
  public static class Instructions {

    // Client instructions
    public static final ForecastInstructionData BPL =
        new ForecastInstructionData(-1,
            LocalDate.now().format(DateUtils.DATE_FMT), NEW.name(),
            NEW_MONEY.name(), Funds.BPL, UNIT.name(), new BigDecimal("100"),
            LocalDateTime.now().format(DateUtils.DATE_FMT), Events.dummyId);

    // COLLECTORS
    public static final List<ForecastInstructionData> list =
        ImmutableList.of(BPL);
  }

  public static class ModelAllocs {

    // ALLOCS
    public static final ForecastModelAllocData BPL_TBPL =
        new ForecastModelAllocData(-1, Instructions.BPL.id, Funds.BPL,
            Funds.TBPL, new BigDecimal("100"), new BigDecimal("100"),
            new BigDecimal("100"), new BigDecimal("100"), new BigDecimal("1"),
            new BigDecimal("1"), new BigDecimal("100"),
            LocalDateTime.now().format(DateUtils.DATE_TIME_FMT));

    public static final ForecastModelAllocData TBPL_PBPL =
        new ForecastModelAllocData(-1, Instructions.BPL.id, Funds.TBPL,
            Funds.PBPL, new BigDecimal("100"), new BigDecimal("100"),
            new BigDecimal("100"), new BigDecimal("100"), new BigDecimal("1"),
            new BigDecimal("1"), new BigDecimal("100"),
            LocalDateTime.now().format(DateUtils.DATE_TIME_FMT));

    public static final ForecastModelAllocData PBPL_MGIEUCSH =
        new ForecastModelAllocData(-1, Instructions.BPL.id, Funds.PBPL,
            Funds.MGIEUCSH, new BigDecimal("100"), new BigDecimal("100"),
            new BigDecimal("100"), new BigDecimal("100"), new BigDecimal("1"),
            new BigDecimal("1"), new BigDecimal("100"),
            LocalDateTime.now().format(DateUtils.DATE_TIME_FMT));

    // COLLECTORS
    public static final List<ForecastModelAllocData> list =
        ImmutableList.of(BPL_TBPL, TBPL_PBPL, PBPL_MGIEUCSH);
  }

  /** Model test data. */
  public static class Models {

    // MODELS
    public static final ForecastModelData BPL =
        new ForecastModelData(Instructions.BPL, ModelAllocs.list);

    // COLLECTORS
    public static final List<ForecastModelData> list = ImmutableList.of(BPL);
  }

  /**
   * Helper method to create a NewForecastInstructionData content from 
   * ForecastInstructionData for testing.
   * 
   * @param data instr data to be converted
   * @return {@code List<ForecastModelAllocData>} data type
   */
  public static NewForecastInstructionData toNewForecastInstructionData(
      ForecastInstructionData data) {

    return new NewForecastInstructionData(data.forecastDate, data.forecastType,
        data.fundId, data.moneyType, data.amount, data.eventSourceId);
  }

  /**
   * Helper method to create a MockResponse containing the given data
   * object as JSON within the body.
   * 
   * @param data data to be mocked as the json response body
   * @return mockResponse
   * @throws JsonProcessingException exception while writing json
   */
  public static MockResponse mockJsonResponse(Object data)
      throws JsonProcessingException {

    return new MockResponse().addHeader("Content-Type", "application/json")
        .addHeader("Cache-Control", "no-cache")
        .setBody(jsonMapper.writeValueAsString(data));
  }

}
