package com.ilim.forecast.web.client;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import org.junit.Ignore;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicLong;

@Ignore
public class ForecastClientIntegrationTest {

  private static final AtomicLong eventId = new AtomicLong(999L);
  private static final ForecastClient client = new ForecastClient();

  @Test
  public void createForecastInstrSuccess() throws Exception {

    NewForecastInstructionData instr = newInstr(LocalDate.now());
    
    boolean result = client.create(instr);

    assertThat(result).isTrue();
  }

  @Test
  public void createForecastInstrFail() throws Exception {

    NewForecastInstructionData instr = newInstr("06/15/2015");
    
    boolean result = client.create(instr);
    
    assertThat(result).isFalse();
  }

  private static NewForecastInstructionData newInstr(LocalDate forecastDate) {

    return newInstr(forecastDate.format(DateUtils.DATE_FMT));
  }
  
  private static NewForecastInstructionData newInstr(String forecastDate) {

    return new NewForecastInstructionData(forecastDate, "NEW_MONEY", 17444,
        "CASH", new BigDecimal("2000.01"), eventId.getAndIncrement());
  }


}
