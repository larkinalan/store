package com.ilim.forecast.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;

import java.math.BigDecimal;

/**
 * ForecastInstructionData API DTO.
 * 
 * <p>shared between client and server. serializes to json.
 * 
 * <p>Represents a new instruction, sent fusion or eclipps.
 * 
 * @author Alan Larkin
 */
public class NewForecastInstructionData {

  public final String forecastDate;
  public final String forecastType;
  public final int fundId;
  public final String moneyType;
  public final BigDecimal amount;
  public final long eventSourceId;

  /** Creates a NewForecastInstructionData. */
  @JsonCreator
  public NewForecastInstructionData(
      @JsonProperty("forecastDate") String forecastDate,
      @JsonProperty("forecastType") String forecastType,
      @JsonProperty("fundId") int fundId,
      @JsonProperty("moneyType") String moneyType,
      @JsonProperty("amount") BigDecimal amount,
      @JsonProperty("eventSourceId") long eventSourceId) {

    this.forecastDate = forecastDate;
    this.forecastType = forecastType;
    this.moneyType = moneyType;
    this.fundId = fundId;
    this.amount = amount;
    this.eventSourceId = eventSourceId;
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("forecastDate", forecastDate)
        .add("forecastType", forecastType).add("fundId", fundId)
        .add("moneyType", moneyType).add("amount", amount)
        .add("eventSourceId", eventSourceId).toString();
  }
}
