package com.ilim.forecast.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

/**
 * RecordedCashData API DTO.
 * 
 * <p>shared between client and server. serializes to json.
 * 
 * @author Alan Larkin
 */
public class RecordedCashData {

  public final ForecastModelAllocIdData id;
  public final BigDecimal cash;

  /** Creates RecordedCashData. */
  @JsonCreator
  public RecordedCashData(@JsonProperty("id") ForecastModelAllocIdData id,
      @JsonProperty("cash") BigDecimal cash) {

    this.id = id;
    this.cash = cash;
  }
}
