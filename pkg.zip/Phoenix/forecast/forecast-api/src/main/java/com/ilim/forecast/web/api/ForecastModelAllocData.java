package com.ilim.forecast.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * ForecastModelAllocData API DTO.
 * 
 * <p>shared between client and server. serializes to json.
 * 
 * @author Alan Larkin
 */
public class ForecastModelAllocData {

  public final int allocId;
  public final int instrId;
  public final int fundId;
  public final int holdingId;
  public final BigDecimal unitsInIssue;
  public final BigDecimal price;
  public final BigDecimal mix;
  public final BigDecimal cash;
  public final String creationTime;

  /** Creates ForecastModelAllocData. */
  @JsonCreator
  public ForecastModelAllocData(@JsonProperty("allocId") int allocId,
      @JsonProperty("instrId") int instrId, 
      @JsonProperty("fundId") int fundId,
      @JsonProperty("holdingId") int holdingId,
      @JsonProperty("unitsInIssue") BigDecimal unitsInIssue,
      @JsonProperty("price") BigDecimal price,
      @JsonProperty("mix") BigDecimal mix,
      @JsonProperty("cash") BigDecimal cash,
      @JsonProperty("creationTime") String creationTime) {

    this.allocId = allocId;
    this.instrId = instrId;
    this.fundId = fundId;
    this.holdingId = holdingId;
    this.unitsInIssue = unitsInIssue;
    this.price = price;
    this.mix = mix;
    this.cash = cash;
    this.creationTime = creationTime;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final ForecastModelAllocData other = (ForecastModelAllocData) obj;
    return Objects.equals(allocId, other.allocId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(allocId);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("allocId", allocId).toString();
  }
}
