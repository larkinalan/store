package com.ilim.forecast.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;

import java.util.List;
import java.util.Objects;

/**
 * ForecastModelData API DTO.
 * 
 * <p>shared between client and server. serializes to json.
 * 
 * @author Alan Larkin
 */
public class ForecastModelData {

  public final ForecastInstructionData instruction;
  public final List<ForecastModelAllocData> modelledAllocs;

  /** Creates ForecastModelData. */
  @JsonCreator
  public ForecastModelData(
      @JsonProperty("instr") ForecastInstructionData instruction,
      @JsonProperty("modelledAllocs") List<ForecastModelAllocData> 
      modelledAllocs) {

    this.instruction = instruction;
    this.modelledAllocs = modelledAllocs;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final ForecastModelData other = (ForecastModelData) obj;
    return Objects.equals(instruction, other.instruction);
  }

  @Override
  public int hashCode() {
    return Objects.hash(instruction.id);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("instruction", instruction.toString())
        .add("modelledAllocs", modelledAllocs.size()).toString();
  }
}
