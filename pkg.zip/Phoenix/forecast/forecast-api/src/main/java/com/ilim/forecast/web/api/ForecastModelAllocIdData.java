package com.ilim.forecast.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/** Unique Id of a ForecastModelAllocData. */
public class ForecastModelAllocIdData {

  public final int modelId;
  public final int instrId;
  public final int fundId;
  public final int holdingId;

  /** Creates Unique ID. */
  @JsonCreator
  public ForecastModelAllocIdData(@JsonProperty("modelId") int modelId,
      @JsonProperty("instrId") int instrId, @JsonProperty("fundId") int fundId,
      @JsonProperty("holdingId") int holdingId) {

    this.modelId = modelId;
    this.instrId = instrId;
    this.fundId = fundId;
    this.holdingId = holdingId;
  }

}
