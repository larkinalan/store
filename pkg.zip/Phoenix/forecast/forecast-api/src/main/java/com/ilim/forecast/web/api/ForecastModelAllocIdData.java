package com.ilim.forecast.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;

import java.util.Objects;

/** Unique Id of a ForecastModelAllocData. */
public class ForecastModelAllocIdData {

  public final int modelId;
  public final int instrId;
  public final int fundId;
  public final int holdingId;

  /** Creates Unique ID. */
  @JsonCreator
  public ForecastModelAllocIdData(@JsonProperty("modelId") int modelId,
      @JsonProperty("instrId") int instrId, @JsonProperty("fundId") int fundId,
      @JsonProperty("holdingId") int holdingId) {

    this.modelId = modelId;
    this.instrId = instrId;
    this.fundId = fundId;
    this.holdingId = holdingId;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final ForecastModelAllocIdData other = (ForecastModelAllocIdData) obj;
    return Objects.equals(modelId, other.modelId)
        && Objects.equals(instrId, other.instrId)
        && Objects.equals(fundId, other.fundId)
        && Objects.equals(holdingId, other.holdingId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(modelId, instrId, fundId, holdingId);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("modelId", modelId)
        .add("instrId", instrId).add("fundId", fundId)
        .add("holdingId", holdingId).toString();
  }
}
