package com.ilim.forecast.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * ForecastInstructionData API DTO.
 * 
 * <p>shared between client and server. serializes to json.
 * 
 * @author Alan Larkin
 */
public class ForecastInstructionData {

  public final int id;
  public final String forecastDate;
  public final String status;
  public final String forecastType;
  public final int fundId;
  public final String moneyType;
  public final BigDecimal amount;
  public final String creationTime;
  public final long eventSourceId;

  /** Creates ForecastInstructionData. */
  @JsonCreator
  public ForecastInstructionData(@JsonProperty("id") int id,
      @JsonProperty("forecastDate") String forecastDate,
      @JsonProperty("status") String status,
      @JsonProperty("forecastType") String forecastType,
      @JsonProperty("fundId") int fundId,
      @JsonProperty("moneyType") String moneyType,
      @JsonProperty("amount") BigDecimal amount,
      @JsonProperty("creationTime") String creationTime,
      @JsonProperty("eventSourceId") long eventSourceId) {

    this.id = id;
    this.forecastDate = forecastDate;
    this.status = status;
    this.forecastType = forecastType;
    this.moneyType = moneyType;
    this.fundId = fundId;
    this.amount = amount;
    this.creationTime = creationTime;
    this.eventSourceId = eventSourceId;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final ForecastInstructionData other = (ForecastInstructionData) obj;
    return Objects.equals(id, other.id);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("id", id)
        .add("forecastDate", forecastDate).add("status", status)
        .add("forecastType", forecastType).add("fundId", fundId)
        .add("moneyType", moneyType).add("amount", amount)
        .add("eventSourceId", eventSourceId).toString();
  }

}
