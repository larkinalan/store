package com.ilim.forecast.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

/**
 * ForecastInstructionData API DTO.
 * 
 * <p>shared between client and server. serializes to json.
 * 
 * @author Alan Larkin
 */
public class ForecastInstructionData {

  public final int id;
  public final String forecastDate;
  public final String status;
  public final String forecastType;
  public final int fundId;
  public final String moneyType;
  public final BigDecimal amount;
  public final String creationTime;
  public final long eventSourceId;

  /** Creates ForecastInstructionData. */
  @JsonCreator
  public ForecastInstructionData(@JsonProperty("id") int id,
      @JsonProperty("forecastDate") String forecastDate,
      @JsonProperty("status") String status,
      @JsonProperty("forecastType") String forecastType,
      @JsonProperty("fundId") int fundId,
      @JsonProperty("moneyType") String moneyType,
      @JsonProperty("amount") BigDecimal amount,
      @JsonProperty("creationTime") String creationTime,
      @JsonProperty("eventSourceId") long eventSourceId) {

    this.id = id;
    this.forecastDate = forecastDate;
    this.status = status;
    this.forecastType = forecastType;
    this.moneyType = moneyType;
    this.fundId = fundId;
    this.amount = amount;
    this.creationTime = creationTime;
    this.eventSourceId = eventSourceId;
  }

}
