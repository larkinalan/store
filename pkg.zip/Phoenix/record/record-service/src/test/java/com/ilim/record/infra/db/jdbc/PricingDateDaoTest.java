package com.ilim.record.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.record.domain.IPricingDateRepo;

import org.junit.Test;

import java.time.LocalDate;

import javax.inject.Inject;


public class PricingDateDaoTest extends JdbcDaoTestSupport{
  
  @Inject
  private IPricingDateRepo pricingDateDao;

  @Test
  public void findCurrentPricingDate(){
    
    LocalDate actual = pricingDateDao.findCurrentPricingDate();
    assertThat(actual).isNotNull();
  }
}
