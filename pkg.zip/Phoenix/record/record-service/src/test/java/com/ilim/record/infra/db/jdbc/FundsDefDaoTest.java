package com.ilim.record.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.record.TestData;

import org.junit.Test;

import javax.inject.Inject;

public class FundsDefDaoTest extends JdbcDaoTestSupport {

  @Inject
  private FundsDefDao fundsDefDao;

  @Test
  public void findScdFundName() {

    int fundId = TestData.Funds.IPAINA.getId();
    String actual = fundsDefDao.findScdFundName(fundId);

    assertThat("IPAINA").isEqualTo(actual);
  }
}
