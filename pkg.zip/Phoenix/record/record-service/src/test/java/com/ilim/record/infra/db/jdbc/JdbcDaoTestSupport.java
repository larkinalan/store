package com.ilim.record.infra.db.jdbc;

import com.ilim.record.app.config.SpringTestConfig;

import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringTestConfig.class)
public abstract class JdbcDaoTestSupport
    extends AbstractTransactionalJUnit4SpringContextTests {

  @Rule
  @Inject
  public TestRule logger;

}
