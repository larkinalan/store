package com.ilim.record.domain.model.tx;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

public class UnitTxTest {

  @Test
  public void testUnitTx() {

    String securityId = "a";
    String portfolioId = "b";
    String requestedStatus = "c";
    BigDecimal price = new BigDecimal("1.1");
    BigDecimal nominal = new BigDecimal("2.2");
    String businessTxCode = "d";
    LocalDate tradeDate = LocalDate.MIN;
    LocalDate paymentDate = LocalDate.MAX;
    String counterParty = "e";
    int txNumOriginSystem = 1;
    String exchange = "f";
    String custody = "g";
    int txFreeCode = 2;
    String txOriginId = "h";

    UnitTx unitTx = new UnitTx(securityId, portfolioId, businessTxCode,
        requestedStatus, nominal, price, tradeDate, paymentDate, counterParty,
        txNumOriginSystem, exchange, custody, txFreeCode, txOriginId);

    assertThat(unitTx.getSecurityId()).isEqualTo(securityId);
    assertThat(unitTx.getPortfolioId()).isEqualTo(portfolioId);
    assertThat(unitTx.getRequestedStatus()).isEqualTo(requestedStatus);
    assertThat(unitTx.getPrice()).isEqualTo(price);
    assertThat(unitTx.getNominal()).isEqualTo(nominal);
    assertThat(unitTx.getBusinessTxCode()).isEqualTo(businessTxCode);
    assertThat(unitTx.getTradeDate()).isEqualTo(tradeDate);
    assertThat(unitTx.getPaymentDate()).isEqualTo(paymentDate);
    assertThat(unitTx.getCounterParty()).isEqualTo(counterParty);
    assertThat(unitTx.getTxNumOriginSystem()).isEqualTo(txNumOriginSystem);
    assertThat(unitTx.getExchange()).isEqualTo(exchange);
    assertThat(unitTx.getCustody()).isEqualTo(custody);
    assertThat(unitTx.getTxFreeCode()).isEqualTo(txFreeCode);
    assertThat(unitTx.getTxOriginId()).isEqualTo(txOriginId);
  }
}
