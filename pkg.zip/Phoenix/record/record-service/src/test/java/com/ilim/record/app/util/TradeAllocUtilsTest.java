package com.ilim.record.app.util;

import static com.ilim.record.TestData.TradeAllocs.ForecastTa.listOfTAs;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.record.TestData.Funds;
import com.ilim.record.app.util.TradeAllocUtils.GroupBy;
import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.domain.model.TradeAlloc.Type;

import org.junit.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TradeAllocUtilsTest {

  @Test
  public void groupAndMergeTradeAllocsA() {

    // group by fund:holding:type
    GroupBy groupBy = new GroupBy(true, true, true, false);

    // set up data to be used (using all combinations of differences)
    List<TradeAlloc> taListA =
        listOfTAs(Funds.PCF, Funds.TPCF, Type.NEW_MONEY, 5); // base example
    List<TradeAlloc> taListB =
        listOfTAs(Funds.TPCF, Funds.TPCF, Type.NEW_MONEY, 5); // diff fund
    List<TradeAlloc> taListC =
        listOfTAs(Funds.PCF, Funds.PCF, Type.NEW_MONEY, 5); // diff holding
    List<TradeAlloc> taListD =
        listOfTAs(Funds.PCF, Funds.TPCF, Type.REBALANCE, 5); // diff type
    List<TradeAlloc> taListE = 
        listOfTAs(Funds.PPCF, Funds.IPAIPE, Type.ZAP, 5); // diff everything

    // combine into one list and shuffle
    List<TradeAlloc> allTradeAllocs = new ArrayList<>();
    allTradeAllocs.addAll(taListA);
    allTradeAllocs.addAll(taListB);
    allTradeAllocs.addAll(taListC);
    allTradeAllocs.addAll(taListD);
    allTradeAllocs.addAll(taListE);
    Collections.shuffle(allTradeAllocs);

    // call the function to test
    List<TradeAlloc> actualList =
        TradeAllocUtils.groupAndMergeTradeAllocs(allTradeAllocs, groupBy);

    // calculate expected data
    TradeAlloc expectedA = new TradeAlloc(0, Funds.PCF, Funds.TPCF.getId(),
        calcTotalCashAmount(taListA), Type.NEW_MONEY, null, null);
    TradeAlloc expectedB = new TradeAlloc(0, Funds.TPCF, Funds.TPCF.getId(),
        calcTotalCashAmount(taListB), Type.NEW_MONEY, null, null);
    TradeAlloc expectedC = new TradeAlloc(0, Funds.PCF, Funds.PCF.getId(),
        calcTotalCashAmount(taListC), Type.NEW_MONEY, null, null);
    TradeAlloc expectedD = new TradeAlloc(0, Funds.PCF, Funds.TPCF.getId(),
        calcTotalCashAmount(taListD), Type.REBALANCE, null, null);
    TradeAlloc expectedE = new TradeAlloc(0, Funds.PPCF, Funds.IPAIPE.getId(),
        calcTotalCashAmount(taListE), Type.ZAP, null, null);

    // assertions
    assertThat(actualList.size()).isEqualTo(5);
    assertThat(actualList).contains(expectedA, expectedB, expectedC, expectedD,
        expectedE);

  }

  @Test
  public void filterByClientLevel() {

    List<TradeAlloc> clientTradeAllocs =
        listOfTAs(Funds.PCF, Funds.TPCF, Type.NEW_MONEY, 5);
    List<TradeAlloc> otherTradeAllocs =
        listOfTAs(Funds.PPCF, Funds.IPAIPE, Type.NEW_MONEY, 5);
    List<TradeAlloc> mixedTradeAllocs = new ArrayList<>();
    mixedTradeAllocs.addAll(clientTradeAllocs);
    mixedTradeAllocs.addAll(otherTradeAllocs);
    Collections.shuffle(mixedTradeAllocs);

    assertThat(TradeAllocUtils.filterByClientLevel(clientTradeAllocs))
        .hasSize(clientTradeAllocs.size());
    assertThat(TradeAllocUtils.filterByClientLevel(otherTradeAllocs))
        .hasSize(0);
    assertThat(TradeAllocUtils.filterByClientLevel(mixedTradeAllocs))
        .hasSize(clientTradeAllocs.size());
  }

  @Test
  public void filterByPrimaryLevel() {

    List<TradeAlloc> primaryTradeAllocs =
        listOfTAs(Funds.PPCF, Funds.IPAIPE, Type.NEW_MONEY, 5);
    List<TradeAlloc> otherTradeAllocs =
        listOfTAs(Funds.TPCF, Funds.PPCF, Type.NEW_MONEY, 5);
    List<TradeAlloc> mixedTradeAllocs = new ArrayList<>();
    mixedTradeAllocs.addAll(primaryTradeAllocs);
    mixedTradeAllocs.addAll(otherTradeAllocs);
    Collections.shuffle(mixedTradeAllocs);

    assertThat(TradeAllocUtils.filterByPrimaryLevel(primaryTradeAllocs))
        .hasSize(primaryTradeAllocs.size());
    assertThat(TradeAllocUtils.filterByPrimaryLevel(otherTradeAllocs))
        .hasSize(0);
    assertThat(TradeAllocUtils.filterByPrimaryLevel(mixedTradeAllocs))
        .hasSize(primaryTradeAllocs.size());
  }

  @Test
  public void newBigDecimalZeroScale4() {
    BigDecimal expected = new BigDecimal("0.0000");
    assertThat(expected).isEqualTo(TradeAllocUtils.newBigDecimalZeroScale4());
  }

  private BigDecimal calcTotalCashAmount(List<TradeAlloc> tradeAllocs) {
    return tradeAllocs.stream().map(TradeAlloc::getCashAmount)
        .reduce(TradeAllocUtils.newBigDecimalZeroScale4(), BigDecimal::add);
  }
}
