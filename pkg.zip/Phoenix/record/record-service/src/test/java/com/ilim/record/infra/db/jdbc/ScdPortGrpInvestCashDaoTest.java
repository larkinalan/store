package com.ilim.record.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.domain.model.Currency;
import com.ilim.record.TestData;

import org.junit.Test;

import javax.inject.Inject;

public class ScdPortGrpInvestCashDaoTest extends JdbcDaoTestSupport {

  @Inject
  private ScdPortGrpInvestCashDao dao;
  
  @Test
  public void findPortfolioOwnerId(){
       
    int holdingId = TestData.Funds.IPAIPE.getId();
    Currency baseCurrency = TestData.Funds.PPCF.getBaseCurrency();
    String actual = dao.findPortfolioOwnerId(holdingId, baseCurrency);
    
    assertThat("A-ITRESX00").isEqualTo(actual);
  }
}
