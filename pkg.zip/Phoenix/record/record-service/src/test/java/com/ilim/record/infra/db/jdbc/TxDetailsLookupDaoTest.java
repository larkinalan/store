package com.ilim.record.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.record.TestData;
import com.ilim.record.domain.model.ScdLobClientCashFinSep;
import com.ilim.record.domain.model.ScdLobClientCashTresIlim;

import org.junit.Test;

import javax.inject.Inject;

public class TxDetailsLookupDaoTest extends JdbcDaoTestSupport {
  
  @Inject
  private TxDetailsLookupDao dao;
  
  @Test
  public void findPortfolioOwnerId(){
       
    int holdingId = TestData.Funds.IPAIPE.getId();
    String baseCurrency = TestData.Funds.PPCF.getBaseCurrency();
    String actual = dao.findPortfolioOwnerId(holdingId, baseCurrency);
    
    assertThat("A-ITRESX00").isEqualTo(actual);
  }
  
  @Test
  public void findScdLobClientCashFinSep() {
    String scdLobId = "9";
    String portfolioOwnerId = "A-ITRESX00";
    String appAlmNumber = "9ALM1185";
    String mcAlmNumber = "9ALM1208";
    String appBankAccount = "ITRESX00-EUR-07";
    String mcBankAccount = "ITRESX00-EUR-07";
    ScdLobClientCashFinSep expected =
        new ScdLobClientCashFinSep(scdLobId, portfolioOwnerId, appAlmNumber,
            mcAlmNumber, appBankAccount, mcBankAccount);

    int lobId = TestData.Funds.PCF.getLobId();
    ScdLobClientCashFinSep actual = dao.findScdLobClientCashFinSep(lobId);

    assertThat(expected).isEqualToComparingFieldByField(actual);
  }
  
  @Test
  public void findScdLobClientCashTresIlim(){
    
    String scdLobId = "9";
    String portfolioOwnerId = "A-ILIMXX00";
    String appAlmNumber = "9ALM1002";
    String mcAlmNumber = "9ALM1088";
    String appBankAccount = "ILIMXX00-EUR-01";
    String mcBankAccount = "ILIMXX00-EUR-01";
    ScdLobClientCashTresIlim expected =
        new ScdLobClientCashTresIlim(scdLobId, portfolioOwnerId, appAlmNumber,
            mcAlmNumber, appBankAccount, mcBankAccount);
    
    int lobId = TestData.Funds.PCF.getLobId();
    ScdLobClientCashTresIlim actual = dao.findScdLobClientCashTresIlim(lobId);
    
    assertThat(expected).isEqualToComparingFieldByField(actual);
  }
}
