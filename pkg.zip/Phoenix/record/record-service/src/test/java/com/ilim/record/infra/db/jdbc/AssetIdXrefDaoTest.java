package com.ilim.record.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.record.TestData;
import com.ilim.record.domain.model.AssetIdXref.ExternalIdType;

import org.junit.Test;

import javax.inject.Inject;

public class AssetIdXrefDaoTest extends JdbcDaoTestSupport {

  @Inject
  private AssetIdXrefDao assetIdXrefDao;

  @Test
  public void findExternalIdByIds() {
    int fundId = TestData.Funds.PCF.getId();
    ExternalIdType extIdType = ExternalIdType.SCD_PORTFOLIO_ID;

    String actual = assetIdXrefDao.findExternalIdByIds(fundId, extIdType);

    assertThat("A-C-PCF").isEqualTo(actual);
  }
}
