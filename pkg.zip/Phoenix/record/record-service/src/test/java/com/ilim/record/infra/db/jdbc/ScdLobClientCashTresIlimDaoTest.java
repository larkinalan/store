package com.ilim.record.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.record.TestData;
import com.ilim.record.domain.model.ScdLobClientCashTresIlim;

import org.junit.Test;

import javax.inject.Inject;

public class ScdLobClientCashTresIlimDaoTest extends JdbcDaoTestSupport {

  @Inject
  private ScdLobClientCashTresIlimDao dao;
  
  @Test
  public void findScdLobClientCashTresIlim(){
    
    String scdLobId = "9";
    String portfolioOwnerId = "A-ILIMXX00";
    String appAlmNumber = "9ALM1002";
    String mcAlmNumber = "9ALM1088";
    String appBankAccount = "ILIMXX00-EUR-01";
    String mcBankAccount = "ILIMXX00-EUR-01";
    ScdLobClientCashTresIlim expected =
        new ScdLobClientCashTresIlim(scdLobId, portfolioOwnerId, appAlmNumber,
            mcAlmNumber, appBankAccount, mcBankAccount);
    
    int lobId = TestData.Funds.PCF.getLobId();
    ScdLobClientCashTresIlim actual = dao.findScdLobClientCashTresIlim(lobId);
    
    assertThat(expected).isEqualToComparingFieldByField(actual);
  }
}
