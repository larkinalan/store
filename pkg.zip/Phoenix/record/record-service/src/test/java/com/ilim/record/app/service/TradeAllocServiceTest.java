package com.ilim.record.app.service;

import static org.assertj.core.api.Assertions.assertThat;

import static com.ilim.record.TestData.TradeAllocs.CrimsTa.newPcfTpcf;
import static com.ilim.record.TestData.TradeAllocs.CrimsTa.newPpcfIpaina;

import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.domain.model.TradeAlloc.Type;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class TradeAllocServiceTest {

  @Mock
  IForecastService forecastService;
  @InjectMocks
  TradeAllocService tradeAllocService;

  final BigDecimal TEN = new BigDecimal("10.0000");

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  @SuppressWarnings("unchecked")
  public void generateRecordableTradeAllocs() {

    // set up input data
    TradeAlloc crimsTA1 = newPcfTpcf();
    TradeAlloc crimsTA2 = newPcfTpcf();
    TradeAlloc crimsTA3 = newPpcfIpaina();
    List<TradeAlloc> crimsTAs = Arrays.asList(crimsTA1, crimsTA2, crimsTA3);

    // set up forecastService.findUnrecordedForecasts(..) mock data
    Fund fund1 = new Fund(crimsTA1.getFund().getId(), null, null, null, -1);
    TradeAlloc unrecdTA1 = new TradeAlloc(1 ,fund1, crimsTA1.getHoldingId(),
        crimsTA1.getCashAmount(), crimsTA1.getType(),
        crimsTA1.getSendToAccDate(), crimsTA1.getRecordOnDate());

    Fund fund2 = new Fund(crimsTA2.getFund().getId(), null, null, null, -1);
    TradeAlloc unrecdTA2 = new TradeAlloc(2, fund2, crimsTA2.getHoldingId(),
        crimsTA2.getCashAmount(), crimsTA2.getType(),
        crimsTA2.getSendToAccDate(), crimsTA2.getRecordOnDate());

    Fund fund3 = new Fund(crimsTA3.getFund().getId(), null, null, null, -1);
    BigDecimal cashAmountDiff = crimsTA3.getCashAmount().subtract(TEN);
    TradeAlloc unrecdTA3 = new TradeAlloc(3, fund3, crimsTA3.getHoldingId(),
        cashAmountDiff, crimsTA3.getType(), crimsTA3.getSendToAccDate(),
        crimsTA3.getRecordOnDate());

    Mockito.when(forecastService.findUnrecordedForecasts(Mockito.any()))
        .thenReturn(Arrays.asList(unrecdTA1, unrecdTA2),
            Arrays.asList(unrecdTA3));

    // set up expected data
    TradeAlloc expected1 = unrecdTA1;
    TradeAlloc expected2 = unrecdTA2;
    TradeAlloc expected3 = unrecdTA3;
    TradeAlloc expected4 = new TradeAlloc(0, crimsTA3.getFund(),
        crimsTA3.getHoldingId(), TEN, Type.REBALANCE, null, null);

    // run the function to test
    List<TradeAlloc> actual =
        tradeAllocService.generateRecordableTradeAllocs(crimsTAs);

    // check the results
    assertThat(actual.size()).isEqualTo(4);
    assertThat(actual).contains(expected1, expected2, expected3, expected4);
  }
}
