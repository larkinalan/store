package com.ilim.record;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.TradeAlloc;

import com.google.common.collect.ImmutableList;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

/*
 * Unit Test Data Object Mother.
 * 
 * <p>Used for 'expected' results in testing.
 * 
 */
public class TestData {

  /******** 
   * Dates.
   ********/
  public static final LocalDate TODAY = LocalDate.now();
  public static final LocalDate TOMORROW = TODAY.plusDays(1);

  /************************
   * Number generator util. 
   ************************/
  public static class Numbers {

    // unique integer generator
    static AtomicInteger atomicInt = new AtomicInteger();

    public static int uniqueInt() {
      return atomicInt.getAndIncrement();
    }

    // Random non unique BigDecimal (scale 4) generator
    static Random random = new Random();
    
    public static BigDecimal randomBigDecimal() {
      int leftSide = random.nextInt(99999999);
      int rightInt = random.nextInt(9999);
      String rightSide = String.format("%-4s", rightInt).replace(' ', '0');
      String number = leftSide + "." + rightSide;

      return new BigDecimal(number);
    }
  }

  public static int uniqueInt() {
    return Numbers.uniqueInt();
  }

  public static BigDecimal randBd() {
    return Numbers.randomBigDecimal();
  }


  /***********************
   * TradeAlloc test data.
   ***********************/
  public static class TradeAllocs {

    public static class RecordableTa {

      // client level
      public static TradeAlloc newPcfTpcfNewMoney() {
        return new TradeAlloc(uniqueInt(), uniqueInt(), uniqueInt(), Funds.PCF,
            Funds.TPCF.getId(), randBd(), TradeAlloc.Type.NEW_MONEY, TODAY,
            TOMORROW);
      }

      public static TradeAlloc newPcfTpcfRebal() {
        return new TradeAlloc(uniqueInt(), uniqueInt(), uniqueInt(), Funds.PCF,
            Funds.TPCF.getId(), randBd(), TradeAlloc.Type.REBALANCE, TODAY,
            TOMORROW);
      }

      // tax lvel
      public static TradeAlloc newTpcfPpcfNewMoney() {
        return new TradeAlloc(uniqueInt(), uniqueInt(), uniqueInt(), Funds.TPCF,
            Funds.PPCF.getId(), randBd(), TradeAlloc.Type.NEW_MONEY, TODAY,
            TOMORROW);
      }

      public static TradeAlloc newTpcfPpcfRebal() {
        return new TradeAlloc(uniqueInt(), uniqueInt(), uniqueInt(), Funds.TPCF,
            Funds.PPCF.getId(), randBd(), TradeAlloc.Type.REBALANCE, TODAY,
            TOMORROW);
      }

      // primary level
      public static TradeAlloc newPpcfIpainaNewMoney() {
        return new TradeAlloc(uniqueInt(), uniqueInt(), uniqueInt(), Funds.PPCF,
            Funds.IPAINA.getId(), randBd(), TradeAlloc.Type.NEW_MONEY, TODAY,
            TOMORROW);
      }

      public static TradeAlloc newPpcfIpainaRebal() {
        return new TradeAlloc(uniqueInt(), uniqueInt(), uniqueInt(), Funds.PPCF,
            Funds.IPAINA.getId(), randBd(), TradeAlloc.Type.REBALANCE, TODAY,
            TOMORROW);
      }

      public static TradeAlloc newPpcfIpaipeNewMoney() {
        return new TradeAlloc(uniqueInt(), uniqueInt(), uniqueInt(), Funds.PPCF,
            Funds.IPAIPE.getId(), randBd(), TradeAlloc.Type.NEW_MONEY, TODAY,
            TOMORROW);
      }

      public static TradeAlloc newPpcfIpaipeRebal() {
        return new TradeAlloc(uniqueInt(), uniqueInt(), uniqueInt(), Funds.PPCF,
            Funds.IPAIPE.getId(), randBd(), TradeAlloc.Type.REBALANCE, TODAY,
            TOMORROW);
      }
    }

    public static class CrimsTa {

      // client level
      public static TradeAlloc newPcfTpcf() {
        return new TradeAlloc(uniqueInt(), uniqueInt(), Funds.PCF,
            Funds.TPCF.getId(), randBd(), TODAY, TOMORROW);
      }

      // primary level
      public static TradeAlloc newPpcfIpaina() {
        return new TradeAlloc(uniqueInt(), uniqueInt(), Funds.PPCF,
            Funds.IPAINA.getId(), randBd(), TODAY, TOMORROW);
      }
    }

    public static class ForecastTa {

      public static List<TradeAlloc> listOfTAs(Fund fund, Fund holding,
          TradeAlloc.Type type, int size) {
        List<TradeAlloc> tradeAllocs = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
          tradeAllocs.add(new TradeAlloc(uniqueInt(), fund, holding.getId(),
              randBd(), type, TODAY, TOMORROW));
        }

        return tradeAllocs;
      }

      // client level
      public static TradeAlloc newPcfTpcfNewMoney() {
        return new TradeAlloc(uniqueInt(), Funds.PCF, Funds.TPCF.getId(),
            randBd(), TradeAlloc.Type.NEW_MONEY, TODAY, TOMORROW);
      }

      public static TradeAlloc newPcfTpcfRebal() {
        return new TradeAlloc(uniqueInt(), Funds.PCF, Funds.TPCF.getId(),
            randBd(), TradeAlloc.Type.REBALANCE, TODAY, TOMORROW);
      }

      // tax lvel
      public static TradeAlloc newTpcfPpcfNewMoney() {
        return new TradeAlloc(uniqueInt(), Funds.TPCF, Funds.PPCF.getId(),
            randBd(), TradeAlloc.Type.NEW_MONEY, TODAY, TOMORROW);
      }

      public static TradeAlloc newTpcfPpcfRebal() {
        return new TradeAlloc(uniqueInt(), Funds.TPCF, Funds.PPCF.getId(),
            randBd(), TradeAlloc.Type.REBALANCE, TODAY, TOMORROW);
      }

      // primary level
      public static TradeAlloc newPpcfIpainaNewMoney() {
        return new TradeAlloc(uniqueInt(), Funds.PPCF, Funds.IPAINA.getId(),
            randBd(), TradeAlloc.Type.NEW_MONEY, TODAY, TOMORROW);
      }

      public static TradeAlloc newPpcfIpainaRebal() {
        return new TradeAlloc(uniqueInt(), Funds.PPCF, Funds.IPAINA.getId(),
            randBd(), TradeAlloc.Type.REBALANCE, TODAY, TOMORROW);
      }

      public static TradeAlloc newPpcfIpaipeNewMoney() {
        return new TradeAlloc(uniqueInt(), Funds.PPCF, Funds.IPAIPE.getId(),
            randBd(), TradeAlloc.Type.NEW_MONEY, TODAY, TOMORROW);
      }

      public static TradeAlloc newPpcfIpaipeRebal() {
        return new TradeAlloc(uniqueInt(), Funds.PPCF, Funds.IPAIPE.getId(),
            randBd(), TradeAlloc.Type.REBALANCE, TODAY, TOMORROW);
      }
    }
  }

  /** Fund test data. */
  public static class Funds {

    public static final Fund PCF =
        new Fund(17444, FundLevel.CLIENT, new BigDecimal("100"), "EUR", 22);
    public static final Fund TPCF =
        new Fund(17803, FundLevel.TAX, new BigDecimal("100"), "EUR", 0);
    public static final Fund PPCF =
        new Fund(133, FundLevel.PRIMARY, new BigDecimal("100"), "EUR", 0);
    public static final Fund IPAINA =
        new Fund(208, FundLevel.INVESTING, new BigDecimal("60"), "EUR", 41);
    public static final Fund IPAIPE =
        new Fund(209, FundLevel.INVESTING, new BigDecimal("40"), "EUR", 41);

    public static final List<Fund> list =
        ImmutableList.of(PCF, TPCF, PPCF, IPAINA, IPAIPE);
  }
}
