package com.ilim.record;

import static com.ilim.commons.domain.model.Currency.EUR;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.TradeAlloc;

import com.google.common.collect.ImmutableList;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/*
 * Unit Test Data Object Mother.
 * 
 * <p>Used for 'expected' results in testing.
 * 
 */
public class TestData {
  
  /** Random number generator */
  public static class RandomNumbers{
    
    // Random unique integer generator
    static ArrayList<Integer> randomInts = new ArrayList<Integer>(10000);
    static {
      for (int i = 1; i < 10000; i++) {
        randomInts.add(i);
      }
      Collections.shuffle(randomInts);
    }
    
    public static int randomInt() {
      return randomInts.iterator().next();
    }
    
    // Random BigDecimal generator
    static Random random = new Random();
    
    public static BigDecimal randomBigDecimal(){
      int leftSide = random.nextInt(99999999);
      int rightSide = random.nextInt(9999); // scale 4
      String number = leftSide + "." + rightSide;
      
      return new BigDecimal(number);
    }
  }
  
  public static int randInt(){
    return RandomNumbers.randomInt();
  }
  
  public static BigDecimal randBD(){
    return RandomNumbers.randomBigDecimal();
  }
  
  
  /** TradeAlloc test data */
  public static class TradeAllocs {
    
    public static List<TradeAlloc> listOfTradeAllocs(Fund fund, Fund holding, TradeAlloc.Type type, int size){
      List<TradeAlloc> tradeAllocs = new ArrayList<>(size);
      for(int i = 0; i < size; i++){
        tradeAllocs.add(new TradeAlloc(randInt(), fund, holding.getId(), randBD(), type));
      }
      
      return tradeAllocs;
    }
    
    //Client level
    public static TradeAlloc newPcfTpcfNewMoney(){
      return new TradeAlloc(randInt(), Funds.PCF, Funds.TPCF.getId(), new BigDecimal("1.1000"), TradeAlloc.Type.NEW_MONEY);
    }
    public static TradeAlloc newPcfTpcfRebal(){
      return new TradeAlloc(randInt(), Funds.PCF, Funds.TPCF.getId(), randBD(), TradeAlloc.Type.REBALANCE);
    }
    public static TradeAlloc newPcfTpcfUnitZap(){
      return new TradeAlloc(randInt(), Funds.PCF, Funds.TPCF.getId(), randBD(), TradeAlloc.Type.UNIT_ZAP);
    }
    
    //Tax level
    public static TradeAlloc newTpcfPpcfNewMoney(){
      return new TradeAlloc(randInt(), Funds.TPCF, Funds.PPCF.getId(), randBD(), TradeAlloc.Type.NEW_MONEY);
    }
    public static TradeAlloc newTpcfPpcfRebal(){
      return new TradeAlloc(randInt(), Funds.TPCF, Funds.PPCF.getId(), randBD(), TradeAlloc.Type.REBALANCE);
    }
    
    //Primary level
    public static TradeAlloc newPpcfIpainaNewMoney(){
      return new TradeAlloc(randInt(), Funds.PPCF, Funds.IPAINA.getId(), randBD(), TradeAlloc.Type.NEW_MONEY);
    }
    public static TradeAlloc newPpcfIpainaRebal(){
      return new TradeAlloc(randInt(), Funds.PPCF, Funds.IPAINA.getId(), randBD(), TradeAlloc.Type.REBALANCE);
    }
    
    public static TradeAlloc newPpcfIpaipeNewMoney(){
      return new TradeAlloc(randInt(), Funds.PPCF, Funds.IPAIPE.getId(), randBD(), TradeAlloc.Type.NEW_MONEY);
    }
    public static TradeAlloc newPpcfIpaipeRebal(){
      return new TradeAlloc(randInt(), Funds.PPCF, Funds.IPAIPE.getId(), randBD(), TradeAlloc.Type.REBALANCE);
    }
  }

  /** Fund test data. */
  public static class Funds {

    public static final Fund PCF =
        new Fund(17444, FundLevel.CLIENT, new BigDecimal("100"), EUR, 22);
    public static final Fund TPCF =
        new Fund(17803, FundLevel.TAX, new BigDecimal("100"), EUR, 0);
    public static final Fund PPCF =
        new Fund(133, FundLevel.PRIMARY, new BigDecimal("100"), EUR, 0);
    public static final Fund IPAINA =
        new Fund(208, FundLevel.INVESTING, new BigDecimal("60"), EUR, 41);
    public static final Fund IPAIPE =
        new Fund(209, FundLevel.INVESTING, new BigDecimal("40"), EUR, 41);

    public static final List<Fund> list =
        ImmutableList.of(PCF, TPCF, PPCF, IPAINA, IPAIPE);
  }
}
