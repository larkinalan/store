package com.ilim.record;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.TradeAlloc;

import com.google.common.collect.ImmutableList;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

/*
 * Unit Test Data Object Mother.
 * 
 * <p>Used for 'expected' results in testing.
 * 
 */
public class TestData {

  /** Number generator util */
  public static class Numbers {

    // unique integer generator
    static AtomicInteger atomicInt = new AtomicInteger();

    public static int uniqueInt() {
      return atomicInt.getAndIncrement();
    }

    // Random non unique BigDecimal (scale 4) generator
    static Random random = new Random();

    public static BigDecimal randomBigDecimal() {
      int leftSide = random.nextInt(99999999);
      int rightInt = random.nextInt(9999);
      String rightSide = String.format("%-4s", rightInt).replace(' ', '0');
      String number = leftSide + "." + rightSide;

      return new BigDecimal(number);
    }
  }

  public static int uniqueInt() {
    return Numbers.uniqueInt();
  }

  public static BigDecimal randBD() {
    return Numbers.randomBigDecimal();
  }


  /** TradeAlloc test data */
  public static class TradeAllocs {

    public static List<TradeAlloc> listOfTradeAllocs(Fund fund, Fund holding,
        TradeAlloc.Type type, int size) {
      List<TradeAlloc> tradeAllocs = new ArrayList<>(size);
      for (int i = 0; i < size; i++) {
        tradeAllocs.add(
            new TradeAlloc(uniqueInt(), fund, holding.getId(), randBD(), type));
      }

      return tradeAllocs;
    }

    // Client level
    public static TradeAlloc newPcfTpcfNewMoney() {
      return new TradeAlloc(uniqueInt(), Funds.PCF, Funds.TPCF.getId(),
          randBD(), TradeAlloc.Type.NEW_MONEY);
    }

    public static TradeAlloc newPcfTpcfRebal() {
      return new TradeAlloc(uniqueInt(), Funds.PCF, Funds.TPCF.getId(),
          randBD(), TradeAlloc.Type.REBALANCE);
    }

    // Tax level
    public static TradeAlloc newTpcfPpcfNewMoney() {
      return new TradeAlloc(uniqueInt(), Funds.TPCF, Funds.PPCF.getId(),
          randBD(), TradeAlloc.Type.NEW_MONEY);
    }

    public static TradeAlloc newTpcfPpcfRebal() {
      return new TradeAlloc(uniqueInt(), Funds.TPCF, Funds.PPCF.getId(),
          randBD(), TradeAlloc.Type.REBALANCE);
    }

    // Primary level
    public static TradeAlloc newPpcfIpainaNewMoney() {
      return new TradeAlloc(uniqueInt(), Funds.PPCF, Funds.IPAINA.getId(),
          randBD(), TradeAlloc.Type.NEW_MONEY);
    }

    public static TradeAlloc newPpcfIpainaRebal() {
      return new TradeAlloc(uniqueInt(), Funds.PPCF, Funds.IPAINA.getId(),
          randBD(), TradeAlloc.Type.REBALANCE);
    }

    public static TradeAlloc newPpcfIpaipeNewMoney() {
      return new TradeAlloc(uniqueInt(), Funds.PPCF, Funds.IPAIPE.getId(),
          randBD(), TradeAlloc.Type.NEW_MONEY);
    }

    public static TradeAlloc newPpcfIpaipeRebal() {
      return new TradeAlloc(uniqueInt(), Funds.PPCF, Funds.IPAIPE.getId(),
          randBD(), TradeAlloc.Type.REBALANCE);
    }
  }

  /** Fund test data. */
  public static class Funds {

    public static final Fund PCF =
        new Fund(17444, FundLevel.CLIENT, new BigDecimal("100"), "EUR", 22);
    public static final Fund TPCF =
        new Fund(17803, FundLevel.TAX, new BigDecimal("100"), "EUR", 0);
    public static final Fund PPCF =
        new Fund(133, FundLevel.PRIMARY, new BigDecimal("100"), "EUR", 0);
    public static final Fund IPAINA =
        new Fund(208, FundLevel.INVESTING, new BigDecimal("60"), "EUR", 41);
    public static final Fund IPAIPE =
        new Fund(209, FundLevel.INVESTING, new BigDecimal("40"), "EUR", 41);

    public static final List<Fund> list =
        ImmutableList.of(PCF, TPCF, PPCF, IPAINA, IPAIPE);
  }
}
