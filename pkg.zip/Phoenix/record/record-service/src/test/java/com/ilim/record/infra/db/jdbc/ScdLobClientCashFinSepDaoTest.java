package com.ilim.record.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.record.TestData;
import com.ilim.record.domain.model.ScdLobClientCashFinSep;

import org.junit.Test;

import javax.inject.Inject;

public class ScdLobClientCashFinSepDaoTest extends JdbcDaoTestSupport {

  @Inject
  private ScdLobClientCashFinSepDao dao;

  @Test
  public void findScdLobClientCashFinSep() {
    String scdLobId = "9";
    String portfolioOwnerId = "A-ITRESX00";
    String appAlmNumber = "9ALM1185";
    String mcAlmNumber = "9ALM1208";
    String appBankAccount = "ITRESX00-EUR-07";
    String mcBankAccount = "ITRESX00-EUR-07";
    ScdLobClientCashFinSep expected =
        new ScdLobClientCashFinSep(scdLobId, portfolioOwnerId, appAlmNumber,
            mcAlmNumber, appBankAccount, mcBankAccount);

    int lobId = TestData.Funds.PCF.getLobId();
    ScdLobClientCashFinSep actual = dao.findScdLobClientCashFinSep(lobId);

    assertThat(expected).isEqualToComparingFieldByField(actual);
  }
}
