package com.ilim.record.app.service;

import static org.assertj.core.api.Assertions.assertThat;

import static com.ilim.record.TestData.TradeAllocs.newPcfTpcfNewMoney;
import static com.ilim.record.TestData.TradeAllocs.newPcfTpcfRebal;
import static com.ilim.record.TestData.TradeAllocs.newPpcfIpainaNewMoney;
import static com.ilim.record.TestData.TradeAllocs.newPpcfIpaipeNewMoney;
import static com.ilim.record.TestData.TradeAllocs.newTpcfPpcfRebal;

import com.ilim.record.app.config.SpringTestConfig;
import com.ilim.record.domain.model.CashTx;
import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.domain.model.UnitTx;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringTestConfig.class)
public class TxTransformerTest {

  @Rule
  @Inject
  public TestRule logger;

  @Inject
  public TxTransformer txTransformer;

  @Test
  public void toAssetPortfolio() {

    // Setup input data. 2 X pcf:tpc:newMoney, 2 X pcf:tpc:rebal
    List<TradeAlloc> tradeAllocs = Arrays.asList(newPcfTpcfNewMoney(),
        newPcfTpcfNewMoney(), newPcfTpcfRebal(), newPcfTpcfRebal());

    // setup expected results
    UnitTx pcfTpcfNewMoney =
        new UnitTx("A-T-PCF", "A-C-PCF", "Buy", "Fin calc", BigDecimal.ZERO,
            BigDecimal.ZERO, LocalDate.now(), LocalDate.now().plusDays(1),
            "ILAUTE-01", "UTE EXCH", "15328", 13, "ILIM UTE");
    UnitTx pcfTpcfRebal =
        new UnitTx("A-T-PCF", "A-C-PCF", "Buy", "Fin calc", BigDecimal.ZERO,
            BigDecimal.ZERO, LocalDate.now(), LocalDate.now().plusDays(1),
            "ILAUTE-01", "UTE EXCH", "15328", 1, "ILIM UTE");

    // get the actual unitTxs
    List<UnitTx> actual = txTransformer.toAssetPortfolioTx(tradeAllocs);

    // These fields are based off variable data in the DB and so can't be checked "nominal",
    // "price", "tradeDate", "paymentDate"
    assertThat(pcfTpcfNewMoney).isEqualToIgnoringGivenFields(actual.get(0),
        "nominal", "price", "tradeDate", "paymentDate");
    assertThat(pcfTpcfRebal).isEqualToIgnoringGivenFields(actual.get(1),
        "nominal", "price", "tradeDate", "paymentDate");
  }

  @Test
  public void toLiabilityPortfolio() {

    // Setup input data. 2 X pcf:newMoney, 1 X pcf:rebal
    List<TradeAlloc> tradeAllocs = Arrays.asList(newPcfTpcfNewMoney(),
        newPcfTpcfNewMoney(), newPcfTpcfRebal());

    // setup expected results
    UnitTx pcfNewMoney =
        new UnitTx("PCF", "L-C-PCF", "IssueFunds", "Fin calc", BigDecimal.ZERO,
            BigDecimal.ZERO, LocalDate.now(), LocalDate.now().plusDays(1),
            "ILAUTE-01", "UTE EXCH", "15328", 13, "ILIM UTE");
    UnitTx pcfRebal =
        new UnitTx("PCF", "L-C-PCF", "IssueFunds", "Fin calc", BigDecimal.ZERO,
            BigDecimal.ZERO, LocalDate.now(), LocalDate.now().plusDays(1),
            "ILAUTE-01", "UTE EXCH", "15328", 1, "ILIM UTE");

    // get the actual unitTxs
    List<UnitTx> actual = txTransformer.toLiabilityPortfolioTx(tradeAllocs);

    // These fields are based off variable data in the DB and so can't be checked "nominal",
    // "price", "tradeDate", "paymentDate"
    assertThat(pcfNewMoney).isEqualToIgnoringGivenFields(actual.get(0),
        "nominal", "price", "tradeDate", "paymentDate");
    assertThat(pcfRebal).isEqualToIgnoringGivenFields(actual.get(1), "nominal",
        "price", "tradeDate", "paymentDate");
  }

  @Test
  public void toTreasuryTx() {

    // Setup input data. 2 X ipaina:newMoney, 1 X ipaipe:rebal, 1 X tpcf:rebal
    List<TradeAlloc> tradeAllocs = Arrays.asList(newPpcfIpainaNewMoney(),
        newPpcfIpainaNewMoney(), newPpcfIpaipeNewMoney(), newPcfTpcfRebal());

    // setup expected results
    CashTx ipainaNewMoney =
        new CashTx("APIPAINA", "A-ITRESX00", LocalDate.now(), "ChargeCash",
            BigDecimal.ONE, LocalDate.now().plusDays(1), "TRE-A-IINAEX00",
            "Fin calc", "UTE_TRES", 1, -1);
    CashTx ipaipeRebal = new CashTx("APIPAIPE", "A-ITRESX00", LocalDate.now(),
        "ChargeCash", BigDecimal.ONE, LocalDate.now().plusDays(1),
        "TRE-A-IIPEXX00", "Fin calc", "UTE_TRES", 1, -1);

    // get the actual cashTxs
    List<CashTx> actual = txTransformer.toTreasuryTx(tradeAllocs);

    // These fields are based off variable data in the DB and so can't be checked "nominal",
    // "tradeDate", "paymentDate"
    assertThat(actual.get(0)).isEqualToIgnoringGivenFields(ipainaNewMoney,
        "tradeDate", "nominal", "paymentDate");
    assertThat(actual.get(1)).isEqualToIgnoringGivenFields(ipaipeRebal,
        "tradeDate", "nominal", "paymentDate");
  }

  @Test
  public void toFinancialSeparationTx() {

    // Setup input data. 2 X lob22:newMoney, 1 X lob22:rebal, 1 X lob-1:rebal
    List<TradeAlloc> tradeAllocs = Arrays.asList(newPcfTpcfNewMoney(),
        newPcfTpcfNewMoney(), newPcfTpcfRebal(), newTpcfPpcfRebal());

    // setup expected results
    CashTx lob22NewMoney = new CashTx("9ALM1185", "A-ITRESX00", LocalDate.now(),
        "ChargeCash", BigDecimal.ONE, LocalDate.now().plusDays(1),
        "ITRESX00-EUR-07", "Fin calc", "UTE_TRES", 13, 22);
    CashTx lob22Rebal = new CashTx("9ALM1185", "A-ITRESX00", LocalDate.now(),
        "ChargeCash", BigDecimal.ONE, LocalDate.now().plusDays(1),
        "ITRESX00-EUR-07", "Fin calc", "UTE_TRES", 1, 22);

    // get the actual cashTxs
    List<CashTx> actual = txTransformer.toFinancialSeparationTx(tradeAllocs);

    // These fields are based off variable data in the DB and so can't be checked "nominal",
    // "tradeDate", "paymentDate"
    assertThat(actual.get(0)).isEqualToIgnoringGivenFields(lob22NewMoney,
        "tradeDate", "nominal", "paymentDate");
    assertThat(actual.get(1)).isEqualToIgnoringGivenFields(lob22Rebal,
        "tradeDate", "nominal", "paymentDate");
  }

  @Test
  public void toTreasuryIlimTx() {

    // Setup input data. 1 X lob22:newMoney, 1 X lob22:rebal, 1 X lob999:rebal
    List<TradeAlloc> lob22TradeAllocs =
        Arrays.asList(newPcfTpcfNewMoney(), newPcfTpcfRebal());
    List<CashTx> findSepCashTxs =
        txTransformer.toFinancialSeparationTx(lob22TradeAllocs);
    CashTx lob999CashTx = new CashTx(null, null, null, null, null, null, null,
        null, null, 0, 999);
    findSepCashTxs.add(lob999CashTx);

    // setup expected results
    CashTx lob22NewMoney = new CashTx("9ALM1002", "A-ILIMXX00", LocalDate.now(),
        "CreditCash", BigDecimal.ONE, LocalDate.now().plusDays(1),
        "ILIMXX00-EUR-01", "Fin calc", "UTE_TRES", 13, 22);
    CashTx lob22Rebal = new CashTx("9ALM1002", "A-ILIMXX00", LocalDate.now(),
        "CreditCash", BigDecimal.ONE, LocalDate.now().plusDays(1),
        "ILIMXX00-EUR-01", "Fin calc", "UTE_TRES", 1, 22);

    // get the actual cashTxs
    List<CashTx> actual = txTransformer.toTreasuryIlimTx(findSepCashTxs);

    // These fields are based off variable data in the DB and so can't be checked "nominal",
    // "tradeDate", "paymentDate"
    assertThat(actual.get(0)).isEqualToIgnoringGivenFields(lob22NewMoney,
        "tradeDate", "nominal", "paymentDate");
    assertThat(actual.get(1)).isEqualToIgnoringGivenFields(lob22Rebal,
        "tradeDate", "nominal", "paymentDate");
  }
}
