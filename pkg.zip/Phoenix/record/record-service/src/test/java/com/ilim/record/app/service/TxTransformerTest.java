package com.ilim.record.app.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import static com.ilim.record.TestData.TradeAllocs.newPcfTpcfNewMoney;
import static com.ilim.record.TestData.TradeAllocs.newPcfTpcfRebal;

import com.ilim.record.app.config.SpringTestConfig;
import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.domain.model.UnitTx;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringTestConfig.class)
public class TxTransformerTest {

  @Rule
  @Inject
  public TestRule logger;

  @Inject
  public TxTransformer txTransformer;

  @Test
  public void toAssetPortfolio() {

    // Setup input data. 2 X pcf:tpc:newMoney, 2 X pcf:tpc:rebal
    List<TradeAlloc> tradeAllocs = Arrays.asList(newPcfTpcfNewMoney(),
        newPcfTpcfNewMoney(), newPcfTpcfRebal(), newPcfTpcfRebal());

    // setup expected results
    UnitTx pcfTpcfNewMoney =
        new UnitTx("A-T-PCF", "A-C-PCF", "Buy", "Fin calc", BigDecimal.ZERO,
            BigDecimal.ZERO, LocalDate.now(), LocalDate.now().plusDays(1),
            "ILAUTE-01", "UTE EXCH", "15328", 13, "ILIM UTE");
    UnitTx pcfTpcfRebal =
        new UnitTx("A-T-PCF", "A-C-PCF", "Buy", "Fin calc", BigDecimal.ZERO,
            BigDecimal.ZERO, LocalDate.now(), LocalDate.now().plusDays(1),
            "ILAUTE-01", "UTE EXCH", "15328", 1, "ILIM UTE");
    List<UnitTx> expected = Arrays.asList(pcfTpcfNewMoney, pcfTpcfRebal);

    // get the actual unitTxs
    List<UnitTx> actual = txTransformer.toAssetPortfolioTx(tradeAllocs);

    // These fields are based off variable data in the DB and so can't be checked "nominal", "price", "tradeDate", "paymentDate"
    assertThat(expected.get(0)).isEqualToIgnoringGivenFields(actual.get(0),
        "nominal", "price", "tradeDate", "paymentDate");
    assertThat(expected.get(1)).isEqualToIgnoringGivenFields(actual.get(1),
        "nominal", "price", "tradeDate", "paymentDate");
  }

  @Test
  public void toLiabilityPortfolio() {
    txTransformer.toAssetPortfolioTx(new ArrayList<TradeAlloc>());
    assertTrue(true);
  }
}
