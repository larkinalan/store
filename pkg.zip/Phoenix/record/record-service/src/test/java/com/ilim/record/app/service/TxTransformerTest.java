package com.ilim.record.app.service;

import static org.junit.Assert.assertTrue;

import com.ilim.record.app.config.SpringTestConfig;
import com.ilim.record.domain.model.TradeAlloc;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;

import javax.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringTestConfig.class)
public class TxTransformerTest {

  @Rule
  @Inject
  public TestRule logger;
  
  @Inject
  public TxTransformer txTransformer;
  
  @Test
  public void toAssetPortfolio(){
    txTransformer.toAssetPortfolioTx(new ArrayList<TradeAlloc>());
    assertTrue(true);
  }
}
