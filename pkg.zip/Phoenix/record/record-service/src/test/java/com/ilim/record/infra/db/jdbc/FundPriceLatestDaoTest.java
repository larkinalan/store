package com.ilim.record.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.domain.model.PriceType;
import com.ilim.record.TestData;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.FundPriceLatest;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.inject.Inject;

public class FundPriceLatestDaoTest extends JdbcDaoTestSupport {

  @Inject
  private FundPriceLatestDao fundPriceLatestDao;
  
  @Test
  public void findByIdAndType(){
    
    Fund fund = TestData.Funds.TPCF;
    PriceType priceType = PriceType.UNIT_TRANSACTION;
    LocalDate priceDate = LocalDate.now();
    BigDecimal closingPrice = new BigDecimal("1.1234");
    FundPriceLatest expected = new FundPriceLatest(fund.getId(), priceType, priceDate, closingPrice);
    
    FundPriceLatest actual = fundPriceLatestDao.findByIdAndType(fund.getId(), priceType);
    
    assertThat(expected).isEqualToIgnoringGivenFields(actual, "priceDate", "closingPrice");
    assertThat(expected.getPriceDate()).isNotNull();
    assertThat(expected.getClosingPrice()).isNotNull();
  }
}
