package com.ilim.record.domain.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.ilim.record.TestData;
import org.junit.Test;

public class TradeAllocTest {

  @Test
  public void testEquals(){
    TradeAlloc tradeAllocA = TestData.TradeAllocs.newPcfTpcfNewMoney();
    TradeAlloc tradeAllocB = TestData.TradeAllocs.newPcfTpcfNewMoney();
    TradeAlloc tradeAllocC = TestData.TradeAllocs.newPcfTpcfRebal();
    
    assertTrue(tradeAllocA.equals(tradeAllocA));
    assertFalse(tradeAllocA.equals(tradeAllocB));
    assertFalse(tradeAllocA.equals(tradeAllocC));
    assertFalse(tradeAllocB.equals(tradeAllocC));
  }
  
  @Test
  public void testHashcode(){
    TradeAlloc tradeAllocA = TestData.TradeAllocs.newPcfTpcfNewMoney();
    TradeAlloc tradeAllocB = TestData.TradeAllocs.newPcfTpcfRebal();
    
    assertThat(tradeAllocA.hashCode()).isEqualTo(tradeAllocA.hashCode());
    assertThat(tradeAllocA.hashCode()).isNotEqualTo(tradeAllocB.hashCode());
  }
}
