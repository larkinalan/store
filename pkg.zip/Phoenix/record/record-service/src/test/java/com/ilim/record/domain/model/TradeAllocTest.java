package com.ilim.record.domain.model;

import static com.ilim.record.TestData.TradeAllocs.RecordableTa.newPcfTpcfNewMoney;
import static com.ilim.record.TestData.TradeAllocs.RecordableTa.newPcfTpcfRebal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


import org.junit.Test;

public class TradeAllocTest {

  @Test
  public void testEquals() {
    TradeAlloc tradeAllocA = newPcfTpcfNewMoney();
    TradeAlloc tradeAllocB = newPcfTpcfNewMoney();
    TradeAlloc tradeAllocC = newPcfTpcfRebal();

    assertTrue(tradeAllocA.equals(tradeAllocA));
    assertFalse(tradeAllocA.equals(tradeAllocB));
    assertFalse(tradeAllocA.equals(tradeAllocC));
    assertFalse(tradeAllocB.equals(tradeAllocC));
  }

  @Test
  public void testHashcode() {
    TradeAlloc tradeAllocA = newPcfTpcfNewMoney();
    TradeAlloc tradeAllocB = newPcfTpcfRebal();

    assertThat(tradeAllocA.hashCode()).isEqualTo(tradeAllocA.hashCode());
    assertThat(tradeAllocA.hashCode()).isNotEqualTo(tradeAllocB.hashCode());
  }
}
