package com.ilim.record.web.resources;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.record.web.datatype.TradeAllocData;

import org.junit.Ignore;
import org.junit.Test;

import java.math.BigDecimal;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;

import javax.ws.rs.core.Response;

public class RecordModelResourceTest extends JerseySpringTestSupport {

  protected WebTarget recordModelResource() {
    return target("model/allocations");
  }

  @Ignore
  @Test
  public void record() {
    Entity<TradeAllocData> entity = Entity.json(getNewTradeData());
    Response response =
        recordModelResource().path("record").request().post(entity);

    assertThat(response.getStatus())
        .isEqualTo(Response.ok().build().getStatus());
  }

  protected TradeAllocData getNewTradeData() {
    return new TradeAllocData(1, 22, 333, new BigDecimal("250000.00"),
        "REBALANCE");
  }
}
