package com.ilim.record.domain.model.tx;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

public class CashTxTest {

  @Test
  public void testCashTx() {

    String securityId = "a";
    String portfolioId = "b";
    LocalDate tradeDate = LocalDate.MIN;
    BigDecimal nominal = new BigDecimal("1.1");
    String txCode = "c";
    LocalDate paymentDate = LocalDate.MAX;
    String bankAccount = "d";
    String requestedStatus = "e";
    String txOriginId = "f";
    int txNumOriginSystem = 1;
    int unitOrderTypeId = 2;
    int lobId = 3;

    CashTx cashTx = new CashTx(securityId, portfolioId, tradeDate, txCode,
        nominal, paymentDate, bankAccount, requestedStatus, txOriginId,
        txNumOriginSystem, unitOrderTypeId, lobId);

    assertThat(cashTx.getSecurityId()).isEqualTo(securityId);
    assertThat(cashTx.getPortfolioId()).isEqualTo(portfolioId);
    assertThat(cashTx.getTradeDate()).isEqualTo(tradeDate);
    assertThat(cashTx.getNominal()).isEqualTo(nominal);
    assertThat(cashTx.getTxCode()).isEqualTo(txCode);
    assertThat(cashTx.getPaymentDate()).isEqualTo(paymentDate);
    assertThat(cashTx.getBankAccount()).isEqualTo(bankAccount);
    assertThat(cashTx.getRequestedStatus()).isEqualTo(requestedStatus);
    assertThat(cashTx.getTxOriginId()).isEqualTo(txOriginId);
    assertThat(cashTx.getTxNumOriginSystem()).isEqualTo(txNumOriginSystem);
    assertThat(cashTx.getUnitOrderTypeId()).isEqualTo(unitOrderTypeId);
    assertThat(cashTx.getLobId()).isEqualTo(lobId);
  }
}
