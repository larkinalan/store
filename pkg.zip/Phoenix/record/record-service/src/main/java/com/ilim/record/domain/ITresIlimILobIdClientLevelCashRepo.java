package com.ilim.record.domain;

import com.ilim.record.domain.model.TresIlimLobIdClientLevelCash;

public interface ITresIlimILobIdClientLevelCashRepo {

  public TresIlimLobIdClientLevelCash findTresIlimLobClientCashByLobId(
      int lobId);
}
