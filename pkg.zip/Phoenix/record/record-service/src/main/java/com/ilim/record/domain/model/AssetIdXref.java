package com.ilim.record.domain.model;

public class AssetIdXref {

  private int fundId;
  private String externalId;
  private ExternalIdType externalIdType;
  
  public AssetIdXref(int fundId, String externalId,
      ExternalIdType externalIdType) {
    
    this.fundId = fundId;
    this.externalId = externalId;
    this.externalIdType = externalIdType;
  }

  public int getFundId() {
    return fundId;
  }

  public String getExternalId() {
    return externalId;
  }

  public ExternalIdType getExternalIdType() {
    return externalIdType;
  }

  public enum ExternalIdType {

    SCD_PORTFOLIO_ID(6), SCD_FUND_CERT_ID(12), SCD_LIABILITY_PORTFOLIO_ID(13);

    private int id;

    ExternalIdType(int id) {
      this.id = id;
    }

    public int id() {
      return id;
    }
  }
}
