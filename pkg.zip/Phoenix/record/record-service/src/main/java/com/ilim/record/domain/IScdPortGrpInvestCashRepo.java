package com.ilim.record.domain;

import com.ilim.commons.domain.model.Currency;

public interface IScdPortGrpInvestCashRepo {

  public String findPortfolioOwnerId(int fundId, Currency baseCurrency);
}
