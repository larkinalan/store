package com.ilim.record.domain.model;

public enum ScdTxType {

  NORMAL_APPROPS(1), MGMT_CHRGS(3), UNIT_ZAP(6), UNIT_UWP_ZAP(12), REBALANCE(
      13);

  private int id;

  ScdTxType(int id) {
    this.id = id;
  }

  public int getId() {
    return id;
  }
  
  public static ScdTxType fromId(int id){
    
    for(ScdTxType type : ScdTxType.values()){
      if(type.id == id){
        return type;
      }
    }
    
    throw new IllegalArgumentException("Unknown ScdTxType id: " + id);
  }
}
