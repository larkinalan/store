package com.ilim.record.domain.model.tx;

import java.math.BigDecimal;
import java.time.LocalDate;

public class UnitTx {

  private final String securityId;
  private final String portfolioId;
  private final String businessTxCode;
  private final String requestedStatus;
  private final BigDecimal nominal;
  private final BigDecimal price;
  private final LocalDate tradeDate;
  private final LocalDate paymentDate;
  private final String counterParty;
  private final int txNumOriginSystem;
  private final String exchange;
  private final String custody;
  private final int txFreeCode;
  private final String txOriginId;
  private int batchNumber;

  public UnitTx(String securityId, String portfolioId, String businessTxCode,
      String requestedStatus, BigDecimal nominal, BigDecimal price,
      LocalDate tradeDate, LocalDate paymentDate, String counterParty,
      int txNumOriginSystem, String exchange, String custody, int txFreeCode,
      String txOriginId) {
    
    this.securityId = securityId;
    this.portfolioId = portfolioId;
    this.businessTxCode = businessTxCode;
    this.requestedStatus = requestedStatus;
    this.nominal = nominal;
    this.price = price;
    this.tradeDate = tradeDate;
    this.paymentDate = paymentDate;
    this.counterParty = counterParty;
    this.txNumOriginSystem = txNumOriginSystem;
    this.exchange = exchange;
    this.custody = custody;
    this.txFreeCode = txFreeCode;
    this.txOriginId = txOriginId;
  }
  
  public void setBatchNumber(int batchNumber){
    this.batchNumber = batchNumber;
  }

  public String getSecurityId() {
    return securityId;
  }

  public String getPortfolioId() {
    return portfolioId;
  }

  public String getBusinessTxCode() {
    return businessTxCode;
  }

  public String getRequestedStatus() {
    return requestedStatus;
  }

  public BigDecimal getNominal() {
    return nominal;
  }

  public BigDecimal getPrice() {
    return price;
  }

  public LocalDate getTradeDate() {
    return tradeDate;
  }

  public LocalDate getPaymentDate() {
    return paymentDate;
  }

  public String getCounterParty() {
    return counterParty;
  }

  public int getTxNumOriginSystem() {
    return txNumOriginSystem;
  }

  public String getExchange() {
    return exchange;
  }

  public String getCustody() {
    return custody;
  }

  public int getTxFreeCode() {
    return txFreeCode;
  }

  public String getTxOriginId() {
    return txOriginId;
  }

  public int getBatchNumber() {
    return batchNumber;
  }
}
