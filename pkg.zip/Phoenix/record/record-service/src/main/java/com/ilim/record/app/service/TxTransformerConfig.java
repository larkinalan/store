package com.ilim.record.app.service;

import static com.ilim.commons.conf.AppConfig.settings;

import java.util.List;

public class TxTransformerConfig {

  // Common constants
  public static final String REQUESTED_STATUS =
      settings().getString("tx.transformer.requestedstatus");

  // Unit Tx Constants
  public static final String COUNTER_PARTY =
      settings().getString("tx.transformer.counterparty");
  public static final String EXCHANGE =
      settings().getString("tx.transformer.exchange");
  public static final String CUSTODY =
      settings().getString("tx.transformer.custody");
  public static final String BUS_TX_BUY =
      settings().getString("tx.transformer.bustxbuy");
  public static final String BUS_TX_SELL =
      settings().getString("tx.transformer.bustxsell");
  public static final String BUS_TX_REDEMPTION_FUNDS =
      settings().getString("tx.transformer.bustxredemptionfunds");
  public static final String BUS_TX_ISSUE_FUNDS =
      settings().getString("tx.transformer.bustxissuefunds");
  public static final String UNIT_TX_ORIGIN_ID =
      settings().getString("tx.transformer.unittxoriginid");

  // Cash Tx Constants
  public static final String TREASURY_SEC_ID_PREFIX =
      settings().getString("tx.transformer.treasurysecidprefix");
  public static final String TX_CODE_CREDIT_CASH =
      settings().getString("tx.transformer.txcodecreditcash");
  public static final String TX_CODE_CHARGE_CASH =
      settings().getString("tx.transformer.txcodechargecash");
  public static final String TREASURY_BANK_ACC_PREFIX =
      settings().getString("tx.transformer.treasurybankaccprefix");
  public static final String CASH_TX_ORIGIN_ID =
      settings().getString("tx.transformer.cashtxoriginid");
  public static final List<String> TREASURY_ILIM_TX_LOB_IDS =
      settings().getStringList("tx.transformer.treasuryilimtxlobids");
}
