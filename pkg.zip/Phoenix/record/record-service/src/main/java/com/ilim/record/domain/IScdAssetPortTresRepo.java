package com.ilim.record.domain;

import com.ilim.commons.domain.model.Currency;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.ScdAssetPortTres;

public interface IScdAssetPortTresRepo {

  public ScdAssetPortTres findByFund(Fund fund);
  
  public ScdAssetPortTres findDefaultByCurrency(Currency currency);
}
