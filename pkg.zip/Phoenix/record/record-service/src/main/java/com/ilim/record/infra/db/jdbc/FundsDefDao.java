package com.ilim.record.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.record.domain.IFundsDefRepo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import javax.sql.DataSource;

@Repository
public class FundsDefDao extends NamedParameterJdbcDaoSupport implements IFundsDefRepo {

  private static final Logger log =
      LoggerFactory.getLogger(FundsDefDao.class);
  
  @Inject
  public FundsDefDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }
  
  @Override
  public String findScdFundName(int fundId) {
    
    log.info("findScdFundName ({})", fundId);
    final String sql = SQL.select_from_a_funds_def_by_ilim_id;
    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("fundId", fundId);

    final String result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return rs.getString("fund");
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(
          String.format("Error in findScdFundName %s", fundId),
          ex);
    }

    return result;
  }

}
