package com.ilim.record.app.service;

import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.domain.model.tx.CashTx;
import com.ilim.record.domain.model.tx.UnitTx;

import java.util.List;

public interface ITxTransformer {

  public List<UnitTx> toAssetPortfolioTx(List<TradeAlloc> tradeAllocs);
  
  public List<UnitTx> toLiabilityPortfolioTx(List<TradeAlloc> tradeAllocs);
  
  public List<CashTx> toTreasuryTx(List<TradeAlloc> tradeAllocs);
  
  public List<CashTx> toFinancialSeparationTx(List<TradeAlloc> tradeAllocs);
  
  public List<CashTx> toTreasuryIlimTx(List<CashTx> finSepTxs);
}
