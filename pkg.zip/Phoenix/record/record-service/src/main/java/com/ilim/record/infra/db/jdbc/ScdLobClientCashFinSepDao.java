package com.ilim.record.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.record.domain.IScdLobClientCashFinSepRepo;
import com.ilim.record.domain.model.ScdLobClientCashFinSep;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.inject.Inject;
import javax.sql.DataSource;

public class ScdLobClientCashFinSepDao extends NamedParameterJdbcDaoSupport
    implements IScdLobClientCashFinSepRepo {

  private static final Logger log =
      LoggerFactory.getLogger(ScdLobClientCashFinSepDao.class);

  @Inject
  public ScdLobClientCashFinSepDao(DataSource dataSource) {

    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  public ScdLobClientCashFinSep findScdLobClientCashFinSep(int lobId) {

    log.info("findScdLobClientCashFinSep ({})", lobId);
    final String sql = SQL.select_from_lob_client_cash_finsep_by_lob_id;
    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("lobId", lobId);

    final ScdLobClientCashFinSep result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toLobIdClientLevelCash(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findScdLobClientCashFinSep " + lobId,
          ex);
    }

    return result;
  }

  private ScdLobClientCashFinSep toLobIdClientLevelCash(ResultSet rs) {

    try {
      String portfolioOwnerId = rs.getString("portfolio_owner_id");
      String appAlmNumber = rs.getString("app_alm_no");
      String mcAlmNum = rs.getString("mc_alm_no");
      String appBankAcc = rs.getString("app_bank_account");
      String mcBankAcc = rs.getString("mc_bank_account");

      return new ScdLobClientCashFinSep(null, portfolioOwnerId, appAlmNumber,
          mcAlmNum, appBankAcc, mcBankAcc);

    } catch (SQLException e) {
      throw new AppSqlException(
          "Error mapping sql result set to ScdLobClientCashFinSep!", e);
    }
  }
}
