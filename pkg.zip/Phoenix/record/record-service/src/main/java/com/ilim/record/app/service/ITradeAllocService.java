package com.ilim.record.app.service;

import com.ilim.record.domain.model.TradeAlloc;

import java.util.List;

public interface ITradeAllocService {

  public List<TradeAlloc> processTradeAllocs(List<TradeAlloc> tradeAllocs);

  public List<TradeAlloc> generateRecordableTradeAllocs(
      List<TradeAlloc> crimsTAs);
}
