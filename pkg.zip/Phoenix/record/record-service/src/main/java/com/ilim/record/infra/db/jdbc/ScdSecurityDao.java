package com.ilim.record.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.record.domain.IScdSecurityRepo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import javax.inject.Inject;
import javax.sql.DataSource;

public class ScdSecurityDao extends NamedParameterJdbcDaoSupport implements IScdSecurityRepo {

  private static final Logger log =
      LoggerFactory.getLogger(ScdSecurityDao.class);
  
  @Inject
  public ScdSecurityDao(DataSource dataSource) {

    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }
  
  @Override
  public boolean existsSecurity(String secShortName) {
    
    log.info("existsSecurity ({})", secShortName);
    final String sql = SQL.select_from_a_secs_by_short_name_and_instr_type;
    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("securityName", secShortName);

    final String result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return rs.getString("sec_short_name");
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(
          String.format("Error in existsSecurity %s", secShortName),
          ex);
    }

    return (result != null) ? true : false;
  }

}
