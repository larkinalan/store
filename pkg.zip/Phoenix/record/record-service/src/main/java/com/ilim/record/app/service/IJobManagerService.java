package com.ilim.record.app.service;

import com.ilim.record.domain.model.CashTx;
import com.ilim.record.domain.model.UnitTx;

import java.util.List;

public interface IJobManagerService {

  public void submitUnitTxs(List<UnitTx> unitTxs);
  
  public void submitCashTxs(List<CashTx> cashTxs);
}
