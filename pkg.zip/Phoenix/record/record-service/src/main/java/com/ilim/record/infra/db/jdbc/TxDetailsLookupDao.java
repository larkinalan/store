package com.ilim.record.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.record.domain.ITxDetailsLookupRepo;
import com.ilim.record.domain.model.ScdLobClientCashFinSep;
import com.ilim.record.domain.model.ScdLobClientCashTresIlim;
import com.ilim.record.domain.model.ScdPortGrpInvestCash;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.inject.Inject;
import javax.sql.DataSource;

public class TxDetailsLookupDao extends NamedParameterJdbcDaoSupport implements ITxDetailsLookupRepo {

  private static final Logger log =
      LoggerFactory.getLogger(TxDetailsLookupDao.class);
  
  @Inject
  public TxDetailsLookupDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }
  
  /**
   * Find the portfolioOwnerId for the given fundId & currency combination
   */
  public String findPortfolioOwnerId(int fundId, String baseCurrency) {

    log.info("findPortfolioOwnerId ({}, {})", fundId, baseCurrency);
    final String sql = SQL.select_from_scd_portgrp_invest_lvl_cash;
    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("fundId", fundId).addValue("currency", baseCurrency);

    final ScdPortGrpInvestCash result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toScdPortGrpInvestCash(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(String.format(
          "Error in findPortfolioOwnerId %s %s", fundId, baseCurrency), ex);
    }

    return result.getPortfolioOwnerId();
  }

  private ScdPortGrpInvestCash toScdPortGrpInvestCash(ResultSet rs) {

    try {
      String portfolioOwnerId = rs.getString("portfolio_owner_id");

      return new ScdPortGrpInvestCash(null, portfolioOwnerId, null);

    } catch (SQLException e) {
      throw new AppSqlException(
          "Error mapping sql result set to ScdPortGrpInvestCash!", e);
    }
  }
  
  /**
   * Find ScdLobClientCashFinSep by Line of Business Id
   */
  public ScdLobClientCashFinSep findScdLobClientCashFinSep(int lobId) {

    log.info("findScdLobClientCashFinSep ({})", lobId);
    final String sql = SQL.select_from_lob_client_cash_finsep_by_lob_id;
    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("lobId", lobId);

    final ScdLobClientCashFinSep result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toLobIdClientLevelCash(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findScdLobClientCashFinSep " + lobId,
          ex);
    }

    return result;
  }

  private ScdLobClientCashFinSep toLobIdClientLevelCash(ResultSet rs) {

    try {
      String lobId = rs.getString("scd_lob_id");
      String portfolioOwnerId = rs.getString("portfolio_owner_id");
      String appAlmNumber = rs.getString("app_alm_no");
      String mcAlmNum = rs.getString("mc_alm_no");
      String appBankAcc = rs.getString("app_bank_account");
      String mcBankAcc = rs.getString("mc_bank_account");

      return new ScdLobClientCashFinSep(lobId, portfolioOwnerId, appAlmNumber,
          mcAlmNum, appBankAcc, mcBankAcc);

    } catch (SQLException e) {
      throw new AppSqlException(
          "Error mapping sql result set to ScdLobClientCashFinSep!", e);
    }
  }
  
  /**
   * Find ScdLobClientCashTresIlim by Line of Business Id
   */
  public ScdLobClientCashTresIlim findScdLobClientCashTresIlim(int lobId) {

    log.info("findScdLobClientCashTresIlim ({})", lobId);
    final String sql = SQL.select_from_lob_client_cash_tresilim_by_lob_id;
    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("lobId", lobId);

    final ScdLobClientCashTresIlim result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toTresIlimLobIdClientLevelCash(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(
          "Error in findScdLobClientCashTresIlim " + lobId, ex);
    }

    return result;
  }

  private ScdLobClientCashTresIlim toTresIlimLobIdClientLevelCash(
      ResultSet rs) {

    try {
      String scdLobId = rs.getString("scd_lob_id");
      String tresIlim = rs.getString("tresilim");
      String appAlmNumber = rs.getString("app_alm_no");
      String mcAlmNum = rs.getString("mc_alm_no");
      String appBankAcc = rs.getString("app_bank_account");
      String mcBankAcc = rs.getString("mc_bank_account");

      return new ScdLobClientCashTresIlim(scdLobId, tresIlim, appAlmNumber,
          mcAlmNum, appBankAcc, mcBankAcc);

    } catch (SQLException e) {
      throw new AppSqlException(
          "Error mapping sql result set to ScdLobClientCashTresIlim!", e);
    }
  }
}
