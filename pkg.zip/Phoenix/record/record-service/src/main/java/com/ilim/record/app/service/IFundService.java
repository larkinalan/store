package com.ilim.record.app.service;

import com.ilim.record.domain.model.Fund;

import java.util.List;
import java.util.Map;

public interface IFundService {

  public Map<Integer, Fund> findFundsByIds(List<Integer> fundIds) throws Exception;
}
