package com.ilim.record.app.service;

import com.ilim.record.app.util.TradeAllocUtils;
import com.ilim.record.app.util.TradeAllocUtils.GroupBy;
import com.ilim.record.domain.IFundPriceLatestRepo;
import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.domain.model.TradeAlloc.Type;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class TradeAllocService implements ITradeAllocService {

  private IForecastService forecastService;
  private IFundPriceLatestRepo fundPriceLatestRepo;

  @Inject
  public TradeAllocService(IForecastService forecastService,
      IFundPriceLatestRepo fundPriceLatestRepo) {
    this.forecastService = forecastService;
    this.fundPriceLatestRepo = fundPriceLatestRepo;
  }

  public List<TradeAlloc> processTradeAllocs(List<TradeAlloc> tradeAllocs) {
    return null;
  }

  public List<TradeAlloc> generateRecordableTradeAllocs(
      List<TradeAlloc> crimsTAs) {

    // list to return
    List<TradeAlloc> recordableTAs = new ArrayList<>();

    // group and merge the tradeAllocs by fund:holding
    GroupBy groupBy = new GroupBy(true, true, false, false);
    List<TradeAlloc> mergedCrimsTAs =
        TradeAllocUtils.groupAndMergeTradeAllocs(crimsTAs, groupBy);

    // get the unrecorded forecast tradeAllocs
    List<TradeAlloc> unRecdTAs = findUnRecordedTradeAllocs(mergedCrimsTAs);

    // group and merge the unrecdTAs by fund:holding
    List<TradeAlloc> mergedUnRecdTAs =
        TradeAllocUtils.groupAndMergeTradeAllocs(unRecdTAs, groupBy);

    // get rebalance tradeaAllocs
    List<TradeAlloc> rebalanceTAs =
        getRebalTradeAllocs(mergedCrimsTAs, mergedUnRecdTAs);

    // add unRecdTAs and rebalTAs to list of recordableTAs
    recordableTAs.addAll(unRecdTAs);
    recordableTAs.addAll(rebalanceTAs);

    return recordableTAs;
  }

  /**
   * Find all 'unrecorded forecast trade allocs' for the fundId & sendToAccDate 
   * combinations contained in each tradeAlloc in the list
   * @param tradeAllocs List of crims trade allocs
   * @return List of unrecorded forecsat trade allocs
   */
  private List<TradeAlloc> findUnRecordedTradeAllocs(
      List<TradeAlloc> tradeAllocs) {

    List<TradeAlloc> unRecdTAs = new ArrayList<>();
    // add any unrecorded forecast tradeAllocs associated with this tradeAlloc
    for (TradeAlloc tradeAlloc : tradeAllocs) {
      unRecdTAs.addAll(forecastService.findUnrecordedForecasts(tradeAlloc));
    }

    return unRecdTAs;
  }

  /**
   * Compare the crimsTAs with the unRecdTAs. Return any differences between the
   * two as new rebalance TAs
   * @param mergedCrimsTAs
   * @param mergedUnRecdTAs
   * @return List of trade allocs of type 'rebalance'
   */
  private List<TradeAlloc> getRebalTradeAllocs(List<TradeAlloc> mergedCrimsTAs,
      List<TradeAlloc> mergedUnRecdTAs) {

    // List to return
    List<TradeAlloc> rebalTAs = new ArrayList<>();

    // loop through each mergedTA
    for (TradeAlloc crimsTA : mergedCrimsTAs) {

      // try find a matching unRecdTA
      TradeAlloc matchingTA = null;
      for (TradeAlloc unRecdTa : mergedUnRecdTAs) {
        if (crimsTA.getFund().getId().equals(unRecdTa.getFund().getId())
            && crimsTA.getHoldingId() == unRecdTa.getHoldingId()) {
          matchingTA = unRecdTa;
          break;
        }
      }

      // if no matching unRecdTA is found, then a rebalTA will be created
      if (matchingTA == null) {
        TradeAlloc rebalTA = new TradeAlloc(0, crimsTA.getFund(),
            crimsTA.getHoldingId(), crimsTA.getCashAmount(), Type.REBALANCE,
            crimsTA.getSendToAccDate(), crimsTA.getRecordOnDate());
        rebalTAs.add(rebalTA);
      } else {
        // if matching unRecdTA found, then check if cashAmounts are different
        BigDecimal cashDiff =
            crimsTA.getCashAmount().subtract(matchingTA.getCashAmount());
        // if the cashAmounts are different then a rebalTA will be created
        if (cashDiff.compareTo(BigDecimal.ZERO) != 0) {
          TradeAlloc rebalTA = new TradeAlloc(0, crimsTA.getFund(),
              crimsTA.getHoldingId(), cashDiff, Type.REBALANCE,
              crimsTA.getSendToAccDate(), crimsTA.getRecordOnDate());
          rebalTAs.add(rebalTA);
        }
      }
    }

    return rebalTAs;
  }
}
