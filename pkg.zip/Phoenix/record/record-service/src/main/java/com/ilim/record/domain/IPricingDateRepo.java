package com.ilim.record.domain;

import java.time.LocalDate;

public interface IPricingDateRepo {

  public LocalDate findCurrentPricingDate();
}
