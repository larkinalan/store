package com.ilim.record.app.conf;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.db.AppSqlException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.sql.SQLException;

import javax.sql.DataSource;

/**
 * Spring standalone / embedded container config.
 *
 * @author Alan Larkin
 */
@Configuration
@EnableTransactionManagement
@Import(SpringConfig.class)
public class SpringStandaloneConfig {

  private static final Logger log =
      LoggerFactory.getLogger(SpringStandaloneConfig.class);

  /** The jdbc Datasource. */
  @Bean
  public DataSource dataSource() {

    final DataSource dataSource;
    final String db = settings().getString("database");

    // Get connection
    if (db.equalsIgnoreCase("fm")) {
      dataSource = oracleConnection(new DriverManagerDataSource());
    } else {
      dataSource = h2Connection(new DriverManagerDataSource());
    }

    // Test connection
    try {
      log.info("Set database connection to "
          + dataSource.getConnection().getMetaData().getURL());
    } catch (SQLException ex) {
      throw new AppSqlException("Failed to connect to database " + db, ex);
    }
    return dataSource;
  }

  /** The spring DataSourceTransactionManager. */
  @Bean
  public PlatformTransactionManager transactionManager(DataSource dataSource) {
    return new DataSourceTransactionManager(dataSource);
  }

  private DataSource oracleConnection(DriverManagerDataSource dataSource) {

    dataSource
        .setDriverClassName(settings().getString("db.jdbc.oracle.driver"));
    dataSource.setUrl(settings().getString("db.fm.url"));
    dataSource.setUsername(settings().getString("db.fm.user"));
    dataSource.setPassword(settings().getString("db.fm.pass"));

    return dataSource;
  }

  private DataSource h2Connection(DriverManagerDataSource dataSource) {

    dataSource.setDriverClassName(settings().getString("db.jdbc.h2.driver"));
    dataSource.setUrl(settings().getString("db.local.url"));
    dataSource.setUsername(settings().getString("db.local.user"));
    dataSource.setPassword(settings().getString("db.local.pass"));

    return dataSource;
  }

}
