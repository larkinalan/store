package com.ilim.record.domain.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class CashTx {

  private final String securityId;
  private final String portfolioId;
  private final LocalDate tradeDate;
  private final String txCode;
  private final BigDecimal nominal;
  private final LocalDate paymentDate;
  private final String bankAccount;
  private final String requestedStatus;
  private final String txOriginId;
  private final int unitOrderTypeId;
  private int batchNumber;
  private int txNumOriginSystem;
  private final transient int lobId;


  public CashTx(String securityId, String portfolioId, LocalDate tradeDate,
      String txCode, BigDecimal nominal, LocalDate paymentDate,
      String bankAccount, String requestedStatus, String txOriginId,
      int unitOrderTypeId, int lobId) {

    this.securityId = securityId;
    this.portfolioId = portfolioId;
    this.tradeDate = tradeDate;
    this.txCode = txCode;
    this.nominal = nominal;
    this.paymentDate = paymentDate;
    this.bankAccount = bankAccount;
    this.requestedStatus = requestedStatus;
    this.txOriginId = txOriginId;
    this.unitOrderTypeId = unitOrderTypeId;
    this.lobId = lobId;
  }

  public String getSecurityId() {
    return securityId;
  }

  public String getPortfolioId() {
    return portfolioId;
  }

  public LocalDate getTradeDate() {
    return tradeDate;
  }

  public String getTxCode() {
    return txCode;
  }

  public BigDecimal getNominal() {
    return nominal;
  }

  public LocalDate getPaymentDate() {
    return paymentDate;
  }

  public String getBankAccount() {
    return bankAccount;
  }

  public String getRequestedStatus() {
    return requestedStatus;
  }

  public String getTxOriginId() {
    return txOriginId;
  }

  public int getUnitOrderTypeId() {
    return unitOrderTypeId;
  }

  public int getBatchNumber() {
    return batchNumber;
  }

  public int getTxNumOriginSystem() {
    return txNumOriginSystem;
  }

  public int getLobId() {
    return lobId;
  }

  // setters
  public void setBatchNumber(int batchNumber) {
    this.batchNumber = batchNumber;
  }

  public void setTxNumOriginSystem(int txNumOriginSystem) {
    this.txNumOriginSystem = txNumOriginSystem;
  }
}
