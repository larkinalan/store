package com.ilim.record.domain;

public interface IFundsDefRepo {

  public String findScdFundName(int fundId);
}
