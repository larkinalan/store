package com.ilim.record.domain.model;

import com.ilim.commons.domain.model.PriceType;

import java.math.BigDecimal;
import java.time.LocalDate;

public class FundPriceLatest {

  private final int ilimId;
  private final PriceType priceType;
  private final LocalDate priceDate;
  private final BigDecimal closingPrice;
  
  
  public FundPriceLatest(int ilimId, PriceType priceType, LocalDate priceDate,
      BigDecimal closingPrice) {
    
    this.ilimId = ilimId;
    this.priceType = priceType;
    this.priceDate = priceDate;
    this.closingPrice = closingPrice;
  }
  
  public int getIlimId() {
    return ilimId;
  }

  public PriceType getPriceType() {
    return priceType;
  }

  public LocalDate getPriceDate() {
    return priceDate;
  }

  public BigDecimal getClosingPrice() {
    return closingPrice;
  }
}
