package com.ilim.record.web.datatype;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

public class TradeAllocData {

  public final int tradeId;
  public final int fundId;
  public final int holdingId;
  public final BigDecimal cashAmount;

  /**
   * Create a TradeData object.
   * @param tradeId
   * @param fundid
   * @param holdingId
   * @param cashAmount
   * @param type
   */
  public TradeAllocData(@JsonProperty("tradeId") int tradeId,
      @JsonProperty("fundid") int fundid,
      @JsonProperty("holdingId") int holdingId,
      @JsonProperty("cashAmount") BigDecimal cashAmount) {

    this.tradeId = tradeId;
    this.fundId = fundid;
    this.holdingId = holdingId;
    this.cashAmount = cashAmount;
  }
}
