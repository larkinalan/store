package com.ilim.record.domain;

public interface IRecordTxNumRepo {

}
