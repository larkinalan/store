package com.ilim.record.domain;

import com.ilim.record.domain.model.ScdLobClientCashFinSep;
import com.ilim.record.domain.model.ScdLobClientCashTresIlim;

public interface ITxDetailsLookupRepo {

  public String findPortfolioOwnerId(int fundId, String baseCurrency);
  
  public ScdLobClientCashFinSep findScdLobClientCashFinSep(int lobId);
  
  public ScdLobClientCashTresIlim findScdLobClientCashTresIlim(int lobId);
}
