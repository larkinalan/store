package com.ilim.record.domain.model;

import com.ilim.commons.domain.model.Currency;

public class ScdAssetPortTres {

  private final String scdAssetPortfolio;
  private final Currency currency;
  private final String appAlmNum;
  private final String mcAlmNum;
  
  
  public ScdAssetPortTres(String scdAssetPortfolio, Currency currency,
      String appAlmNum, String mcAlmNum) {

    this.scdAssetPortfolio = scdAssetPortfolio;
    this.currency = currency;
    this.appAlmNum = appAlmNum;
    this.mcAlmNum = mcAlmNum;
  }


  public String getScdAssetPortfolio() {
    return scdAssetPortfolio;
  }

  public Currency getCurrency() {
    return currency;
  }

  public String getAppAlmNum() {
    return appAlmNum;
  }

  public String getMcAlmNum() {
    return mcAlmNum;
  }
  
}
