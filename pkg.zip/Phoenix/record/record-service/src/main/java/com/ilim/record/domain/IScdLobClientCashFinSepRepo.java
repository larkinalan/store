package com.ilim.record.domain;

import com.ilim.record.domain.model.ScdLobClientCashFinSep;

public interface IScdLobClientCashFinSepRepo {

  public ScdLobClientCashFinSep findScdLobClientCashFinSep(int lobId);
}
