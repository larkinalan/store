package com.ilim.record.domain;

public interface IScdSecurityRepo {

  public boolean existsSecurity(String secShortName);
}
