package com.ilim.record.infra.db.jdbc;

import com.ilim.record.domain.IRecordTxNumRepo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import javax.sql.DataSource;

@Repository
public class RecordTxNumDao extends NamedParameterJdbcDaoSupport implements IRecordTxNumRepo {

  private static final Logger log =
      LoggerFactory.getLogger(RecordTxNumDao.class);

  @Inject
  public RecordTxNumDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  public int findNextRecordTxNum() {
    return 0;
  }

}
