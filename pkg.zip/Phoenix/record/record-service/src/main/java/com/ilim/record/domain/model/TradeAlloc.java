package com.ilim.record.domain.model;

import java.math.BigDecimal;
import java.util.Objects;

public class TradeAlloc {

  private final int tradeId;
  private final Fund fund;
  private final int holdingId;
  private final BigDecimal cashAmount;
  private final Type type;

  public TradeAlloc(int tradeId, Fund fund, int holdingId,
      BigDecimal cashAmount, Type type) {

    this.tradeId = tradeId;
    this.fund = fund;
    this.holdingId = holdingId;
    this.cashAmount = cashAmount;
    this.type = type;
  }

  public int getTradeId() {
    return tradeId;
  }

  public Fund getFund() {
    return fund;
  }

  public int getHoldingId() {
    return holdingId;
  }

  public BigDecimal getCashAmount() {
    return cashAmount;
  }
  
  public Type getType(){
    return type;
  }
  
  @Override
  public boolean equals(Object obj){
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final TradeAlloc other = (TradeAlloc) obj;

    return (this.tradeId == other.tradeId 
        && Objects.equals(this.fund, other.fund) 
        && this.holdingId == other.holdingId 
        && Objects.equals(this.cashAmount, other.cashAmount)
        && Objects.equals(this.type, other.type));
  }
  
  @Override
  public int hashCode() {
    return Objects.hash(tradeId, fund, holdingId, cashAmount, type);
  }

  /**
   * The various possible Types of a TransAlloc
   */
  public enum Type {

    NEW_MONEY(1), MANAGEMENT_CHARGES(3), UNIT_ZAP(6), UWP_ZAP(12), 
    REBALANCE(13);

    private int id;

    private Type(int id) {
      this.id = id;
    }
    
    public int getId(){
      return id;
    }
    
    /**
     * Get a Type corresponding to the name passed in.
     * @param name Type name
     * @return Type
     */
    public static Type fromName(String name) {
      
      for (Type type : Type.values()) {
        if (name.equalsIgnoreCase(type.name())) {
          return type;
        }
      }
      throw new IllegalArgumentException("Unknown Type name: " + name);
    }
  }
}
