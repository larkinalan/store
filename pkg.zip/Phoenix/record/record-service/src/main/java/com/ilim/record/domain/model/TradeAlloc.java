package com.ilim.record.domain.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

public class TradeAlloc {

  private final int orderId;
  private final int tradeId;
  private final int instrId;
  private final Fund fund;
  private final int holdingId;
  private final BigDecimal cashAmount;
  private final Type type;
  private final LocalDate sendToAccDate;
  private final LocalDate recordOnDate; 
  
  /**
   * Create a 'Recordable' TradeAlloc. 
   * The orderId, TradeId, instrId and type are optional fields.
   * 
   * @param orderId
   * @param tradeId
   * @param instrId
   * @param fund
   * @param holdingId
   * @param cashAmount
   * @param type
   * @param sendToAccDate
   * @param recordOnDate
   */
  public TradeAlloc(int orderId, int tradeId, int instrId, Fund fund,
      int holdingId, BigDecimal cashAmount, Type type, LocalDate sendToAccDate,
      LocalDate recordOnDate) {
    
    this.orderId = orderId;
    this.tradeId = tradeId;
    this.instrId = instrId;
    this.fund = fund;
    this.holdingId = holdingId;
    this.cashAmount = cashAmount;
    this.type = type;
    this.sendToAccDate = sendToAccDate;
    this.recordOnDate = recordOnDate;
  }

  /**
   * Create a 'Crims' TradeAlloc. The orderId and tradeId are known. The instrId
   * and type are N/A.
   * 
   * @param orderId
   * @param tradeId
   * @param fund
   * @param holdingId
   * @param cashAmount
   * @param type
   * @param sendToAccDate
   * @param recordOnDate
   */
  public TradeAlloc(int orderId, int tradeId, Fund fund, int holdingId,
      BigDecimal cashAmount, LocalDate sendToAccDate,
      LocalDate recordOnDate) {

    this.orderId = orderId;
    this.tradeId = tradeId;
    this.instrId = 0;
    this.fund = fund;
    this.holdingId = holdingId;
    this.cashAmount = cashAmount;
    this.type = null;
    this.sendToAccDate = sendToAccDate;
    this.recordOnDate = recordOnDate;
  }

  /**
   * Create a 'Forecast' or 'Rebalance' TradeAlloc. 
   * Forecast TA: The orderId and tradeId are N/A. The instrId & type are known.
   * Rebalance TA: The orderId, tradeId and instrId are N/A. The type is known.
   * 
   * @param instrId
   * @param fund
   * @param holdingId
   * @param cashAmount
   * @param type
   * @param sendToAccDate
   * @param recordOnDate
   */
  public TradeAlloc(int instrId, Fund fund, int holdingId,
      BigDecimal cashAmount, Type type, LocalDate sendToAccDate,
      LocalDate recordOnDate) {

    this.orderId = 0;
    this.tradeId = 0;
    this.instrId = instrId;
    this.fund = fund;
    this.holdingId = holdingId;
    this.cashAmount = cashAmount;
    this.type = type;
    this.sendToAccDate = sendToAccDate;
    this.recordOnDate = recordOnDate;
  }

  public int getOrderId() {
    return orderId;
  }

  public int getTradeId() {
    return tradeId;
  }

  public int getInstrId() {
    return instrId;
  }

  public Fund getFund() {
    return fund;
  }

  public int getHoldingId() {
    return holdingId;
  }

  public BigDecimal getCashAmount() {
    return cashAmount;
  }

  public Type getType() {
    return type;
  }

  public LocalDate getSendToAccDate() {
    return sendToAccDate;
  }

  public LocalDate getRecordOnDate() {
    return recordOnDate;
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final TradeAlloc other = (TradeAlloc) obj;

    return (this.orderId == other.orderId && this.tradeId == other.tradeId
        && this.instrId == other.instrId
        && Objects.equals(this.fund, other.fund)
        && this.holdingId == other.holdingId
        && Objects.equals(this.cashAmount, other.cashAmount)
        && Objects.equals(this.type, other.type)
        && Objects.equals(this.sendToAccDate, other.sendToAccDate)
        && Objects.equals(this.recordOnDate, other.recordOnDate));
  }

  @Override
  public int hashCode() {
    return Objects.hash(orderId, tradeId, instrId, fund, holdingId, cashAmount,
        type, sendToAccDate, recordOnDate);
  }

  /**
   * The various possible Types of a TradeAlloc
   */
  public enum Type {

    UNKNOWN(0), NEW_MONEY(1), ZAP(2), MGMT_CHARGE(3), REBALANCE(99);

    private int id;

    private Type(int id) {
      this.id = id;
    }

    public int getId() {
      return id;
    }

    /**
     * Get a Type corresponding to the name passed in.
     * @param name Type name
     * @return Type
     */
    public static Type fromName(String name) {

      for (Type type : Type.values()) {
        if (name.equalsIgnoreCase(type.name())) {
          return type;
        }
      }
      throw new IllegalArgumentException("Unknown Type name: " + name);
    }
  }
}
