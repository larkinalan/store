package com.ilim.record.app.service;

import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.domain.model.tx.CashTx;
import com.ilim.record.domain.model.tx.UnitTx;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class RecordService implements IRecordService {

  private final ITxTransformer txTransformer;
  private final ITradeAllocProcessorService taProcService;
  private final IJobManagerService jobManagerService;

  @Inject
  public RecordService(ITxTransformer txTransformer,
      ITradeAllocProcessorService taProcService,
      IJobManagerService jobManagerService) {

    this.txTransformer = txTransformer;
    this.taProcService = taProcService;
    this.jobManagerService = jobManagerService;
  }

  @Transactional(propagation = Propagation.REQUIRED)
  public void record(List<TradeAlloc> tradeAllocs) {

    // process tradeAllocs
    List<TradeAlloc> procdTradeAllocs =
        taProcService.processTradeAllocs(tradeAllocs);

    // create all Treasury, FinSep and TresIlim txs
    List<CashTx> finSepCashTxs =
        txTransformer.toFinancialSeparationTx(procdTradeAllocs);
    List<CashTx> tresIlimCashTxs =
        txTransformer.toTreasuryIlimTx(finSepCashTxs);
    List<CashTx> treasuryCashTxs = txTransformer.toTreasuryTx(procdTradeAllocs);

    // combine them into one list
    List<CashTx> allCashTxs = new ArrayList<>();
    allCashTxs.addAll(finSepCashTxs);
    allCashTxs.addAll(tresIlimCashTxs);
    allCashTxs.addAll(treasuryCashTxs);

    // create and combine all Asset Portfolio and Liability Portfolio txs
    List<UnitTx> allUnitTxs =
        txTransformer.toAssetPortfolioTx(procdTradeAllocs);
    allUnitTxs.addAll(txTransformer.toLiabilityPortfolioTx(procdTradeAllocs));

    // submit all transactions to the job manager
    jobManagerService.submitCashTxs(allCashTxs);
    jobManagerService.submitUnitTxs(allUnitTxs);

    // update positions
    // @transaction end
  }
}
