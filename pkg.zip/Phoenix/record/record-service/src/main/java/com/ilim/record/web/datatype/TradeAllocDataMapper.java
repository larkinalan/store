package com.ilim.record.web.datatype;

import com.ilim.commons.time.DateUtils;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.TradeAlloc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TradeAllocDataMapper {

  public static TradeAlloc toTradeAlloc(TradeAllocData tradeAllocData,
      Map<Integer, Fund> funds) {

    int orderId = tradeAllocData.orderId;
    int tradeId = tradeAllocData.tradeId;
    Fund fund = funds.get(tradeAllocData.fundId);
    int holdingId = tradeAllocData.holdingId;
    BigDecimal cashAmount = tradeAllocData.cashAmount;
    LocalDate sendToAccDate =
        LocalDate.parse(tradeAllocData.sendToAccDate, DateUtils.DATE_FMT);
    LocalDate recordOnDate =
        LocalDate.parse(tradeAllocData.recordOnDate, DateUtils.DATE_FMT);

    TradeAlloc tradeAlloc = new TradeAlloc(orderId, tradeId, fund, holdingId,
        cashAmount, sendToAccDate, recordOnDate);

    return tradeAlloc;
  }

  public static List<TradeAlloc> toTradeAllocs(
      List<TradeAllocData> tradeAllocDatas, Map<Integer, Fund> funds) {

    List<TradeAlloc> tradeAllocs = new ArrayList<>(tradeAllocDatas.size());
    for (TradeAllocData tradeAllocData : tradeAllocDatas) {
      tradeAllocs.add(toTradeAlloc(tradeAllocData, funds));
    }

    return tradeAllocs;
  }
}
