package com.ilim.record.web.datatype;

import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.domain.model.TradeAlloc.Type;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TradeAllocDataMapper {

  public static TradeAlloc toTradeAlloc(TradeAllocData tradeAllocData,
      Map<Integer, Fund> funds) {

    int tradeId = tradeAllocData.tradeId; 
    Fund fund = funds.get(tradeAllocData.fundId);
    int holdingId = tradeAllocData.holdingId;
    BigDecimal cashAmount = tradeAllocData.cashAmount;
    Type type = Type.fromName(tradeAllocData.type);

    TradeAlloc tradeAlloc =
        new TradeAlloc(tradeId, fund, holdingId, cashAmount, type);

    return tradeAlloc;
  }

  public static List<TradeAlloc> toTradeAllocs(
      List<TradeAllocData> tradeAllocDatas, Map<Integer, Fund> funds) {

    List<TradeAlloc> tradeAllocs =
        new ArrayList<>(tradeAllocDatas.size());
    for (TradeAllocData tradeAllocData : tradeAllocDatas) {
      tradeAllocs.add(toTradeAlloc(tradeAllocData, funds));
    }

    return tradeAllocs;
  }
}
