package com.ilim.record.domain.model;

import com.ilim.commons.domain.IEntity;
import com.ilim.commons.domain.model.FundLevel;

import java.math.BigDecimal;

public class Fund implements IEntity<Integer> {

  private final int id;
  private final FundLevel level;
  private final BigDecimal committedUnits;
  private final String baseCurrency;
  private final int lobId;

  public Fund(int fundId, FundLevel level, BigDecimal committedUnits,
      String baseCurrency, int lobId) {

    this.id = fundId;
    this.level = level;
    this.committedUnits = committedUnits;
    this.baseCurrency = baseCurrency;
    this.lobId = lobId;
  }

  @Override
  public Integer getId() {
    return id;
  }

  public FundLevel getLevel() {
    return level;
  }

  public BigDecimal getCommittedUnits() {
    return committedUnits;
  }

  public String getBaseCurrency() {
    return baseCurrency;
  }

  public int getLobId() {
    return lobId;
  }
}
