package com.ilim.record.domain.model;
public enum TxRounding {

  ROUND_CASH(2), ROUND_UNITS(4), ROUND_PRICE(6), ROUND_MIX(13);

  private final int scale;

  TxRounding(int scale) {
    this.scale = scale;
  }

  public int scale() {
    return scale;
  }

}