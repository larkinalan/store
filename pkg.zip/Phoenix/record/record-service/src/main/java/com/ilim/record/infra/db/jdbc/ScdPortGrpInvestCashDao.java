package com.ilim.record.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.domain.model.Currency;
import com.ilim.record.domain.IScdPortGrpInvestCashRepo;
import com.ilim.record.domain.model.ScdPortGrpInvestCash;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.inject.Inject;
import javax.sql.DataSource;

public class ScdPortGrpInvestCashDao extends NamedParameterJdbcDaoSupport
    implements IScdPortGrpInvestCashRepo {

  private static final Logger log =
      LoggerFactory.getLogger(ScdPortGrpInvestCashDao.class);

  @Inject
  public ScdPortGrpInvestCashDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  public String findPortfolioOwnerId(int fundId, Currency baseCurrency) {

    log.info("findPortfolioOwnerId ({})", fundId);
    final String sql = SQL.select_from_scd_portgrp_invest_lvl_cash;
    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("fundId", fundId).addValue("currency", baseCurrency);

    final ScdPortGrpInvestCash result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toScdPortGrpInvestCash(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(String.format(
          "Error in findPortfolioOwnerId %s %s", fundId, baseCurrency), ex);
    }

    return result.getPortfolioOwnerId();
  }

  private ScdPortGrpInvestCash toScdPortGrpInvestCash(ResultSet rs) {

    try {
      String portfolioOwnerId = rs.getString("portfolio_owner_id");

      return new ScdPortGrpInvestCash(null, portfolioOwnerId, null);

    } catch (SQLException e) {
      throw new AppSqlException(
          "Error mapping sql result set to ScdPortGrpInvestCash!", e);
    }
  }
}
