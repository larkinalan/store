package com.ilim.record.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.record.domain.ITresIlimILobIdClientLevelCashRepo;
import com.ilim.record.domain.model.TresIlimLobIdClientLevelCash;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.inject.Inject;
import javax.sql.DataSource;

public class TresIlimLobIdClientLevelCashDao extends
    NamedParameterJdbcDaoSupport implements ITresIlimILobIdClientLevelCashRepo {

  private static final Logger log =
      LoggerFactory.getLogger(TresIlimLobIdClientLevelCashDao.class);

  @Inject
  public TresIlimLobIdClientLevelCashDao(DataSource dataSource) {

    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  public TresIlimLobIdClientLevelCash findTresIlimLobClientCashByLobId(
      int lobId) {

    log.info("findTresIlimLobClientCashByLobId ({})", lobId);
    final String sql = SQL.select_from_ti_lob_client_cash_by_lob_id;
    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("lobId", lobId);

    final TresIlimLobIdClientLevelCash result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toTresIlimLobIdClientLevelCash(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findLobClientCashByLobId " + lobId,
          ex);
    }

    return result;
  }

  private TresIlimLobIdClientLevelCash toTresIlimLobIdClientLevelCash(
      ResultSet rs) {

    try {
      String tresIlim = rs.getString("tresilim");
      String appAlmNumber = rs.getString("app_alm_no");
      String appBankAcc = rs.getString("tresilim_app_bank_acc");

      return new TresIlimLobIdClientLevelCash(null, tresIlim,
          appAlmNumber, null, appBankAcc, null);

    } catch (SQLException e) {
      throw new AppSqlException(
          "Error mapping sql result set to TresIlimLobIdClientLevelCash!", e);
    }
  }
}
