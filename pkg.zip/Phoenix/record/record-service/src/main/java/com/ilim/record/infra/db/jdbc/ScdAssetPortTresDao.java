package com.ilim.record.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.domain.model.Currency;
import com.ilim.record.domain.IScdAssetPortTresRepo;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.ScdAssetPortTres;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.inject.Inject;
import javax.sql.DataSource;

public class ScdAssetPortTresDao extends NamedParameterJdbcDaoSupport
    implements IScdAssetPortTresRepo {

  private static final Logger log =
      LoggerFactory.getLogger(ScdAssetPortTresDao.class);

  @Inject
  public ScdAssetPortTresDao(DataSource dataSource) {

    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  @Override
  public ScdAssetPortTres findByFund(Fund fund) {

    log.info("findById ({})", fund);
    final String sql = SQL.select_from_scd_asset_port_treasury;
    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("scdAssetPortfolio", fund.getId())
        .addValue("currency", fund.getBaseCurrency());

    final ScdAssetPortTres result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toScdAssetPortTres(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(
          String.format("Error in findByFund %s", fund),
          ex);
    }

    return result;
  }

  @Override
  public ScdAssetPortTres findDefaultByCurrency(Currency currency) {

    log.info("findDefaultByCurrency ({})", currency);
    final String sql = SQL.select_from_scd_asset_port_treasury;
    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("scdAssetPortfolio", null)
        .addValue("currency", currency);

    final ScdAssetPortTres result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toScdAssetPortTres(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(
          String.format("Error in findDefaultByCurrency %s %s", currency),
          ex);
    }

    return result;
  }

  private ScdAssetPortTres toScdAssetPortTres(ResultSet rs) {

    try {
      String appAlmNumber = rs.getString("app_alm_no");
      String mcAlmNum = rs.getString("mc_alm_no");

      return new ScdAssetPortTres(null, null, appAlmNumber, mcAlmNum);

    } catch (SQLException e) {
      throw new AppSqlException(
          "Error mapping sql result set to ScdAssetPortTres!", e);
    }
  }

}
