package com.ilim.record.app.service;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.domain.model.Currency;
import com.ilim.record.app.util.TradeAllocUtils;
import com.ilim.record.app.util.TradeAllocUtils.GroupBy;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.ScdLobClientCashFinSep;
import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.domain.model.TradeAlloc.Type;
import com.ilim.record.domain.model.ScdLobClientCashTresIlim;
import com.ilim.record.domain.model.tx.CashTx;
import com.ilim.record.domain.model.tx.UnitTx;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

public class TxTransformer implements ITxTransformer {

  // Common constants
  public static final String REQUESTED_STATUS =
      settings().getString("tx.transformer.requestedstatus");

  // Unit Tx Constants
  public static final String COUNTER_PARTY =
      settings().getString("tx.transformer.counterparty");
  public static final String EXCHANGE =
      settings().getString("tx.transformer.exchange");
  public static final String CUSTODY =
      settings().getString("tx.transformer.custody");
  public static final String BUS_TX_BUY =
      settings().getString("tx.transformer.bustxbuy");
  public static final String BUS_TX_SELL =
      settings().getString("tx.transformer.bustxsell");
  public static final String BUS_TX_REDEMPTION_FUNDS =
      settings().getString("tx.transformer.bustxredemptionfunds");
  public static final String BUS_TX_ISSUE_FUNDS =
      settings().getString("tx.transformer.bustxissuefunds");
  public static final String UNIT_TX_ORIGIN_ID =
      settings().getString("tx.transformer.unittxoriginid");

  // Cash Tx Constants
  public static final String TX_CODE_CREDIT_CASH =
      settings().getString("tx.transformer.txcodecreditcash");
  public static final String TX_CODE_CHARGE_CASH =
      settings().getString("tx.transformer.txcodechargecash");
  public static final String TREASURY_BANK_ACC_PREFIX =
      settings().getString("tx.transformer.treasurybankaccprefix");
  public static final String CASH_TX_ORIGIN_ID =
      settings().getString("tx.transformer.cashtxoriginid");
  public static final List<String> TREASURY_ILIM_TX_LOB_IDS =
      settings().getStringList("tx.transformer.treasuryilimtxlobids");

  // Tx transformer helper class
  private TxTransformerHelper txHelper;

  @Inject
  public TxTransformer(TxTransformerHelper txHelper) {
    this.txHelper = txHelper;
  }

  /**
   * Transform a 'list of TradeAllocs' to a 'list of AssetPortfolio UnitTxs'.
   * @param tradeAllocs tradeAllocs
   * @return list of Asset Portfolio unitTxs
   */
  public List<UnitTx> toAssetPortfolioTx(List<TradeAlloc> tradeAllocs) {

    // group and merge the tradeAllocs by fund:holding:type
    GroupBy groupBy = new GroupBy(true, true, true, false);
    List<TradeAlloc> mergedTradeAllocs =
        TradeAllocUtils.groupAndMergeTradeAllocs(tradeAllocs, groupBy);
    // transform each mergedTradeAlloc into an Asset Portfolio Unit Tx
    List<UnitTx> unitTxs = mergedTradeAllocs.parallelStream()
        .map(this::toAssetPortfolioTx).collect(Collectors.toList());

    return unitTxs;
  }

  private UnitTx toAssetPortfolioTx(TradeAlloc tradeAlloc) {

    int fundId = tradeAlloc.getFund().getId();
    int holdingId = tradeAlloc.getHoldingId();
    String securityId = txHelper.findAssetPortfolioExtId(holdingId);
    String portfolioId = txHelper.findAssetPortfolioExtId(fundId);
    String requestedStatus = REQUESTED_STATUS;
    BigDecimal price = txHelper.findClosingPrice(holdingId);
    BigDecimal nominal = calculateNominal(tradeAlloc.getCashAmount(), price);
    String businessTxCode = (isNegative(nominal) ? BUS_TX_SELL : BUS_TX_BUY);
    LocalDate tradeDate = txHelper.findTradeDate(); // TODO
    LocalDate paymentDate = txHelper.findPaymentDate(); // TODO
    String counterParty = COUNTER_PARTY;
    int txNumOriginSystem = txHelper.findTxNumOriginSystem(); // TODO
    String exchange = EXCHANGE;
    String custody = CUSTODY;
    int txFreeCode = 0; // TODO map from TradeAlloc.Type to SCD.Type
    String txOriginId = UNIT_TX_ORIGIN_ID;

    return new UnitTx(securityId, portfolioId, businessTxCode, requestedStatus,
        nominal, price, tradeDate, paymentDate, counterParty, txNumOriginSystem,
        exchange, custody, txFreeCode, txOriginId);
  }

  /**
   * Transform 'list of TradeAllocs' to 'list of LiabilityPortfolio UnitTxs'.
   * @param tradeAllocs tradeAllocs
   * @return list of Liability Portfolio UnitTxs
   */
  public List<UnitTx> toLiabilityPortfolioTx(List<TradeAlloc> tradeAllocs) {

    // group and merge the tradeAllocs by fund:type
    GroupBy groupBy = new GroupBy(true, false, true, false);
    List<TradeAlloc> mergedTradeAllocs =
        TradeAllocUtils.groupAndMergeTradeAllocs(tradeAllocs, groupBy);
    // transform each mergedTradeAlloc into a Liability Portfolio UnitTx
    List<UnitTx> unitTxs = mergedTradeAllocs.parallelStream()
        .map(this::toLiabilityPortfolioTx).collect(Collectors.toList());

    return unitTxs;
  }

  private UnitTx toLiabilityPortfolioTx(TradeAlloc tradeAlloc) {

    int fundId = tradeAlloc.getFund().getId();
    String securityId = txHelper.findLiabilityPortfolioSecurityId(fundId);
    String portfolioId = txHelper.findLiabilityPortfolioId(fundId);
    String requestedStatus = REQUESTED_STATUS;
    BigDecimal price = txHelper.findClosingPrice(fundId);
    BigDecimal nominal = calculateNominal(tradeAlloc.getCashAmount(), price);
    String businessTxCode =
        (isNegative(nominal) ? BUS_TX_REDEMPTION_FUNDS : BUS_TX_ISSUE_FUNDS);
    LocalDate tradeDate = txHelper.findTradeDate(); // TODO
    LocalDate paymentDate = txHelper.findPaymentDate(); // TODO
    String counterParty = COUNTER_PARTY;
    int txNumOriginSystem = txHelper.findTxNumOriginSystem(); // TODO
    String exchange = EXCHANGE;
    String custody = CUSTODY;
    int txFreeCode = 0; // TODO
    String txOriginId = UNIT_TX_ORIGIN_ID;

    return new UnitTx(securityId, portfolioId, businessTxCode, requestedStatus,
        nominal, price, tradeDate, paymentDate, counterParty, txNumOriginSystem,
        exchange, custody, txFreeCode, txOriginId);
  }

  /**
   * Transform 'list of TradeAllocs' to 'list of Treasury CashTxs'.
   * @param tradeAllocs tradeAllocs
   * @return List of Treasury CashTxs
   */
  public List<CashTx> toTreasuryTx(List<TradeAlloc> tradeAllocs) {

    // We only want tradeAllocs containing Primary level funds
    List<TradeAlloc> primaryTradeAllocs =
        TradeAllocUtils.filterByPrimaryLevel(tradeAllocs);

    // group tradeAllocs by holdingId:type
    GroupBy groupBy = new GroupBy(false, true, true, false);
    List<TradeAlloc> mergedTradeAllocs =
        TradeAllocUtils.groupAndMergeTradeAllocs(primaryTradeAllocs, groupBy);

    // transform each mergedTradeAlloc into a Treasury CashTx
    List<CashTx> cashTxs = mergedTradeAllocs.parallelStream()
        .map(this::toTreasuryTx).collect(Collectors.toList());

    return cashTxs;
  }

  private CashTx toTreasuryTx(TradeAlloc tradeAlloc) {

    Fund fund = tradeAlloc.getFund();
    Currency baseCurrency = fund.getBaseCurrency();
    Type type = tradeAlloc.getType();
    String securityId = txHelper.findTreasurySecurityId(fund, type); // TODO
    String portfolioId = txHelper
        .findTreasuryPortfolioId(tradeAlloc.getHoldingId(), baseCurrency);
    LocalDate tradeDate = txHelper.findTradeDate(); // TODO
    BigDecimal nominal = tradeAlloc.getCashAmount();
    String txCode =
        (isNegative(nominal) ? TX_CODE_CREDIT_CASH : TX_CODE_CHARGE_CASH);
    LocalDate paymentDate = txHelper.findPaymentDate(); // TODO
    String bankAccount = TREASURY_BANK_ACC_PREFIX + ""; // TODO
    String requestedStatus = REQUESTED_STATUS;
    String txOriginId = CASH_TX_ORIGIN_ID;
    int txNumOriginSystem = txHelper.findTxNumOriginSystem(); // TODO
    int unitOrderTypeId = 0; // TODO
    int lobId = fund.getLobId();

    return new CashTx(securityId, portfolioId, tradeDate, txCode, nominal,
        paymentDate, bankAccount, requestedStatus, txOriginId,
        txNumOriginSystem, unitOrderTypeId, lobId);
  }

  /**
   * Transform 'list of TradeAllocs' to 'list of Financial Separation CashTxs'.
   * @param tradeAllocs tradeAllocs
   * @return List of FinSep CashTxs
   */
  public List<CashTx> toFinancialSeparationTx(List<TradeAlloc> tradeAllocs) {

    // We want tradeAllocs with Client level funds only
    List<TradeAlloc> clientTradeAllocs =
        TradeAllocUtils.filterByClientLevel(tradeAllocs);

    // group by lob:type
    GroupBy groupBy = new GroupBy(false, false, true, true);
    List<TradeAlloc> mergedTradeAllocs =
        TradeAllocUtils.groupAndMergeTradeAllocs(clientTradeAllocs, groupBy);

    // transform each tradeAlloc to a Financial Separation CashTx
    List<CashTx> cashTxs = mergedTradeAllocs.parallelStream()
        .map(this::toFinancialSeparationTx).collect(Collectors.toList());

    return cashTxs;

  }

  private CashTx toFinancialSeparationTx(TradeAlloc tradeAlloc) {

    Fund fund = tradeAlloc.getFund();
    Type type = tradeAlloc.getType();
    ScdLobClientCashFinSep slccfs =
        txHelper.findScdLobClientCashFinSep(fund.getLobId());
    String securityId = (type == Type.MANAGEMENT_CHARGES) 
        ? slccfs.getMcAlmNum() : slccfs.getAppAlmNum();
    String portfolioId = slccfs.getPortfolioOwnerId();
    LocalDate tradeDate = txHelper.findTradeDate(); // TODO
    BigDecimal nominal = tradeAlloc.getCashAmount();
    String txCode =
        (isNegative(nominal) ? TX_CODE_CREDIT_CASH : TX_CODE_CHARGE_CASH);
    LocalDate paymentDate = txHelper.findPaymentDate(); // TODO
    String bankAccount = (type == Type.MANAGEMENT_CHARGES)
        ? slccfs.getMcBankAcc() : slccfs.getAppBankAcc();
    String requestedStatus = REQUESTED_STATUS;
    String txOriginId = CASH_TX_ORIGIN_ID;
    int txNumOriginSystem = txHelper.findTxNumOriginSystem(); // TODO
    int unitOrderTypeId = 0; // TODO
    int lobId = fund.getLobId();

    return new CashTx(securityId, portfolioId, tradeDate, txCode, nominal,
        paymentDate, bankAccount, requestedStatus, txOriginId,
        txNumOriginSystem, unitOrderTypeId, lobId);
  }

  /**
   * Create a list of Treasury Ilim Cash Txs based off the finSepTxs.
   * One TresIlim CashTx is created for each finSepTx whose 'line of business' 
   * is contained in TREASURY_ILIM_TX_LOB_IDS. 
   * @param finSepTxs finSepTxs
   * @return List of TresIlim cashTxs
   */
  public List<CashTx> toTreasuryIlimTx(List<CashTx> finSepTxs) {

    List<CashTx> tresIlimTxs =
        finSepTxs.parallelStream()
            .filter(
                fstx -> TREASURY_ILIM_TX_LOB_IDS.contains((fstx.getLobId())))
            .map(this::toTreasuryIlimTx).collect(Collectors.toList());

    return tresIlimTxs;
  }

  private CashTx toTreasuryIlimTx(CashTx finSepTx) {

    int lobId = finSepTx.getLobId();
//    Type type = Type.valueOf(finSepTx.getUnitOrderTypeId());
    ScdLobClientCashTresIlim slccti =
        txHelper.findScdLobClientCashTresIlim(lobId);
    String securityId = slccti.getAppAlmNum(); // TODO
    String portfolioId = slccti.getTresIlim(); // TODO
    LocalDate tradeDate = finSepTx.getTradeDate();
    BigDecimal nominal = finSepTx.getNominal();
    String txCode =
        (isNegative(nominal) ? TX_CODE_CHARGE_CASH : TX_CODE_CREDIT_CASH);
    LocalDate paymentDate = finSepTx.getPaymentDate();
    String bankAccount = slccti.getAppBankAcc(); // TODO
    String requestedStatus = finSepTx.getRequestedStatus();
    String txOriginId = finSepTx.getTxOriginId();
    int txNumOriginSystem = txHelper.findTxNumOriginSystem(); // TODO
    int unitOrderTypeId = finSepTx.getUnitOrderTypeId();

    return new CashTx(securityId, portfolioId, tradeDate, txCode, nominal,
        paymentDate, bankAccount, requestedStatus, txOriginId,
        txNumOriginSystem, unitOrderTypeId, lobId);
  }

  private BigDecimal calculateNominal(BigDecimal cashAmount, BigDecimal price) {
    return cashAmount.divide(price);
  }

  private boolean isNegative(BigDecimal value) {
    return value.compareTo(BigDecimal.ZERO) == -1;
  }
}
