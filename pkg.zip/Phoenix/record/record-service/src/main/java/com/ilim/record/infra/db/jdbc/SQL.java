package com.ilim.record.infra.db.jdbc;

/*
 *  Sql statements used in Dao
 *  
 *  <p>Formatted and wrapped using TOAD. 
 *  
 *  @formatter:off
 *  CHECKSTYLE:OFF
 */
public class SQL {

  /****************
   * asset_id_xref
   ****************/
  public static final String select_from_asset_id_xref_by_ids = 
      "SELECT external_id " + 
        "FROM asset_id_xref " + 
       "WHERE ilim_id = :fundId " +
         "AND ext_id_type_id = :extIdTypeId;";
  
  
  /*******************
   * fund_price_latest
   *******************/
  public static final String select_from_price_latest_by_fund_id_and_type = 
      "SELECT price_dt, " + 
            " closing_price " + 
      "  FROM fund_price_latest" + 
      " WHERE ilim_id = :fundId " +
      "   AND price_type_id = :priceTypeId";
  
  
  /***************************
   * scd_lob_id_cl_cash_finsep
   ***************************/
  public static final String select_from_lob_client_cash_finsep_by_lob_id = 
      "SELECT sliccf.portfolio_owner_id, " +
            " sliccf.app_alm_no, " + 
            " sliccf.mc_alm_no, " + 
            " sliccf.app_bank_account, " + 
            " sliccf.mc_bank_account " +
        "FROM scd_lob_id_cl_cash_finsep sliccf " + 
  "INNER JOIN line_of_business lob " + 
          "ON sliccf.scd_lob_id = lob.scd_lob_id " + 
       "WHERE lob.lob_id = :lobId";
  
  
  /*****************************
   * scd_lob_id_cl_cash_tresilim
   *****************************/
  public static final String select_from_lob_client_cash_tresilim_by_lob_id = 
      "SELECT slicct.tresilim, " +
            " slicct.app_alm_no, " + 
            " slicct.mc_alm_no, " +
            " slicct.app_bank_account, " +
            " slicct.mc_bank_account " +
        "FROM scd_lob_id_cl_cash_tresilim slicct " + 
  "INNER JOIN line_of_business lob " + 
          "ON slicct.scd_lob_id = lob.scd_lob_id " + 
       "WHERE lob.lob_id = :lobId";

  
  /*****************************
   * scd_portgrp_invest_lvl_cash
   *****************************/
  public static final String select_from_scd_portgrp_invest_lvl_cash = 
      "SELECT spilc.portfolio_owner_id " +
        "FROM scd_portgrp_invest_lvl_cash spilc " + 
  "INNER JOIN fund_group fg " + 
          "ON (spilc.portfolio_group = fg.fund_group_mnemonic) " +
  "INNER JOIN fund_group_list fgl " +
          "ON (fg.fund_group_id = fgl.fund_group_id) " +
       "WHERE fg.fund_group_type_id = 3 " +
         "AND fgl.ilim_id = :fundId ";
  
  
  /*****************************
   * scd_asset_port_treasury
   *****************************/
  // TODO: This SQL is wrong!!! Rewrite it to use :fundId
  public static final String select_from_scd_asset_port_treasury = 
      "SELECT app_alm_no " +
            " mc_alm_no " +
        "FROM scd_asset_port_treasury " + 
       "WHERE scd_asset_portfolio = :scdAssetPortfolio " +
         "AND currency_id = :currency;";
  
  
  /*****************************
   * a_secs
   *****************************/
  public static final String select_from_a_secs_by_short_name_and_instr_type = 
      "SELECT sec_short_name " +
        "FROM a_secs " + 
       "WHERE sec_short_name = :secShortName " + 
         "AND instr_type = 'ALM'";
}
