package com.ilim.record.infra.db.jdbc;

/*
 *  Sql statements used in Dao
 *  
 *  <p>Formatted and wrapped using TOAD. 
 *  
 *  @formatter:off
 *  CHECKSTYLE:OFF
 */
public class SQL {

  /**
   * asset_id_xref
   */
  public static final String select_from_asset_id_xref_by_ids = 
      "SELECT external_id " + 
        "FROM asset_id_xref " + 
       "WHERE ilim_id = :fundId " +
         "AND ext_id_type_id = :extIdTypeId;";
  
  /**
   * fund_price_latest
   */
  public static final String select_from_price_latest_by_fund_id_and_type = 
      "SELECT price_dt, " + 
            " closing_price " + 
      "  FROM fund_price_latest" + 
      " WHERE ilim_id = :fundId " +
      "   AND price_type_id = :priceTypeId";
  
  /**
   * lob_id_client_level_cash
   */
  public static final String select_from_lob_client_cash_by_lob_id = 
      "SELECT liclc.portfolio_owner_id, " +
            " liclc.app_alm_no " + 
        "FROM lob_id_client_level_cash liclc " + 
  "INNER JOIN line_of_business lob " + 
          "ON liclc.scd_lob_id = lob.scd_lob_id " + 
       "WHERE lob.lob_id = :lobId";
  
  /**
   * tres_ilim_lob_id_client_level_cash
   */
  public static final String select_from_ti_lob_client_cash_by_lob_id = 
      "SELECT tiliclc.portfolio_owner_id, " +
            " tiliclc.app_alm_no " + 
            " tiliclc.tresIlim_app_bank_acc " + 
        "FROM tres_ilim_lob_id_client_level_cash tiliclc " + 
  "INNER JOIN line_of_business lob " + 
          "ON tiliclc.scd_lob_id = lob.scd_lob_id " + 
       "WHERE lob.lob_id = :lobId";
  
}
