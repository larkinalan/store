package com.ilim.record.infra.fund;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.fund.web.api.FundData;
import com.ilim.record.domain.model.Fund;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class FundMapper {

  private static final Logger log =
      LoggerFactory.getLogger(FundMapper.class);

  /**
   * Map from a Fund to a FundData.
   * @param fund fund
   * @return FundData
   */
  public static FundData toFundData(Fund fund) {

    log.trace("toFundData ({})", fund);
    int fundId = fund.getId();
    String level = fund.getLevel().name();
    BigDecimal committedUnits = fund.getCommittedUnits();
    String baseCurrency = fund.getBaseCurrency();
    int lobId = fund.getLobId();

    return new FundData(fundId, level, committedUnits, baseCurrency, lobId);
  }
   
  /**
   * Map from 'List of Funds' to 'List of FundDatas'.
   * @param funds fundList
   * @return List of FundDatas
   */
  public static List<FundData> toFundData(List<Fund> funds) {
    
    log.trace("toFundData {()}", funds);
    List<FundData> fundDatas = new ArrayList<FundData>(funds.size());
    
    for (Fund fund : funds) {
      fundDatas.add(toFundData(fund));
    }
    
    return fundDatas;  
  }
  
  /**
   * Map from a FundData to a Fund.
   * @param fundData fundData
   * @return FundData
   */
  public static Fund toFund(FundData fundData) {

    log.trace("toFund ({})", fundData);
    int fundId = fundData.fundId;
    String levelName = fundData.level;
    FundLevel level = FundLevel.valueOf(levelName);
    BigDecimal committedUnits = fundData.committedUnits;
    String baseCurrency = fundData.baseCurrency;
    int lobId = fundData.lobId;

    return new Fund(fundId, level, committedUnits, baseCurrency, lobId);
  }
  
  /**
   * Map from 'List of FundData' to 'List of Funds'.
   * @param fundDatas List of FundDatas
   * @return List of Funds
   */
  public static List<Fund> toFund(List<FundData> fundDatas) {
    
    log.info("toFund ({})", fundDatas);
    List<Fund> funds = new ArrayList<Fund>(fundDatas.size());
    
    for (FundData fundData : fundDatas) {
      funds.add(toFund(fundData));
    }
    
    return funds;  
  }
}
