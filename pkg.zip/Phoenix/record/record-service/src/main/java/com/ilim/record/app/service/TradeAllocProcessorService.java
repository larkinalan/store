package com.ilim.record.app.service;

import com.ilim.record.domain.IFundPriceLatestRepo;
import com.ilim.record.domain.model.TradeAlloc;

import java.util.List;

import javax.inject.Inject;

public class TradeAllocProcessorService implements ITradeAllocProcessorService {

  private IForecastService forecastService;
  private IFundPriceLatestRepo fundPriceLatestRepo;
  
  @Inject
  public TradeAllocProcessorService(IForecastService forecastService, IFundPriceLatestRepo fundPriceLatestRepo){
    this.forecastService = forecastService;
    this.fundPriceLatestRepo = fundPriceLatestRepo;
  }
  
  public List<TradeAlloc> processTradeAllocs(List<TradeAlloc> tradeAllocs){
    return null;
  }
}
