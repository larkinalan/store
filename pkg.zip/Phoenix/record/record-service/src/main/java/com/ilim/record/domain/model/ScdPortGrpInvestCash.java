package com.ilim.record.domain.model;

public class ScdPortGrpInvestCash {

  private String portfolioGroupId;
  private String portfolioOwnerId;
  private String currency;
  
  
  public ScdPortGrpInvestCash(String portfolioGroupId, String portfolioOwnerId,
      String currency) {
    
    this.portfolioGroupId = portfolioGroupId;
    this.portfolioOwnerId = portfolioOwnerId;
    this.currency = currency;
  }


  public String getPortfolioGroupId() {
    return portfolioGroupId;
  }

  public String getPortfolioOwnerId() {
    return portfolioOwnerId;
  }

  public String getCurrency() {
    return currency;
  }
}
