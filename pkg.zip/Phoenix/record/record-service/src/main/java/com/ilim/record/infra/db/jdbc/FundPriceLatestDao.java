package com.ilim.record.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.domain.model.PriceType;
import com.ilim.commons.time.DateUtils;
import com.ilim.record.domain.IFundPriceLatestRepo;
import com.ilim.record.domain.model.FundPriceLatest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.inject.Inject;
import javax.sql.DataSource;

public class FundPriceLatestDao extends NamedParameterJdbcDaoSupport
    implements IFundPriceLatestRepo {

  private static final Logger log =
      LoggerFactory.getLogger(FundPriceLatestDao.class);

  @Inject
  public FundPriceLatestDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  public FundPriceLatest findByIdAndType(int fundId, PriceType priceType) {

    int priceTypeId = priceType.getId();
    log.info("findPriceByIdAndType ({}, {})", fundId, priceType);
    final String sql = SQL.select_from_price_latest_by_fund_id_and_type;
    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("fundId", fundId).addValue("priceTypeId", priceTypeId);

    final FundPriceLatest result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toFundPriceLatest(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(String.format(
          "Error in findPriceByIdAndType %s %s", fundId, priceTypeId), ex);
    }

    return result;
  }


  private FundPriceLatest toFundPriceLatest(ResultSet rs) {

    BigDecimal closingPrice;
    try {
      int ilimId = rs.getInt("ilim_id");
      int priceTypeId = rs.getInt("price_type_id");
      PriceType priceType = PriceType.from(priceTypeId);
      LocalDate priceDate = DateUtils.asLocalDate(rs.getDate("price_dt"));
      closingPrice = rs.getBigDecimal("closing_price");

      FundPriceLatest fundPriceLatest =
          new FundPriceLatest(ilimId, priceType, priceDate, closingPrice);

      return fundPriceLatest;
      
    } catch (SQLException e) {
      throw new AppSqlException(
          "Error mapping sql result set to FundPriceLatest!", e);
    }
  }
}
