package com.ilim.record.infra.jobmanager;

import com.ilim.record.app.service.IJobManagerService;
import com.ilim.record.domain.model.tx.CashTx;
import com.ilim.record.domain.model.tx.UnitTx;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public class JobManagerService implements IJobManagerService{
  
  public static final DateTimeFormatter DIMENSION_TX_DATE_FMT =
      DateTimeFormatter.ofPattern("yyyyMMdd");
  
  @Transactional(propagation = Propagation.REQUIRED)
  public void submitUnitTxs(List<UnitTx> unitTxs){
    
    List<String> unitTxCsvs = new ArrayList<>(unitTxs.size());
    int jobId = getNextJobId();
    
    for(UnitTx unitTx : unitTxs){
      unitTx.setBatchNumber(jobId);
      //unitTx.setTxNumOriginSystem(getNextMessageId()); ?
      unitTxCsvs.add(toCsvString(unitTx));
    }
    
    // call the client
  }
  
  @Transactional(propagation = Propagation.REQUIRED)
  public void submitCashTxs(List<CashTx> cashTxs){
    
    List<String> cashTxCsvs = new ArrayList<>(cashTxs.size());
    int jobId = getNextJobId();
    
    for(CashTx cashTx : cashTxs){
      cashTx.setBatchNumber(jobId);
      //unitTx.setTxNumOriginSystem(getNextMessageId()); ?
      cashTxCsvs.add(toCsvString(cashTx));
    }
    
    // call the client
  }
  
  public int getNextMessageId(){
  //TODO: implement
    return 0;
  }
  
  private int getNextJobId(){
    //TODO: implement
    return 0;
  }
  
  private String toCsvString(CashTx ct){
    
    StringJoiner sj = new StringJoiner(",");
    sj.add(ct.getSecurityId())
    .add(ct.getPortfolioId())
    .add(toTxDateString(ct.getTradeDate()))
    .add(ct.getTxCode())
    .add(ct.getNominal().toPlainString())
    .add(toTxDateString(ct.getPaymentDate()))
    .add(ct.getBankAccount())
    .add(ct.getRequestedStatus())
    .add(String.valueOf(ct.getBatchNumber()))
    .add(ct.getTxOriginId())
    .add(String.valueOf(ct.getTxNumOriginSystem()))
    .add(String.valueOf(ct.getUnitOrderTypeId()));
    
    return sj.toString();
  }
  
  private String toCsvString(UnitTx ut){
    
    StringJoiner sj = new StringJoiner(",");
    sj.add(ut.getSecurityId())
    .add(ut.getPortfolioId())
    .add(ut.getBusinessTxCode())
    .add(ut.getRequestedStatus())
    .add(ut.getNominal().toPlainString())
    .add(ut.getPrice().toPlainString())
    .add(toTxDateString(ut.getTradeDate()))
    .add(toTxDateString(ut.getPaymentDate()))
    .add(ut.getCounterParty())
    .add(ut.getTxOriginId())
    .add(ut.getExchange())
    .add(ut.getCustody())
    .add(String.valueOf(ut.getTxFreeCode()))
    .add(ut.getTxOriginId())
    .add(String.valueOf(ut.getBatchNumber()));
    
    return sj.toString();
  }
  
  private static String toTxDateString(LocalDate date){
    return date.format(DIMENSION_TX_DATE_FMT);
  }
}
