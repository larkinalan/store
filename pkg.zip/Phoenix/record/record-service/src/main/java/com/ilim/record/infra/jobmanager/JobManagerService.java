package com.ilim.record.infra.jobmanager;

import com.ilim.record.app.service.IJobManagerService;
import com.ilim.record.domain.model.CashTx;
import com.ilim.record.domain.model.UnitTx;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public class JobManagerService implements IJobManagerService{
  
  public static final DateTimeFormatter DIMENSION_TX_DATE_FMT =
      DateTimeFormatter.ofPattern("yyyyMMdd");
  
  // TODO: Think about removing batchNumber and txNumOriginSystem vars from UnitTx and CashTx.
  // These values can be filled in the functions toCsvString(..) perhaps?
  // Would make for cleaner UnitTx and CashTx models. 
  
  @Transactional(propagation = Propagation.REQUIRED)
  public void submitUnitTxs(List<UnitTx> unitTxs){
    
    int numTxs = unitTxs.size();
    List<String> unitTxCsvs = new ArrayList<>(numTxs);
    
    // get the jobId and messageIds
    int jobId = getNextJobId("unitTxJob");
    int [] messageIds = reserveMessageIds(numTxs);
    
    // inject them into each unitTx
    for(int i = 0; i < numTxs; i++){
      UnitTx unitTx = unitTxs.get(i);
      unitTx.setBatchNumber(jobId);
      unitTx.setTxNumOriginSystem(messageIds[i]);
      unitTxCsvs.add(toCsvString(unitTx));
    }
    
    // call the client
    startJob();
  }
  
  @Transactional(propagation = Propagation.REQUIRED)
  public void submitCashTxs(List<CashTx> cashTxs){
    
    int numTxs = cashTxs.size();
    List<String> cashTxCsvs = new ArrayList<>(numTxs);
    
    // get the jobId and messageIds
    int jobId = getNextJobId("cashTxJob");
    int [] messageIds = reserveMessageIds(numTxs);
    
    // inject them into each cashTx
    for(int i = 0; i < numTxs; i++){
      CashTx cashTx = cashTxs.get(i);
      cashTx.setBatchNumber(jobId);
      cashTx.setTxNumOriginSystem(messageIds[i]);
      cashTxCsvs.add(toCsvString(cashTx));
    }
    
    // call the client
    startJob();
  }
  
  private int [] reserveMessageIds(int count){
    // TODO: call client.reserveMsgIds(count)
    return null;
  }
  
  private int getNextJobId(String jobType){
    //TODO: call client.createJob()
    return 0;
  }
  
  private void startJob(){
    
  }
  
  private String toCsvString(CashTx ct){
    
    StringJoiner sj = new StringJoiner(",");
    sj.add(ct.getSecurityId())
    .add(ct.getPortfolioId())
    .add(toTxDateString(ct.getTradeDate()))
    .add(ct.getTxCode())
    .add(ct.getNominal().toPlainString())
    .add(toTxDateString(ct.getPaymentDate()))
    .add(ct.getBankAccount())
    .add(ct.getRequestedStatus())
    .add(String.valueOf(ct.getBatchNumber()))
    .add(ct.getTxOriginId())
    .add(String.valueOf(ct.getTxNumOriginSystem()))
    .add(String.valueOf(ct.getUnitOrderTypeId()));
    
    return sj.toString();
  }
  
  private String toCsvString(UnitTx ut){
    
    StringJoiner sj = new StringJoiner(",");
    sj.add(ut.getSecurityId())
    .add(ut.getPortfolioId())
    .add(ut.getBusinessTxCode())
    .add(ut.getRequestedStatus())
    .add(ut.getNominal().toPlainString())
    .add(ut.getPrice().toPlainString())
    .add(toTxDateString(ut.getTradeDate()))
    .add(toTxDateString(ut.getPaymentDate()))
    .add(ut.getCounterParty())
    .add(ut.getTxOriginId())
    .add(ut.getExchange())
    .add(ut.getCustody())
    .add(String.valueOf(ut.getTxFreeCode()))
    .add(ut.getTxOriginId())
    .add(String.valueOf(ut.getBatchNumber()));
    
    return sj.toString();
  }
  
  private static String toTxDateString(LocalDate date){
    return date.format(DIMENSION_TX_DATE_FMT);
  }
}
