package com.ilim.record.app.conf;

import com.google.common.eventbus.EventBus;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Spring component config.
 */
@Configuration
@EnableTransactionManagement()
public class SpringConfig {

  /** Guava EventBus bean. */
  @Bean
  public EventBus eventBus() {

    EventBus eventBus = new EventBus("RecordServiceEventBus");
    return eventBus;
  }
}
