package com.ilim.record.app.conf;

import com.ilim.forecast.web.client.ForecastClient;
import com.ilim.fund.web.client.FundClient;
import com.ilim.record.app.service.IForecastService;
import com.ilim.record.app.service.IFundService;
import com.ilim.record.app.service.IJobManagerService;
import com.ilim.record.app.service.IRecordService;
import com.ilim.record.app.service.ITradeAllocService;
import com.ilim.record.app.service.ITxTransformer;
import com.ilim.record.app.service.RecordService;
import com.ilim.record.app.service.TradeAllocService;
import com.ilim.record.app.service.TxTransformer;
import com.ilim.record.app.service.TxTransformerHelper;
import com.ilim.record.domain.IAssetIdXrefRepo;
import com.ilim.record.domain.IFundPriceLatestRepo;
import com.ilim.record.domain.IFundsDefRepo;
import com.ilim.record.domain.IPricingDateRepo;
import com.ilim.record.domain.ITxDetailsLookupRepo;
import com.ilim.record.infra.db.jdbc.AssetIdXrefDao;
import com.ilim.record.infra.db.jdbc.FundPriceLatestDao;
import com.ilim.record.infra.db.jdbc.FundsDefDao;
import com.ilim.record.infra.db.jdbc.PricingDateDao;
import com.ilim.record.infra.db.jdbc.TxDetailsLookupDao;
import com.ilim.record.infra.forecast.ForecastServiceAdapter;
import com.ilim.record.infra.fund.FundServiceAdapter;
import com.ilim.record.infra.jobmanager.JobManagerService;
import com.ilim.record.web.resources.RecordResource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;


/**
 * Spring component config.
 */
@Configuration
@EnableTransactionManagement()
public class SpringConfig {

  /** Rest Resources */
  public RecordResource recordResource(IFundService fundService,
      IRecordService recordService) {

    return new RecordResource(fundService, recordService);
  }


  /** Services */
  @Bean
  public IRecordService recordService(ITxTransformer txTransformer,
      ITradeAllocService taService,
      IJobManagerService jobManagerService) {

    return new RecordService(txTransformer, taService, jobManagerService);
  }

  @Bean
  public IFundService fundService(FundClient fundClient) {
    return new FundServiceAdapter(fundClient);
  }

  @Bean
  public ITxTransformer txTransformer(TxTransformerHelper txHelper) {
    return new TxTransformer(txHelper);
  }

  @Bean
  public TxTransformerHelper txHelper(IAssetIdXrefRepo assetIdXrefRepo,
      IFundPriceLatestRepo fundPriceLatestRepo,
      ITxDetailsLookupRepo txDetailsLookupRepo,
      IFundsDefRepo fundsDefRepo,
      IPricingDateRepo pricingDateRepo) {

    return new TxTransformerHelper(assetIdXrefRepo, fundPriceLatestRepo,
        txDetailsLookupRepo, fundsDefRepo,
        pricingDateRepo);
  }

  @Bean
  public ITradeAllocService taService(
      IForecastService forecastService,
      IFundPriceLatestRepo fundPriceLatestRepo) {
    return new TradeAllocService(forecastService, fundPriceLatestRepo);
  }

  @Bean
  public IJobManagerService jobManagerService() {
    return new JobManagerService();
  }

  @Bean
  public IForecastService forecastService(ForecastClient fundClient) {
    return new ForecastServiceAdapter(fundClient);
  }


  /** Repositories */
  @Bean
  public IAssetIdXrefRepo assetIdXrefRepo(DataSource ds) {
    return new AssetIdXrefDao(ds);
  }

  @Bean
  public IFundPriceLatestRepo fundPriceLatestRepo(DataSource ds) {
    return new FundPriceLatestDao(ds);
  }

  @Bean
  public ITxDetailsLookupRepo txDetailsLookupRepo(DataSource ds){
    return new TxDetailsLookupDao(ds);
  }

  @Bean
  public IFundsDefRepo fundsDefRepo(DataSource ds) {
    return new FundsDefDao(ds);
  }

  @Bean
  public IPricingDateRepo pricingDateRepo(DataSource ds) {
    return new PricingDateDao(ds);
  }


  /** Clients */
  @Bean
  public FundClient fundClient() {
    return new FundClient();
  }

  @Bean
  public ForecastClient forecastClient() {
    return new ForecastClient();
  }
}
