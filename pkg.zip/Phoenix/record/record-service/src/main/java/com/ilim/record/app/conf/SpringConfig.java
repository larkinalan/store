package com.ilim.record.app.conf;

import com.ilim.forecast.web.client.ForecastClient;
import com.ilim.fund.web.client.FundClient;
import com.ilim.record.app.service.IForecastService;
import com.ilim.record.app.service.IFundService;
import com.ilim.record.app.service.IJobManagerService;
import com.ilim.record.app.service.IRecordService;
import com.ilim.record.app.service.ITradeAllocProcessorService;
import com.ilim.record.app.service.ITxTransformer;
import com.ilim.record.app.service.RecordService;
import com.ilim.record.app.service.TradeAllocProcessorService;
import com.ilim.record.app.service.TxTransformer;
import com.ilim.record.app.service.TxTransformerHelper;
import com.ilim.record.domain.IAssetIdXrefRepo;
import com.ilim.record.domain.IFundPriceLatestRepo;
import com.ilim.record.domain.ILobIdClientLevelCashRepo;
import com.ilim.record.domain.IPricingDateRepo;
import com.ilim.record.domain.ITresIlimILobIdClientLevelCashRepo;
import com.ilim.record.infra.db.jdbc.AssetIdXrefDao;
import com.ilim.record.infra.db.jdbc.FundPriceLatestDao;
import com.ilim.record.infra.db.jdbc.LobIdClientLevelCashDao;
import com.ilim.record.infra.db.jdbc.PricingDateDao;
import com.ilim.record.infra.db.jdbc.TresIlimLobIdClientLevelCashDao;
import com.ilim.record.infra.forecast.ForecastService;
import com.ilim.record.infra.fund.FundServiceAdapter;
import com.ilim.record.infra.jobmanager.JobManagerService;
import com.ilim.record.web.resources.RecordResource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;


/**
 * Spring component config.
 */
@Configuration
@EnableTransactionManagement()
public class SpringConfig {

  /** Rest Resources */
  public RecordResource recordResource(IFundService fundService,
      IRecordService recordService) {

    return new RecordResource(fundService, recordService);
  }


  /** Services */
  @Bean
  public IRecordService recordService(ITxTransformer txTransformer,
      ITradeAllocProcessorService taProcService,
      IJobManagerService jobManagerService) {

    return new RecordService(txTransformer, taProcService, jobManagerService);
  }

  @Bean
  public IFundService fundService(FundClient fundClient) {
    return new FundServiceAdapter(fundClient);
  }

  @Bean
  public ITxTransformer txTransformer(TxTransformerHelper txHelper) {
    return new TxTransformer(txHelper);
  }

  @Bean
  public TxTransformerHelper txHelper(IAssetIdXrefRepo assetIdXrefRepo,
      IFundPriceLatestRepo fundPriceLatestRepo,
      ILobIdClientLevelCashRepo lobIdClientLevelCashRepo,
      ITresIlimILobIdClientLevelCashRepo tiLobIdClientLevelCashRepo,
      IPricingDateRepo pricingDateRepo, IJobManagerService jobManagerService) {

    return new TxTransformerHelper(assetIdXrefRepo, fundPriceLatestRepo,
        lobIdClientLevelCashRepo, tiLobIdClientLevelCashRepo, pricingDateRepo,
        jobManagerService);
  }

  @Bean
  public ITradeAllocProcessorService taProcService(
      IForecastService forecastService,
      IFundPriceLatestRepo fundPriceLatestRepo) {
    return new TradeAllocProcessorService(forecastService, fundPriceLatestRepo);
  }

  @Bean
  public IJobManagerService jobManagerService() {
    return new JobManagerService();
  }

  @Bean
  public IForecastService forecastService(ForecastClient fundClient) {
    return new ForecastService(fundClient);
  }

  
  /** Repositories */
  @Bean
  public IAssetIdXrefRepo assetIdXrefRepo(DataSource ds) {
    return new AssetIdXrefDao(ds);
  }

  @Bean
  public IFundPriceLatestRepo fundPriceLatestRepo(DataSource ds) {
    return new FundPriceLatestDao(ds);
  }

  @Bean
  public ILobIdClientLevelCashRepo lobIdClientLevelCashRepo(DataSource ds) {
    return new LobIdClientLevelCashDao(ds);
  }

  @Bean
  public ITresIlimILobIdClientLevelCashRepo tiLobIdClientLevelCashRepo(
      DataSource ds) {
    return new TresIlimLobIdClientLevelCashDao(ds);
  }

  @Bean
  public IPricingDateRepo pricingDateRepo(DataSource ds) {
    return new PricingDateDao(ds);
  }


  /** Clients */
  @Bean
  public FundClient fundClient() {
    return new FundClient();
  }

  @Bean
  public ForecastClient forecastClient() {
    return new ForecastClient();
  }
}
