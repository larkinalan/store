package com.ilim.record.app.util;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.domain.model.TradeAlloc.Type;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TradeAllocUtils {

  /**
   * Group the tradeAllocs by fund:holding:type:lob combo defined in groupBy
   * Then merge all tradeAllocs in each group into a single TradeAlloc.
   * Return a list containing all of the merged tradeAllocs. 
   * Each tradeAlloc in the list will have a unique fund:holding:type:lob combo 
   * as defined in groupBy 
   * @param tradeAllocs tradeAllocs
   * @return List of unique merged TradeAllocs.
   */
  public static List<TradeAlloc> groupAndMergeTradeAllocs(
      List<TradeAlloc> tradeAllocs, GroupBy groupBy) {

    // List to return
    List<TradeAlloc> mergedTradeAllocs = new ArrayList<>();

    // group the tradeAllocs by the values defined in groupBy
    List<List<TradeAlloc>> groupedTradeAllocs =
        groupTradeAllocs(tradeAllocs, groupBy);

    // merge the members of each group into a single TradeAlloc
    for (List<TradeAlloc> group : groupedTradeAllocs) {
      TradeAlloc mergedTradeAlloc = mergeTradeAllocs(group, groupBy);
      // add the merged tradeAlloc to the mergedTradeAllocs list
      mergedTradeAllocs.add(mergedTradeAlloc);
    }

    return mergedTradeAllocs;
  }

  /**
   * Place the tradeAllocs into groups (lists). Each tradeAlloc in a particular 
   * group will contain the exact same values for 'the fields defined in 
   * groupBy' as the other tradeAllocs in the same group.
   * @param tradeAllocs tradeAllocs
   * @param groupBy groupBy
   * @return A List of Lists (groups) of TradeAllocs
   */
  private static List<List<TradeAlloc>> groupTradeAllocs(
      List<TradeAlloc> tradeAllocs, GroupBy groupBy) {

    // Place the tradeAllocs into a map of groups (lists)
    // The key for each map entry will be defined by the combo of flags set in 
    // groupeBy the value of each map entry will be a group(list) of tradeAllocs
    Map<String, List<TradeAlloc>> tradeAllocsMap = new HashMap<>();
    for (TradeAlloc tradeAlloc : tradeAllocs) {
      int fundId = groupBy.fund ? tradeAlloc.getFund().getId() : 0;
      int holdingId = groupBy.holding ? tradeAlloc.getHoldingId() : 0;
      int typeId = groupBy.type ? tradeAlloc.getType().getId() : null;
      int lobId = groupBy.lob ? tradeAlloc.getFund().getLobId() : 0;

      String combinedId = fundId + ":" + holdingId + ":" + typeId + ":" + lobId;
      List<TradeAlloc> tempTradeAllocs = tradeAllocsMap.get(combinedId);
      if (tempTradeAllocs == null) {
        tempTradeAllocs = new ArrayList<>();
        tradeAllocsMap.put(combinedId, tempTradeAllocs);
      }
      tempTradeAllocs.add(tradeAlloc);
    }

    // convert the 'map of lists' into a 'list of lists'
    List<List<TradeAlloc>> groupedTradeAllocs = tradeAllocsMap.entrySet()
        .parallelStream().map(Map.Entry::getValue).collect(Collectors.toList());

    return groupedTradeAllocs;
  }

  /**
   * Merge all tradeAllocs into a new single TradeAlloc. The values of the 
   * fields in the TradeAlloc will be determined by the flags set in groupBy.
   */
  private static TradeAlloc mergeTradeAllocs(List<TradeAlloc> tradeAllocs,
      GroupBy groupBy) {

    // set values of relevant fields
    Fund fund = groupBy.fund ? tradeAllocs.get(0).getFund() : null;
    int holdingId = groupBy.holding ? tradeAllocs.get(0).getHoldingId() : 0;
    Type type = groupBy.type ? tradeAllocs.get(0).getType() : null;
    if (groupBy.lob) {
      int lobId = tradeAllocs.get(0).getFund().getLobId();
      fund = new Fund(0, null, null, lobId);
    }
    // calculate the sum of cashAmounts of all tradeAllocs in the group
    BigDecimal totalCashAmount =
        tradeAllocs.stream().map(TradeAlloc::getCashAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

    return new TradeAlloc(0, fund, holdingId, totalCashAmount, type);
  }


  /**
   * Filter the list of tradeAllocs by fund level of 'client'.
   * A sub list of tradeAllocs is returned. 
   * All TradeAlloc objects in the sub list have a fund level of 'client'.
   * @param tradeAllocs
   * @return List of client level TradeAllocs
   */
  public static List<TradeAlloc> filterByClientLevel(
      List<TradeAlloc> tradeAllocs) {

    return tradeAllocs.parallelStream()
        .filter(ta -> ta.getFund().getLevel() == FundLevel.CLIENT)
        .collect(Collectors.toList());
  }


  /**
   * Filter the list of tradeAllocs by fund level of 'primary'.
   * A sub list of tradeAllocs is returned. 
   * All TradeAlloc objects in the sub list have a fund level of 'primary'.
   * @param tradeAllocs
   * @return List of client level TradeAllocs
   */
  public static List<TradeAlloc> filterByPrimaryLevel(
      List<TradeAlloc> tradeAllocs) {

    return tradeAllocs.parallelStream()
        .filter(ta -> ta.getFund().getLevel() == FundLevel.PRIMARY)
        .collect(Collectors.toList());
  }

  /**
   * Defines the TradeAlloc fields that a collection of TradeAllocs should be 
   * grouped by. Values set to true will be 'grouped by'.
   */
  public static class GroupBy {

    final boolean fund;
    final boolean holding;
    final boolean type;
    final boolean lob;

    public GroupBy(boolean fund, boolean holding, boolean type, boolean lob) {

      this.fund = fund;
      this.holding = holding;
      this.type = type;
      this.lob = lob;
    }
  }
}
