package com.ilim.record.app.service;

import com.ilim.record.domain.model.TradeAlloc;

import java.util.List;

public interface ITradeAllocProcessorService {

  public List<TradeAlloc> processTradeAllocs(List<TradeAlloc> tradeAllocs);
}
