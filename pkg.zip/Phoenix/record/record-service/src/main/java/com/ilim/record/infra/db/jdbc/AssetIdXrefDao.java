package com.ilim.record.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.record.domain.IAssetIdXrefRepo;
import com.ilim.record.domain.model.AssetIdXref;
import com.ilim.record.domain.model.AssetIdXref.ExternalIdType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.inject.Inject;
import javax.sql.DataSource;

@Repository
public class AssetIdXrefDao extends NamedParameterJdbcDaoSupport
    implements IAssetIdXrefRepo {

  private static final Logger log =
      LoggerFactory.getLogger(AssetIdXrefDao.class);

  @Inject
  public AssetIdXrefDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  public String findExternalIdByIds(int fundId, ExternalIdType extIdType) {

    log.info("findExternalIdByIds ({})", fundId);
    final String sql = SQL.select_from_asset_id_xref_by_ids;
    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("fundId", fundId).addValue("extIdTypeId", extIdType.id());

    final AssetIdXref result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toAssetIdXref(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(String.format(
          "Error in findExternalIdByIds %s %s", fundId, extIdType.id()), ex);
    }

    return result.getExternalId();
  }


  private AssetIdXref toAssetIdXref(ResultSet rs) {

    try { 
      String externalId = rs.getString("external_id");

      return new AssetIdXref(0, externalId, null);

    } catch (SQLException e) {
      throw new AppSqlException("Error mapping sql result set to AssetIdXref!",
          e);
    }
  }
}
