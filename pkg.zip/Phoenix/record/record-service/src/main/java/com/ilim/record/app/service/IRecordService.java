package com.ilim.record.app.service;

import com.ilim.record.domain.model.TradeAlloc;

import java.util.List;

public interface IRecordService {

  public void record(List<TradeAlloc> tradeAllocs);
}
