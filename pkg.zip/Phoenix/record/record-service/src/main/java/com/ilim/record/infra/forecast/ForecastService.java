package com.ilim.record.infra.forecast;

import com.ilim.forecast.web.client.ForecastClient;
import com.ilim.record.app.service.IForecastService;
import com.ilim.record.domain.model.TradeAlloc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.util.List;

import javax.inject.Inject;

public class ForecastService implements IForecastService {

  private static final Logger log = LoggerFactory.getLogger(ForecastService.class);
  private ForecastClient forecastClient;
  
  @Inject
  public ForecastService(ForecastClient forecastclient){
    this.forecastClient = forecastclient;
  }
  
  public List<TradeAlloc> findForecastsByFundAndDate(int fundId, LocalDate forecastDate){
    
    log.info("findForecastsByFundAndDate {} {} ", fundId, forecastDate);
    //List<ForecastModel> forecastModels = forecastClient.findForecastsByFundAndDate(fundId, forecastDate);
    //List<TradeAlloc> forecasts = ForecastModelMapper.toFundAlloc(forecastModels);
    
    return null;
  }

}
