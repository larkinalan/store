package com.ilim.record.domain;

import com.ilim.record.domain.model.LobIdClientLevelCash;

public interface ILobIdClientLevelCashRepo {

  public LobIdClientLevelCash findLobClientCashByLobId(int lobId);
}
