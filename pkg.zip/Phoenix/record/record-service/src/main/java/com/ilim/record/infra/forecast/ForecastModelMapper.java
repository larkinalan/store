package com.ilim.record.infra.forecast;

public class ForecastModelMapper {

}
