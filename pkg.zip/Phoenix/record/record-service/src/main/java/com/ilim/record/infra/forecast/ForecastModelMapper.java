package com.ilim.record.infra.forecast;

import com.ilim.commons.time.DateUtils;
import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.domain.model.TradeAlloc.Type;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ForecastModelMapper {

  public static TradeAlloc toTradeAlloc(ForecastModelAllocData fmad,
      String forecastType, LocalDate recordOnDate) {

    int instrId = fmad.id.instrId;
    int fundId = fmad.id.fundId;
    Fund fund = new Fund(fundId, null, null, null, -1);
    int holdingId = fmad.id.holdingId;
    BigDecimal cashAmount = fmad.cash;
    Type type = Type.fromName(forecastType);
    LocalDate sendToAccDate =
        LocalDate.parse(fmad.forecastDate, DateUtils.DATE_FMT);

    return new TradeAlloc(instrId, fund, holdingId, cashAmount, type,
        sendToAccDate, recordOnDate);
  }

  public static List<TradeAlloc> totradeAlloc(
      List<ForecastModelAllocData> fmAllocDatas,
      ForecastInstructionData instr, LocalDate recordOnDate) {

    List<TradeAlloc> tradeAllocs = new ArrayList<>(fmAllocDatas.size());
    for (ForecastModelAllocData fmad : fmAllocDatas) {
      tradeAllocs.add(toTradeAlloc(fmad, instr.forecastType, recordOnDate));
    }

    return tradeAllocs;
  }
}
