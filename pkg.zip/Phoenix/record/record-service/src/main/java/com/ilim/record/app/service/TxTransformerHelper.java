package com.ilim.record.app.service;

import com.ilim.record.domain.IAssetIdXrefRepo;
import com.ilim.record.domain.IFundPriceLatestRepo;
import com.ilim.record.domain.ILobIdClientLevelCashRepo;
import com.ilim.record.domain.IPricingDateRepo;
import com.ilim.record.domain.ITresIlimILobIdClientLevelCashRepo;
import com.ilim.record.domain.model.AssetIdXref.ExternalIdType;
import com.ilim.record.domain.model.FundPriceLatest;
import com.ilim.record.domain.model.FundPriceLatest.PriceType;
import com.ilim.record.domain.model.LobIdClientLevelCash;
import com.ilim.record.domain.model.TresIlimLobIdClientLevelCash;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.inject.Inject;

public class TxTransformerHelper {

  private final IAssetIdXrefRepo assetIdXrefRepo;
  private final IFundPriceLatestRepo fundPriceLatestRepo;
  private final ILobIdClientLevelCashRepo lobIdClientLevelCashRepo;
  private final ITresIlimILobIdClientLevelCashRepo tiLobIdClientLevelCashRepo;
  private final IPricingDateRepo pricingDateRepo;
  private final IJobManagerService jobManagerService;

  @Inject
  public TxTransformerHelper(IAssetIdXrefRepo assetIdXrefRepo,
      IFundPriceLatestRepo fundPriceLatestRepo,
      ILobIdClientLevelCashRepo lobIdClientLevelCashRepo,
      ITresIlimILobIdClientLevelCashRepo tiLobIdClientLevelCashRepo,
      IPricingDateRepo pricingDateRepo, IJobManagerService jobManagerService) {

    this.assetIdXrefRepo = assetIdXrefRepo;
    this.fundPriceLatestRepo = fundPriceLatestRepo;
    this.lobIdClientLevelCashRepo = lobIdClientLevelCashRepo;
    this.tiLobIdClientLevelCashRepo = tiLobIdClientLevelCashRepo;
    this.pricingDateRepo = pricingDateRepo;
    this.jobManagerService = jobManagerService;
  }


  /** 
   * Common functions
   */
  public LocalDate findTradeDate() {
    return pricingDateRepo.findCurrentPricingDate();
  }

  public LocalDate findPaymentDate() {
    return pricingDateRepo.findNextPricingDate();
  }

  public int findTxNumOriginSystem() {
    // TODO: This function shouldn't be called from within a loop if possible, as it makes a network
    // call
    return jobManagerService.getNextMessageId();
  }


  /**
   *  Unit Tx functions
   */
  public String findAssetPortfolioExtId(int fundId) {
    return assetIdXrefRepo.findExternalIdByIds(fundId,
        ExternalIdType.SCD_PORTFOLIO_ID);
  }

  public String findLiabilityPortfolioSecurityId(int fundId) {
    return assetIdXrefRepo.findExternalIdByIds(fundId,
        ExternalIdType.SCD_FUND_CERT_ID);
  }

  public String findLiabilityPortfolioId(int fundId) {
    return assetIdXrefRepo.findExternalIdByIds(fundId,
        ExternalIdType.SCD_LIABILITY_PORTFOLIO_ID);
  }

  public BigDecimal findClosingPrice(int fundId) {

    FundPriceLatest fundPriceLatest =
        fundPriceLatestRepo.findByIdAndType(fundId, PriceType.UNIT_TRANSACTION);

    return fundPriceLatest.getClosingPrice();
  }


  /** 
   * Cash Tx functions
   */
  public String findTreasuryExtId(int fundId) {
    return assetIdXrefRepo.findExternalIdByIds(fundId,
        ExternalIdType.SCD_FUND_CERT_ID);
  }

  public String findTreasuryPortfolioId() {
    // TODO: select from 'investing level mappings for recording' table
    return "";
  }

  public LobIdClientLevelCash getLobIdClientLevelCash(int lobId) {
    return lobIdClientLevelCashRepo.findLobClientCashByLobId(lobId);
  }

  public TresIlimLobIdClientLevelCash findTresIlimLobIdClientLevelCash(
      int lobId) {
    return tiLobIdClientLevelCashRepo.findTresIlimLobClientCashByLobId(lobId);
  }
}
