package com.ilim.record.app.service;

import com.ilim.commons.domain.model.Currency;
import com.ilim.commons.domain.model.PriceType;
import com.ilim.record.domain.IAssetIdXrefRepo;
import com.ilim.record.domain.IFundPriceLatestRepo;
import com.ilim.record.domain.IFundsDefRepo;
import com.ilim.record.domain.IPricingDateRepo;
import com.ilim.record.domain.IScdLobClientCashFinSepRepo;
import com.ilim.record.domain.IScdLobClientCashTresIlimRepo;
import com.ilim.record.domain.IScdPortGrpInvestCashRepo;
import com.ilim.record.domain.model.AssetIdXref.ExternalIdType;
import com.ilim.record.domain.model.FundPriceLatest;
import com.ilim.record.domain.model.ScdLobClientCashFinSep;
import com.ilim.record.domain.model.ScdLobClientCashTresIlim;
import com.ilim.record.domain.model.ScdTxType;
import com.ilim.record.domain.model.TradeAlloc.Type;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

import javax.inject.Inject;

public class TxTransformerHelper {

  private final IAssetIdXrefRepo assetIdXrefRepo;
  private final IFundPriceLatestRepo fundPriceLatestRepo;
  private final IScdLobClientCashFinSepRepo scdLobClientCashFinSepRepo;
  private final IScdLobClientCashTresIlimRepo scdLobClientCashTresIlimRepo;
  private final IScdPortGrpInvestCashRepo scdPortGrpInvestCashRepo;
  private final IFundsDefRepo fundsDefRepo;
  private final IPricingDateRepo pricingDateRepo;
  
  // TODO: !!!!IMPORTANANT!!!! These values should be stored in commons. Ask Alan where exactly.
  public static final int UNIT_SCALE = 4;
  public static final RoundingMode UNIT_ROUNDING_MODE = RoundingMode.HALF_UP;

  @Inject
  public TxTransformerHelper(IAssetIdXrefRepo assetIdXrefRepo,
      IFundPriceLatestRepo fundPriceLatestRepo,
      IScdLobClientCashFinSepRepo scdLobClientCashFinSepRepo,
      IScdLobClientCashTresIlimRepo tiLobIdClientLevelCashRepo,
      IScdPortGrpInvestCashRepo scdPortGrpInvestCashRepo,
      IFundsDefRepo fundsDefRepo,
      IPricingDateRepo pricingDateRepo) {

    this.assetIdXrefRepo = assetIdXrefRepo;
    this.fundPriceLatestRepo = fundPriceLatestRepo;
    this.scdLobClientCashFinSepRepo = scdLobClientCashFinSepRepo;
    this.scdLobClientCashTresIlimRepo = tiLobIdClientLevelCashRepo;
    this.scdPortGrpInvestCashRepo = scdPortGrpInvestCashRepo;
    this.fundsDefRepo = fundsDefRepo;
    this.pricingDateRepo = pricingDateRepo;
  }


  /******************
   * Common functions
   *****************/
  public BigDecimal calculateNominal(BigDecimal cashAmount, BigDecimal price) {
    return cashAmount.divide(price, UNIT_SCALE, UNIT_ROUNDING_MODE);
  }

  public boolean isNegative(BigDecimal value) {
    return value.compareTo(BigDecimal.ZERO) == -1;
  }

  public LocalDate findTradeDate() {
    return pricingDateRepo.findCurrentPricingDate();
  }

  public int mapToScdTransactionType(Type type) {
    // map from a TradeAlloc.Type to a ScdTxType
    int txFreeCode;
    switch (type) {

      case NEW_MONEY:
        txFreeCode = ScdTxType.NORMAL_APPROPS.getId();
        break;

      case MGMT_CHARGE:
        txFreeCode = ScdTxType.MGMT_CHRGS.getId();
        break;

      case REBALANCE:
        txFreeCode = ScdTxType.REBALANCE.getId();
        break;

      default:
        throw new IllegalArgumentException(
            "No ScdTxType mapping exists for value:" + type);
    }

    return txFreeCode;
  }


  /********************
   *  Unit Tx functions
   ********************/
  public String findAssetPortfolioExtId(int fundId) {
    return assetIdXrefRepo.findExternalIdByIds(fundId,
        ExternalIdType.SCD_PORTFOLIO_ID);
  }

  public String findLiabilityPortfolioSecurityId(int fundId) {
    return assetIdXrefRepo.findExternalIdByIds(fundId,
        ExternalIdType.SCD_FUND_CERT_ID);
  }

  public String findLiabilityPortfolioId(int fundId) {
    return assetIdXrefRepo.findExternalIdByIds(fundId,
        ExternalIdType.SCD_LIABILITY_PORTFOLIO_ID);
  }

  public BigDecimal findClosingPrice(int fundId) {

    FundPriceLatest fundPriceLatest =
        fundPriceLatestRepo.findByIdAndType(fundId, PriceType.UNIT_TRANSACTION);

    return fundPriceLatest.getClosingPrice();
  }


  /*******************
   * Cash Tx functions
   *******************/
  public String findTreasurySecurityId(int fundId, Type type) {
    String secIdSuffix = fundsDefRepo.findScdFundName(fundId);
    String securityId =
        ((type == Type.MGMT_CHARGE) ? 
            TxTransformer.TREASURY_MGMT : TxTransformer.TREASURY_NORMAL_APP) 
        + secIdSuffix;
    
    return securityId;
  }

  public String findTreasuryPortfolioId(int fundId, Currency baseCurrency) {
    return scdPortGrpInvestCashRepo.findPortfolioOwnerId(fundId, baseCurrency);
  }

  public String findTreasuryBankAcc(int fundId) {

    String prefix = TxTransformer.TREASURY_BANK_ACC_PREFIX;
    String suffix = assetIdXrefRepo.findExternalIdByIds(fundId,
        ExternalIdType.SCD_PORTFOLIO_ID);;

    return prefix + suffix;
  }

  public ScdLobClientCashFinSep findScdLobClientCashFinSep(int lobId) {
    return scdLobClientCashFinSepRepo.findScdLobClientCashFinSep(lobId);
  }

  public ScdLobClientCashTresIlim findScdLobClientCashTresIlim(int lobId) {
    return scdLobClientCashTresIlimRepo.findScdLobClientCashTresIlim(lobId);
  }
}
