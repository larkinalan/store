package com.ilim.record.app.service;

import com.ilim.commons.domain.model.Currency;
import com.ilim.record.domain.IAssetIdXrefRepo;
import com.ilim.record.domain.IFundPriceLatestRepo;
import com.ilim.record.domain.IScdLobClientCashFinSepRepo;
import com.ilim.record.domain.IPricingDateRepo;
import com.ilim.record.domain.IScdAssetPortTresRepo;
import com.ilim.record.domain.IScdLobClientCashTresIlimRepo;
import com.ilim.record.domain.IScdPortGrpInvestCashRepo;
import com.ilim.record.domain.IScdSecurityRepo;
import com.ilim.record.domain.model.AssetIdXref.ExternalIdType;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.FundPriceLatest;
import com.ilim.record.domain.model.FundPriceLatest.PriceType;
import com.ilim.record.domain.model.TradeAlloc.Type;
import com.ilim.record.domain.model.ScdAssetPortTres;
import com.ilim.record.domain.model.ScdLobClientCashFinSep;
import com.ilim.record.domain.model.ScdLobClientCashTresIlim;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.inject.Inject;

public class TxTransformerHelper {

  private final IAssetIdXrefRepo assetIdXrefRepo;
  private final IFundPriceLatestRepo fundPriceLatestRepo;
  private final IScdLobClientCashFinSepRepo scdLobClientCashFinSepRepo;
  private final IScdLobClientCashTresIlimRepo scdLobClientCashTresIlimRepo;
  private final IScdPortGrpInvestCashRepo scdPortGrpInvestCashRepo;
  private final IScdAssetPortTresRepo scdAssetPortTresRepo;
  private final IScdSecurityRepo scdSecurityRepo;
  private final IPricingDateRepo pricingDateRepo;
  private final IJobManagerService jobManagerService;

  @Inject
  public TxTransformerHelper(IAssetIdXrefRepo assetIdXrefRepo,
      IFundPriceLatestRepo fundPriceLatestRepo,
      IScdLobClientCashFinSepRepo scdLobClientCashFinSepRepo,
      IScdLobClientCashTresIlimRepo tiLobIdClientLevelCashRepo,
      IScdPortGrpInvestCashRepo scdPortGrpInvestCashRepo,
      IScdAssetPortTresRepo scdAssetPortTresRepo,
      IScdSecurityRepo scdSecurityRepo, IPricingDateRepo pricingDateRepo,
      IJobManagerService jobManagerService) {

    this.assetIdXrefRepo = assetIdXrefRepo;
    this.fundPriceLatestRepo = fundPriceLatestRepo;
    this.scdLobClientCashFinSepRepo = scdLobClientCashFinSepRepo;
    this.scdLobClientCashTresIlimRepo = tiLobIdClientLevelCashRepo;
    this.scdPortGrpInvestCashRepo = scdPortGrpInvestCashRepo;
    this.scdAssetPortTresRepo = scdAssetPortTresRepo;
    this.scdSecurityRepo = scdSecurityRepo;
    this.pricingDateRepo = pricingDateRepo;
    this.jobManagerService = jobManagerService;
  }


  /** 
   * Common functions
   */
  public LocalDate findTradeDate() {
    return pricingDateRepo.findCurrentPricingDate();
  }

  public LocalDate findPaymentDate() {
    return pricingDateRepo.findNextPricingDate();
  }

  public int findTxNumOriginSystem() {
    // TODO: This function shouldn't be called from within a loop if possible, as it makes a network
    // call
    return jobManagerService.getNextMessageId();
  }


  /**
   *  Unit Tx functions
   */
  public String findAssetPortfolioExtId(int fundId) {
    return assetIdXrefRepo.findExternalIdByIds(fundId,
        ExternalIdType.SCD_PORTFOLIO_ID);
  }

  public String findLiabilityPortfolioSecurityId(int fundId) {
    return assetIdXrefRepo.findExternalIdByIds(fundId,
        ExternalIdType.SCD_FUND_CERT_ID);
  }

  public String findLiabilityPortfolioId(int fundId) {
    return assetIdXrefRepo.findExternalIdByIds(fundId,
        ExternalIdType.SCD_LIABILITY_PORTFOLIO_ID);
  }

  public BigDecimal findClosingPrice(int fundId) {

    FundPriceLatest fundPriceLatest =
        fundPriceLatestRepo.findByIdAndType(fundId, PriceType.UNIT_TRANSACTION);

    return fundPriceLatest.getClosingPrice();
  }


  /** 
   * Cash Tx functions
   */
  public String findTreasurySecurityId(Fund fund, Type type) {
    
    String returnVal;
    // find the assetPortfolio for the given fund and type
    ScdAssetPortTres scdAssetPortTres = scdAssetPortTresRepo.findByFund(fund);
    String assetPortfolio = (type == Type.MANAGEMENT_CHARGES)
        ? scdAssetPortTres.getMcAlmNum() : scdAssetPortTres.getAppAlmNum();
    
    // check if assetPortfolio exists in dimension
    boolean exists = scdSecurityRepo.existsSecurity(assetPortfolio);
    if (exists) {
      returnVal = assetPortfolio;
    } else {
      // assetPortfolio doesn't exist in dimension, so find the default 
      // alternative for the given baseCurrency and type
      ScdAssetPortTres defaultSapt =
          scdAssetPortTresRepo.findDefaultByCurrency(fund.getBaseCurrency());
      returnVal = (type == Type.MANAGEMENT_CHARGES) ? defaultSapt.getMcAlmNum()
          : defaultSapt.getAppAlmNum();
    }

    return returnVal;
  }

  public String findTreasuryPortfolioId(int fundId, Currency baseCurrency) {
    return scdPortGrpInvestCashRepo.findPortfolioOwnerId(fundId, baseCurrency);
  }

  public ScdLobClientCashFinSep findScdLobClientCashFinSep(int lobId) {
    return scdLobClientCashFinSepRepo.findScdLobClientCashFinSep(lobId);
  }

  public ScdLobClientCashTresIlim findScdLobClientCashTresIlim(int lobId) {
    return scdLobClientCashTresIlimRepo.findScdLobClientCashTresIlim(lobId);
  }
}
