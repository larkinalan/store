package com.ilim.record.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.record.domain.ILobIdClientLevelCashRepo;
import com.ilim.record.domain.model.LobIdClientLevelCash;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.inject.Inject;
import javax.sql.DataSource;

public class LobIdClientLevelCashDao extends NamedParameterJdbcDaoSupport
    implements ILobIdClientLevelCashRepo {

  private static final Logger log =
      LoggerFactory.getLogger(LobIdClientLevelCashDao.class);

  @Inject
  public LobIdClientLevelCashDao(DataSource dataSource) {

    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  public LobIdClientLevelCash findLobClientCashByLobId(int lobId) {

    log.info("findLobClientCashByLobId ({})", lobId);
    final String sql = SQL.select_from_lob_client_cash_by_lob_id;
    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("lobId", lobId);

    final LobIdClientLevelCash result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toLobIdClientLevelCash(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findLobClientCashByLobId " + lobId,
          ex);
    }

    return result;
  }

  private LobIdClientLevelCash toLobIdClientLevelCash(ResultSet rs) {

    try {
      String portfolioOwnerId = rs.getString("portfolio_owner_id");
      String appAlmNumber = rs.getString("app_alm_no");

      return new LobIdClientLevelCash(null, portfolioOwnerId, appAlmNumber,
          null, null, null);

    } catch (SQLException e) {
      throw new AppSqlException(
          "Error mapping sql result set to LobIdClientLevelCash!", e);
    }
  }
}
