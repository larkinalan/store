package com.ilim.record.infra.forecast;

import com.ilim.forecast.web.api.ForecastInstructionData;
import com.ilim.forecast.web.api.ForecastModelAllocData;
import com.ilim.forecast.web.client.ForecastClient;
import com.ilim.record.app.service.IForecastService;
import com.ilim.record.domain.model.TradeAlloc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class ForecastServiceAdapter implements IForecastService {

  private static final Logger log =
      LoggerFactory.getLogger(ForecastServiceAdapter.class);
  private ForecastClient forecastClient;

  @Inject
  public ForecastServiceAdapter(ForecastClient forecastClient) {
    this.forecastClient = forecastClient;
  }

  public List<TradeAlloc> findForecastsByFundAndDate(int fundId,
      LocalDate forecastDate) {

    log.info("findForecastsByFundAndDate {} {} ", fundId, forecastDate);
    // List<ForecastModel> forecastModels = forecastClient.findForecastsByFundAndDate(fundId,
    // forecastDate);
    // List<TradeAlloc> forecasts = ForecastModelMapper.toFundAlloc(forecastModels);

    return null;
  }

  /**
   * Find any unrecorded forecast trade allocs associated with the 
   * tradeAlloc passed in
   */
  public List<TradeAlloc> findUnrecordedForecasts(TradeAlloc tradeAlloc) {

    log.info("findUnrecordedForecasts {}", tradeAlloc);
    // list to return
    List<TradeAlloc> unrecdForecasts = new ArrayList<>();

    // find unrecorded forecast TAs that have the same fundId and sendToAccDate as the tradeAlloc
    int fundId = tradeAlloc.getFund().getId();
    LocalDate sendToAccDate = tradeAlloc.getSendToAccDate();
    List<ForecastModelAllocData> forecastModels = forecastClient
        .findUnrecordedModelsByFundIdAndDate(fundId, sendToAccDate);

    // find the instruction data for the forecastModels
    if (forecastModels.get(0) != null) {
      int instrId = forecastModels.get(0).id.instrId;
      ForecastInstructionData instrData = findForecastInstr(instrId);
      unrecdForecasts = ForecastModelMapper.totradeAlloc(forecastModels,
          instrData, tradeAlloc.getRecordOnDate());
    }

    return unrecdForecasts;
  }

  private ForecastInstructionData findForecastInstr(int instrId) {
    return forecastClient.findInstrById(instrId);
  }

}
