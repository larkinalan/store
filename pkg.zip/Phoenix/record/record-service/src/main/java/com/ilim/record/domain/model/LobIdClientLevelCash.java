package com.ilim.record.domain.model;

public class LobIdClientLevelCash {

  private final String scdLobId;
  private final String portfolioOwnerId;
  private final String appAlmNum;
  private final String mcAlmNum;
  private final String appBankAcc;
  private final String mcBankAcc;

  
  public LobIdClientLevelCash(String scdLobId, String portfolioOwnerId,
      String appAlmNumber, String mcAlmNumber, String appBankAccount,
      String mcBankAccount) {

    this.scdLobId = scdLobId;
    this.portfolioOwnerId = portfolioOwnerId;
    this.appAlmNum = appAlmNumber;
    this.mcAlmNum = mcAlmNumber;
    this.appBankAcc = appBankAccount;
    this.mcBankAcc = mcBankAccount;
  }

  public String getScdLobId() {
    return scdLobId;
  }

  public String getPortfolioOwnerId() {
    return portfolioOwnerId;
  }

  public String getAppAlmNum() {
    return appAlmNum;
  }

  public String getMcAlmNum() {
    return mcAlmNum;
  }

  public String getAppBankAcc() {
    return appBankAcc;
  }

  public String getMcBankAcc() {
    return mcBankAcc;
  }
}
