package com.ilim.record.domain;

import com.ilim.record.domain.model.AssetIdXref.ExternalIdType;

public interface IAssetIdXrefRepo {

  public String findExternalIdByIds(int fundId, ExternalIdType extIdType);
}
