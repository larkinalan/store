package com.ilim.record.domain.model;

public class TresIlimLobIdClientLevelCash {

  private final String scdLobId;
  private final String tresIlim;
  private final String appAlmNum;
  private final String mcAlmNum;
  private final String appBankAcc;
  private final String mcBankAcc;


  public TresIlimLobIdClientLevelCash(String scdLobId, String tresIlim,
      String appAlmNum, String mcAlmNum, String appBankAcc, String mcBankAcc) {

    this.scdLobId = scdLobId;
    this.tresIlim = tresIlim;
    this.appAlmNum = appAlmNum;
    this.mcAlmNum = mcAlmNum;
    this.appBankAcc = appBankAcc;
    this.mcBankAcc = mcBankAcc;
  }


  public String getScdLobId() {
    return scdLobId;
  }

  public String getTresIlim() {
    return tresIlim;
  }

  public String getAppAlmNum() {
    return appAlmNum;
  }

  public String getMcAlmNum() {
    return mcAlmNum;
  }

  public String getAppBankAcc() {
    return appBankAcc;
  }

  public String getMcBankAcc() {
    return mcBankAcc;
  }
}
