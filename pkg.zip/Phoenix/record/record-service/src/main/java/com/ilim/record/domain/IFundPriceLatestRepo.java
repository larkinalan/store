package com.ilim.record.domain;

import com.ilim.commons.domain.model.PriceType;
import com.ilim.record.domain.model.FundPriceLatest;

public interface IFundPriceLatestRepo {

  public FundPriceLatest findByIdAndType(int fundId, PriceType priceType);
}
