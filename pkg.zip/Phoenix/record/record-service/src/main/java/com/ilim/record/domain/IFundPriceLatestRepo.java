package com.ilim.record.domain;

import com.ilim.record.domain.model.FundPriceLatest;
import com.ilim.record.domain.model.FundPriceLatest.PriceType;

public interface IFundPriceLatestRepo {

  public FundPriceLatest findByIdAndType(int fundId, PriceType priceType);
}
