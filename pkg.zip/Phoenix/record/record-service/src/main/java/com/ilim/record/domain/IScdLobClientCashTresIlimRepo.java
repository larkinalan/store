package com.ilim.record.domain;

import com.ilim.record.domain.model.ScdLobClientCashTresIlim;

public interface IScdLobClientCashTresIlimRepo {

  public ScdLobClientCashTresIlim findScdLobClientCashTresIlim(
      int lobId);
}
