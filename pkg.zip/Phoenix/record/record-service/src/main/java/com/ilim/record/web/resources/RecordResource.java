package com.ilim.record.web.resources;

import com.ilim.record.app.service.IFundService;
import com.ilim.record.app.service.IRecordService;
import com.ilim.record.domain.model.Fund;
import com.ilim.record.domain.model.TradeAlloc;
import com.ilim.record.web.datatype.TradeAllocData;
import com.ilim.record.web.datatype.TradeAllocDataMapper;

import com.codahale.metrics.annotation.Timed;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Record rest service.
 * 
 * <p>This manages all the http requests for the Record module.
 * Exception are mapped to HTTP error codes @see AppExceptionMapper .
 * 
 * <p>Consumes/Produces MediaType.APPLICATION_JSON only. 
 * 
 * <p>Requests and Responses will automatically get logged by filters.
 *
 * @author Barry Folan
 */
@Singleton
@Service
@Path("record")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class RecordResource {

  private final IFundService fundService;
  private final IRecordService recordService;

  @Inject
  public RecordResource(IFundService fundService,
      IRecordService recordService) {

    this.fundService = fundService;
    this.recordService = recordService;
  }

  /**
   * Record the list of TradeAllocDatas passed in.
   * @param tradeAllocDatas List of TradeAllocData
   * @return response response
   * @throws Exception 
   */
  @POST
  @Timed
  public Response record(List<TradeAllocData> tradeAllocDatas)
      throws Exception {

    // retrieve the funds referenced in the tradeAllocDatas
    List<Integer> fundIds = tradeAllocDatas.parallelStream()
        .map(tad -> tad.fundId).collect(Collectors.toList());
    Map<Integer, Fund> funds = fundService.findFundsByIds(fundIds);

    // map TradeAllocDatas to TradeAllocs
    List<TradeAlloc> tradeAllocs =
        TradeAllocDataMapper.toTradeAllocs(tradeAllocDatas, funds);
    
    //record the tradeAllocs
    recordService.record(tradeAllocs);

    return Response.ok("done").build();
  }

}
