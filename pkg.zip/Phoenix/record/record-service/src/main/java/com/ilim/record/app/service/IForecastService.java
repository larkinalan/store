package com.ilim.record.app.service;

import com.ilim.record.domain.model.TradeAlloc;

import java.time.LocalDate;
import java.util.List;

public interface IForecastService {

  public List<TradeAlloc> findForecastsByFundAndDate(int fundId, LocalDate forecastDate);
  
  public List<TradeAlloc> findUnrecordedForecasts(TradeAlloc tradeAlloc);
}
