package com.ilim.record.infra.fund;

import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.client.FundClient;
import com.ilim.record.app.service.IFundService;
import com.ilim.record.domain.model.Fund;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

@Service
public class FundServiceAdapter implements IFundService {

  private static final Logger log = LoggerFactory.getLogger(FundServiceAdapter.class);
  private FundClient fundClient;

  @Inject
  public FundServiceAdapter(FundClient fundClient) {
    this.fundClient = fundClient;
  }

  @Override
  public Map<Integer, Fund> findFundsByIds(List<Integer> fundIds)
      throws Exception {

    log.info("findFundsByIds ({})", fundIds);
    Map<Integer, Fund> funds = new HashMap<Integer, Fund>();

    try {
      // get list of fundDatas
      List<FundData> fundDatas =
          fundClient.api().findFunds(fundIds).execute().body();
      // map from FundDatas to Funds
      List<Fund> fundList = FundMapper.toFund(fundDatas);
      // translate from 'list of funds' to 'map of funds'
      fundList.forEach(f -> funds.put(f.getId(), f));

    } catch (IOException e) {
      log.error("FundClient findFundsByIds failed", e.getMessage());
      throw e;
    }

    return funds;
  }
}
