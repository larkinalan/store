package com.ilim.record.infra.db.jdbc;

import com.ilim.record.domain.IPricingDateRepo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

import java.time.LocalDate;

import javax.inject.Inject;
import javax.sql.DataSource;

public class PricingDateDao extends NamedParameterJdbcDaoSupport implements IPricingDateRepo{

  private static final Logger log =
      LoggerFactory.getLogger(PricingDateDao.class);

  @Inject
  public PricingDateDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  } 
  
  @Override
  public LocalDate findCurrentPricingDate() {
    // TODO Auto-generated method stub
    return LocalDate.now();
  }

  @Override
  public LocalDate findNextPricingDate() {
    // TODO Auto-generated method stub
    return LocalDate.now();
  }

}
