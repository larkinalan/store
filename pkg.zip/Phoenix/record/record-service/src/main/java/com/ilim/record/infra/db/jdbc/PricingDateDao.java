package com.ilim.record.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.time.DateUtils;
import com.ilim.record.domain.IPricingDateRepo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

import javax.inject.Inject;
import javax.sql.DataSource;

@Repository
public class PricingDateDao extends NamedParameterJdbcDaoSupport
    implements IPricingDateRepo {

  private static final Logger log =
      LoggerFactory.getLogger(PricingDateDao.class);

  @Inject
  public PricingDateDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  public LocalDate findCurrentPricingDate() {
    // TODO: 1) Is it ok to call a stored function in this manner? Or should we use the option
    // commented out below?
    // TODO: 2) This function should be cached as it is called multiple times in one day
    log.info("findScdFundName");
    final String todaysDate = LocalDate.now().format(DateUtils.DATE_FMT);
    final String sql = SQL.select_current_price_date;
    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("todaysDate", todaysDate);

    final String result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return rs.getString("pricingDate");
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(
          String.format("Error in findCurrentPricingDate2"), ex);
    }

    return LocalDate.parse(result, DateUtils.DATE_FMT);
  }

  /*
   * Best effort using jdbc stored function call. Doesn't work on overloaded oracle function
   * 
   * @Override
   * public LocalDate findCurrentPricingDate() {
   * 
   * final String todaysDate = LocalDate.now().format(DateUtils.DATE_FMT);
   * 
   * SqlParameter spIn = new SqlParameter("iv_business_dt", Types.VARCHAR);
   * SqlParameter spOut = new SqlParameter("ld_date", Types.VARCHAR);
   * 
   * getPricingDay = new
   * SimpleJdbcCall(getJdbcTemplate()).withSchemaName("FMUATLDR").withCatalogName(
   * "STRATEGY_DEFS_PKG")
   * .withFunctionName("get_pricing_day").declareParameters(spIn).withReturnValue().
   * declareParameters(spOut).withoutProcedureColumnMetaDataAccess();
   * 
   * SqlParameterSource in = new MapSqlParameterSource()
   * .addValue("iv_business_dt", todaysDate).addValue("ld_date", null);
   * 
   * String date = getPricingDay.executeFunction(String.class, in);
   * 
   * return LocalDate.parse(date);
   * }
   */

  /*
   * Works for non overloaded function
   * 
   * @Override
   * public LocalDate findCurrentPricingDate() {
   * 
   * String today = "28-JAN-16";
   * SqlParameter spIn = new SqlParameter("iv_prev_price_dt", Types.VARCHAR);
   * SqlParameter spOut = new SqlParameter("ld_date", Types.VARCHAR);
   * 
   * getPricingDay = new
   * SimpleJdbcCall(getJdbcTemplate()).withSchemaName("FMUATLDR").withCatalogName(
   * "STRATEGY_DEFS_PKG")
   * .withFunctionName("get_next_pricing_date").declareParameters(spIn).withReturnValue().
   * declareParameters(spOut);
   * SqlParameterSource in = new MapSqlParameterSource()
   * .addValue("iv_prev_price_dt", today);
   * 
   * String name = getPricingDay.executeFunction(String.class, in);
   * 
   * return null;
   * }
   */

}
