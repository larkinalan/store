package com.ilim.fund.web.client;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.fund.FundServiceApplication;
import com.ilim.fund.TestData;
import com.ilim.fund.web.datatype.FundData;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.List;

public class FundClientIT {

  private static FundServiceApplication fsa;
  private FundClient client;
  
  /**
   * Set up req'd services.
   * @throws Exception
   * 
   */
  @BeforeClass
  public static void setUpOnce() throws Exception {
    
    fsa = new FundServiceApplication();
    fsa.startUp();
    //TODO: replace sleep with proper thread notification (CompletableFuture?)
    Thread.currentThread().sleep(5000);
  }
  
  @AfterClass
  public static void shutdown() {
    fsa.shutDown();
  }
  
  @Before
  public void setupEachTime() {
    client = new FundClient();
  }
  
  @Test
  public void findById() throws IOException {

    FundData expected = TestData.PCF_Data; 
    FundData actual = client.api().findById(expected.fundId).execute().body();
    
    assertThat(expected).isEqualToComparingFieldByField(actual);
  }
  
  @Test
  public void find() throws IOException {

    String level = "CLIENT";
    
    List<FundData> fundList =
        client.api().find(level).execute().body();

    assertThat(fundList.size()).isGreaterThan(0);
    assertThat(fundList).extracting("level").containsOnly(level);
  }
}
