package com.ilim.fund;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.fund.web.datatype.FundData;
import com.ilim.fund.web.datatype.FundHoldingData;
import com.ilim.fund.web.datatype.FundPriceData;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.math.BigDecimal;

/*
 *  Data used for 'expected' results in testing
 *    
 *  @formatter:off
 *  CHECKSTYLE:OFF
 */
public class TestData {

  private static final ObjectMapper mapper = new ObjectMapper();

  /**
   * Serialize the object passed in into a json String.
   * @param obj Object to serialize
   * @return String
   * @throws JsonProcessingException
   * 
   */
  public static String jsonSerialize(Object obj)
      throws JsonProcessingException {

    return mapper.writeValueAsString(obj);
  }
  
  /*
   * FundData
   */
  public static final FundData PCF_Data = new FundData(17444, "CLIENT");
  public static final FundData CAS_1_Data = new FundData(17803, "TAX");
  
  /*
   * FundHoldingData
   */
  public static final FundHoldingData PCF_HoldingData = new FundHoldingData(PCF_Data.fundId, CAS_1_Data.fundId, BigDecimal.TEN);
  public static final FundHoldingData IL_FTSE_RAFI_HOLDING_1 = new FundHoldingData(43865, 3630, BigDecimal.ONE);
  
  public static void assertSimilar(FundHoldingData fhOne, FundHoldingData fhTwo) {
    assertThat(fhOne).isEqualToIgnoringGivenFields(fhTwo, "holdingQty");
  }
  
  /*
   * FundPriceData
   */
  public static final String UNIT_TRANSACTION = "UNIT_TRANSACTION";
  public static final FundPriceData PCF_Price_Data = new FundPriceData(PCF_Data.fundId, BigDecimal.ONE, "13/11/2015", UNIT_TRANSACTION);
  public static final FundPriceData CAS_1_Price_Data = new FundPriceData(CAS_1_Data.fundId, BigDecimal.ONE, "13/11/2015", UNIT_TRANSACTION);
  
  public static void assertSimilar(FundPriceData fpOne, FundPriceData fpTwo) {
    assertThat(fpOne).isEqualToIgnoringGivenFields(fpTwo, "price", "priceDate");
  }
  
  /*
   * ErrorData
   */
  public static final String CLIENT_ERROR = "CLIENT_ERROR";
}
