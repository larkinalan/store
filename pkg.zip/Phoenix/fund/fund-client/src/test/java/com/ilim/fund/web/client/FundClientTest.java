package com.ilim.fund.web.client;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.web.api.ErrorData;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.squareup.okhttp.HttpUrl;
import com.squareup.okhttp.ResponseBody;
import com.squareup.okhttp.mockwebserver.MockResponse;
import com.squareup.okhttp.mockwebserver.MockWebServer;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FundClientTest {

  private MockWebServer server;
  private FundClient client;
  private HttpUrl baseUrl;

  /** Create fund client against mock web server. */
  @Before
  public void setUp() throws Exception {

    server = new MockWebServer();
    server.start();
    baseUrl = server.url("/mock/");
    client = new FundClient(baseUrl.toString());
  }

  @After
  public void tearDown() throws Exception {

    server.shutdown();
  }

  @Test
  public void findFund() throws Exception {

    FundData expected = new FundData(123, "CLIENT", BigDecimal.TEN);
    server.enqueue(mockJsonResponse(expected));

    FundData actual = client.api().findFund(expected.fundId).execute().body();
    assertThat(expected).isEqualToComparingFieldByField(actual);
  }

  @Test
  public void findFundsByLevel() throws Exception {

    // mock
    final String level = "INVESTING";
    List<FundData> expected = mockFunds(level);
    server.enqueue(mockJsonResponse(expected));

    // test
    List<FundData> actual =
        client.api().findFundsByLevel(level).execute().body();

    // verify
    assertThat(expected).usingFieldByFieldElementComparator()
        .containsExactlyElementsOf(actual);
  }

  @Test
  public void findFundHolding() throws IOException {

    // mock
    FundHoldingData expected = new FundHoldingData(123, 456, BigDecimal.TEN);
    server.enqueue(mockJsonResponse(expected));

    // test
    FundHoldingData actual = client.api()
        .findFundHolding(expected.fundId, expected.holdingId).execute().body();

    // verify
    assertThat(expected).isEqualToComparingFieldByField(actual);
  }

  @Test
  public void findFundHoldingsByFund() throws IOException {

    // mock
    int fundId = 123;
    List<FundHoldingData> expected = mockFundHoldings(fundId);
    server.enqueue(mockJsonResponse(expected));

    // test
    List<FundHoldingData> actual =
        client.api().findFundHoldings(fundId).execute().body();

    // verify
    assertThat(expected).usingFieldByFieldElementComparator()
        .containsExactlyElementsOf(actual);
  }

  @Test
  public void fundHoldingsLookthru() throws IOException {

    // mock
    int fundId = 123;
    List<FundHoldingData> expected = mockFundHoldings(fundId);
    server.enqueue(mockJsonResponse(expected));

    // test
    List<FundHoldingData> actual =
        client.api().fundHoldingsLookthru(fundId).execute().body();

    assertThat(expected).usingFieldByFieldElementComparator()
        .containsExactlyElementsOf(actual);
  }

  @Test
  public void findUnitPrice() throws IOException {

    // mock data
    FundPriceData expected = new FundPriceData(123, BigDecimal.ONE,
        "01/01/2016", "UNIT_TRANSACTION");
    server.enqueue(mockJsonResponse(expected));

    // test
    FundPriceData actual =
        client.api().findPrice(expected.fundId).execute().body();

    // verify
    assertThat(expected).isEqualToComparingFieldByField(actual);
  }

  @Test
  public void findOfferPrice() throws IOException {

    // mock data
    FundPriceData expected =
        new FundPriceData(123, BigDecimal.ONE, "01/01/2016", "OFFER");
    server.enqueue(mockJsonResponse(expected));

    // test
    FundPriceData actual = client.api()
        .findPrice(expected.fundId, expected.priceType).execute().body();

    // verify
    assertThat(expected).isEqualToComparingFieldByField(actual);
  }

  @Test
  public void findUnitPrices() throws IOException {

    // mock data
    List<Integer> fundIds = Arrays.asList(123, 456);
    String type = "UNIT_TRANSACTION";
    String date = "01/01/2016";
    List<FundPriceData> expected = mockFundPrices(fundIds, type, date);
    server.enqueue(mockJsonResponse(expected));

    // test
    List<FundPriceData> actual =
        client.api().findPrices(fundIds).execute().body();

    // verify
    assertThat(expected).usingFieldByFieldElementComparator()
        .containsExactlyElementsOf(actual);
  }

  @Test
  public void findBidPrices() throws IOException {

    // mock data
    List<Integer> fundIds = Arrays.asList(123, 456);
    String type = "BID";
    String date = "01/01/2016";
    List<FundPriceData> expected = mockFundPrices(fundIds, type, date);
    server.enqueue(mockJsonResponse(expected));

    // test
    List<FundPriceData> actual =
        client.api().findPrices(fundIds, type).execute().body();

    // verify
    assertThat(expected).usingFieldByFieldElementComparator()
        .containsExactlyElementsOf(actual);
  }

  @Ignore("TODO: Complete this after code review")
  @Test
  public void errorDataResponse() throws Exception {

    ErrorData expected = new ErrorData("MOCK_ERROR", "mock server error!",
        "something went wrong!");
    MockResponse mockResponse = mockJsonResponse(expected);
    mockResponse.setStatus("500");
    server.enqueue(mockResponse);

    ResponseBody resp = client.api().findFund(0).execute().errorBody();
    assertThat(resp).isNotNull();
  }


  private static final ObjectMapper jsonMapper = new ObjectMapper();

  private static MockResponse mockJsonResponse(Object data)
      throws JsonProcessingException {

    return new MockResponse().addHeader("Content-Type", "application/json")
        .addHeader("Cache-Control", "no-cache")
        .setBody(jsonMapper.writeValueAsString(data));
  }

  private static List<FundData> mockFunds(String level) {

    List<FundData> funds = new ArrayList<>();
    funds.add(new FundData(123, level, new BigDecimal(Math.random())));
    funds.add(new FundData(456, level, new BigDecimal(Math.random())));
    funds.add(new FundData(789, level, new BigDecimal(Math.random())));
    return funds;
  }

  private static List<FundHoldingData> mockFundHoldings(int fundId) {

    List<FundHoldingData> fundHoldings = new ArrayList<>();
    fundHoldings.add(new FundHoldingData(fundId, 456, BigDecimal.ONE));
    fundHoldings.add(new FundHoldingData(fundId, 789, BigDecimal.TEN));
    return fundHoldings;
  }

  private static List<FundPriceData> mockFundPrices(List<Integer> fundIds,
      String priceDate, String priceType) {

    List<FundPriceData> fundPrices = new ArrayList<>();
    for (int id : fundIds) {
      fundPrices.add(new FundPriceData(id, new BigDecimal(Math.random()),
          priceDate, priceType));
    }

    return fundPrices;
  }

}
