package com.ilim.fund;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import java.math.BigDecimal;
import java.util.List;

/*
 * Data used for 'expected' results in testing
 * 
 */
public class TestData {

  // Fund test data
  public static final FundData PCF_Data =
      new FundData(17444, "CLIENT", BigDecimal.TEN);
  public static final FundData CAS_1_Data =
      new FundData(17803, "TAX", BigDecimal.TEN);

  // FundHolding test data
  public static final FundHoldingData PCF_HoldingData =
      new FundHoldingData(PCF_Data.fundId, CAS_1_Data.fundId, BigDecimal.TEN);
  public static final FundHoldingData IL_FTSE_RAFI_HOLDING_1 =
      new FundHoldingData(43865, 3630, BigDecimal.ONE);

  // FundPrice test data
  public static final String UNIT_TRANSACTION = "UNIT_TRANSACTION";
  public static final FundPriceData PCF_Price_Data = new FundPriceData(
      PCF_Data.fundId, BigDecimal.ONE, "13/11/2015", UNIT_TRANSACTION);
  public static final FundPriceData CAS_1_Price_Data = new FundPriceData(
      CAS_1_Data.fundId, BigDecimal.ONE, "13/11/2015", UNIT_TRANSACTION);

  /** Assertion helper. */
  public static void assertSimilar(FundHoldingData actual,
      FundHoldingData expected) {

    assertThat(actual).isEqualToIgnoringGivenFields(expected, "holdingQty");
  }

  /** Assertion helper. */
  public static void assertSimilar(FundPriceData actual,
      FundPriceData expected) {

    assertThat(actual).isEqualToIgnoringGivenFields(expected, "price",
        "priceDate");
  }

  /** Assertion helper. */
  public static void assertSimilar(List<FundPriceData> actual,
      List<FundPriceData> expected) {

    assertThat(actual.size()).isEqualTo(expected.size());
    for (int i = 0; i < actual.size(); i++) {
      assertSimilar(actual.get(i), expected.get(i));
    }
  }

}
