package com.ilim.fund;

import static com.ilim.commons.conf.AppConfig.settings;
import static com.ilim.commons.domain.model.FundLevel.CLIENT;
import static com.ilim.commons.domain.model.FundLevel.INVESTING;
import static com.ilim.commons.domain.model.FundLevel.PRIMARY;
import static com.ilim.commons.domain.model.FundLevel.TAX;
import static com.ilim.commons.domain.model.PriceType.UNIT_TRANSACTION;

import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import com.google.common.collect.ImmutableList;

import java.math.BigDecimal;
import java.util.List;

/*
 * Unit Test Data Object Mother.
 * 
 * <p>Used for 'expected' results in testing.
 * 
 */
public class TestData {

  /** Fund test data. */
  public static class Funds {

    public static final FundData PCF =
        new FundData(17444, CLIENT.name(), new BigDecimal("100"), "EUR", 22);
    public static final FundData TPCF =
        new FundData(17803, TAX.name(), new BigDecimal("100"), "EUR", 0);
    public static final FundData PPCF =
        new FundData(133, PRIMARY.name(), new BigDecimal("100"), "EUR", 0);
    public static final FundData IPAINA =
        new FundData(208, INVESTING.name(), new BigDecimal("60"), "EUR", 41);
    public static final FundData IPAIPE =
        new FundData(209, INVESTING.name(), new BigDecimal("40"), "EUR", 41);

    public static final List<FundData> list =
        ImmutableList.of(PCF, TPCF, PPCF, IPAINA, IPAIPE);
  }

  /** FundHolding test data. */
  public static class FundHoldings {

    // CLIENT -> TAX
    public static final FundHoldingData PCF_TPCF = new FundHoldingData(
        Funds.PCF.fundId, Funds.TPCF.fundId, Funds.TPCF.committedUnits);
    // TAX -> PRIMARY
    public static final FundHoldingData TPCF_PPCF = new FundHoldingData(
        Funds.TPCF.fundId, Funds.PPCF.fundId, Funds.PPCF.committedUnits);
    // PRIMARY -> INVESTING
    public static final FundHoldingData PPCF_IPAINA = new FundHoldingData(
        Funds.PPCF.fundId, Funds.IPAINA.fundId, Funds.IPAINA.committedUnits);
    public static final FundHoldingData PPCF_IPAIPE = new FundHoldingData(
        Funds.PPCF.fundId, Funds.IPAIPE.fundId, Funds.IPAIPE.committedUnits);

    public static final List<FundHoldingData> list =
        ImmutableList.of(PCF_TPCF, TPCF_PPCF, PPCF_IPAINA, PPCF_IPAIPE);
  }

  /** FundPrice test data. */
  public static class FundPrices {

    public static String priceDate = settings().getString("price.date");
    public static String priceType = UNIT_TRANSACTION.name();

    public static final FundPriceData PCF = new FundPriceData(Funds.PCF.fundId,
        priceDate, priceType, BigDecimal.ONE);
    public static final FundPriceData TPCF = new FundPriceData(
        Funds.TPCF.fundId, priceDate, priceType, BigDecimal.ONE);
    public static final FundPriceData PPCF = new FundPriceData(
        Funds.PPCF.fundId, priceDate, priceType, BigDecimal.ONE);
    public static final FundPriceData IPAINA = new FundPriceData(
        Funds.IPAINA.fundId, priceDate, priceType, BigDecimal.ONE);
    public static final FundPriceData IPAIPE = new FundPriceData(
        Funds.IPAIPE.fundId, priceDate, priceType, BigDecimal.ONE);

    public static final List<FundPriceData> list =
        ImmutableList.of(PCF, TPCF, PPCF, IPAINA, IPAIPE);
  }

}
