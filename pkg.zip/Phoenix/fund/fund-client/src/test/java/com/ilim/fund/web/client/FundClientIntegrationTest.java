package com.ilim.fund.web.client;

import static com.ilim.fund.TestData.CAS_1_Price_Data;
import static com.ilim.fund.TestData.PCF_Price_Data;
import static com.ilim.fund.TestData.assertSimilar;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.domain.model.PriceType;
import com.ilim.fund.TestData;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import retrofit.Response;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FundClientIntegrationTest {

  private FundClient client;

  @Before
  public void setUp() throws Exception {
    client = new FundClient();
  }

  @Test
  public void findFund() throws IOException {

    FundData expected = TestData.PCF_Data;
    FundData actual = client.api().findFund(expected.fundId).execute().body();

    assertThat(expected).isEqualToComparingFieldByField(actual);
  }

  @Test
  public void findFundsByLevel() throws IOException {

    String level = "CLIENT";
    List<FundData> funds =
        client.api().findFundsByLevel(level).execute().body();

    assertThat(funds.size()).isGreaterThan(0);
    assertThat(funds).extracting("level").containsOnly(level);
  }

  @Test
  public void findFundHolding() throws IOException {

    FundHoldingData expected =
        new FundHoldingData(17444, 17803, BigDecimal.TEN);

    FundHoldingData actual = client.api()
        .findFundHolding(expected.fundId, expected.holdingId).execute().body();

    assertSimilar(actual, expected);
  }


  @Test
  public void findFundHoldingsByFund() throws IOException {

    FundHoldingData expected = TestData.PCF_HoldingData;

    List<FundHoldingData> fundHoldings =
        client.api().findFundHoldings(expected.fundId).execute().body();
    FundHoldingData actual = fundHoldings.get(0);

    assertSimilar(actual, expected);
  }


  @Test
  public void fundHoldingsLookthru() throws IOException {

    int fundId = TestData.IL_FTSE_RAFI_HOLDING_1.fundId;

    List<FundHoldingData> fundHoldings =
        client.api().fundHoldingsLookthru(fundId).execute().body();

    // this fund had 2 fund holdings as of 13/11/2015
    assertThat(fundHoldings.size()).isEqualTo(2);
  }

  @Test
  public void findPrice() throws IOException {

    FundPriceData expected = PCF_Price_Data;
    FundPriceData actual =
        client.api().findPrice(expected.fundId, null).execute().body();

    assertSimilar(actual, expected);
  }

  @Test
  public void findPriceOfType() throws IOException {

    FundPriceData expected = CAS_1_Price_Data;
    FundPriceData actual = client.api()
        .findPrice(expected.fundId, expected.priceType).execute().body();

    assertSimilar(actual, expected);
  }

  @Test
  public void findPrices() throws IOException {

    // test data
    List<Integer> fundIds =
        Arrays.asList(PCF_Price_Data.fundId, CAS_1_Price_Data.fundId);
    List<FundPriceData> expected = new ArrayList<>();
    expected.add(PCF_Price_Data);
    expected.add(CAS_1_Price_Data);

    List<FundPriceData> actual =
        client.api().findPrices(fundIds).execute().body();

    assertSimilar(actual, expected);
  }

  @Test
  public void findPricesOfType() throws IOException {

    // test data
    String priceType = PriceType.UNIT_TRANSACTION.name();
    List<Integer> fundIds =
        Arrays.asList(PCF_Price_Data.fundId, CAS_1_Price_Data.fundId);
    List<FundPriceData> expected = new ArrayList<>();
    expected.add(PCF_Price_Data);
    expected.add(CAS_1_Price_Data);

    List<FundPriceData> actual =
        client.api().findPrices(fundIds, priceType).execute().body();

    assertSimilar(actual, expected);
  }

  @Ignore("TODO: need to add filter to transofrm error body in client")
  @Test
  public void findPricesMissingReqdParam() throws IOException {

    // The required 1 -> n param values of fundId are missing.
    Response<List<FundPriceData>> response =
        client.api().findPrices(null, null).execute();

    // expecting a CLIENT_ERROR response code

    assertThat(response.body()).isNull();
    /*
     * ErrorData errorData =
     * client.toErrorData(response.errorBody());
     * assertThat(errorData.code).isEqualTo(CLIENT_ERROR);
     * assertThat(errorData.message).isNotEmpty();
     */
  }


}
