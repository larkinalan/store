package com.ilim.fund.web.api;

import com.ilim.fund.web.api.FundData;

import retrofit.Call;
import retrofit.http.GET;
import retrofit.http.Path;
import retrofit.http.Query;

import java.util.List;

/**
 * Fund API.
 * 
 * <p>HTTP adapter for all fund resources and sub resources (Holdings, Prices).
 * 
 * @author Alan Larkin
 */
public interface FundApi {

  @GET("funds/{fundId}")
  public Call<FundData> findFund(@Path("fundId") int fundId);
  
  @GET("funds")
  public Call<List<FundData>> findFunds(@Query("fundId") List<Integer> fundIds);

  @GET("funds")
  public Call<List<FundData>> findFundsByLevel(@Query("level") String level);

  @GET("funds/{fundId}/holdings/{holdingId}")
  public Call<FundHoldingData> findFundHolding(@Path("fundId") int fundId,
      @Path("holdingId") int holdingId);

  @GET("funds/{fundId}/holdings")
  public Call<List<FundHoldingData>> findFundHoldings(
      @Path("fundId") int fundId);

  @GET("funds/{fundId}/holdings/lookthru")
  public Call<List<FundHoldingData>> fundHoldingsLookthru(
      @Path("fundId") int fundId);

  @GET("funds/{fundId}/prices")
  public Call<FundPriceData> findPrice(@Path("fundId") int fundId);

  @GET("funds/{fundId}/prices")
  public Call<FundPriceData> findPrice(@Path("fundId") int fundId,
      @Query("type") String priceType);

  @GET("funds/prices")
  public Call<List<FundPriceData>> findPrices(
      @Query("fundId") List<Integer> fundIds);

  @GET("funds/prices")
  public Call<List<FundPriceData>> findPrices(
      @Query("fundId") List<Integer> fundIds, @Query("type") String priceType);
}
