package com.ilim.fund.web.client;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.web.client.RetrofitClient;
import com.ilim.fund.web.api.FundApi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit2.JacksonConverterFactory;
import retrofit2.Retrofit;

/**
 * FundClient sdk for jaxrs fund-service. 
 * 
 * @author barry folan
 */
public class FundClient {

  private static final Logger log = LoggerFactory.getLogger(FundClient.class);

  private final RetrofitClient retrofitClient;
  private final FundApi fundApi;

  /** Default constructor (uses conf file). */
  public FundClient() {
    this(settings().getString("fund.service.baseurl"));
  }

  /** Configures client using FundApi. */
  public FundClient(String baseUrl) {

    // Create retrofit http client with jackson converter
    retrofitClient = RetrofitClient.newBuilder(baseUrl).witLogger(log)
        .withConverter(JacksonConverterFactory.create()).build();

    // Generate fund api
    fundApi = retrofitClient.adapter().create(FundApi.class);
  }

  /** Retrofit Adapter. */
  public Retrofit retrofit() {

    return retrofitClient.adapter();
  }

  /** FundApi @see#com.ilim.web.api.FundApi. */
  public FundApi api() {
    return fundApi;
  }

}
