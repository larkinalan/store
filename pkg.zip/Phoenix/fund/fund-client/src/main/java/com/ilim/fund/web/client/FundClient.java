package com.ilim.fund.web.client;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.fund.web.api.FundApi;

import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.logging.HttpLoggingInterceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit.JacksonConverterFactory;
import retrofit.Retrofit;

/**
 * FundClient sdk for jaxrs fund-service. 
 * 
 * @author barry folan
 */
public class FundClient {

  private static final Logger log = LoggerFactory.getLogger(FundClient.class);

  private final Retrofit retrofitAdapter;
  private final FundApi fundApi;

  /** Default constructor (uses conf file). */
  public FundClient() {
    this(settings().getString("fund.service.baseurl"));
  }

  /** Configures client using FundApi. */
  public FundClient(String baseUrl) {

    log.debug("Creating FundClient for " + baseUrl);

    // create http client with logging
    OkHttpClient client = new OkHttpClient();
    HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
    interceptor.setLevel(HttpLoggingInterceptor.Level.BASIC);
    client.interceptors().add(interceptor);

    // Create retrofit with json converter
    this.retrofitAdapter =
        new Retrofit.Builder().baseUrl(baseUrl).client(client)
            .addConverterFactory(JacksonConverterFactory.create()).build();

    // Generate fund api
    fundApi = retrofitAdapter.create(FundApi.class);
  }

  /**  FundApi @see#com.ilim.web.api.FundApi. */
  public FundApi api() {
    return fundApi;
  }

}
