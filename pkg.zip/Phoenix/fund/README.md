Fund module 
===========
*Fund components for phoenix project*

build
-----
   
`mvn clean install`

*requires* 
* [Java8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)  
* [Maven3](https://maven.apache.org/)

deploy
------

`mvn clean deploy`

Test
----

TODO: add intergation test setup instructions

docs
----

TODO: add confluence links

