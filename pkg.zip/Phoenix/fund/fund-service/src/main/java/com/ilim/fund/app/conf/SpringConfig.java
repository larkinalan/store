package com.ilim.fund.app.conf;


import com.ilim.fund.app.service.FundService;
import com.ilim.fund.app.service.IFundService;
import com.ilim.fund.app.service.IPriceService;
import com.ilim.fund.app.service.PriceService;
import com.ilim.fund.domain.IFundRepository;
import com.ilim.fund.domain.IPriceRepository;
import com.ilim.fund.infra.db.jdbc.JdbcFundDao;
import com.ilim.fund.infra.db.jdbc.JdbcPriceDao;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

/**
 * Spring component config.
 */
@Configuration
@EnableTransactionManagement()
public class SpringConfig {

  /* Services */
  @Bean
  public IFundService fundService(IFundRepository fundDao) {

    return new FundService(fundDao);
  }

  @Bean
  public IPriceService fundPriceService(IPriceRepository fundPriceDao) {
    return new PriceService(fundPriceDao);
  }

  /* Repositories */
  @Bean
  public IFundRepository fundDao(DataSource dataSource) {
    return new JdbcFundDao(dataSource);
  }

  @Bean
  public IPriceRepository fundPriceDao(DataSource dataSource) {
    return new JdbcPriceDao(dataSource);
  }
}
