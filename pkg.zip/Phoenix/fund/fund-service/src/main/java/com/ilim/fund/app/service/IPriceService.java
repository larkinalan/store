package com.ilim.fund.app.service;

import com.ilim.fund.domain.model.FundPrice;
import com.ilim.fund.domain.model.FundPrice.PriceType;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface IPriceService {

  FundPrice findPrice(int fundId, PriceType priceType);

  List<FundPrice> findPrices(List<Integer> fundIds, PriceType priceType);

  LocalDate findLatestPriceDate(int fundId, Optional<PriceType> priceType);

}
