package com.ilim.fund.infra.db.jdbc;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.domain.model.PriceType;
import com.ilim.commons.time.DateUtils;
import com.ilim.fund.domain.IPriceRepository;
import com.ilim.fund.domain.model.FundPrice;

import com.google.common.collect.Lists;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;


/**
 * Database operations over MV_FUND_PRICE_LATEST.
 * 
 * @author barry folan
 */
public class JdbcPriceDao extends NamedParameterJdbcDaoSupport
    implements IPriceRepository {

  private static final Logger log = LoggerFactory.getLogger(JdbcPriceDao.class);

  private static final int SELECT_IN_LIMIT =
      settings().getInt("db.oracle.select.in.limit");

  /** Initialize Dao with sql dataSource. */
  @Inject
  public JdbcPriceDao(DataSource dataSource) {

    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  /**
   * Find the FundPrice with the fundId and priceType.
   * 
   * @param fundId fundId
   * @param priceType priceType
   * @return FundPrice fundPrice
   * @throws AppSqlException
   * 
   */
  @Override
  public FundPrice findPrice(int fundId, PriceType priceType) {

    log.info("findPrice ({}, {})", fundId, priceType);

    final String sql = SQL.select_from_fund_price_latest_by_fund_id_and_type;

    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("fundIds", fundId).addValue("priceTypeId", priceType.getId());

    final FundPrice result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toFundPrice(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(
          "Error in findPrice " + fundId + "," + priceType, ex);
    }

    return result;
  }

  /**
   * Find the FundPrices for each of the fundIds and priceType.
   * 
   * @param fundIds List of fundIds
   * @param priceType priceType
   * @return List of FundPrices
   * @throws AppSqlException
   * 
   */
  @Override
  public List<FundPrice> findPrices(List<Integer> fundIds,
      PriceType priceType) {

    log.info("findPrices ({}, {})", fundIds, priceType);

    final String sql = SQL.select_from_fund_price_latest_by_fund_id_and_type;

    final List<FundPrice> result = new ArrayList<>();
    List<List<Integer>> groups = Lists.partition(fundIds, SELECT_IN_LIMIT);

    for (List<Integer> ids : groups) {

      SqlParameterSource params = new MapSqlParameterSource()
          .addValue("fundIds", ids).addValue("priceTypeId", priceType.getId());

      try {

        result.addAll(
            getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
              return toFundPrice(rs);
            }));

      } catch (DataAccessException ex) {
        throw new AppSqlException(
            "Error in findPrices " + fundIds + ", " + priceType, ex);
      }
    }

    return result;
  }

  /**
   * Find the latest price date for a fundId and priceType.
   * 
   * @param fundId fundId
   * @param priceType priceType
   * @return LocalDate day of the year
   * @throws AppSqlException
   * 
   */
  @Override
  public LocalDate findLatestPriceDate(int fundId, PriceType priceType) {

    log.info("findLatestPriceDate ({}, {})", fundId, priceType);

    final String sql =
        SQL.select_from_fund_price_latest_date_by_fund_id_and_type;

    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("fundId", fundId).addValue("priceTypeId", priceType.getId());

    final LocalDate result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return DateUtils.asLocalDate(rs.getDate("price_dt"));
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(
          "Error in findLatestPriceDate " + fundId + "," + priceType, ex);
    }

    return result;
  }

  private FundPrice toFundPrice(ResultSet rs) {

    try {

      int fundId = rs.getInt("ilim_id");
      LocalDate priceDate = DateUtils.asLocalDate(rs.getDate("price_dt"));
      PriceType priceType = PriceType.from(rs.getInt("price_type_id"));
      BigDecimal price = rs.getBigDecimal("closing_price");

      return new FundPrice(fundId, priceDate, priceType, price);

    } catch (SQLException ex) {
      throw new AppSqlException("Error mapping sql result set to FundPrice!",
          ex);
    }
  }

}
