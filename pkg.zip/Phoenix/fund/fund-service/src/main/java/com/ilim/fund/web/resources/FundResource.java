package com.ilim.fund.web.resources;

import static com.ilim.fund.web.resources.FundDataMapper.toFundData;
import static com.ilim.fund.web.resources.FundDataMapper.toFundHoldingData;

import com.ilim.fund.app.service.IFundService;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.Fund.Level;
import com.ilim.fund.domain.model.FundHolding;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import com.codahale.metrics.annotation.Timed;
import com.google.common.base.Strings;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

@Singleton
@Service
@Path("funds")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class FundResource {

  @Inject
  private IFundService fundService;

  /**
   * Find fund by fundId.
   * 
   * @param fundId fundId
   * @return FundData
   */
  @GET
  @Path("{fundId}")
  @Timed
  public FundData findById(@PathParam("fundId") int fundId) {

    Fund fund = fundService.findById(fundId);

    return toFundData(fund);
  }

  /**
   * Find all Funds at level.
   * 
   * <p>If no query parameters 
   *    then {@link IFundService#findAll()}
   *     
   * <p>If level
   *    then {@link IFundService#findByLevel(Fund.Level)}
   *    
   * <p>If fundId
   *    then {@link IFundService#findById(List)}
   *    
   * @param uriInfo OPTIONAL query param.
   * @return {@code List<FundData>}
   */
  @GET
  @Timed
  public List<FundData> find(@Context UriInfo uriInfo) {

    final MultivaluedMap<String, String> queryParams =
        uriInfo.getQueryParameters();
    final List<Fund> funds;

    if (queryParams == null || queryParams.isEmpty()) {

      // FIND ALL
      funds = fundService.findAll();

    } else {

      List<String> fundIds = queryParams.get("level");
      String level = queryParams.getFirst("level");

      if (!Strings.isNullOrEmpty(level)) {

        // FIND BY LEVEL
        funds = fundService.findByLevel(Level.fromName(level));
      } else {

        // FIND BY IDS
        List<Integer> ids = fundIds.stream().map(f -> Integer.valueOf(f))
            .collect(Collectors.toList());
        funds = fundService.findById(ids);
      }
    }

    return toFundData(funds);
  }

  /**
   * Find a FundHolding by fundId and holdingId. 
   * 
   * @param fundId ilimId
   * @param holdingId underlying ilimId
   * @return FundHoldingData
   */
  @GET
  @Path("{fundId}/holdings/{holdingId}")
  @Timed
  public FundHoldingData find(@PathParam("fundId") int fundId,
      @PathParam("holdingId") int holdingId) {

    FundHolding fundHolding = fundService.findFundHolding(fundId, holdingId);

    return toFundHoldingData(fundHolding);
  }

  /**
   * Find all FundHoldings with the parent fundId.
   * 
   * @param fundId ilimId
   * @return List of FundHoldingData
   */
  @GET
  @Path("{fundId}/holdings")
  @Timed
  public List<FundHoldingData> findByFundId(@PathParam("fundId") int fundId) {

    List<FundHolding> fundHoldings = fundService.findFundHoldings(fundId);

    return toFundHoldingData(fundHoldings);
  }

  /**
   * Recursively look through the fundIds holdings, to find all held funds.
   * 
   * @param fundId ilimId
   * @return FundHoldingData
   */
  @GET
  @Path("{fundId}/holdings/lookthru")
  @Timed
  public List<FundHoldingData> lookthru(@PathParam("fundId") int fundId) {

    List<FundHolding> fundHoldings = fundService.lookthru(fundId);

    return toFundHoldingData(fundHoldings);
  }

}
