package com.ilim.fund.domain;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.FundHolding;

import java.util.List;

/**
 * Fund Database.
 */
public interface IFundRepository {

  Fund findById(int fundId);

  List<Fund> findByIds(List<Integer> fundIds);

  List<Fund> findAll();

  List<Fund> findByLevel(FundLevel level);

  FundHolding findFundHolding(int fundId, int holdingId);

  List<FundHolding> findFundHoldings(int fundId);

  List<FundHolding> lookthru(int fundId);

}
