package com.ilim.fund.web.resources;

import static com.google.common.base.Preconditions.checkArgument;

import static com.ilim.fund.web.resources.FundDataMapper.toFundPriceData;

import com.ilim.commons.domain.model.PriceType;
import com.ilim.fund.app.service.IPriceService;
import com.ilim.fund.domain.model.FundPrice;
import com.ilim.fund.web.api.FundPriceData;

import com.codahale.metrics.annotation.Timed;

import org.springframework.stereotype.Service;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Singleton
@Service
@Path("funds")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class FundPriceResource {

  @Inject
  private IPriceService priceService;

  /**
  * Find the latest Fund Price. 
   * 
   * <p>If no priceType is provided, then default to unit prices.
   * {@link PriceType#UNIT_TRANSACTION}.
   * 
   * @param fundId fundId
   * @param priceTypeName PriceType to filter by
   * @return FundPriceData 
   */
  @GET
  @Path("{fundId}/prices")
  @Timed
  public FundPriceData findPrice(@PathParam("fundId") int fundId,
      @QueryParam("type") String priceTypeName) {

    PriceType type = toPriceType(priceTypeName);
    FundPrice fundPrice = priceService.findPrice(fundId, type);

    return toFundPriceData(fundPrice);
  }


  /**
   * Find the latest Fund Prices for each of the fundIds. 
   * 
   * <p>If no priceType is provided, then default to unit prices.
   * {@link PriceType#UNIT_TRANSACTION}.
   * 
   * @param fundIds List of fundIds
   * @param priceTypeName priceType name
   * @return List of FundPriceData
   */
  @GET
  @Path("/prices")
  @Timed
  public List<FundPriceData> findPrices(
      @QueryParam("fundId") List<Integer> fundIds,
      @QueryParam("type") String priceTypeName) {

    checkArgument(fundIds.size() > 0,
        "You must supply at least one fundId query param!");

    PriceType type = toPriceType(priceTypeName);
    List<FundPrice> fundPrices = priceService.findPrices(fundIds, type);

    return toFundPriceData(fundPrices);
  }

  /** Defaults to UNIT prices, if type is left out of query params. */
  private PriceType toPriceType(String type) {

    if (type != null) {
      return PriceType.from(type); // Attempt to resolve.
    } else {
      return PriceType.UNIT_TRANSACTION; // Default to unit prices.
    }
  }

}
