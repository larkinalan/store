package com.ilim.fund.web.resources;

import com.ilim.commons.time.DateUtils;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.FundHolding;
import com.ilim.fund.domain.model.FundPrice;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
* Fund DataType Mapper.
* 
* @author Alan Larkin
*/
public class FundDataMapper {

  private static final Logger log =
      LoggerFactory.getLogger(FundDataMapper.class);

  /** Converts Fund domain object to a FundData DTO. */
  public static FundData toFundData(Fund entity) {

    log.trace("toFundData ({})" + entity);

    int fundId = entity.getId();
    String level = entity.getLevel().name();
    BigDecimal committedUnits = entity.getCommittedUnits();
    int lobId = entity.getLobId();

    return new FundData(fundId, level, committedUnits, lobId);
  }

  /** Converts List of Fund domain objects to List of FundData DTO's. */
  public static List<FundData> toFundData(List<Fund> entities) {

    log.trace("toFundData entities.size {}", entities.size());

    List<FundData> dataList = new ArrayList<FundData>(entities.size());

    for (Fund fund : entities) {
      dataList.add(toFundData(fund));
    }

    return dataList;
  }

  /** Converts FundHolding domain object to a FundHoldingData DTO. */
  public static FundHoldingData toFundHoldingData(FundHolding valueObject) {

    log.trace("toFundHoldingData ({})", valueObject);

    int fundId = valueObject.getFundId();
    int holdingId = valueObject.getHoldingId();
    BigDecimal heldUnits = valueObject.getHeldUnits();

    return new FundHoldingData(fundId, holdingId, heldUnits);
  }

  /** Converts List of FundHolding domain objects to List of FundData DTO's. */
  public static List<FundHoldingData> toFundHoldingData(
      List<FundHolding> valueObjects) {

    log.trace("toFundHoldingData valueObject.size {}", valueObjects.size());

    List<FundHoldingData> dataList =
        new ArrayList<FundHoldingData>(valueObjects.size());

    for (FundHolding o : valueObjects) {
      dataList.add(toFundHoldingData(o));
    }

    return dataList;
  }

  /** Converts FundPrice domain object to FundPriceData DTO. */
  public static FundPriceData toFundPriceData(FundPrice valueObject) {

    log.trace("toFundPriceData ({})", valueObject);

    int fundId = valueObject.getFundId();
    String priceDate = valueObject.getPriceDate().format(DateUtils.DATE_FMT);
    String priceType = valueObject.getPriceType().name();
    BigDecimal price = valueObject.getPrice();

    return new FundPriceData(fundId, priceDate, priceType, price);
  }

  /** Converts List FundPrice domain objects to List FundPriceData DTO's.*/
  public static List<FundPriceData> toFundPriceData(
      List<FundPrice> valueObjects) {

    log.trace("toFundPriceData valueObjects.size {}", valueObjects.size());

    List<FundPriceData> dataList =
        new ArrayList<FundPriceData>(valueObjects.size());

    for (FundPrice o : valueObjects) {
      dataList.add(toFundPriceData(o));
    }

    return dataList;
  }

}
