package com.ilim.fund.domain;

import com.ilim.commons.domain.model.PriceType;
import com.ilim.fund.domain.model.FundPrice;

import java.time.LocalDate;
import java.util.List;

/**
 * Fund Price Database.
 */
public interface IPriceRepository {

  FundPrice findPrice(int fundId, PriceType priceType);

  List<FundPrice> findPrices(List<Integer> fundIds, PriceType priceType);

  LocalDate findLatestPriceDate(int fundId, PriceType priceType);
  
}
