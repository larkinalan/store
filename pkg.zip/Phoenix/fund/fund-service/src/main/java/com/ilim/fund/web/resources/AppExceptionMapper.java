package com.ilim.fund.web.resources;

import static com.ilim.commons.web.api.ErrorData.newErrorData;

import com.ilim.commons.conf.AppConfigException;
import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.web.api.ErrorCode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.DateTimeException;
import java.util.NoSuchElementException;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 * Exception mappers that convert Exceptions to a Web Response with ErrorData.
 *
 * @author Alan Larkin
 */

public final class AppExceptionMapper {

  private static final Logger log =
      LoggerFactory.getLogger(AppExceptionMapper.class);

  private AppExceptionMapper() {}

  /** 
   * Converts {@link AppSqlException}. 
   */
  @Provider
  public static class AppDataExceptionMapper
      implements ExceptionMapper<AppSqlException> {

    @Override
    public Response toResponse(AppSqlException ex) {

      log.error(ex.getMessage(), ex);
      return Response.status(Status.INTERNAL_SERVER_ERROR)
          .entity(newErrorData(ErrorCode.DATA.id(), ex)).build();
    }
  }

  /** 
   * Converts {@link AppConfigException}. 
   */
  @Provider
  public static class AppConfigExceptionMapper
      implements ExceptionMapper<AppConfigException> {

    @Override
    public Response toResponse(AppConfigException ex) {

      log.error(ex.getMessage(), ex);
      return Response.status(Status.INTERNAL_SERVER_ERROR)
          .entity(newErrorData(ErrorCode.CONFIG.id(), ex)).build();
    }
  }

  /** 
   * Converts {@link DateTimeException}. 
   */
  @Provider
  public static class DateTimeExceptionMapper
      implements ExceptionMapper<DateTimeException> {

    @Override
    public Response toResponse(DateTimeException ex) {

      log.error(ex.getMessage(), ex);
      return Response.status(Status.CONFLICT)
          .entity(newErrorData(ErrorCode.DATA.id(), ex)).build();
    }
  }

  /** 
   * Converts {@link IllegalArgumentException}. 
   */
  @Provider
  public static class IllegalArgumentExceptionMapper
      implements ExceptionMapper<IllegalArgumentException> {

    @Override
    public Response toResponse(IllegalArgumentException ex) {

      log.error(ex.getMessage(), ex);
      return Response.status(Status.BAD_REQUEST)
          .entity(newErrorData(ErrorCode.CLIENT.id(), ex)).build();
    }
  }

  /** 
   * Converts {@link IllegalStateException}. 
   */
  @Provider
  public static class IllegalStateExceptionMapper
      implements ExceptionMapper<IllegalStateException> {

    @Override
    public Response toResponse(IllegalStateException ex) {

      log.error(ex.getMessage(), ex);
      return Response.status(Status.CONFLICT)
          .entity(newErrorData(ErrorCode.STATE.id(), ex)).build();
    }
  }

  /** 
   * Converts {@link NoSuchElementException}. 
   */
  @Provider
  public static class NoSuchElementExceptionMapper
      implements ExceptionMapper<NoSuchElementException> {

    @Override
    public Response toResponse(NoSuchElementException ex) {

      log.error(ex.getMessage(), ex);
      return Response.status(Status.INTERNAL_SERVER_ERROR)
          .entity(newErrorData(ErrorCode.DATA.id(), ex)).build();
    }
  }

  /** 
   * Converts {@link NullPointerException}. 
   */
  @Provider
  public static class NullPointerExceptionMapper
      implements ExceptionMapper<NullPointerException> {

    @Override
    public Response toResponse(NullPointerException ex) {

      log.error(ex.getMessage(), ex);
      return Response.status(Status.INTERNAL_SERVER_ERROR)
          .entity(newErrorData(ErrorCode.DATA.id(), ex)).build();
    }
  }

  /** 
   * Converts {@link UnsupportedOperationException}. 
   */
  @Provider
  public static class UnsupportedOperationExceptionMapper
      implements ExceptionMapper<UnsupportedOperationException> {

    @Override
    public Response toResponse(UnsupportedOperationException ex) {

      log.error(ex.getMessage(), ex);
      return Response.status(Status.NOT_IMPLEMENTED)
          .entity(newErrorData(ErrorCode.NOT_IMPL.id(), ex)).build();
    }
  }

}
