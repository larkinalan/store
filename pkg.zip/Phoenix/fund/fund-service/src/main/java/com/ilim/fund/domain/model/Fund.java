package com.ilim.fund.domain.model;

import com.ilim.commons.domain.IEntity;
import com.ilim.commons.domain.model.FundLevel;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/** 
 * Fund Entity.
 * 
 * <p>This represents the basic details of an ilim fund.
 * 
 * @author alan larkin 
 */
public class Fund implements IEntity<Integer> {

  private final int fundId;
  private final FundLevel level;
  private final BigDecimal committedUnits;
  private final String baseCurrency;
  private final int lobId;


  /** Creates an immutable Fund Entity. */
  public Fund(int fundId, FundLevel level, BigDecimal committedUnits,
      String baseCurrency, int lobId) {

    this.fundId = fundId;
    this.level = level;
    this.committedUnits = committedUnits;
    this.baseCurrency = baseCurrency;
    this.lobId = lobId;
  }

  @Override
  public Integer getId() {
    return fundId;
  }

  public FundLevel getLevel() {
    return level;
  }

  public BigDecimal getCommittedUnits() {
    return committedUnits;
  }
  
  public String getBaseCurrency() {
    return baseCurrency;
  }

  public int getLobId() {
    return lobId;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final Fund other = (Fund) obj;

    return Objects.equals(this.getId(), other.getId());
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(this.getId());
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("fundId", fundId)
        .add("level", level).add("committedUnits", committedUnits)
        .add("baseCurrency", baseCurrency).add("lobId", lobId).toString();
  }
}
