package com.ilim.fund.domain.model;

import com.ilim.commons.domain.IEntity;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/** 
 * Fund Entity.
 * 
 * <p>This represents the basic details of an ilim fund.
 * 
 * @author alan larkin 
 */
public class Fund implements IEntity<Integer> {

  private final int fundId;
  private final Level level;
  private final BigDecimal committedUnits;

  /** Creates an immutable Fund Entity. */
  public Fund(int fundId, Level level, BigDecimal committedUnits) {

    this.fundId = fundId;
    this.level = level;
    this.committedUnits = committedUnits;
  }

  @Override
  public Integer getId() {
    return fundId;
  }

  public Level getLevel() {
    return level;
  }

  public BigDecimal getCommittedUnits() {
    return committedUnits;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final Fund other = (Fund) obj;

    return Objects.equals(this.getId(), other.getId());
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(this.getId());
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("fundId", fundId)
        .add("level", level).toString();
  }


  /** Fund Level. */
  public enum Level {

    CLIENT(1), TAX(2), PRIMARY(3), INVESTING(4), SCHEME(5);

    private int id;

    /**
     * Get a Level corresponding to the id passed in.
     * @param id level id
     * @return level
     */
    public static Level fromId(int id) {

      for (Level level : Level.values()) {
        if (id == level.id()) {
          return level;
        }
      }
      throw new IllegalArgumentException("Unknown Level Id: " + id);
    }

    /**
     * Get a Level corresponding to the name passed in.
     * @param name level name
     * @return level
     */
    public static Level fromName(String name) {

      for (Level level : Level.values()) {
        if (name.equalsIgnoreCase(level.name())) {
          return level;
        }
      }
      throw new IllegalArgumentException("Unknown Level name: " + name);
    }

    Level(int id) {
      this.id = id;
    }

    public int id() {
      return id;
    }
  }

}
