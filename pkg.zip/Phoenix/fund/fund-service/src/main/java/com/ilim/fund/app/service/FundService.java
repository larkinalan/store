package com.ilim.fund.app.service;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.fund.domain.IFundRepository;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.FundHolding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import javax.inject.Inject;

/**
 * Fund Service.
 * 
 * <p>Find fund basic details, and holdings.
 * 
 * @author barry folan
 */
@Service
public class FundService implements IFundService {

  private static final Logger log = LoggerFactory.getLogger(FundService.class);

  private final IFundRepository fundDao;

  @Inject
  public FundService(IFundRepository fundDao) {

    this.fundDao = fundDao;
  }

  /**
   * Find a fund based on the fundId passed in.
   * 
   * @param fundId fundId
   * @return fund
   */
  @Override
  @Transactional
  public Fund findById(int fundId) {

    log.info("findById ({})", fundId);

    return fundDao.findById(fundId);
  }
  
  /**
   * Find a funds based on the fundIds.
   * 
   * @param fundIds list
   * @return fund
   */
  @Override
  @Transactional
  public List<Fund> findByIds(List<Integer> fundIds) {

    log.info("findByIds (...)", fundIds);

    return fundDao.findByIds(fundIds);
  }
  

  /**
   * Return all Funds.
   * 
   * @return List of Funds
   */
  @Override
  @Transactional
  public List<Fund> findAll() {

    log.info("findAll ()");

    return fundDao.findAll();
  }

  /**
   * Return all funds with this level.
   * 
   * @param level FundLevel
   * @return List of Funds 
   */
  @Override
  @Transactional
  public List<Fund> findByLevel(FundLevel level) {

    log.info("findByLevel ({})", level);

    return fundDao.findByLevel(level);
  }

  /**
   * Find a specific FundHolding.
   * 
   * @param fundId ilimId
   * @param holdingId underlying ilimId
   * @return fundHolding
   */
  @Override
  @Transactional
  public FundHolding findFundHolding(int fundId, int holdingId) {

    log.info("findFundHolding ({}, {})", fundId, holdingId);

    return fundDao.findFundHolding(fundId, holdingId);
  }

  /**
   * Find all holdings with the parent fundId.
   * 
   * @param fundId ilimId
   * @return List of FundHolding
   */
  @Override
  @Transactional
  public List<FundHolding> findFundHoldings(int fundId) {

    log.info("findFundHoldings ({})", fundId);

    return fundDao.findFundHoldings(fundId);
  }

  /**
   * Recursively look through the fund holdings, to find all held funds.
   * 
   * @param fundId ilimId
   * @return List of FundHolding
   */
  @Override
  @Transactional
  public List<FundHolding> lookthru(int fundId) {

    log.info("lookthru ({})", fundId);

    return fundDao.lookthru(fundId);
  }

}
