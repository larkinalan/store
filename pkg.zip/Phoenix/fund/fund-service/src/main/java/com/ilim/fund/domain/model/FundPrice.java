package com.ilim.fund.domain.model;

import com.ilim.commons.domain.IValueObject;
import com.ilim.commons.domain.model.PriceType;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

/** 
 * Fund Price Value Object.
 * 
 * <p>This represents the closing price of a fund on a date.
 * 
 * @author alan larkin 
 */
public class FundPrice implements IValueObject<FundPrice> {

  private final int fundId;
  private final BigDecimal price;
  private final LocalDate priceDate;
  private final PriceType priceType;

  /** Creates an immutable Fund Price. */
  public FundPrice(int fundId, LocalDate priceDate, PriceType priceType,
      BigDecimal price) {

    this.fundId = fundId;
    this.priceDate = priceDate;
    this.priceType = priceType;
    this.price = price;
  }

  public int getFundId() {
    return fundId;
  }

  public LocalDate getPriceDate() {
    return priceDate;
  }

  public PriceType getPriceType() {
    return priceType;
  }

  public BigDecimal getPrice() {
    return price;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final FundPrice other = (FundPrice) obj;

    return (this.fundId == other.getFundId()
        && this.priceDate.equals(other.getPriceDate())
        && this.priceType.equals(other.getPriceType()));
  }

  @Override
  public int hashCode() {
    return Objects.hash(fundId, price, priceType);
  }

  @Override
  public String toString() {

    return MoreObjects.toStringHelper(this).add("fundId", fundId)
        .add("priceDate", priceDate).add("priceType", priceType)
        .add("price", price).toString();
  }

}
