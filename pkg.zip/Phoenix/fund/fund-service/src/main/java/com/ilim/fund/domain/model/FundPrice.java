package com.ilim.fund.domain.model;

import com.ilim.commons.domain.IValueObject;
import com.ilim.commons.domain.model.PriceType;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

/** 
 * Fund Price Value Object.
 * 
 * <p>This represents the closing price of a fund on a date.
 * 
 * @author alan larkin 
 */
public class FundPrice implements IValueObject<FundPrice> {

  private final int fundId;
  private final BigDecimal price;
  private final LocalDate priceDate;
  private final PriceType priceType;

  /** Creates an immutable Fund Price Entity. */
  public FundPrice(int fundId, BigDecimal price, LocalDate priceDate,
      PriceType priceType) {

    this.fundId = fundId;
    this.price = price;
    this.priceDate = priceDate;
    this.priceType = priceType;
  }

  public int getFundId() {
    return fundId;
  }

  public BigDecimal getPrice() {
    return price;
  }

  public LocalDate getPriceDate() {
    return priceDate;
  }

  public PriceType getPriceType() {
    return priceType;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final FundPrice other = (FundPrice) obj;

    return (this.fundId == other.getFundId()
        && this.price.equals(other.getPrice())
        && this.priceDate.equals(other.getPriceDate())
        && this.priceType.equals(other.getPriceType()));
  }

  @Override
  public int hashCode() {
    return Objects.hash(fundId, price, priceDate, priceType);
  }

  @Override
  public String toString() {

    return MoreObjects.toStringHelper(this).add("fundId", fundId)
        .add("price", price).add("priceDate", priceDate)
        .add("priceType", priceType).toString();
  }

}
