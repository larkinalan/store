package com.ilim.fund.domain.model;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

/** 
 * Fund Price Entity.
 * 
 * <p>This represents the closing price of a fund on a date.
 * 
 * @author alan larkin 
 */
public class FundPrice {

  private final int fundId;
  private final BigDecimal price;
  private final LocalDate priceDate;
  private final PriceType priceType;

  /** Creates an immutable Fund Price Entity. */
  public FundPrice(int fundId, BigDecimal price, LocalDate priceDate,
      PriceType priceType) {

    this.fundId = fundId;
    this.price = price;
    this.priceDate = priceDate;
    this.priceType = priceType;
  }

  public int getFundId() {
    return fundId;
  }

  public BigDecimal getPrice() {
    return price;
  }

  public LocalDate getPriceDate() {
    return priceDate;
  }

  public PriceType getPriceType() {
    return priceType;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final FundPrice other = (FundPrice) obj;

    return (this.fundId == other.getFundId()
        && this.price.equals(other.getPrice())
        && this.priceDate.equals(other.getPriceDate())
        && this.priceType.equals(other.getPriceType()));
  }

  @Override
  public int hashCode() {
    return Objects.hash(fundId, price, priceDate, priceType);
  }

  @Override
  public String toString() {

    return MoreObjects.toStringHelper(this).add("fundId", fundId)
        .add("price", price).add("priceDate", priceDate)
        .add("priceType", priceType).toString();
  }

  /* Fund price type. */
  public enum PriceType {

    TOTAL_RETURN(1), 
    PRICE_RETURN(2), 
    UNIT_TRANSACTION(3), 
    BID(4), 
    OFFER(5), 
    SEGO_PRICE(6), 
    BID_ASK(7), 
    ASK(8), 
    ILIM_UTE_APPROPRIATIONS_PRICE(9), 
    CONSULTANT_PRICE(10), 
    GIPS_PRICE(11);

    private int id;

    PriceType(int id) {
      this.id = id;
    }

    public int getId() {
      return id;
    }

    /** Gets a PriceType by id. */
    public static PriceType fromId(int id) {

      for (PriceType priceType : PriceType.values()) {
        if (id == priceType.getId()) {
          return priceType;
        }
      }
      throw new IllegalArgumentException("Unknown PriceType Id: " + id);
    }

    /** Gets a PriceType by name. */
    public static PriceType fromName(String name) {

      for (PriceType priceType : PriceType.values()) {
        if (name.equalsIgnoreCase(priceType.name())) {
          return priceType;
        }
      }
      throw new IllegalArgumentException("Unknown PriceType Name: " + name);
    }
  }
}
