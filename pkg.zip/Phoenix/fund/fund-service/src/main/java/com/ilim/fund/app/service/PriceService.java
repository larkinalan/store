package com.ilim.fund.app.service;

import com.ilim.fund.domain.IPriceRepository;
import com.ilim.fund.domain.model.FundPrice;
import com.ilim.fund.domain.model.FundPrice.PriceType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

/**
 * Provides FundPrice related services.
 */
public class PriceService implements IPriceService {

  private static final Logger log = LoggerFactory.getLogger(PriceService.class);

  private IPriceRepository fundPriceDao;

  @Inject
  public PriceService(IPriceRepository fundPriceDao) {
    this.fundPriceDao = fundPriceDao;
  }

  /**
   * Find the FundPrice with the fundId and priceType.
   * 
   * @param fundId fundId
   * @param priceType priceType
   * @return fundPrice
   */
  @Override
  @Transactional
  public FundPrice findPrice(int fundId, PriceType priceType) {

    log.info("findPrice ({}, {})", fundId, priceType);

    return fundPriceDao.findPrice(fundId, priceType);
  }

  /**
   * Find the FundPrice with for the fundIds and priceType.
   * 
   * @param fundIds List of fundIds
   * @param priceType priceType
   * @return List of FundPrice
   */
  @Override
  @Transactional
  public List<FundPrice> findPrices(List<Integer> fundIds,
      PriceType priceType) {

    log.info("findPrices ({}, {})", fundIds, priceType);

    return fundPriceDao.findPrices(fundIds, priceType);
  }

  /**
   * Find the FundPrice with for the fundIds and priceType.
   * 
   * @param fundIds List of fundIds
   * @param priceType price type
   * @return LocalDate price date
   */
  @Override
  @Transactional
  public LocalDate findLatestPriceDate(int fundId,
      Optional<PriceType> priceType) {

    log.info("findLatestPriceDate ({}, {})", fundId, priceType);

    return fundPriceDao.findLatestPriceDate(fundId,
        priceType.orElse(PriceType.UNIT_TRANSACTION));
  }

}
