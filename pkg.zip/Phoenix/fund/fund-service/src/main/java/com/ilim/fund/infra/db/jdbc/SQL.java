package com.ilim.fund.infra.db.jdbc;

/*
 *  Sql statements used in Dao
 *  
 *  <p>Formatted and wrapped using TOAD. 
 *  
 *  @formatter:off
 *  CHECKSTYLE:OFF
 */
public class SQL {

  
  /*******************************************
   * T_FUND sql statements
   *******************************************/
  public static final String select_from_fund = 
      "SELECT ilim_id " +
      "     , fund_level_id " +
      "     , committed_units_in_issue_qty " +
      "     , base_currency_id " + 
      "     , lob_id " + 
      "  FROM fund "; 
  
  public static final String select_from_fund_by_id = 
      "SELECT ilim_id " +
      "     , fund_level_id " +
      "     , committed_units_in_issue_qty " +
      "     , base_currency_id " + 
      "     , lob_id " + 
      "  FROM fund " +
      " WHERE ilim_id IN (:fundIds) "; 
  
  public static final String select_from_fund_by_level =
      "SELECT ilim_id " +
      "     , fund_level_id " +
      "     , committed_units_in_issue_qty " +
      "     , base_currency_id " + 
      "     , lob_id " + 
      "  FROM fund " +
      " WHERE fund_level_id = :levelId "; 
  
  
  /*******************************************
   * T_FUND_HOLDING sql statements
   *******************************************/
  public static final String select_from_fund_holding_by_id = 
      "SELECT ilim_id " +
      "     , underlying_ilim_id " +
      "     , holding_qty " +
      "  FROM fund_holding " +
      " WHERE ilim_id = :fundId " +
      "   AND underlying_ilim_id = :holdingId "; 

  public static final String select_from_fund_holding_by_fund_id = 
      "SELECT ilim_id " +
      "     , underlying_ilim_id " +
      "     , holding_qty " +
      "  FROM fund_holding " +
      " WHERE ilim_id = :fundId "; 
  
  public static final String select_lookthru_from_fund_holding_by_fund_id = 
      "SELECT fh.ilim_id " +
      "     , fh.underlying_ilim_id " +
      "     , fh.holding_qty " +
      "  FROM fund_holding fh " +
      "     , fund f " +
      "     , fund h " +
      " WHERE fh.ilim_id = f.ilim_id " +
      "   AND fh.underlying_ilim_id = h.ilim_id " +
      "CONNECT BY PRIOR fh.underlying_ilim_id = fh.ilim_id " +
      "START WITH fh.ilim_id = :fundId ";
  
  /*******************************************
   * MV_FUND_PRICE_LATEST sql statements
   *******************************************/
  public static final String select_from_fund_price_latest_by_fund_id_and_type = 
      "SELECT ilim_id " +
      "     , price_dt " +
      "     , price_type_id " +
      "     , closing_price " +
      "  FROM fund_price_latest " +
      " WHERE ilim_id IN (:fundIds) " +
      "   AND price_type_id = :priceTypeId "; 
  
  /*******************************************
   * MV_FUND_PRICE_LATEST_DATE sql statements
   *******************************************/
  public static final String select_from_fund_price_latest_date_by_fund_id_and_type = 
      "SELECT price_dt " +
      "  FROM fund_price_latest_date " +
      " WHERE ilim_id = :fundId " +
      "   AND price_type_id = :priceTypeId "; 
  
}
