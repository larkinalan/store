package com.ilim.fund.domain.model;

import com.ilim.commons.domain.IValueObject;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/** 
 * Fund Holding Value Object.
 * 
 * <p>This holds the positions of units held by an underlying fund.
 * 
 * @author alan larkin 
 */
public class FundHolding implements IValueObject<FundHolding> {

  private final int fundId;
  private final int holdingId;
  private final BigDecimal heldUnits;
  private final BigDecimal committedHeldUnits;

  /**
   * Creates an immutable FundHolding.
   * 
   * @param fundId ilimId 
   * @param holdingId underlying ilimId
   * @param heldUnits units of the fund, that are held by this holding 
   */
  public FundHolding(int fundId, int holdingId, BigDecimal heldUnits,
      BigDecimal committedHeldUnits) {

    this.fundId = fundId;
    this.holdingId = holdingId;
    this.heldUnits = heldUnits;
    this.committedHeldUnits = committedHeldUnits;
  }

  public int getFundId() {
    return fundId;
  }

  public int getHoldingId() {
    return holdingId;
  }

  /** Start of day position. */
  public BigDecimal getHeldUnits() {

    if (heldUnits == null) {
      return BigDecimal.ZERO;
    } else {
      return heldUnits;
    }
  }

  /** Intra day position. */
  public BigDecimal getCommittedHeldUnits() {

    if (committedHeldUnits == null) {
      return getHeldUnits();
    } else {
      return committedHeldUnits;
    }
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final FundHolding other = (FundHolding) obj;
    return Objects.equals(fundId, other.getFundId())
        && Objects.equals(holdingId, other.getHoldingId());
  }

  @Override
  public int hashCode() {
    return Objects.hash(fundId, holdingId);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("fundId", fundId)
        .add("holdingId", holdingId).toString();
  }

}
