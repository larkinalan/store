package com.ilim.fund.domain.model;

import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/** 
 * Fund Holding Entity.
 * 
 * <p>This represents a fund relationship with an underlying fund.
 * 
 * @author alan larkin 
 */
public class FundHolding {

  private final int fundId;
  private final int holdingId;
  private final BigDecimal heldUnits;

  /**
   * Creates an immutable FundHolding.
   * 
   * @param fundId ilimId 
   * @param holdingId underlying ilimId
   * @param heldUnits units of the fund, that are held by this holding 
   */
  public FundHolding(int fundId, int holdingId, BigDecimal heldUnits) {

    this.fundId = fundId;
    this.holdingId = holdingId;
    this.heldUnits = heldUnits;
  }

  public int getFundId() {
    return fundId;
  }

  public int getHoldingId() {
    return holdingId;
  }

  public BigDecimal getHeldUnits() {

    return heldUnits;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final FundHolding other = (FundHolding) obj;
    return Objects.equals(fundId, other.getFundId())
        && Objects.equals(holdingId, other.getHoldingId());
  }

  @Override
  public int hashCode() {
    return Objects.hash(fundId, holdingId);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("fundId", fundId)
        .add("holdingId", holdingId).toString();
  }

}
