package com.ilim.fund.infra.db.jdbc;

import com.ilim.commons.db.AppSqlException;
import com.ilim.fund.domain.IFundRepository;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.Fund.Level;
import com.ilim.fund.domain.model.FundHolding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;

/**
 * Database operations over T_FUND and T_FUND_HOLDING.
 * 
 * @author barry folan
 */
@Repository
public class JdbcFundDao extends NamedParameterJdbcDaoSupport
    implements IFundRepository {

  private static final Logger log = LoggerFactory.getLogger(JdbcFundDao.class);

  /** Initialize Dao with sql dataSource. */
  @Inject
  public JdbcFundDao(DataSource dataSource) {
    setDataSource(dataSource);
    getJdbcTemplate().setResultsMapCaseInsensitive(true);
  }

  /**
   * Find a fund by its fundId.
   * 
   * @param fundId fundId
   * @return fund
   * @throws AppSqlException
   * 
   */
  @Override
  public Fund findById(int fundId) {

    log.info("findById ({})", fundId);

    final String sql = SQL.select_from_fund_by_id;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("fundIds", fundId);

    final Fund result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toFund(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByid " + fundId, ex);
    }

    return result;
  }
  
  /**
   * Find funds by ids.
   * 
   * @param fundIds list
   * @return List of Fund
   * @throws AppSqlException
   * 
   */
  @Override
  public List<Fund> findById(List<Integer> fundIds) {

    log.info("findById ({})", fundIds);

    final String sql = SQL.select_from_fund_by_id;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("fundIds", fundIds);

    final List<Fund> result = new ArrayList<>();;
    try {

      result.addAll(getNamedParameterJdbcTemplate().query(sql, params,
          (rs, rowNum) -> {
            return toFund(rs);
          }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findById ", ex);
    }

    return result;
  }

  /**
   * Find all funds.
   * 
   * @return List of Funds
   * @throws AppSqlException
   * 
   */
  @Override
  public List<Fund> findAll() {

    log.info("findAll ()");

    final String sql = SQL.select_from_fund;

    final List<Fund> result = new ArrayList<>();
    try {

      result.addAll(getNamedParameterJdbcTemplate().query(sql, (rs, rowNum) -> {
        return toFund(rs);
      }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findAll", ex);
    }

    return result;
  }

  /**
   * Find all funds by level.
   * 
   * @param level level
   * @return List of Funds
   * @throws AppSqlException
   * 
   */
  @Override
  public List<Fund> findByLevel(Level level) {

    log.info("findByLevel ({}) ", level);

    final String sql = SQL.select_from_fund_by_level;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("levelId", level.id());

    final List<Fund> result = new ArrayList<>();
    try {

      result.addAll(
          getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
            return toFund(rs);
          }));


    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findByLevel", ex);
    }

    return result;
  }

  /**
   * Find the FundHolding with composite id passed in.
   * 
   * @param fundId ilimId
   * @param holdingId underlying ilimId
   * @return FundHolding.
   * @throws AppSqlException
   * 
   */
  @Override
  public FundHolding findFundHolding(int fundId, int holdingId) {

    log.info("findFundHolding ({}, {})", fundId, holdingId);

    final String sql = SQL.select_from_fund_holding_by_id;

    final SqlParameterSource params = new MapSqlParameterSource()
        .addValue("fundId", fundId).addValue("holdingId", holdingId);

    final FundHolding result;
    try {

      result = getNamedParameterJdbcTemplate().queryForObject(sql, params,
          (rs, rowNum) -> {
            return toFundHolding(rs);
          });

    } catch (DataAccessException ex) {
      throw new AppSqlException(
          "Error in findFundHolding " + fundId + ", " + holdingId, ex);
    }

    return result;
  }

  /**
   * Find all FundHoldings with the fundId
   * 
   * @param fundId fundId
   * @return List of FundHoldings.
   * @throws AppSqlException
   * 
   */
  @Override
  public List<FundHolding> findFundHoldings(int fundId) {

    log.info("findFundHoldings ({}) ", fundId);

    final String sql = SQL.select_from_fund_holding_by_fund_id;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("fundId", fundId);

    final List<FundHolding> result = new ArrayList<>();
    try {

      result.addAll(
          getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
            return toFundHolding(rs);
          }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in findFundHoldings " + fundId, ex);
    }

    return result;
  }

  /**
   * Recursively look through the fundIds holdings, to find all held funds.
   * 
   * @param fundId fundId
   * @return List of FundHolding
   * @throws AppSqlException
   * 
   */
  @Override
  public List<FundHolding> lookthru(int fundId) {

    log.info("lookthru ({})", fundId);

    final String sql = SQL.select_lookthru_from_fund_holding_by_fund_id;

    final SqlParameterSource params =
        new MapSqlParameterSource().addValue("fundId", fundId);

    final List<FundHolding> result = new ArrayList<>();
    try {

      result.addAll(
          getNamedParameterJdbcTemplate().query(sql, params, (rs, rowNum) -> {
            return toFundHolding(rs);
          }));

    } catch (DataAccessException ex) {
      throw new AppSqlException("Error in lookthru " + fundId, ex);
    }

    return result;
  }

  private Fund toFund(ResultSet rs) {

    try {

      int fundId = rs.getInt("ilim_id");
      int fundLevelId = rs.getInt("fund_level_id");
      Fund.Level fundLevel = Fund.Level.fromId(fundLevelId);
      BigDecimal committedUnits =
          rs.getBigDecimal("committed_units_in_issue_qty");

      return new Fund(fundId, fundLevel, committedUnits);

    } catch (SQLException ex) {
      throw new AppSqlException("Error mapping sql result set to Fund!", ex);
    }
  }

  private FundHolding toFundHolding(ResultSet rs) {

    try {

      int fundId = rs.getInt("ilim_id");
      int holdingId = rs.getInt("underlying_ilim_id");
      BigDecimal heldUnits = rs.getBigDecimal("holding_qty");

      return new FundHolding(fundId, holdingId, heldUnits);

    } catch (SQLException ex) {
      throw new AppSqlException("Error mapping sql result set to FundHolding!",
          ex);
    }
  }
}
