package com.ilim.fund;

import static com.ilim.commons.conf.AppConfig.settings;
import static com.ilim.commons.domain.model.PriceType.UNIT_TRANSACTION;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.commons.domain.model.PriceType;
import com.ilim.commons.time.DateUtils;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.FundHolding;
import com.ilim.fund.domain.model.FundPrice;

import com.google.common.collect.ImmutableList;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/*
 * Unit Test Data Object Mother.
 * 
 * <p>Used for 'expected' results in testing.
 * 
 */
public class TestData {

  /** Fund test data. */
  public static class Funds {

    public static final Fund PCF =
        new Fund(17444, FundLevel.CLIENT, new BigDecimal("100"), "EUR", 22);
    public static final Fund TPCF =
        new Fund(17803, FundLevel.TAX, new BigDecimal("100"), "EUR", 0);
    public static final Fund PPCF =
        new Fund(133, FundLevel.PRIMARY, new BigDecimal("100"), "EUR", 0);
    public static final Fund IPAINA =
        new Fund(208, FundLevel.INVESTING, new BigDecimal("60"), "EUR", 41);
    public static final Fund IPAIPE =
        new Fund(209, FundLevel.INVESTING, new BigDecimal("40"), "EUR", 41);

    public static final List<Fund> list =
        ImmutableList.of(PCF, TPCF, PPCF, IPAINA, IPAIPE);
  }

  /** FundHolding test data. */
  public static class FundHoldings {

    // CLIENT -> TAX
    public static final FundHolding PCF_TPCF = new FundHolding(
        Funds.PCF.getId(), Funds.TPCF.getId(), Funds.TPCF.getCommittedUnits());
    // TAX -> PRIMARY
    public static final FundHolding TPCF_PPCF = new FundHolding(
        Funds.TPCF.getId(), Funds.PPCF.getId(), Funds.PPCF.getCommittedUnits());
    // PRIMARY -> INVESTING
    public static final FundHolding PPCF_IPAINA =
        new FundHolding(Funds.PPCF.getId(), Funds.IPAINA.getId(),
            Funds.IPAINA.getCommittedUnits());
    public static final FundHolding PPCF_IPAIPE =
        new FundHolding(Funds.PPCF.getId(), Funds.IPAIPE.getId(),
            Funds.IPAIPE.getCommittedUnits());

    public static final List<FundHolding> list =
        ImmutableList.of(PCF_TPCF, TPCF_PPCF, PPCF_IPAINA, PPCF_IPAIPE);
  }

  /** FundPrice test data. */
  public static class FundPrices {

    public static LocalDate priceDate =
        LocalDate.parse(settings().getString("price.date"), DateUtils.DATE_FMT);
    public static PriceType priceType = UNIT_TRANSACTION;

    public static final FundPrice PCF =
        new FundPrice(Funds.PCF.getId(), priceDate, priceType, BigDecimal.ONE);
    public static final FundPrice TPCF =
        new FundPrice(Funds.TPCF.getId(), priceDate, priceType, BigDecimal.ONE);
    public static final FundPrice PPCF =
        new FundPrice(Funds.PPCF.getId(), priceDate, priceType, BigDecimal.ONE);
    public static final FundPrice IPAINA = new FundPrice(Funds.IPAINA.getId(),
        priceDate, priceType, BigDecimal.ONE);
    public static final FundPrice IPAIPE = new FundPrice(Funds.IPAIPE.getId(),
        priceDate, priceType, BigDecimal.ONE);

    public static final List<FundPrice> list =
        ImmutableList.of(PCF, TPCF, PPCF, IPAINA, IPAIPE);
  }

}
