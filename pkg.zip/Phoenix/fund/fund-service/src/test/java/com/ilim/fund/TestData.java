package com.ilim.fund;

import static com.ilim.commons.conf.AppConfig.settings;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.time.DateUtils;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.FundHolding;
import com.ilim.fund.domain.model.FundPrice;
import com.ilim.fund.domain.model.FundPrice.PriceType;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/*
 * Test Data Object Mother.
 * 
 * <p>Used for 'expected' results in testing.
 * 
 */
public class TestData {

  /** Fund test data. */
  public static class Funds {

    public static final Fund PCF =
        new Fund(17444, Fund.Level.CLIENT, BigDecimal.TEN);
    public static final Fund CAS1 =
        new Fund(17803, Fund.Level.TAX, BigDecimal.TEN);
    public static final Fund UKPDF =
        new Fund(11024, Fund.Level.PRIMARY, BigDecimal.TEN);
    public static final Fund ILA_INDX_EUR =
        new Fund(44117, Fund.Level.INVESTING, BigDecimal.TEN);

    public static class Data {

      public static final FundData PCF = new FundData(Funds.PCF.getId(),
          Funds.PCF.getLevel().name(), Funds.PCF.getCommittedUnits());
      public static final FundData CAS1 = new FundData(Funds.CAS1.getId(),
          Funds.CAS1.getLevel().name(), Funds.CAS1.getCommittedUnits());
    }
  }

  /** FundHolding test data. */
  public static class FundHoldings {

    public static final FundHolding PCF_CAS1 = new FundHolding(
        Funds.PCF.getId(), Funds.CAS1.getId(), new BigDecimal("10"));

    // TODO: name these properly
    public static final FundHolding IL_FTSE_RAFI_HOLDING_1 =
        new FundHolding(43865, 3630, new BigDecimal("743.69"));
    public static final FundHolding IL_FTSE_RAFI_HOLDING_2 =
        new FundHolding(43865, 44530, new BigDecimal("11411469.85"));

    public static class Data {

      public static final FundHoldingData PCF_CAS1 =
          new FundHoldingData(FundHoldings.PCF_CAS1.getFundId(),
              FundHoldings.PCF_CAS1.getHoldingId(),
              FundHoldings.PCF_CAS1.getHeldUnits());
      public static final FundHoldingData IL_FTSE_RAFI_HOLDING_1 =
          new FundHoldingData(FundHoldings.IL_FTSE_RAFI_HOLDING_1.getFundId(),
              FundHoldings.IL_FTSE_RAFI_HOLDING_1.getHoldingId(),
              FundHoldings.IL_FTSE_RAFI_HOLDING_1.getHeldUnits());
      public static final FundHoldingData IL_FTSE_RAFI_HOLDING_2 =
          new FundHoldingData(FundHoldings.IL_FTSE_RAFI_HOLDING_2.getFundId(),
              FundHoldings.IL_FTSE_RAFI_HOLDING_2.getHoldingId(),
              FundHoldings.IL_FTSE_RAFI_HOLDING_2.getHeldUnits());
    }
  }

  /** FundPrice test data. */
  public static class FundPrices {

    //TODO: integrate with db to get latest date of avaialble
    public static LocalDate testPriceDate = LocalDate
        .parse(settings().getString("tests.price.date"), DateUtils.DATE_FMT);

    public static final FundPrice PCF = new FundPrice(Funds.PCF.getId(),
        BigDecimal.ONE, testPriceDate, PriceType.UNIT_TRANSACTION);
    public static final FundPrice CAS1 = new FundPrice(Funds.CAS1.getId(),
        BigDecimal.ONE, testPriceDate, PriceType.UNIT_TRANSACTION);

    public static class Data {

      public static final FundPriceData PCF = new FundPriceData(
          FundPrices.PCF.getFundId(), FundPrices.PCF.getPrice(),
          FundPrices.PCF.getPriceDate().format((DateUtils.DATE_FMT)),
          FundPrices.PCF.getPriceType().name());
      public static final FundPriceData CAS1 = new FundPriceData(
          FundPrices.CAS1.getFundId(), FundPrices.CAS1.getPrice(),
          FundPrices.CAS1.getPriceDate().format((DateUtils.DATE_FMT)),
          FundPrices.CAS1.getPriceType().name());
    }
  }

  /** Assertion helper. */
  public static void assertSimilar(FundHolding actual, FundHolding expected) {

    assertThat(actual).isEqualToIgnoringGivenFields(expected, "holdingQty");
  }

  /** Assertion helper. */
  public static void assertSimilar(FundHoldingData actual,
      FundHoldingData expected) {

    assertThat(actual).isEqualToIgnoringGivenFields(expected, "holdingQty");
  }

  /** Assertion helper. */
  public static void assertSimilar(FundPrice actual, FundPrice expected) {

    assertThat(actual).isEqualToIgnoringGivenFields(expected, "price");
  }

  /** Assertion helper. */
  public static void assertSimilar(FundPriceData actual,
      FundPriceData expected) {

    assertThat(actual).isEqualToIgnoringGivenFields(expected, "price");
  }

  /** Assertion helper. */
  public static void assertSimilarHoldings(List<FundHoldingData> actual,
      List<FundHoldingData> expected) {

    assertThat(actual.size()).isEqualTo(expected.size());
    for (int i = 0; i < actual.size(); i++) {
      assertSimilar(actual.get(i), expected.get(i));
    }
  }

  /** Assertion helper. */
  public static void assertSimilarPrices(List<FundPrice> actual,
      List<FundPrice> expected) {

    assertThat(actual.size()).isEqualTo(expected.size());
    for (int i = 0; i < actual.size(); i++) {
      assertSimilar(actual.get(i), expected.get(i));
    }
  }

  /** Assertion helper. */
  public static void assertSimilarPriceData(List<FundPriceData> actual,
      List<FundPriceData> expected) {

    assertThat(actual.size()).isEqualTo(expected.size());
    for (int i = 0; i < actual.size(); i++) {
      assertSimilar(actual.get(i), expected.get(i));
    }
  }

}
