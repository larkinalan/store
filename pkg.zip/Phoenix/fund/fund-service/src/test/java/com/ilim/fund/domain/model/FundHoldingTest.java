package com.ilim.fund.domain.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.math.BigDecimal;

public class FundHoldingTest {

  FundHolding fundHoldingA = new FundHolding(123, 111, BigDecimal.TEN);
  FundHolding fundHoldingB = new FundHolding(123, 111, BigDecimal.TEN);
  FundHolding fundHoldingC = new FundHolding(456, 111, BigDecimal.TEN);
  FundHolding fundHoldingD = new FundHolding(123, 222, BigDecimal.TEN);

  @Test
  public void fundHolding() {

    int fundId = 123;
    int holdingId = 456;
    BigDecimal heldUnits = new BigDecimal("501.01");
    FundHolding fundHolding = new FundHolding(fundId, holdingId, heldUnits);

    assertThat(fundHolding.getFundId()).isEqualTo(fundId);
    assertThat(fundHolding.getHoldingId()).isEqualTo(holdingId);
    assertThat(fundHolding.getHeldUnits()).isEqualTo(heldUnits);
  }

  @Test
  public void equalsTest() {

    assertTrue(fundHoldingA.equals(fundHoldingB));
    assertFalse(fundHoldingA.equals(fundHoldingC));
    assertFalse(fundHoldingA.equals(fundHoldingD));
  }

  @Test
  public void hashCodeTest() {

    assertThat(fundHoldingA.hashCode()).isEqualTo(fundHoldingB.hashCode());
    assertThat(fundHoldingA.hashCode()).isNotEqualTo(fundHoldingC.hashCode());
    assertThat(fundHoldingA.hashCode()).isNotEqualTo(fundHoldingD.hashCode());
  }

}
