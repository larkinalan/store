package com.ilim.fund.web.resources;

import static com.ilim.fund.web.resources.FundDataMapper.toFundData;
import static com.ilim.fund.web.resources.FundDataMapper.toFundHoldingData;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.ilim.fund.TestData;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;

import org.junit.Test;

import java.util.List;

import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;

public class FundResourceTest extends JerseySpringTestSupport {

  protected WebTarget fundResource() {
    return target("funds");
  }

  protected WebTarget fundHoldingResource(int fundId) {
    return fundResource().path(fundId + "/holdings");
  }

  protected WebTarget fundHoldingResource(int fundId, int holdingId) {
    return fundHoldingResource(fundId).path("/" + holdingId);
  }

  @Test
  public void findFundById() {

    FundData expected = toFundData(TestData.Funds.PCF);
    String fundId = String.valueOf(expected.fundId);

    FundData actual = fundResource().path(fundId).request()
        .get(new GenericType<FundData>() {});

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findFundsByIds() {

    FundData expected = toFundData(TestData.Funds.PCF);

    List<FundData> actual = fundResource().queryParam("fundId", expected.fundId)
        .request().get(new GenericType<List<FundData>>() {});

    assertThat(actual).containsOnly(expected);
  }

  @Test
  public void findAll() {

    List<FundData> funds =
        fundResource().request().get(new GenericType<List<FundData>>() {});

    assertThat(funds.size()).isGreaterThan(0);
  }

  @Test
  public void findByLevel() {

    String level = "tax";

    List<FundData> funds = fundResource().queryParam("level", level).request()
        .get(new GenericType<List<FundData>>() {});

    int size = funds.size();
    assertThat(size).isGreaterThan(0);
    assertTrue(funds.stream().allMatch(f -> f.level.equalsIgnoreCase(level)));

  }

  @Test
  public void findByLevelMixedCase() {

    String level = "clIEnt";

    List<FundData> fundDatas = fundResource().queryParam("level", level)
        .request().get(new GenericType<List<FundData>>() {});

    int size = fundDatas.size();
    assertThat(size).isGreaterThan(0);
    assertTrue(
        fundDatas.stream().allMatch(fd -> fd.level.equalsIgnoreCase(level)));
  }

  @Test
  public void findFundHolding() {

    FundHoldingData expected =
        toFundHoldingData(TestData.FundHoldings.PCF_TPCF);

    FundHoldingData actual =
        fundHoldingResource(expected.fundId, expected.holdingId).request()
            .get(new GenericType<FundHoldingData>() {});

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findFundHoldings() {

    FundHoldingData expected =
        toFundHoldingData(TestData.FundHoldings.PCF_TPCF);

    List<FundHoldingData> actual = fundHoldingResource(expected.fundId)
        .request().get(new GenericType<List<FundHoldingData>>() {});

    assertThat(actual).containsOnly(expected);
  }

  @Test
  public void lookthru() {

    int fundId = TestData.Funds.PCF.getId();

    List<FundHoldingData> fundHoldings =
        fundHoldingResource(fundId).path("/lookthru").request()
            .get(new GenericType<List<FundHoldingData>>() {});

    assertThat(fundHoldings.size()).isGreaterThan(1);
  }
}
