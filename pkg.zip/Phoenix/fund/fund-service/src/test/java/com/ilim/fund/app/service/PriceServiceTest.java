package com.ilim.fund.app.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.domain.model.PriceType;
import com.ilim.fund.TestData;
import com.ilim.fund.domain.model.FundPrice;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

public class PriceServiceTest extends AppServiceTestSupport {

  @Inject
  IPriceService fundPriceService;

  @Test
  public void findPrice() {

    FundPrice expected = TestData.FundPrices.PCF;

    FundPrice actual = fundPriceService.findPrice(expected.getFundId(),
        expected.getPriceType());

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findPrices() {

    // set up expected results
    List<FundPrice> expected =
        Arrays.asList(TestData.FundPrices.PCF, TestData.FundPrices.TPCF);
    List<Integer> fundIds = expected.stream().map(FundPrice::getFundId)
        .collect(Collectors.toList());

    // test
    List<FundPrice> actual =
        fundPriceService.findPrices(fundIds, PriceType.UNIT_TRANSACTION);

    // verify
    assertThat(actual).containsAll(expected);
  }
}
