package com.ilim.fund.app.service;

import static com.ilim.fund.TestData.assertSimilar;
import static com.ilim.fund.TestData.assertSimilarPrices;

import com.ilim.fund.TestData;
import com.ilim.fund.domain.model.FundPrice;
import com.ilim.fund.domain.model.FundPrice.PriceType;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

public class PriceServiceTest extends AppServiceTestSupport {

  @Inject
  IPriceService fundPriceService;

  @Test
  public void findPrice() {

    FundPrice expected = TestData.FundPrices.PCF;

    FundPrice actual = fundPriceService.findPrice(expected.getFundId(),
        expected.getPriceType());

    assertSimilar(actual, expected);
  }

  @Test
  public void findPrices() {

    // set up expected results
    FundPrice expectedA = TestData.FundPrices.PCF;
    FundPrice expectedB = TestData.FundPrices.CAS1;
    List<FundPrice> expectedList = Arrays.asList(expectedA, expectedB);
    List<Integer> fundIds = expectedList.stream().map(FundPrice::getFundId)
        .collect(Collectors.toList());

    // test
    List<FundPrice> actualList =
        fundPriceService.findPrices(fundIds, PriceType.UNIT_TRANSACTION);

    // verify
    assertSimilarPrices(actualList, expectedList);
  }
}
