package com.ilim.fund.app.service;

import static com.ilim.fund.TestData.assertSimilar;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.fund.TestData;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.Fund.Level;
import com.ilim.fund.domain.model.FundHolding;

import org.junit.Test;

import java.util.List;

import javax.inject.Inject;

public class FundServiceTest extends AppServiceTestSupport {

  @Inject
  private IFundService fundService;

  @Test
  public void findById() {

    Fund expected = TestData.Funds.PCF;
    Fund actual = fundService.findById(expected.getId());

    assertThat(actual).isEqualToComparingFieldByField(expected);
  }

  @Test
  public void findAll() {

    List<Fund> fundList = fundService.findAll();

    assertThat(fundList.size()).isGreaterThan(0);
  }

  @Test
  public void findByLevel() {

    Level level = Level.PRIMARY;

    List<Fund> fundList = fundService.findByLevel(level);

    assertThat(fundList.size()).isGreaterThan(0);
    assertThat(fundList).extracting("level").containsOnly(level);
  }

  @Test
  public void findFundHolding() {

    FundHolding expected = TestData.FundHoldings.PCF_CAS1;
    FundHolding actual = fundService.findFundHolding(expected.getFundId(),
        expected.getHoldingId());

    assertSimilar(actual, expected);
  }

  @Test
  public void findFundHoldings() {

    // Find single
    FundHolding expected = TestData.FundHoldings.PCF_CAS1;
    
    List<FundHolding> fundHoldings =
        fundService.findFundHoldings(expected.getFundId());
    assertThat(fundHoldings.size()).isEqualTo(1);
    assertSimilar(fundHoldings.get(0), expected);

    // Find multiple
    int fundId = TestData.Funds.ILA_INDX_EUR.getId();

    fundHoldings = fundService.findFundHoldings(fundId);

    assertThat(fundHoldings.size()).isGreaterThan(1);
    assertThat(fundHoldings).extracting("id", FundHolding.class)
        .extracting("fundId").containsOnly(fundId);
  }

  @Test
  public void lookthru() {

    int fundId = TestData.FundHoldings.IL_FTSE_RAFI_HOLDING_1.getFundId();
    List<FundHolding> fundHoldings = fundService.lookthru(fundId);

    assertThat(fundHoldings.size()).isEqualTo(2);
  }
}
