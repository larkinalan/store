package com.ilim.fund.app.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.domain.model.FundLevel;
import com.ilim.fund.TestData;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.FundHolding;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

public class FundServiceTest extends AppServiceTestSupport {

  @Inject
  private IFundService fundService;

  @Test
  public void findFundById() {

    Fund expected = TestData.Funds.PCF;
    Fund actual = fundService.findById(expected.getId());

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findManyFundsById() {

    Fund expected = TestData.Funds.PCF;
    List<Fund> actual = fundService.findByIds(Arrays.asList(expected.getId()));

    assertThat(actual).containsOnly(expected);
  }

  @Test
  public void findAll() {

    List<Fund> fundList = fundService.findAll();

    assertThat(fundList.size()).isGreaterThan(0);
  }

  @Test
  public void findByLevel() {

    FundLevel level = FundLevel.PRIMARY;

    List<Fund> fundList = fundService.findByLevel(level);

    assertThat(fundList.size()).isGreaterThan(0);
    assertThat(fundList).extracting("level").containsOnly(level);
  }

  @Test
  public void findFundHolding() {

    FundHolding expected = TestData.FundHoldings.PCF_TPCF;
    FundHolding actual = fundService.findFundHolding(expected.getFundId(),
        expected.getHoldingId());

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findFundHoldings() {

    // Find single
    FundHolding expected = TestData.FundHoldings.PCF_TPCF;

    List<FundHolding> fundHoldings =
        fundService.findFundHoldings(expected.getFundId());
    assertThat(fundHoldings).containsOnly(expected);

    // Find multiple
    int fundId = TestData.Funds.IPAIPE.getId();

    fundHoldings = fundService.findFundHoldings(fundId);

    assertThat(fundHoldings.size()).isGreaterThan(1);
    assertThat(fundHoldings).extracting("fundId").containsOnly(fundId);
  }

  @Test
  public void lookthru() {

    int fundId = TestData.Funds.PCF.getId();
    List<FundHolding> fundHoldings = fundService.lookthru(fundId);

    // assertThat(fundHoldings.size()).isGreaterThan(1);
    assertThat(fundHoldings).hasSize(43);
  }
}
