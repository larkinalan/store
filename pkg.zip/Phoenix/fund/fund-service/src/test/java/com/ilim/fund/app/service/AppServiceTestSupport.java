package com.ilim.fund.app.service;

import com.ilim.fund.app.config.SpringTestConfig;

import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringTestConfig.class)
public abstract class AppServiceTestSupport {

  @Rule
  @Inject
  public TestRule logger;

}
