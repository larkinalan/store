package com.ilim.fund.web.resources;

import static com.ilim.fund.web.resources.FundDataMapper.toFundPriceData;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.fund.TestData;
import com.ilim.fund.web.api.FundPriceData;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

public class FundPriceResourceTest extends JerseySpringTestSupport {

  protected WebTarget fundResource() {
    return target("funds");
  }

  protected WebTarget fundPriceResource() {
    return fundResource().path("/prices");
  }

  protected WebTarget fundPriceResource(int fundId) {
    return fundResource().path("/" + fundId + "/prices");
  }

  @Test
  public void findPrice() {

    FundPriceData expected = toFundPriceData(TestData.FundPrices.PCF);

    FundPriceData actual = fundPriceResource(expected.fundId).request()
        .get(new GenericType<FundPriceData>() {});

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findPriceOfType() {

    FundPriceData expected = toFundPriceData(TestData.FundPrices.PCF);

    FundPriceData actual = fundPriceResource(expected.fundId)
        .queryParam("type", "unit_transaction").request()
        .get(new GenericType<FundPriceData>() {});

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findPrices() {

    FundPriceData pcf = toFundPriceData(TestData.FundPrices.PCF);
    FundPriceData tpcf = toFundPriceData(TestData.FundPrices.TPCF);
    List<FundPriceData> expected = Arrays.asList(pcf, tpcf);

    List<FundPriceData> actual = fundPriceResource()
        .queryParam("fundId", pcf.fundId).queryParam("fundId", tpcf.fundId)
        .request().get(new GenericType<List<FundPriceData>>() {});

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findPricesOfType() {

    String typeName = "unit_transaction";
    FundPriceData pcf = toFundPriceData(TestData.FundPrices.PCF);
    FundPriceData tpcf = toFundPriceData(TestData.FundPrices.TPCF);
    List<FundPriceData> expected = Arrays.asList(pcf, tpcf);

    List<FundPriceData> actual =
        fundPriceResource().queryParam("fundId", pcf.fundId)
            .queryParam("fundId", tpcf.fundId).queryParam("type", typeName)
            .request().get(new GenericType<List<FundPriceData>>() {});

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findPricesMissingReqdParam() {

    // The required 1 -> n param values of fundId are missing.
    Response response = fundPriceResource().request().get();
    // expecting a 400 response status code
    assertThat(response.getStatus())
        .isEqualTo(Status.BAD_REQUEST.getStatusCode());
  }
}
