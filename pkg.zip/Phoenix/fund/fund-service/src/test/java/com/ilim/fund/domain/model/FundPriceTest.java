package com.ilim.fund.domain.model;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.domain.model.PriceType;
import com.ilim.fund.TestData;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

public class FundPriceTest {


  @Test
  public void fundPrice() {

    int fundId = 123;
    BigDecimal price = BigDecimal.TEN;
    LocalDate priceDate = LocalDate.now();
    PriceType priceType = PriceType.BID;

    FundPrice fundPrice = new FundPrice(fundId, priceDate, priceType, price);

    assertThat(fundPrice.getFundId()).isEqualTo(fundId);
    assertThat(fundPrice.getPrice()).isEqualTo(price);
    assertThat(fundPrice.getPriceDate()).isEqualTo(priceDate);
    assertThat(fundPrice.getPriceType()).isEqualTo(priceType);
  }

  @Test
  public void equalsTest() {

    assertThat(TestData.FundPrices.PCF).isEqualTo(TestData.FundPrices.PCF);
    assertThat(TestData.FundPrices.PCF).isNotEqualTo(TestData.FundPrices.TPCF);
  }

  @Test
  public void hashCodeTest() {

    assertThat(TestData.FundPrices.PCF.hashCode())
        .isEqualTo(TestData.FundPrices.PCF.hashCode());
    assertThat(TestData.FundPrices.PCF.hashCode())
        .isNotEqualTo(TestData.FundPrices.TPCF.hashCode());
  }

  @Test
  public void priceTypeFromId() {

    PriceType expected = PriceType.ASK;
    PriceType actual = PriceType.from(8);

    assertThat(actual).isEqualTo(expected);
  }

  @Test(expected = IllegalArgumentException.class)
  public void priceTypeFromIdUnknown() {

    PriceType.from(99999);
  }

  @Test
  public void priceTypeFromNameUpperCase() {

    PriceType expected = PriceType.OFFER;
    PriceType actual = PriceType.from("OFFER");

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void priceTypeFromNameLowerCase() {

    PriceType expected = PriceType.GIPS_PRICE;
    PriceType actual = PriceType.from("gips_price");

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void priceTypeFromNameMixedCase() {

    PriceType expected = PriceType.SEGO_PRICE;
    PriceType actual = PriceType.from("sEGo_PricE");

    assertThat(actual).isEqualTo(expected);
  }

  @Test(expected = IllegalArgumentException.class)
  public void priceTypeFromNameUnknown() {

    PriceType.from("abcd");
  }


}
