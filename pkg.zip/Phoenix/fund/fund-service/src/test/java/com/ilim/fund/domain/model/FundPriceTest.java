package com.ilim.fund.domain.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.ilim.fund.domain.model.FundPrice.PriceType;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

public class FundPriceTest {

  FundPrice fundPriceA = new FundPrice(123, BigDecimal.ONE, LocalDate.now(),
      PriceType.CONSULTANT_PRICE);
  FundPrice fundPriceB = new FundPrice(123, BigDecimal.ONE, LocalDate.now(),
      PriceType.CONSULTANT_PRICE);
  FundPrice fundPriceC = new FundPrice(456, BigDecimal.ONE, LocalDate.now(),
      PriceType.CONSULTANT_PRICE);
  FundPrice fundPriceD = new FundPrice(123, BigDecimal.TEN, LocalDate.now(),
      PriceType.CONSULTANT_PRICE);
  FundPrice fundPriceE = new FundPrice(123, BigDecimal.ONE, LocalDate.MAX,
      PriceType.CONSULTANT_PRICE);
  FundPrice fundPriceF =
      new FundPrice(123, BigDecimal.ONE, LocalDate.now(), PriceType.BID);

  @Test
  public void fundPrice() {

    int fundId = 123;
    BigDecimal price = BigDecimal.TEN;
    LocalDate priceDate = LocalDate.now();
    PriceType priceType = PriceType.BID;

    FundPrice fundPrice = new FundPrice(fundId, price, priceDate, priceType);

    assertThat(fundPrice.getFundId()).isEqualTo(fundId);
    assertThat(fundPrice.getPrice()).isEqualTo(price);
    assertThat(fundPrice.getPriceDate()).isEqualTo(priceDate);
    assertThat(fundPrice.getPriceType()).isEqualTo(priceType);
  }

  @Test
  public void equalsTest() {

    assertTrue(fundPriceA.equals(fundPriceB));
    assertFalse(fundPriceA.equals(fundPriceC));
    assertFalse(fundPriceA.equals(fundPriceD));
    assertFalse(fundPriceA.equals(fundPriceE));
    assertFalse(fundPriceA.equals(fundPriceF));
  }

  @Test
  public void hashCodeTest() {

    assertThat(fundPriceA.hashCode()).isEqualTo(fundPriceB.hashCode());
    assertThat(fundPriceA.hashCode()).isNotEqualTo(fundPriceC.hashCode());
    assertThat(fundPriceA.hashCode()).isNotEqualTo(fundPriceD.hashCode());
    assertThat(fundPriceA.hashCode()).isNotEqualTo(fundPriceE.hashCode());
    assertThat(fundPriceA.hashCode()).isNotEqualTo(fundPriceF.hashCode());
  }

  @Test
  public void priceTypeFromId() {

    PriceType expected = PriceType.ASK;
    PriceType actual = PriceType.fromId(8);

    assertThat(actual).isEqualTo(expected);
  }

  @Test(expected = IllegalArgumentException.class)
  public void priceTypeFromIdUnknown() {

    PriceType.fromId(99999);
  }

  @Test
  public void priceTypeFromNameUpperCase() {

    PriceType expected = PriceType.OFFER;
    PriceType actual = PriceType.fromName("OFFER");

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void priceTypeFromNameLowerCase() {

    PriceType expected = PriceType.GIPS_PRICE;
    PriceType actual = PriceType.fromName("gips_price");

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void priceTypeFromNameMixedCase() {

    PriceType expected = PriceType.SEGO_PRICE;
    PriceType actual = PriceType.fromName("sEGo_PricE");

    assertThat(actual).isEqualTo(expected);
  }

  @Test(expected = IllegalArgumentException.class)
  public void priceTypeFromNameUnknown() {

    PriceType.fromName("abcd");
  }


}
