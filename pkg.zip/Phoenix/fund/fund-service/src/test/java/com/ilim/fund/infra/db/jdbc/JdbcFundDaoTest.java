package com.ilim.fund.infra.db.jdbc;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.db.AppSqlException;
import com.ilim.commons.domain.model.FundLevel;
import com.ilim.fund.TestData;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.FundHolding;

import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

import javax.inject.Inject;

public class JdbcFundDaoTest extends JdbcDaoTestSupport {

  @Inject
  private JdbcFundDao fundDao;

  @Test
  public void findById() {

    Fund expected = TestData.Funds.PCF;
    Fund actual = fundDao.findById(expected.getId());

    assertThat(actual).isEqualTo(expected);
  }

  @Test(expected = AppSqlException.class)
  public void findByIdNoResult() {

    int fundId = -1;
    fundDao.findById(fundId);
  }

  @Test
  public void findAll() {

    List<Fund> fundList = fundDao.findAll();

    assertThat(fundList.size()).isGreaterThan(0);
  }

  @Test
  public void findByLevel() {

    FundLevel expected = FundLevel.PRIMARY;

    List<Fund> fundList = fundDao.findByLevel(expected);

    int size = fundList.size();
    assertThat(size).isGreaterThan(0);
    assertThat(fundList.get(0).getLevel()).isEqualTo(expected);
    assertThat(fundList.get(size - 1).getLevel()).isEqualTo(expected);
  }

  @Test
  public void findFundHolding() {

    FundHolding expected = TestData.FundHoldings.PCF_TPCF;
    FundHolding actual =
        fundDao.findFundHolding(expected.getFundId(), expected.getHoldingId());

    assertThat(actual).isEqualTo(expected);
  }

  @Test(expected = AppSqlException.class)
  public void findFundHoldingException() {

    FundHolding holding = new FundHolding(TestData.Funds.PPCF.getId(),
        TestData.Funds.TPCF.getId(), BigDecimal.TEN, BigDecimal.TEN);

    fundDao.findFundHolding(holding.getFundId(), holding.getHoldingId());
  }

  @Test
  public void findFundHoldings() {

    FundHolding expected = TestData.FundHoldings.PCF_TPCF;

    List<FundHolding> actual = fundDao.findFundHoldings(expected.getFundId());

    assertThat(actual).hasSize(1);
    assertThat(actual).containsOnly(expected);
  }

  @Test
  public void findFundHoldingsEmptyList() {

    int fundId = -1;
    List<FundHolding> actual = fundDao.findFundHoldings(fundId);

    assertThat(actual).hasSize(0);
  }

  @Test
  public void lookthruPcf() {

    int fundId = TestData.Funds.PCF.getId();
    List<FundHolding> fundHoldings = fundDao.lookthru(fundId);
    assertThat(fundHoldings.size()).isGreaterThan(1);
  }

  @Test
  public void lookthruEmpty() {

    int fundId = 0;
    List<FundHolding> fundHoldings = fundDao.lookthru(fundId);

    assertThat(fundHoldings).hasSize(0);
  }

}
