package com.ilim.fund.infra.db.jdbc;

import static com.ilim.fund.TestData.assertSimilar;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.db.AppSqlException;
import com.ilim.fund.TestData;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.Fund.Level;
import com.ilim.fund.domain.model.FundHolding;

import org.junit.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

public class JdbcFundDaoTest extends JdbcDaoTestSupport {

  @Inject
  private JdbcFundDao fundDao;

  @Test
  public void findById() {

    Fund expected = TestData.Funds.PCF;
    Fund actual = fundDao.findById(expected.getId());

    assertThat(actual).isEqualToComparingFieldByField(expected);
  }

  @Test(expected = AppSqlException.class)
  public void findByIdNoResult() {

    int fundId = -1;
    fundDao.findById(fundId);
  }

  @Test
  public void findAll() {

    List<Fund> fundList = fundDao.findAll();

    assertThat(fundList.size()).isGreaterThan(0);
  }

  @Test
  public void findByLevel() {

    Level expected = Level.PRIMARY;

    List<Fund> fundList = fundDao.findByLevel(expected);

    int size = fundList.size();
    assertThat(size).isGreaterThan(0);
    assertThat(fundList.get(0).getLevel()).isEqualTo(expected);
    assertThat(fundList.get(size - 1).getLevel()).isEqualTo(expected);
  }

  @Test
  public void findFundHolding() {

    FundHolding expected = TestData.FundHoldings.PCF_CAS1;
    FundHolding actual =
        fundDao.findFundHolding(expected.getFundId(), expected.getHoldingId());

    assertSimilar(actual, expected);
  }

  @Test(expected = AppSqlException.class)
  public void findFundHoldingException() {

    // CAS_1 is not a holding of UKPDF
    FundHolding holding = new FundHolding(TestData.Funds.UKPDF.getId(),
        TestData.Funds.CAS1.getId(), BigDecimal.ONE);

    fundDao.findFundHolding(holding.getFundId(), holding.getHoldingId());
  }

  @Test
  public void findFundHoldings() {

    FundHolding expected = TestData.FundHoldings.PCF_CAS1;

    List<FundHolding> fundHoldings =
        fundDao.findFundHoldings(expected.getFundId());

    assertThat(fundHoldings.size()).isEqualTo(1);
    assertSimilar(fundHoldings.get(0), expected);
  }

  @Test
  public void findFundHoldingsEmptyList() {

    List<FundHolding> actual = fundDao.findFundHoldings(-1);

    assertThat(actual.size()).isEqualTo(0);
  }

  @Test
  public void lookthruPcf() {

    int fundId = TestData.Funds.PCF.getId();
    List<FundHolding> fundHoldings = fundDao.lookthru(fundId);
    // PCF had 8984 holdings in its hierarchy in Nov 2015. Using a rough value
    // below to keep test as viable as possible without using an absolute value
    assertThat(fundHoldings.size()).isGreaterThan(8500);
    assertThat(fundHoldings.size()).isLessThan(9500);
  }

  @Test
  public void lookthruIlFtse() {

    FundHolding expectedA = TestData.FundHoldings.IL_FTSE_RAFI_HOLDING_1;
    FundHolding expectedB = TestData.FundHoldings.IL_FTSE_RAFI_HOLDING_2;
    List<FundHolding> expectedList = Arrays.asList(expectedA, expectedB);

    int fundId = expectedA.getFundId();
    List<FundHolding> actualList = fundDao.lookthru(fundId);

    for (int i = 0; i < actualList.size(); i++) {
      assertSimilar(actualList.get(i), expectedList.get(i));
    }
  }

  @Test
  public void lookthruEmpty() {

    int fundId = 3630;
    List<FundHolding> fundHoldings = fundDao.lookthru(fundId);

    assertThat(fundHoldings.size()).isEqualTo(0);
  }

}
