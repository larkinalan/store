package com.ilim.fund.infra.db.jdbc;

import static com.ilim.commons.domain.model.PriceType.UNIT_TRANSACTION;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.db.AppSqlException;
import com.ilim.fund.TestData;
import com.ilim.fund.domain.model.FundPrice;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

public class JdbcPriceDaoTest extends JdbcDaoTestSupport {

  @Inject
  private JdbcPriceDao fundPriceDao;

  @Test
  public void findPrice() {

    FundPrice expected = TestData.FundPrices.PCF;

    FundPrice actual =
        fundPriceDao.findPrice(expected.getFundId(), expected.getPriceType());

    assertThat(actual).isEqualTo(expected);
  }

  @Test(expected = AppSqlException.class)
  public void findPriceNoResult() {

    fundPriceDao.findPrice(-1, UNIT_TRANSACTION);
  }

  @Test
  public void findPrices() {

    // set up expected results
    List<FundPrice> expected =
        Arrays.asList(TestData.FundPrices.PCF, TestData.FundPrices.TPCF);
    List<Integer> fundIds = expected.stream().map(FundPrice::getFundId)
        .collect(Collectors.toList());

    // test
    List<FundPrice> actual = fundPriceDao.findPrices(fundIds, UNIT_TRANSACTION);

    // compare actual results with expected ones
    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void findPricesNoResults() {

    List<Integer> fundIds = Arrays.asList(-1, -2);
    List<FundPrice> actual = fundPriceDao.findPrices(fundIds, UNIT_TRANSACTION);

    assertThat(actual).hasSize(0);
  }
}
