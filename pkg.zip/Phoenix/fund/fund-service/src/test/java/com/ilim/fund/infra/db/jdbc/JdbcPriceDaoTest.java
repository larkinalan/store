package com.ilim.fund.infra.db.jdbc;

import static com.ilim.fund.TestData.assertSimilar;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.db.AppSqlException;
import com.ilim.fund.TestData;
import com.ilim.fund.domain.model.FundPrice;
import com.ilim.fund.domain.model.FundPrice.PriceType;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

public class JdbcPriceDaoTest extends JdbcDaoTestSupport {

  @Inject
  private JdbcPriceDao fundPriceDao;

  @Test
  public void findPrice() {

    FundPrice expected = TestData.FundPrices.PCF;

    FundPrice actual =
        fundPriceDao.findPrice(expected.getFundId(), expected.getPriceType());

    assertSimilar(actual, expected);
  }

  @Test(expected = AppSqlException.class)
  public void findPriceNoResult() {

    int fundId = -1;
    fundPriceDao.findPrice(fundId, PriceType.UNIT_TRANSACTION);
  }

  @Test
  public void findPrices() {

    // set up expected results
    FundPrice expectedA = TestData.FundPrices.PCF;
    FundPrice expectedB = TestData.FundPrices.CAS1;
    List<FundPrice> expectedList = Arrays.asList(expectedA, expectedB);
    List<Integer> fundIds = expectedList.stream().map(FundPrice::getFundId)
        .collect(Collectors.toList());

    // test
    List<FundPrice> actualList =
        fundPriceDao.findPrices(fundIds, PriceType.UNIT_TRANSACTION);

    // compare actual results with expected ones
    TestData.assertSimilarPrices(actualList, expectedList);
  }

  @Test
  public void findPricesNoResults() {

    List<Integer> fundIds = Arrays.asList(-1, -2);

    List<FundPrice> actual =
        fundPriceDao.findPrices(fundIds, PriceType.UNIT_TRANSACTION);

    assertThat(0).isEqualTo(actual.size());
  }
}
