package com.ilim.fund.web.resources;

import static com.ilim.commons.domain.model.Currency.EUR;
import static com.ilim.commons.domain.model.FundLevel.CLIENT;
import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.domain.model.PriceType;
import com.ilim.commons.time.DateUtils;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.FundHolding;
import com.ilim.fund.domain.model.FundPrice;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

public class FundDataMapperTest {

  @Test
  public void mapFundToFundData() {

    Fund fund = new Fund(123, CLIENT, new BigDecimal("10"), EUR, 1);
    FundData expected =
        new FundData(123, CLIENT.name(), new BigDecimal("10"), "EUR", 1);

    FundData actual = FundDataMapper.toFundData(fund);

    assertThat(expected).isEqualToComparingFieldByField(actual);
  }

  @Test
  public void mapFundHoldingToFundHoldingData() {

    FundHolding fundHolding = new FundHolding(123, 456, new BigDecimal("10"));
    FundHoldingData expected =
        new FundHoldingData(123, 456, new BigDecimal("10"));

    FundHoldingData actual = FundDataMapper.toFundHoldingData(fundHolding);

    assertThat(expected).isEqualToComparingFieldByField(actual);
  }

  @Test
  public void mapFundPriceToFundPriceData() {

    // set up test data
    int fundId = 1234;
    BigDecimal price = BigDecimal.ONE;
    LocalDate priceDate = LocalDate.now();
    PriceType priceType = PriceType.CONSULTANT_PRICE;
    FundPriceData expected = new FundPriceData(fundId,
        priceDate.format(DateUtils.DATE_FMT), priceType.name(), price);

    // test
    FundPrice fundPrice = new FundPrice(fundId, priceDate, priceType, price);
    FundPriceData actual = FundDataMapper.toFundPriceData(fundPrice);

    // verify
    assertThat(expected).isEqualToComparingFieldByField(actual);
  }
}
