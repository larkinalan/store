package com.ilim.fund.web.resources;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.domain.model.PriceType;
import com.ilim.commons.time.DateUtils;
import com.ilim.fund.TestData;
import com.ilim.fund.domain.model.Fund;
import com.ilim.fund.domain.model.FundHolding;
import com.ilim.fund.domain.model.FundPrice;
import com.ilim.fund.web.api.FundData;
import com.ilim.fund.web.api.FundHoldingData;
import com.ilim.fund.web.api.FundPriceData;

import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

public class FundDataMapperTest {

  @Test
  public void mapFundToFundData() {

    Fund fund = TestData.Funds.PCF;
    FundData expected = TestData.Funds.Data.PCF;

    FundData actual = FundDataMapper.toFundData(fund);

    assertThat(expected).isEqualToComparingFieldByField(actual);
  }

  @Test
  public void mapFundHoldingToFundHoldingData() {

    FundHolding fundHolding = TestData.FundHoldings.PCF_CAS1;
    FundHoldingData expected = TestData.FundHoldings.Data.PCF_CAS1;

    FundHoldingData actual = FundDataMapper.toFundHoldingData(fundHolding);

    assertThat(expected).isEqualToComparingFieldByField(actual);
  }

  @Test
  public void mapFundPriceToFundPriceData() {

    // set up test data
    int fundId = 1234;
    BigDecimal price = BigDecimal.ONE;
    LocalDate priceDate = LocalDate.now();
    PriceType priceType = PriceType.CONSULTANT_PRICE;
    FundPriceData expected = new FundPriceData(fundId, price,
        priceDate.format(DateUtils.DATE_FMT), priceType.name());

    // test
    FundPrice fundPrice = new FundPrice(fundId, price, priceDate, priceType);
    FundPriceData actual = FundDataMapper.toFundPriceData(fundPrice);

    // verify
    assertThat(expected).isEqualToComparingFieldByField(actual);
  }
}
