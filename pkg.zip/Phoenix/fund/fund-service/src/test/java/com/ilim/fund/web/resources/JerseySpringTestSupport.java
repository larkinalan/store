package com.ilim.fund.web.resources;

import com.ilim.fund.app.config.SpringTestConfig;
import com.ilim.fund.web.conf.JerseyConfig;

import com.codahale.metrics.MetricRegistry;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.test.JerseyTest;
import org.glassfish.jersey.test.TestProperties;
import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.ws.rs.core.Application;


/**
 * Support class for Testing our jersey services with spring transactions.
 * 
 * <p>Extend this class instead of JerseyTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringTestConfig.class)
@Transactional
@Rollback
public class JerseySpringTestSupport extends JerseyTest {

  private JerseyConfig jerseyTestConfig;
  private ApplicationContext springTestConfig;

  @Override
  protected Application configure() {

    enable(TestProperties.LOG_TRAFFIC);
    enable(TestProperties.DUMP_ENTITY);
    forceSet(TestProperties.CONTAINER_PORT, "0");

    jerseyTestConfig = new JerseyConfig();
    springTestConfig =
        new AnnotationConfigApplicationContext(SpringTestConfig.class);
    jerseyTestConfig.property("contextConfig", springTestConfig);
   
    return jerseyTestConfig;
  }

  @Override
  protected void configureClient(ClientConfig config) {

    config.register(JacksonFeature.class);
  }
  
  protected JerseyConfig jerseyConfig() {
    return jerseyTestConfig;
  }
  
  protected ApplicationContext springConfig() {
    return springTestConfig;
  }
  
  protected MetricRegistry metrics() {
    return jerseyTestConfig.metrics();
  }
  
  @Rule
  @Inject
  public TestRule logger;
  
}


