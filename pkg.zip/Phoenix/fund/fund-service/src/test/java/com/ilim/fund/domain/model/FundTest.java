package com.ilim.fund.domain.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.ilim.fund.domain.model.Fund.Level;

import org.junit.Test;

import java.math.BigDecimal;

public class FundTest {

  Fund fundA = new Fund(111, Level.CLIENT, BigDecimal.TEN);
  Fund fundB = new Fund(111, Level.CLIENT, BigDecimal.TEN);
  Fund fundC = new Fund(222, Level.CLIENT, BigDecimal.TEN);

  @Test
  public void fund() {

    int fundId = 123;
    Level level = Level.INVESTING;
    BigDecimal committedUnits = new BigDecimal("98765");

    Fund fund = new Fund(fundId, level, committedUnits);

    assertThat(fund.getId()).isEqualTo(fundId);
    assertThat(fund.getLevel()).isEqualTo(level);
    assertThat(fund.getCommittedUnits()).isEqualTo(committedUnits);
  }

  @Test
  public void equalsTest() {

    assertTrue(fundA.equals(fundB));
    assertFalse(fundA.equals(fundC));
  }

  @Test
  public void hashCodeTest() {

    assertThat(fundA.hashCode()).isEqualTo(fundB.hashCode());
    assertThat(fundA.hashCode()).isNotEqualTo(fundC.hashCode());
  }

  @Test
  public void fundLevelFromId() {

    Level expected = Level.CLIENT;
    Level actual = Level.fromId(1);

    assertThat(actual).isEqualTo(expected);
  }

  @Test(expected = IllegalArgumentException.class)
  public void fundLevelFromIdUnknown() {

    Level.fromId(9999);
  }

  @Test
  public void fundLevelFromNameUpperCase() {

    Level expected = Level.INVESTING;
    Level actual = Level.fromName("INVESTING");

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void fundLevelFromNameLowerCase() {

    Level expected = Level.TAX;
    Level actual = Level.fromName("tax");

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void fundLevelFromNameMixedCase() {

    Level expected = Level.CLIENT;
    Level actual = Level.fromName("Client");

    assertThat(actual).isEqualTo(expected);
  }

  @Test(expected = IllegalArgumentException.class)
  public void fundLevelFromNameUnknown() {

    Level.fromName("abcd");
  }
}
