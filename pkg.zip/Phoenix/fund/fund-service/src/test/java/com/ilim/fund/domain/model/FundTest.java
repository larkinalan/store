package com.ilim.fund.domain.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.ilim.commons.domain.model.FundLevel;

import org.junit.Test;

import java.math.BigDecimal;

public class FundTest {

  Fund fundA = new Fund(111, FundLevel.CLIENT, BigDecimal.TEN, 1);
  Fund fundB = new Fund(111, FundLevel.CLIENT, BigDecimal.TEN, 1);
  Fund fundC = new Fund(222, FundLevel.CLIENT, BigDecimal.TEN, 2);

  @Test
  public void fund() {

    int fundId = 123;
    FundLevel level = FundLevel.INVESTING;
    BigDecimal committedUnits = new BigDecimal("98765");
    int lobId = 1;

    Fund fund = new Fund(fundId, level, committedUnits, lobId);

    assertThat(fund.getId()).isEqualTo(fundId);
    assertThat(fund.getLevel()).isEqualTo(level);
    assertThat(fund.getCommittedUnits()).isEqualTo(committedUnits);
    assertThat(fund.getLobId()).isEqualTo(lobId);
  }

  @Test
  public void equalsTest() {

    assertTrue(fundA.equals(fundB));
    assertFalse(fundA.equals(fundC));
  }

  @Test
  public void hashCodeTest() {

    assertThat(fundA.hashCode()).isEqualTo(fundB.hashCode());
    assertThat(fundA.hashCode()).isNotEqualTo(fundC.hashCode());
  }

  @Test
  public void fundLevelFromId() {

    FundLevel expected = FundLevel.CLIENT;
    FundLevel actual = FundLevel.from(1);

    assertThat(actual).isEqualTo(expected);
  }

  @Test(expected = IllegalArgumentException.class)
  public void fundLevelFromIdUnknown() {

    FundLevel.from(9999);
  }

  @Test
  public void fundLevelFromNameUpperCase() {

    FundLevel expected = FundLevel.INVESTING;
    FundLevel actual = FundLevel.from("INVESTING");

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void fundLevelFromNameLowerCase() {

    FundLevel expected = FundLevel.TAX;
    FundLevel actual = FundLevel.from("tax");

    assertThat(actual).isEqualTo(expected);
  }

  @Test
  public void fundLevelFromNameMixedCase() {

    FundLevel expected = FundLevel.CLIENT;
    FundLevel actual = FundLevel.from("Client");

    assertThat(actual).isEqualTo(expected);
  }

  @Test(expected = IllegalArgumentException.class)
  public void fundLevelFromNameUnknown() {

    FundLevel.from("abcd");
  }
}
