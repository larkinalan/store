Fund Service 
================
*This is the Fund web service API*

build
-----
   
`mvn clean install`

*requires* 
* [Java8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)   
* [Maven3](https://maven.apache.org/)

test
----
All tests  

`mvn clean test`

Single test 

`mvn -Dtest=JdbcFundDaoTest test`  

run
---
run as a java app using an embedded http server **(only use this for testing)**

`mvn exec:java`

deploy
------

`mvn clean deploy`

typically you will add this jar to a war then deploy to a jboss app server 

libs
----

`mvn dependency:tree`

* [Jersey2](https://jersey.java.net/) for restful resources.
* [Jackson](http://wiki.fasterxml.com/JacksonHome) for Json data mapping.
* [Spring4](http://projects.spring.io/spring-framework/) for Dependency Injection.
* [Logback](http://logback.qos.ch/) and [slf4j](http://www.slf4j.org/) for Logging.
* [TypeSafe Config] (https://github.com/typesafehub/config) for configuration.
* [Dropwizard metrics] (http://metrics.dropwizard.io) for instrumentation and metrics.
* [Junit](http://junit.org/) for unit testing.
* [AssertJ](http://joel-costigliola.github.io/assertj/) for more advanced unit testing.
* [Mockito](http://mockito.org/) for mock testing.
* [H2 Database Engine] (http://www.h2database.com) for embedded db testing.
* [Errorprone](http://errorprone.info/) to detect common bugs at compile time.
* [Google Java Style Guide] (http://google.github.io/styleguide/javaguide.html) for java coding standards.
* [Checkstyle](http://checkstyle.sourceforge.net/) to enforce the standards.

docs
----
* [Architecture](L:\ITUNIT\PROJECTS\Strategy\FMA_Phoenix\System Architecture\phoenix-architecture.docx)  
* [confluence](http://ilm12807:7090/).
