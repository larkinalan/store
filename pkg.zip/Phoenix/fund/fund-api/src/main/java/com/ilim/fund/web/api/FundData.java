package com.ilim.fund.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

/**
 * Basic Fund api data type annotated for JSON serialization.
 * 
 * @author Alan Larkin
 */
public class FundData {

  @JsonProperty
  public final int fundId;
  @JsonProperty
  public final String level;
  @JsonProperty
  public final BigDecimal committedUnits;

  /**
   * Fund basic data.
   * 
   * @param fundId ilimId
   * @param level fund level
   * @param committedUnits units in issue
   */
  @JsonCreator
  public FundData(@JsonProperty("fundId") int fundId,
      @JsonProperty("level") String level,
      @JsonProperty("committedUnits") BigDecimal committedUnits) {

    this.fundId = fundId;
    this.level = level;
    this.committedUnits = committedUnits;
  }
}
