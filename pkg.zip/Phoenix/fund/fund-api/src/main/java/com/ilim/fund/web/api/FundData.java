package com.ilim.fund.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * Basic Fund api data type annotated for JSON serialization.
 * 
 * @author Alan Larkin
 */
public class FundData {

  @JsonProperty
  public final int fundId;
  @JsonProperty
  public final String level;
  @JsonProperty
  public final BigDecimal committedUnits;

  /**
   * Fund basic data.
   * 
   * @param fundId ilimId
   * @param level fund level
   * @param committedUnits units in issue
   */
  @JsonCreator
  public FundData(@JsonProperty("fundId") int fundId,
      @JsonProperty("level") String level,
      @JsonProperty("committedUnits") BigDecimal committedUnits) {

    this.fundId = fundId;
    this.level = level;
    this.committedUnits = committedUnits;
  }


  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final FundData other = (FundData) obj;

    return Objects.equals(this.fundId, other.fundId);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(this.fundId);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("fundId", fundId)
        .add("level", level).toString();
  }
}
