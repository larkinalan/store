package com.ilim.fund.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

/**
 * Fund Price api data type annotated for JSON serialization.
 * 
 * @author Alan Larkin
 */
public class FundPriceData {

  @JsonProperty
  public final int fundId;
  @JsonProperty
  public final BigDecimal price;
  @JsonProperty
  public final String priceDate;
  @JsonProperty
  public final String priceType;

  /**
   * Fund with price data.
   * 
   * @param fundId ilimId
   * @param price closing price
   * @param priceDate date priced on 
   * @param priceType price type
   */
  @JsonCreator
  public FundPriceData(@JsonProperty("fundId") int fundId,
      @JsonProperty("price") BigDecimal price,
      @JsonProperty("priceDate") String priceDate,
      @JsonProperty("priceType") String priceType) {

    this.fundId = fundId;
    this.price = price;
    this.priceDate = priceDate;
    this.priceType = priceType;
  }
}
