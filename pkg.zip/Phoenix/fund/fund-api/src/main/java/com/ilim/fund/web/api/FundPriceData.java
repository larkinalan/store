package com.ilim.fund.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * Fund Price api data type annotated for JSON serialization.
 * 
 * @author Alan Larkin
 */
public class FundPriceData {

  @JsonProperty
  public final int fundId;
  @JsonProperty
  public final BigDecimal price;
  @JsonProperty
  public final String priceDate;
  @JsonProperty
  public final String priceType;

  /**
   * Fund with price data.
   * 
   * @param fundId ilimId
   * @param price closing price
   * @param priceDate date priced on 
   * @param priceType price type
   */
  @JsonCreator
  public FundPriceData(@JsonProperty("fundId") int fundId,
      @JsonProperty("price") BigDecimal price,
      @JsonProperty("priceDate") String priceDate,
      @JsonProperty("priceType") String priceType) {

    this.fundId = fundId;
    this.price = price;
    this.priceDate = priceDate;
    this.priceType = priceType;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final FundPriceData other = (FundPriceData) obj;

    return (this.fundId == other.fundId && this.price.equals(other.price)
        && this.priceDate.equals(other.priceDate)
        && this.priceType.equals(other.priceType));
  }

  @Override
  public int hashCode() {
    return Objects.hash(fundId, price, priceDate, priceType);
  }

  @Override
  public String toString() {

    return MoreObjects.toStringHelper(this).add("fundId", fundId)
        .add("price", price).add("priceDate", priceDate)
        .add("priceType", priceType).toString();
  }
}
