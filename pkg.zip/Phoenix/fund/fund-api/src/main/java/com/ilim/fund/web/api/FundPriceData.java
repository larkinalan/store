package com.ilim.fund.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * Fund Price api data type annotated for JSON serialization.
 * 
 * @author Alan Larkin
 */
public class FundPriceData {

  @JsonProperty
  public final int fundId;
  @JsonProperty
  public final String priceDate;
  @JsonProperty
  public final String priceType;
  @JsonProperty
  public final BigDecimal price;

  /**
   * Fund with price data.
   * 
   * @param fundId ilimId
   * @param price closing price
   * @param priceDate date priced on 
   * @param priceType price type
   */
  @JsonCreator
  public FundPriceData(@JsonProperty("fundId") int fundId,
      @JsonProperty("priceDate") String priceDate,
      @JsonProperty("priceType") String priceType,
      @JsonProperty("price") BigDecimal price) {

    this.fundId = fundId;
    this.priceDate = priceDate;
    this.priceType = priceType;
    this.price = price;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final FundPriceData other = (FundPriceData) obj;

    return (this.fundId == other.fundId
        && this.priceDate.equals(other.priceDate)
        && this.priceType.equals(other.priceType));
  }

  @Override
  public int hashCode() {
    return Objects.hash(fundId, priceDate, priceType);
  }

  @Override
  public String toString() {

    return MoreObjects.toStringHelper(this).add("fundId", fundId)
        .add("priceDate", priceDate).add("priceType", priceType)
        .add("price", price).toString();
  }
}
