package com.ilim.fund.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

/**
 * Fund Holding api data type annotated for JSON serialization.
 * 
 * @author Alan Larkin
 */
public class FundHoldingData {

  @JsonProperty
  public final int fundId;
  @JsonProperty
  public final int holdingId;
  @JsonProperty
  public final BigDecimal heldUnits;

  /**
   * Fund with underlying fund data.
   * 
   * @param fundId ilimId
   * @param holdingId underlying ilimId
   * @param heldUnits units of fund held by holding
   */
  @JsonCreator
  public FundHoldingData(@JsonProperty("fundId") int fundId,
      @JsonProperty("holdingId") int holdingId,
      @JsonProperty("heldUnits") BigDecimal heldUnits) {

    this.fundId = fundId;
    this.holdingId = holdingId;
    this.heldUnits = heldUnits;
  }
}
