package com.ilim.fund.web.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * Fund Holding api data type annotated for JSON serialization.
 * 
 * @author Alan Larkin
 */
public class FundHoldingData {

  @JsonProperty
  public final int fundId;
  @JsonProperty
  public final int holdingId;
  @JsonProperty
  public final BigDecimal heldUnits;
  @JsonProperty
  public final BigDecimal committedHeldUnits;


  /**
   * Fund with underlying fund data.
   * 
   * @param fundId ilimId
   * @param holdingId underlying ilimId
   * @param heldUnits units of fund held by holding
   */
  @JsonCreator
  public FundHoldingData(@JsonProperty("fundId") int fundId,
      @JsonProperty("holdingId") int holdingId,
      @JsonProperty("heldUnits") BigDecimal heldUnits,
      @JsonProperty("committedHeldUnits") BigDecimal committedHeldUnits) {

    this.fundId = fundId;
    this.holdingId = holdingId;
    this.heldUnits = heldUnits;
    this.committedHeldUnits = committedHeldUnits;
  }

  @Override
  public boolean equals(Object obj) {

    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final FundHoldingData other = (FundHoldingData) obj;
    return Objects.equals(fundId, other.fundId)
        && Objects.equals(holdingId, other.holdingId);
  }

  @Override
  public int hashCode() {

    return Objects.hash(fundId, holdingId);
  }

  @Override
  public String toString() {

    return MoreObjects.toStringHelper(this).add("fundId", fundId)
        .add("holdingId", holdingId).add("heldUnits", heldUnits)
        .add("committedHeldUnits", committedHeldUnits).toString();
  }
}
