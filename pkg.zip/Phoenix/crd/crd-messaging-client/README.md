BBCW Client 
===========
*The Java client SDK for BBCW service.*
*This uses Retrofit and simplexml to build a soap meesage for CRDMessaging API*

build
-----
   
`mvn clean install`

*requires* 
* [Java8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)   
* [Maven3](https://maven.apache.org/)

deploy
------

`mvn clean deploy`

libs
----

`mvn dependency:tree`

* [retrofit](http://square.github.io/retrofit/) http client binder.
* [SimpleXML](http://simple.sourceforge.net/) for Soap Envelope and Schema.

