package com.ilim.crd.web.client;

import static org.junit.Assert.assertTrue;

import com.ilim.crd.web.api.CrdCashForecast;

import org.junit.Ignore;
import org.junit.Test;

import java.math.BigDecimal;

//@Ignore
public class CrdMessagingIntegrationTest {

  @Test
  public void sendToBbcw() throws Exception {

    CrdCashForecast cashForecast =
        new CrdCashForecast("P-CPS", "FTC", "EUR", new BigDecimal("24008"),
            "2015-12-16 10:05:30", "Create forecast to bbcw");
    
    CrdMessagingClient client = new CrdMessagingClient();
    assertTrue("Message failed to send!", client.sendToBbcw(cashForecast));
  }

}
