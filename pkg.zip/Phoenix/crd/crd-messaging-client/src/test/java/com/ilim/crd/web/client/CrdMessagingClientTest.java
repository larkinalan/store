package com.ilim.crd.web.client;

import static org.junit.Assert.assertTrue;

import com.ilim.crd.web.api.CrdCashForecast;

import okhttp3.HttpUrl;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;

public class CrdMessagingClientTest {

  private MockWebServer server;
  private CrdMessagingClient client;
  private HttpUrl baseUrl;

  /** Create client against mock web server. */
  @Before
  public void setUp() throws Exception {
    
    server = new MockWebServer();
    server.start();
    baseUrl = server.url("/mock/");
    client = new CrdMessagingClient(baseUrl.toString());
  }

  @After
  public void tearDown() throws Exception {

    server.shutdown();
  }

  @Test
  public void sendToMockBbcw() throws Exception {

    server.enqueue(new MockResponse().setBody("message recieved!"));

    CrdCashForecast cashForecast =
        new CrdCashForecast("P-CPS", "FTC", "EUR", new BigDecimal("24008"),
            "2015-12-16 10:05:30", "Create forecast to bbcw");
    
    boolean response = client.sendToBbcw(cashForecast);
    assertTrue("Message failed to send!", response);
  }

}
