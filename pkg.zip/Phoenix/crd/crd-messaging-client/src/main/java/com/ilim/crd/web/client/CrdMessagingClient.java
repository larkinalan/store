package com.ilim.crd.web.client;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.commons.web.client.AppClientException;
import com.ilim.commons.web.client.RetrofitClient;
import com.ilim.crd.web.api.CrdAuth;
import com.ilim.crd.web.api.CrdCashForecast;
import com.ilim.crd.web.api.CrdMessagingApi;
import com.ilim.crd.web.api.CrdMessagingEnvelope;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit2.SimpleXmlConverterFactory;

import java.io.IOException;


/**
 * CRIMS SOAP XML messaging client SDK. 
 * 
 * <p>Using:
 * (1) squares retrofit http client adapter.
 * See <a href="http://square.github.io/retrofit/">http://square.github.io/retrofit/</a>
 * (2) squares okttp as a http client. 
 * See <a href="http://square.github.io/okhttp/">http://square.github.io/okhttp/</a>
 * (3) simplexml to build the soap envelope, body and serialize the xml. 
 * See <a href="http://simple.sourceforge.net">http://simple.sourceforge.net</a>
 * 
 * @author alan larkin
 */
public class CrdMessagingClient {

  private static final Logger log =
      LoggerFactory.getLogger(CrdMessagingClient.class);

  private final RetrofitClient retrofitClient;
  private final CrdMessagingApi api;

  /** Create client using the env's default crd.messaging.service.baseurl. */
  public CrdMessagingClient() {

    this(settings().getString("crd.messaging.service.baseurl"));
  }

  /** Configures client using CrdMessagingApi. */
  public CrdMessagingClient(String baseUrl) {

    log.debug("Creating CrdMessagingClient for " + baseUrl);

    // Create retrofit http client with simple xml converter
    retrofitClient = RetrofitClient.newBuilder(baseUrl).witLogger(log)
        .withConverter(SimpleXmlConverterFactory.create()).build();

    // Generate api
    this.api = retrofitClient.adapter().create(CrdMessagingApi.class);
  }

  /** Sends cash forecast message to CRD BBCW.
   *
   * @param cashForecast bbcw data
   * @return true on success
   */
  public boolean sendToBbcw(CrdCashForecast cashForecast) {

    log.info("sendToBbcw ({})" + cashForecast);

    CrdMessagingEnvelope soapEnvelope = new CrdMessagingEnvelope()
        .withAuthToken(CrdAuth.newAuthToken()).withCashForecast(cashForecast);

    boolean isSuccess = false;
    try {
   
      isSuccess = api.sendMessage(soapEnvelope).execute().isSuccess();

    } catch (IOException ex) {

      log.error("sendToBbcw failed!");
      throw new AppClientException(ex);
    }

    return isSuccess;
  }

}
