package com.ilim.crd.web.api;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Namespace;
import org.simpleframework.xml.NamespaceList;
import org.simpleframework.xml.Root;

/**
 * Soap envelope and body for crd messaging.
 * 
 * <p>This is a little of static inner class mania going on here.
 * But hopefully its a one off as crd service has not changed in years!.
 *
 * @author Alan Larkin
 */
@Root(name = "soapenv:Envelope")
@NamespaceList({
    @Namespace(reference = "http://schemas.xmlsoap.org/soap/envelope/",
        prefix = "soapenv"),
    @Namespace(reference = "http://ilim.com/wsdl/CRDMessaging",
        prefix = "crd")})
public final class CrdMessagingEnvelope {

  @Element(name = "soapenv:Body")
  private CrdMessageBody body;

  /** Build CRD Messaging Soap Envelope with Body. */
  public CrdMessagingEnvelope() {

    this.body = new CrdMessageBody();
    this.body.messageRequest = new CrdMessageBody.CrdMessageRequest();
    this.body.messageRequest.message =
        new CrdMessageBody.CrdMessageRequest.CrdMessage();
    this.body.messageRequest.message.envelope =
        new CrdMessageBody.CrdMessageRequest.CrdMessage.Envelope();
  }

  /** Add Auth token to body. */
  public CrdMessagingEnvelope withAuthToken(CrdAuth auth) {

    this.body.messageRequest.message.envelope.auth = auth;
    return this;
  }

  /** Add Cash Forecast to body,  (only supports one per msg). */
  public CrdMessagingEnvelope withCashForecast(CrdCashForecast cashForecast) {

    this.body.messageRequest.message.envelope.cashForecast = cashForecast;
    return this;
  }

  /** Soap Message Body. */
  private static class CrdMessageBody {

    @Element(name = "crd:sendMessageRequest")
    private CrdMessageRequest messageRequest;

    private static class CrdMessageRequest {

      @Element(name = "crd:message")
      private CrdMessage message;

      private static class CrdMessage {

        @Element(name = "envelope")
        private Envelope envelope;

        private static class Envelope {

          // Defaults, may need to expose in the future ?
          @Attribute
          private static final String ack = "info";
          @Attribute
          private static final String logout = "true";
          @Attribute
          private static final String transaction = "multi";
          @Attribute
          private static final boolean stopOnError = false;
          @Attribute
          private static final String echoRequest = "error";

          @Element(name = "auth")
          private CrdAuth auth;
          @Element(name = "cashForecastExt")
          private CrdCashForecast cashForecast;

        }
      }
    }
  }
  
}
