package com.ilim.instruction.datatype;

import static org.assertj.core.api.Assertions.assertThat;

import com.ilim.commons.time.DateUtils;
import com.ilim.crd.web.api.CrdCashForecast;
import com.ilim.forecast.web.api.NewForecastInstructionData;
import com.ilim.instruction.TestData;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.Test;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class InstructionDataMapperTest {

  @Test
  public void toCrdCashForecast() throws Exception {

    Map<String, Object> map = new HashMap<String, Object>();
    map.put("fundCode", "PCF");
    map.put("fundCurrency", "EUR");
    map.put("amount", new Double("20000.01"));
    String mapAsJson = new ObjectMapper().writeValueAsString(map);

    Map<String, Object> instrEventMap = new HashMap<String, Object>();
    instrEventMap.put("INSTRUCTION_DATA", mapAsJson);

    CrdCashForecast actual =
        InstructionDataMapper.toCrdCashForecast(instrEventMap);

    CrdCashForecast expected = TestData.createCrdCashForecast();
    assertThat(actual).isEqualToIgnoringGivenFields(expected, "forecastDate");
  }

  @Test
  public void toNewForecastInstructionData() throws Exception {

    Map<String, Object> map = new HashMap<String, Object>();

    NewForecastInstructionData expected =
        TestData.createNewForecastInstructionData();

    String forecastDate = LocalDateTime.now().format(DateUtils.DATE_FMT);
    map.put("forecastDate", forecastDate);
    map.put("fundId", expected.fundId);
    map.put("instrId", expected.eventSourceId);
    map.put("moneyNotificationType", "CASH");
    map.put("instructionType", "MONEY_NOTIFICATION");
    map.put("amount", new Double("2000.01"));
    String mapAsJson = new ObjectMapper().writeValueAsString(map);

    Map<String, Object> instrEventMap = new HashMap<String, Object>();
    instrEventMap.put("INSTRUCTION_DATA", mapAsJson);

    NewForecastInstructionData actual =
        InstructionDataMapper.toNewForecastInstructionData(instrEventMap);

    assertThat(actual).isEqualToComparingFieldByField(expected);
  }
}
