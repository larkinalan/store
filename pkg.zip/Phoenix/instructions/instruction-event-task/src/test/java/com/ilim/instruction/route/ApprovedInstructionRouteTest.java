package com.ilim.instruction.route;

import com.ilim.instruction.TestData;
import com.ilim.instruction.app.conf.SpringTestConfig;

import com.squareup.okhttp.mockwebserver.MockResponse;

import org.apache.camel.EndpointInject;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.apache.camel.test.spring.UseAdviceWith;
import org.junit.After;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;

import java.io.IOException;

import javax.inject.Inject;

@Ignore
@RunWith(CamelSpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringTestConfig.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@UseAdviceWith(true)
public class ApprovedInstructionRouteTest {

  @Inject
  private ModelCamelContext context;

  @EndpointInject(uri = "mock:out")
  private MockEndpoint mockOut;
  
  @After
  public void tearDown() throws IOException {
    TestData.getMockServer().shutdown();
  }
  
  @Test
  public void approvedRouteSuccess() throws Exception {
    
    TestData.getMockServer().enqueue(new MockResponse().setResponseCode(200));
    
    context.addRoutes(new ApprovedInstructionRoute());
    
    context.getRouteDefinition("approvedInstructionRoute").adviceWith(context,
        new AdviceWithRouteBuilder() {
          @Override
          public void configure() throws Exception {
            replaceFromWith("direct:in");

            interceptSendToEndpoint("direct:updateOnSuccess")
                .skipSendToOriginalEndpoint().to(mockOut);
          }
        });
    context.start();

    mockOut.setExpectedMessageCount(1);
    mockOut.message(0).body().isEqualTo(true);

    ProducerTemplate template = context.createProducerTemplate();
    template.sendBody("direct:in", TestData.createNewForecastInstructionData());

    mockOut.assertIsSatisfied();
  }
    
  @Test
  public void approvedRouteFail() throws Exception {
    
    TestData.getMockServer().enqueue(new MockResponse().setResponseCode(400));
    
    context.addRoutes(new ApprovedInstructionRoute());
    
    context.getRouteDefinition("approvedInstructionRoute").adviceWith(context,
        new AdviceWithRouteBuilder() {
          @Override
          public void configure() throws Exception {
            replaceFromWith("direct:in");

            interceptSendToEndpoint("direct:updateOnFail")
                .skipSendToOriginalEndpoint().to(mockOut);
          }
        });
    context.start();

    mockOut.setExpectedMessageCount(1);
    mockOut.message(0).body().isEqualTo(false);

    ProducerTemplate template = context.createProducerTemplate();
    template.sendBody("direct:in", TestData.createNewForecastInstructionData());

    mockOut.assertIsSatisfied();
  }
  
}
