package com.ilim.instruction;

import com.ilim.crd.web.api.CrdCashForecast;

import com.squareup.okhttp.mockwebserver.MockWebServer;

import java.io.IOException;
import java.math.BigDecimal;

public class TestData {

  public static MockWebServer server;

  public static void init() throws IOException {
    server = new MockWebServer();
    server.start();
  }

  public static CrdCashForecast createCrdCashForecast() {
    return new CrdCashForecast("PCF", "FTC", "EUR", new BigDecimal("20000"),
        "2015-12-16 10:05:30", "Forecast Instruction to BBCW");
  }
}
