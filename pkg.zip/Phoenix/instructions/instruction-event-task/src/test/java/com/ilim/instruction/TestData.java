package com.ilim.instruction;

import static com.ilim.commons.time.DateUtils.DATE_FMT;

import com.ilim.crd.web.api.CrdCashForecast;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import com.squareup.okhttp.mockwebserver.MockWebServer;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicLong;

public class TestData {

  public static final AtomicLong eventId = new AtomicLong(999L);

  private static MockWebServer server;

  /**
   * Initialise the MockWebSever.
   * 
   * @throws IOException    while starting the mock web server
   */
  public static void init() throws IOException {
    if (server == null) {
      server = new MockWebServer();
      server.start();
    }
  }

  /**
   * Return the mock web sever.
   * 
   * @return    mock web server
   */
  public static MockWebServer getMockServer() {
    return server;
  }

  /** Creates test CrdCashForecast object. */
  public static CrdCashForecast createCrdCashForecast() {
    return new CrdCashForecast("PCF", "FTC", "EUR", new BigDecimal("20000"),
        "2015-12-16 10:05:30", "Forecast Instruction to BBCW");
  }

  /** Creates test NewForecastInstructionData object. */
  public static NewForecastInstructionData createNewForecastInstructionData() {

    String forecastDate = LocalDate.now().format(DATE_FMT);
    return new NewForecastInstructionData(forecastDate, "NEW_MONEY", 17444,
        "CASH", new BigDecimal("2000.01"), eventId.getAndIncrement());
  }
}
