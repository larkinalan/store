package com.ilim.instruction.route;

import com.ilim.instruction.TestData;
import com.ilim.instruction.app.conf.SpringTestConfig;

import com.squareup.okhttp.mockwebserver.MockResponse;

import org.apache.camel.EndpointInject;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.apache.camel.test.spring.UseAdviceWith;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;

import java.io.IOException;

import javax.inject.Inject;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringTestConfig.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@UseAdviceWith(true)
public class ReleasedInstructionRouteTest {

  @Inject
  private ModelCamelContext context;

  @EndpointInject(uri = "mock:out")
  private MockEndpoint mockOut;
  
  @After
  public void tearDown() throws IOException {
    TestData.server.shutdown();
  }
  
  @Test
  public void releasedRouteSuccess() throws Exception {
    
    TestData.server.enqueue(new MockResponse().setResponseCode(200));
    
    context.addRoutes(new ReleasedInstructionRoute());
    
    context.getRouteDefinition("releasedInstructionRoute").adviceWith(context,
        new AdviceWithRouteBuilder() {
          @Override
          public void configure() throws Exception {
            replaceFromWith("direct:in");

            interceptSendToEndpoint("direct:updateOnSuccess")
                .skipSendToOriginalEndpoint().to(mockOut);
          }
        });
    context.start();

    mockOut.setExpectedMessageCount(1);
    mockOut.message(0).body().isEqualTo(true);

    ProducerTemplate template = context.createProducerTemplate();
    template.sendBody("direct:in", TestData.createCrdCashForecast());

    mockOut.assertIsSatisfied();
  }
    
  @Test
  public void releasedRouteFail() throws Exception {
    
    TestData.server.enqueue(new MockResponse().setResponseCode(400));
    
    context.addRoutes(new ReleasedInstructionRoute());
    
    context.getRouteDefinition("releasedInstructionRoute").adviceWith(context,
        new AdviceWithRouteBuilder() {
          @Override
          public void configure() throws Exception {
            replaceFromWith("direct:in");

            interceptSendToEndpoint("direct:updateOnFail")
                .skipSendToOriginalEndpoint().to(mockOut);
          }
        });
    context.start();

    mockOut.setExpectedMessageCount(1);
    mockOut.message(0).body().isEqualTo(false);

    ProducerTemplate template = context.createProducerTemplate();
    template.sendBody("direct:in", TestData.createCrdCashForecast());

    mockOut.assertIsSatisfied();
  }
}
