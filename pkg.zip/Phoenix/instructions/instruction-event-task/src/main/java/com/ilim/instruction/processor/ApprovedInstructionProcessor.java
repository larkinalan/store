package com.ilim.instruction.processor;

import com.ilim.forecast.web.api.NewForecastInstructionData;
import com.ilim.forecast.web.client.ForecastClient;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;

import javax.inject.Inject;

public class ApprovedInstructionProcessor implements Processor {

  private static Logger log = LoggerFactory
      .getLogger(ApprovedInstructionProcessor.class);

  @Inject
  private ForecastClient forecastClient;

  /**
   * Process Approved Instruction Event.
   * 
   * @param exchange            camel exchange containing the event data
   * @throws Exception          exception during the process
   */
  @Override
  public void process(Exchange exchange) throws Exception {

    NewForecastInstructionData forecastInstrData =
        (NewForecastInstructionData) exchange.getIn().getBody(
            NewForecastInstructionData.class);

    log.info("Processing NewForecastInstructionData: " + forecastInstrData);

    // send to Forecaster via client api
    boolean result = false;
    result = forecastClient.createForecastInstr(forecastInstrData);

    final BigDecimal instrEventId =
        (BigDecimal) exchange.getIn().getHeader("instrEventId");
    exchange.getOut().setHeader("instrEventId", instrEventId);
    exchange.getOut().setBody(result);
  }

}
