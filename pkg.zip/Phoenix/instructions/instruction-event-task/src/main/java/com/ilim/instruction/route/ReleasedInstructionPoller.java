package com.ilim.instruction.route;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.crd.web.api.CrdCashForecast;
import com.ilim.instruction.datatype.InstructionDataMapper;
import com.ilim.instruction.infra.db.jdbc.Sql;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Poller Task which is a scheduled Camel Route to handle retrieve
 * Release Instructions via camel-jdbc (dataSource). These are 
 * transformed to the required @see CrdCashForecast and then
 * routed to @see ReleasedInstructionRoute.
 * 
 * @author Michael Cunningham
 *
 */
public class ReleasedInstructionPoller extends RouteBuilder {

  @Override
  public void configure() throws Exception {

    String timerSchedule =
        settings().getString("released.instruction.event.schedule");

    from("timer://onReleasedTimer?" + timerSchedule)
        .routeId("releasedInstructionPoller")
        .setBody(constant(Sql.select_from_instruction_event_by_released))
        .to("jdbc:dataSource").split(body())
        .process(new EventMappingProcessor())
        .to("direct:releasedInstructionRoute")
        .log("Released Instruction event processing completed: " + body());

  }

  private class EventMappingProcessor implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {

      Map<String, Object> instrEventMap = exchange.getIn().getBody(Map.class);

      // transform into expected client model object
      CrdCashForecast cf =
          InstructionDataMapper.toCrdCashForecast(instrEventMap);

      exchange.getOut().setBody(cf);

      // add the instruction_event_id for update on success/fail
      BigDecimal instrEventId =
          (BigDecimal) instrEventMap.get("INSTRUCTION_EVENT_ID");
      exchange.getOut().setHeader("instrEventId", instrEventId);
    }
  }

}
