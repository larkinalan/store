package com.ilim.instruction.route;

import static com.ilim.commons.conf.AppConfig.settings;

import com.ilim.forecast.web.api.NewForecastInstructionData;
import com.ilim.instruction.datatype.InstructionDataMapper;
import com.ilim.instruction.infra.db.jdbc.Sql;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Poller Task which is a scheduled Camel Route to handle retrieved
 * Approved Instructions via camel-jdbc (dataSource). These are 
 * transformed to the required @see NewForecastInstructionData and then
 * routed to @see ApprovedInstructionRoute.
 * 
 * @author Michael Cunningham
 *
 */
public class ApprovedInstructionPoller extends RouteBuilder {

  private String timerSchedule =
      settings().getString("approved.instruction.event.schedule");

  @Override
  public void configure() throws Exception {

    from("timer://onApprovedTimer?" + timerSchedule)
        .routeId("approvedInstructionPoller")
        .setBody(constant(Sql.select_from_instruction_event_by_approved))
        .to("jdbc:dataSource").split(body())
        .process(new EventMappingProcessor())
        .to("direct:approvedInstructionRoute")
        .log("Approved Instruction event processing completed: " + body());

  }

  private class EventMappingProcessor implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {

      Map<String, Object> instrEventMap = exchange.getIn().getBody(Map.class);

      // transform into expected client model object
      NewForecastInstructionData forecastInstr =
          InstructionDataMapper.toNewForecastInstructionData(instrEventMap);

      exchange.getOut().setBody(forecastInstr);

      // add the instruction_event_id for update on success/fail
      BigDecimal instrEventId =
          (BigDecimal) instrEventMap.get("INSTRUCTION_EVENT_ID");
      exchange.getOut().setHeader("instrEventId", instrEventId);
    }
  }

}
