package com.ilim.instruction.app.conf;

import com.ilim.instruction.route.ReleasedInstructionPoller;
import com.ilim.instruction.route.ReleasedInstructionRoute;
import com.ilim.instruction.route.UpdateOnFailRoute;
import com.ilim.instruction.route.UpdateOnSuccessRoute;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.spring.javaconfig.SingleRouteCamelConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import java.util.ArrayList;
import java.util.List;


/**
 * Spring Camel component config.
 *
 * @author Michael Cunningham
 */
@Configuration
@Import(SpringConfig.class)
public class SpringCamelConfig extends SingleRouteCamelConfiguration {

  @Override
  protected CamelContext createCamelContext() throws Exception {
    return new SpringCamelContext(getApplicationContext());
  }

  @Override
  protected void setupCamelContext(CamelContext camelContext) 
      throws Exception {}

  @Override
  public List<RouteBuilder> routes() {

    List<RouteBuilder> routes = new ArrayList<RouteBuilder>();

    routes.add(new ReleasedInstructionPoller());
    routes.add(new ReleasedInstructionRoute());
    routes.add(new UpdateOnSuccessRoute());
    routes.add(new UpdateOnFailRoute());

    return routes;
  }

  @Override
  public RouteBuilder route() {
    // TODO Auto-generated method stub
    return null;
  }

}
