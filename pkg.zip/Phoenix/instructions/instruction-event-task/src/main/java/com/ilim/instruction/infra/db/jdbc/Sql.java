package com.ilim.instruction.infra.db.jdbc;

/*
 *  Sql statements used in instruction_event_task
 *  
 *  <p>Formatted and wrapped using TOAD. 
 *  
 *  @author Michael Cunningham
 *  
 *  @formatter:off
 *  CHECKSTYLE:OFF
 */
public class Sql {

  public static final String select_from_instruction_event_by_approved = 
      "SELECT * " +
      "  FROM instruction_event " +
      " WHERE event_type_id = 1 " +
      "   AND ( UPPER( delivered_fg ) = 'N' " +
      "     OR delivered_fg IS NULL ) "; 
  
  public static final String select_from_instruction_event_by_released =        
      "SELECT * " +
      "  FROM instruction_event " +
      " WHERE event_type_id = 2 " +
      "   AND ( UPPER( delivered_fg ) = 'N' " +
      "     OR delivered_fg IS NULL ) "; 

  public static final String update_instruction_event_delivered_flag =        
      "UPDATE instruction_event " +
      "   SET delivered_fg = 'Y' " +
      " WHERE instruction_event_id = :?instrEventId"; 
}