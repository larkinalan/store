package com.ilim.instruction.route;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.camel.builder.RouteBuilder;

/**
 * Main Route to handle Release Instructions which are routed from
 * the Poller task  @see ReleasedInstructionPoller.
 * 
 * @author Michael Cunningham
 *
 */
public class ReleasedInstructionRoute extends RouteBuilder {

  @Override
  public void configure() throws Exception {

    from("direct:releasedInstructionRoute")
        .routeId("releasedInstructionRoute")
        .to("bean:releasedInstructionProcessor")
        .choice()
            .when(new Success())
              .to("direct:updateOnSuccess")
              .log("Transmitting of Released Instruction to BBCW Succeded ")
            .otherwise()
              .to("direct:updateOnFail")
              .log("Transmitting of Released Instruction to BBCW Failed ")
        .log("Released Instruction processing completed: " + body());

  }

  public class Success implements Predicate {
    @Override
    public boolean matches(Exchange exchange) {
      if (exchange.getIn() == null) {
        return false;
      }

      return exchange.getIn().getBody(Boolean.class).booleanValue();
    }
  }
}
