package com.ilim.instruction.route;

import org.apache.camel.builder.RouteBuilder;

/**
 * Camel Route to perform an update for failed
 * result of sending an instruction to BBCW soap interface.
 *   
 * <p>TODO: complete with regard to extra or further error handling.
 * 
 * @author Michael Cunningham
 *
 */
public class UpdateOnFailRoute extends RouteBuilder {

  @Override
  public void configure() throws Exception {

    from("direct:updateOnFail")
        .routeId("updateOnFail")
        .transacted()
        .log("Failed instruction event:  ${headers.instrEventId}");

  }

}
