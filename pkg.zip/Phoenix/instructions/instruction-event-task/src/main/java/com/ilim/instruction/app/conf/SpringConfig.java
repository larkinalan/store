package com.ilim.instruction.app.conf;

import com.ilim.crd.web.client.CrdMessagingClient;
import com.ilim.instruction.processor.ReleasedInstructionProcessor;
import com.ilim.instruction.route.ReleasedInstructionPoller;
import com.ilim.instruction.route.ReleasedInstructionRoute;
import com.ilim.instruction.route.UpdateOnFailRoute;
import com.ilim.instruction.route.UpdateOnSuccessRoute;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;


/**
 * Spring component config.
 *
 * @author Michael Cunningham
 */
@Configuration
@EnableTransactionManagement()
public class SpringConfig {

  @Bean
  public ReleasedInstructionProcessor releasedInstructionProcessor() {
    return new ReleasedInstructionProcessor();
  }

  @Bean
  public ReleasedInstructionPoller releasedInstructionPoller() {
    return new ReleasedInstructionPoller();
  }

  @Bean
  public ReleasedInstructionRoute releasedInstructionRoute() {
    return new ReleasedInstructionRoute();
  }

  @Bean
  public UpdateOnSuccessRoute updateOnSuccessRoute() {
    return new UpdateOnSuccessRoute();
  }

  @Bean
  public UpdateOnFailRoute updateOnFailRoute() {
    return new UpdateOnFailRoute();
  }

  @Bean
  public CrdMessagingClient crdMessagingClient() {
    return new CrdMessagingClient();
  }
}
