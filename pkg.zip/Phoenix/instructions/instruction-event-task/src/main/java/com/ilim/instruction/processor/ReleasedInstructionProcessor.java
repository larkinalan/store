package com.ilim.instruction.processor;

import com.ilim.crd.web.api.CrdCashForecast;
import com.ilim.crd.web.client.CrdMessagingClient;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;

import javax.inject.Inject;

public class ReleasedInstructionProcessor implements Processor {

  private static Logger log = LoggerFactory
      .getLogger(ReleasedInstructionProcessor.class);

  @Inject
  private CrdMessagingClient crdMessagingClient;
  
  /**
   * Process Released Events.
   * 
   * @param exchange            camel exchange containing the event data
   * @throws Exception          exception during the process
   */
  @Override
  public void process(Exchange exchange) throws Exception {

    CrdCashForecast cf =
        (CrdCashForecast) exchange.getIn().getBody(CrdCashForecast.class);

    log.info("Processing CrdCashForecast: " + cf);

    // send to BBCW via client api
    boolean result = false;
    result = crdMessagingClient.sendToBbcw(cf);

    final BigDecimal instrEventId =
        (BigDecimal) exchange.getIn().getHeader("instrEventId");
    exchange.getOut().setHeader("instrEventId", instrEventId);
    exchange.getOut().setBody(result);
  }

}
