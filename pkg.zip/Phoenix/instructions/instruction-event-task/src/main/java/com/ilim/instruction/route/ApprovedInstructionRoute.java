package com.ilim.instruction.route;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.camel.builder.RouteBuilder;

/**
 * Main Route to handle Release Instructions which are routed from
 * the Poller task  @see ReleasedInstructionPoller.
 * 
 * @author Michael Cunningham
 *
 */
public class ApprovedInstructionRoute extends RouteBuilder {

  @Override
  public void configure() throws Exception {

    from("direct:approvedInstructionRoute")
        .routeId("approvedInstructionRoute")
        .to("bean:approvedInstructionProcessor")
        .choice()
            .when(new Success())
              .to("direct:updateOnSuccess")
              .log("Transmitting of Approved Instruction to Forecaster Success")
            .otherwise()
              .to("direct:updateOnFail")
              .log("Transmitting of Approved Instruction to Forecaster Failed ")
        .log("Approved Instruction processing completed: " + body());

  }

  public class Success implements Predicate {
    @Override
    public boolean matches(Exchange exchange) {
      if (exchange.getIn() == null) {
        return false;
      }

      return exchange.getIn().getBody(Boolean.class).booleanValue();
    }
  }
}
