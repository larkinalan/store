package com.ilim.instruction.datatype;

import com.ilim.crd.web.api.CrdCashForecast;
import com.ilim.forecast.web.api.NewForecastInstructionData;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * Data Mapper class to help transform the Instruction Data to various model 
 * objects required for processing within routes.
 * 
 * @author Michael Cunningham
 *
 */
public final class InstructionDataMapper {

  private static Logger log = LoggerFactory
      .getLogger(InstructionDataMapper.class);

  private static final ObjectMapper jsonMapper = new ObjectMapper();

  public static final DateTimeFormatter DATE_TIME_FMT_BBCW = DateTimeFormatter
      .ofPattern("yyyy-MM-dd HH:mm:ss");

  private InstructionDataMapper() {}

  /**
   * Returns CrdCashForecast.
   * 
   * @param instrEventMap       map containing the instruction data
   * @return CrdCashForecast
   * @throws Exception          if parsing exception occurs
   */
  public static CrdCashForecast toCrdCashForecast(
      final Map<String, Object> instrEventMap) throws Exception {

    Map<String, Object> map = retrieveInstrData(instrEventMap);

    final String acctCd = (String) map.get("fundCode");
    final String amtType = "FTC";
    final String crrncyCd = (String) map.get("fundCurrency");
    final String forecastDate = LocalDateTime.now().format(DATE_TIME_FMT_BBCW);
    final String descr = "Forecast Instruction to BBCW";

    Double tmp = (Double) map.get("amount");
    final BigDecimal amt = BigDecimal.valueOf(tmp);

    return new CrdCashForecast(acctCd, amtType, crrncyCd, amt, forecastDate,
        descr);
  }

  /**
   * Returns NewForecastInstructionData.
   * 
   * @param instrEventMap       map containing the instruction data
   * @return NewForecastInstructionData
   * @throws Exception          if parsing exception occurs
   */
  public static NewForecastInstructionData toNewForecastInstructionData(
      final Map<String, Object> instrEventMap) throws Exception {

    Map<String, Object> map = retrieveInstrData(instrEventMap);

    final String forecastDate = (String) map.get("forecastDate");

    final int fundId = (Integer) map.get("fundId");
    final int eventSourceId = (Integer) map.get("instrId");

    // TODO: correctly align moneyType to moneyNotificationType (from FUSION)
    String moneyType = (String) map.get("moneyNotificationType");
    if (moneyType != null && moneyType.equalsIgnoreCase("UNIT")) {
      moneyType = "UNITS";
    }

    // TODO: correctly align forecastType to instructionType (from FUSION)
    String forecastType = (String) map.get("instructionType");
    if (forecastType != null
        && forecastType.equalsIgnoreCase("MONEY_NOTIFICATION")) {
      forecastType = "NEW_MONEY";
    }

    Double tmp = (Double) map.get("amount");
    final BigDecimal amount = BigDecimal.valueOf(tmp);

    return new NewForecastInstructionData(forecastDate, forecastType, fundId,
        moneyType, amount, eventSourceId);
  }

  private static Map<String, Object> retrieveInstrData(
      final Map<String, Object> instrEventMap) throws Exception {

    final String eventData = (String) instrEventMap.get("INSTRUCTION_DATA");

    Map<String, Object> map = new HashMap<String, Object>();
    try {
      map = jsonMapper.readValue(eventData, HashMap.class);
    } catch (Exception e) {
      log.error("Error while parsing instruction data: " + e.getMessage());
      throw e;
    }
    return map;
  }

}
