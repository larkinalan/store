package com.ilim.instruction.datatype;

import com.ilim.commons.time.DateUtils;
import com.ilim.crd.web.api.CrdCashForecast;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public final class InstructionDataMapper {

  private static Logger log = LoggerFactory
      .getLogger(InstructionDataMapper.class);

  private static final ObjectMapper jsonMapper = new ObjectMapper();

  private InstructionDataMapper() {}

  /**
   * Returns CrdCashForecast.
   * 
   * @param instrEventMap       map containing the instruction data
   * @return CrdCashForecast
   * @throws Exception          if parsing exception occurs
   */
  public static CrdCashForecast toCrdCashForecast(
      final Map<String, Object> instrEventMap) throws Exception {

    final String eventData = (String) instrEventMap.get("INSTRUCTION_DATA");

    Map<String, String> map = new HashMap<String, String>();
    try {
      map = jsonMapper.readValue(eventData, HashMap.class);
    } catch (Exception e) {
      log.error("Error while parsing instruction data to CrdCashForecast: "
          + e.getMessage());
      throw e;
    }

    final String acctCd = map.get("fundCode");
    final String amtType = "FTC";
    final String crrncyCd = "EUR";
    Object tmp = map.get("amount");
    final BigDecimal amt = new BigDecimal(Double.valueOf((double) tmp));
    final String forecastDate = LocalDateTime.now().format(DateUtils.DATE_FMT);
    final String descr = "Forecast Instruction to BBCW";

    return new CrdCashForecast(acctCd, amtType, crrncyCd, amt, forecastDate,
        descr);
  }

}
