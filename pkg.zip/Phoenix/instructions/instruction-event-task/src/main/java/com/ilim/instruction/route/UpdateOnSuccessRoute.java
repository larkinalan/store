package com.ilim.instruction.route;

import com.ilim.instruction.infra.db.jdbc.Sql;

import org.apache.camel.builder.RouteBuilder;

/**
 * Camel Route to perform an update for successful
 * result of sending an instruction to BBCW soap interface.
 *   
 * @author Michael Cunningham
 *
 */
public class UpdateOnSuccessRoute extends RouteBuilder {

  @Override
  public void configure() throws Exception {

    from("direct:updateOnSuccess")
        .routeId("updateOnSuccess")
        .transacted()
        .setBody(constant(Sql.update_instruction_event_delivered_flag))
        .to("jdbc:dataSource?useHeadersAsParameters=true")
        .setBody(constant("Updating instruction : ${headers.instrEventId}"))
        .log("Update on instruction :  ${headers.instrEventId}");

  }

}
