Phoenix
==========
*Phoenix project, everything you need for modern java development in ILIM*

There are 2 types of sub project.
 **service** for building restful web service using Jersey
 **broker** for integrating systems, messaging using Apache Camel.

Read more at [confluence](http://ilm12807:7090/).

Need help or found an issue?
---
Reporting issue through [Jira](http://jirasrv:8080)

Docs?
---
* [Architecture](L:\ITUNIT\PROJECTS\Strategy\FMA_Phoenix\System Architecture\phoenix-architecture.docx)
* [High level User Stories](L:\ITUNIT\PROJECTS\Strategy\Unit Txn Execution\UTE v2\phoenix-user-stories.docx)
* [Detailed Requirments](\\ILIFE104\TEAMDISK\ITUNIT\PROJECTS\Strategy\Unit Txn Execution\UTE v2\UTE Secondary level Modelling Functional Requirements-V.1.docx)


architecture layers
===================

com.ilim.example.app.*   =>  app services, tasks, factories, external client interfaces
                     manages the Application rules that belong to the use cases.
                     wrapps all calls in a transaction/

com.ilim.example.domain.* =>  entites, value objects, domain services, repository interfaces 
                      manages the Business rules thats belong to entites. 

com.ilim.example.db.* =>  impls for domain repository Interfaces. e.g. Jdbc or JPA
                  Data Mapping recordsets to entities

com.ilim.example.web.* = > restful resources 
                   Data Mapping json schema to entities

