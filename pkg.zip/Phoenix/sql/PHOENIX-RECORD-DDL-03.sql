-- PHOENIX-RECORD-DDL-03.SQL
-- Run as: FM(UAT)DBA
-- Desc: Add t_scd_portgrp_invest_lvl_cash table
-- Author: y491
-- Date: 21/01/2016
--
--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

SPOOL PHOENIX-RECORD-DDL-03.OUT;
--Begin Script

ALTER TABLE fmuatdba.t_scd_portgrp_invest_lvl_cash
   DROP PRIMARY KEY CASCADE;

DROP TABLE fmuatdba.t_scd_portgrp_invest_lvl_cash CASCADE CONSTRAINTS;

CREATE TABLE fmuatdba.t_scd_portgrp_invest_lvl_cash( portfolio_group	VARCHAR2( 50 ) NOT NULL
                                                , portfolio_owner_id	VARCHAR2( 50 ) NOT NULL
                                                , currency_id			VARCHAR2(  3 ))
TABLESPACE fmsmalldat
PCTUSED 0
PCTFREE 10
INITRANS 1
MAXTRANS 255
STORAGE( INITIAL 80 K
         NEXT 80 K
         MINEXTENTS 1
         MAXEXTENTS UNLIMITED
         PCTINCREASE 0
         BUFFER_POOL DEFAULT )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX fmuatdba.scd_pgrp_il_cash_pk
   ON fmuatdba.t_scd_portgrp_invest_lvl_cash( portfolio_group )
   LOGGING
   TABLESPACE fmsmalldat
   PCTFREE 10
   INITRANS 2
   MAXTRANS 255
   STORAGE( INITIAL 80 K
            NEXT 80 K
            MINEXTENTS 1
            MAXEXTENTS UNLIMITED
            PCTINCREASE 0
            BUFFER_POOL DEFAULT )
   NOPARALLEL;


ALTER TABLE fmuatdba.t_scd_portgrp_invest_lvl_cash ADD (
  CONSTRAINT scd_pgrp_il_cash_pk
  PRIMARY KEY
  (portfolio_group)
  USING INDEX fmuatdba.scd_pgrp_il_cash_pk);
  

CREATE INDEX fmuatdba.scd_pgrp_il_cash_fk_i ON fmuatdba.t_scd_portgrp_invest_lvl_cash
(currency_id)
LOGGING
TABLESPACE FMSMALLNDX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          32K
            NEXT             32K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


DROP SYNONYM fmuatdba.scd_portgrp_invest_lvl_cash;

CREATE OR REPLACE SYNONYM fmuatdba.scd_portgrp_invest_lvl_cash FOR fmuatdba.t_scd_portgrp_invest_lvl_cash;

DROP SYNONYM fmuatldr.scd_portgrp_invest_lvl_cash;

CREATE OR REPLACE SYNONYM fmuatldr.scd_portgrp_invest_lvl_cash FOR fmuatdba.t_scd_portgrp_invest_lvl_cash;

DROP SYNONYM readonly.scd_portgrp_invest_lvl_cash;

CREATE OR REPLACE SYNONYM readonly.scd_portgrp_invest_lvl_cash FOR fmuatdba.t_scd_portgrp_invest_lvl_cash;


ALTER TABLE t_scd_portgrp_invest_lvl_cash ADD CONSTRAINT
 scd_pgrp_il_cash_fk FOREIGN KEY 
  (currency_id) REFERENCES t_currency
  (currency_id)
  ENABLE VALIDATE;


GRANT SELECT ON fmuatdba.t_scd_portgrp_invest_lvl_cash TO batchplsql;

GRANT SELECT ON fmuatdba.t_scd_portgrp_invest_lvl_cash TO enduser;

GRANT SELECT ON fmuatdba.t_scd_portgrp_invest_lvl_cash TO fmuatldr WITH GRANT OPTION;
GRANT DELETE
    , INSERT
    , UPDATE
   ON fmuatdba.t_scd_portgrp_invest_lvl_cash
   TO fmuatldr;

GRANT DELETE
    , INSERT
    , SELECT
    , UPDATE
   ON fmuatdba.t_scd_portgrp_invest_lvl_cash
   TO ormtools;
/

--End Script
SPOOL OFF