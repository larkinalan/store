--PHOENIX-RECORD-DML-03.sql
-- Runas: FM(UAT)DBA
-- Desc: Create SCD Portfolio Group Investing Level Cash entries
-- Author: y491

--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

SPOOL PHOENIX-RECORD-DML-03.OUT
--Begin Script

INSERT INTO t_scd_portgrp_invest_lvl_cash( portfolio_group
                                    , portfolio_owner_id
                                    , currency_id)
VALUES ( '10'
       , 'A-ITRESX00'
       , 'EUR');

INSERT INTO t_scd_portgrp_invest_lvl_cash( portfolio_group
                                    , portfolio_owner_id
                                    , currency_id)
VALUES ( '11'
       , 'A-CTRESX00'
       , 'GBP');
	   
INSERT INTO t_scd_portgrp_invest_lvl_cash( portfolio_group
                                    , portfolio_owner_id
                                    , currency_id)
VALUES ( '40'
       , 'A-CLETRES'
       , 'EUR');
	   
INSERT INTO t_scd_portgrp_invest_lvl_cash( portfolio_group
                                    , portfolio_owner_id
                                    , currency_id)
VALUES ( '44'
       , 'A-ARKTRES'
       , 'EUR');
	   
--End Script
SPOOL OFF