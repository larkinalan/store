-- PHOENIX-RECORD-DDL-02.SQL
-- Run as: FM(UAT)DBA
-- Desc: Add t_scd_lob_id_cl_cash_tresilim table
-- Author: y491
-- Date: 21/01/2016
--
--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

SPOOL PHOENIX-RECORD-DDL-02.OUT;
--Begin Script

ALTER TABLE fmuatdba.t_scd_lob_id_cl_cash_tresilim
   DROP PRIMARY KEY CASCADE;

DROP TABLE fmuatdba.t_scd_lob_id_cl_cash_tresilim CASCADE CONSTRAINTS;

CREATE TABLE fmuatdba.t_scd_lob_id_cl_cash_tresilim( scd_lob_id           VARCHAR2( 50 ) NOT NULL
                                                , tresilim   VARCHAR2( 50 ) NOT NULL
                                                , app_alm_no           VARCHAR2( 22 )
                                                , mc_alm_no            VARCHAR2( 22 )
                                                , app_bank_account     VARCHAR2( 50 )
                                                , mc_bank_account      VARCHAR2( 50 ) )
TABLESPACE fmsmalldat
PCTUSED 0
PCTFREE 10
INITRANS 1
MAXTRANS 255
STORAGE( INITIAL 80 K
         NEXT 80 K
         MINEXTENTS 1
         MAXEXTENTS UNLIMITED
         PCTINCREASE 0
         BUFFER_POOL DEFAULT )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX fmuatdba.scd_lob_cl_csh_ti_pk
   ON fmuatdba.t_scd_lob_id_cl_cash_tresilim( scd_lob_id )
   LOGGING
   TABLESPACE fmsmalldat
   PCTFREE 10
   INITRANS 2
   MAXTRANS 255
   STORAGE( INITIAL 80 K
            NEXT 80 K
            MINEXTENTS 1
            MAXEXTENTS UNLIMITED
            PCTINCREASE 0
            BUFFER_POOL DEFAULT )
   NOPARALLEL;


ALTER TABLE fmuatdba.t_scd_lob_id_cl_cash_tresilim ADD (
  CONSTRAINT scd_lob_cl_csh_ti_pk
  PRIMARY KEY
  (scd_lob_id)
  USING INDEX fmuatdba.scd_lob_cl_csh_ti_pk);


DROP SYNONYM fmuatdba.scd_lob_id_cl_cash_tresilim;

CREATE OR REPLACE SYNONYM fmuatdba.scd_lob_id_cl_cash_tresilim FOR fmuatdba.t_scd_lob_id_cl_cash_tresilim;

DROP SYNONYM fmuatldr.scd_lob_id_cl_cash_tresilim;

CREATE OR REPLACE SYNONYM fmuatldr.scd_lob_id_cl_cash_tresilim FOR fmuatdba.t_scd_lob_id_cl_cash_tresilim;

DROP SYNONYM readonly.scd_lob_id_cl_cash_tresilim;

CREATE OR REPLACE SYNONYM readonly.scd_lob_id_cl_cash_tresilim FOR fmuatdba.t_scd_lob_id_cl_cash_tresilim;


GRANT SELECT ON fmuatdba.t_scd_lob_id_cl_cash_tresilim TO batchplsql;

GRANT SELECT ON fmuatdba.t_scd_lob_id_cl_cash_tresilim TO enduser;

GRANT SELECT ON fmuatdba.t_scd_lob_id_cl_cash_tresilim TO fmuatldr WITH GRANT OPTION;
GRANT DELETE
    , INSERT
    , UPDATE
   ON fmuatdba.t_scd_lob_id_cl_cash_tresilim
   TO fmuatldr;

GRANT DELETE
    , INSERT
    , SELECT
    , UPDATE
   ON fmuatdba.t_scd_lob_id_cl_cash_tresilim
   TO ormtools;
/

--End Script
SPOOL OFF