-- PHOENIX-FORECAST-DML-03.sql
-- Runas: FM(UAT)DBA
-- Desc: Create Instruction Event Type entries
-- Author: y246

--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

spool PHOENIX-FORECAST-DML-03.OUT
--Begin Script

INSERT INTO t_event_type( event_type_id
                        , event_type_nm )
VALUES ( 0
       , 'UNKNOWN' )
/

INSERT INTO t_event_type( event_type_id
                        , event_type_nm )
VALUES ( 1
       , 'FUSION_APPROVED' )
/

INSERT INTO t_event_type( event_type_id
                        , event_type_nm )
VALUES ( 2
       , 'FUSION_RELEASE' )
/

--End Script
spool off
