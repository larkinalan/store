--PHOENIX-RECORD-DML-02.sql
-- Runas: FM(UAT)DBA
-- Desc: Create SCD LOB Client Level Cash Treasury ILIM entries
-- Author: y491

--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

SPOOL PHOENIX-RECORD-DML-02.OUT
--Begin Script

INSERT INTO scd_lob_id_cl_cash_tresilim( scd_lob_id
                                    , tresilim
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '9'
       , 'A-ILIMXX00'
       , '9ALM1002'
       , '9ALM1088'
       , 'ILIMXX00-EUR-01'
       , 'ILIMXX00-EUR-01' );

INSERT INTO scd_lob_id_cl_cash_tresilim( scd_lob_id
                                    , tresilim
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '12'
       , 'A-ILIMXX00'
       , '9ALM1003'
       , '9ALM1089'
       , 'ILIMXX00-GBP-04'
       , 'ILIMXX00-GBP-04' );

INSERT INTO scd_lob_id_cl_cash_tresilim( scd_lob_id
                                    , tresilim
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '48'
       , 'A-ILIMXX00'
       , '9ALM1002'
       , '9ALM1089'
       , 'ILIMXX00-GBP-01'
       , 'ILIMXX00-GBP-01' );

--End Script
SPOOL OFF	   