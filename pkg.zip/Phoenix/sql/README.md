Phoenix Project
===============
*SQL scripts required by the Phoenix Project in ILIM*

Docs
---
Read more on the Phoenix Project at [confluence](http://ilm12807:7090/)

Entity Relation Diagram can be found under the following URL:

........TODO

SCM
---
The SQL scripts are contained within SVN Repository under the following URL:

http://svnsrv.europa.internal:8051/svn/ilimrepos/Phoenix/branches/DEV_LATEST/sql


SQL Scripts under SCM:

PHOENIX-FORECAST-DDL-01.sql   =>  creates T_FORECAST_STATUS

PHOENIX-FORECAST-DDL-02.sql   =>  creates T_FORECAST_TYPE

PHOENIX-FORECAST-DDL-03.sql   =>  creates T_FORECAST_INSTRUCTION

PHOENIX-FORECAST-DDL-04.sql   =>  creates FORECAST_INSTR_SEQ

PHOENIX-FORECAST-DDL-05.sql   =>  creates T_FORECAST_MODEL_ALLOC

PHOENIX-FORECAST-DDL-06.sql   =>  creates FORECAST_MODEL_ALLOC_SEQ

PHOENIX-FORECAST-DDL-07.sql   =>  creates T_EVENT_TYPE

PHOENIX-FORECAST-DDL-08.sql   =>  creates T_INSTRUCTION_EVENT

PHOENIX-FORECAST-DDL-09.sql   =>  creates INSTR_EVENT_SEQ

PHOENIX-FORECAST-DML-01.sql   =>  inserts forecast status types into T_FORECAST_STATUS

PHOENIX-FORECAST-DML-02.sql   =>  inserts forecast types into T_FORECAST_TYPE

PHOENIX-FORECAST-DML-03.sql   =>  inserts event types into T_EVENT_TYPE

