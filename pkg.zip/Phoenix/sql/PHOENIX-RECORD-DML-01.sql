--PHOENIX-RECORD-DML-01.sql
-- Runas: FM(UAT)DBA
-- Desc: Create SCD LOB Client Level Cash Financial Separation entries
-- Author: y491

--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

SPOOL PHOENIX-RECORD-DML-01.OUT
--Begin Script

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '1'
       , 'A-ITRESX00'
       , '9ALM1177'
       , '9ALM1200'
       , 'ITRESX00-EUR-08'
       , 'ITRESX00-EUR-08' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '2'
       , 'A-ITRESX00'
       , '9ALM1178'
       , '9ALM1201'
       , 'ITRESX00-EUR-08'
       , 'ITRESX00-EUR-08' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '3'
       , 'A-ITRESX00'
       , '9ALM1179'
       , '9ALM1202'
       , 'ITRESX00-EUR-09'
       , 'ITRESX00-EUR-09' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '4'
       , 'A-ITRESX00'
       , '9ALM1180'
       , '9ALM1203'
       , 'ITRESX00-EUR-09'
       , 'ITRESX00-EUR-09' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '5'
       , 'A-ITRESX00'
       , '9ALM1181'
       , '9ALM1204'
       , 'ITRESX00-EUR-09'
       , 'ITRESX00-EUR-09' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '6'
       , 'A-ITRESX00'
       , '9ALM1182'
       , '9ALM1205'
       , 'ITRESX00-EUR-09'
       , 'ITRESX00-EUR-09' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '7'
       , 'A-ITRESX00'
       , '9ALM1183'
       , '9ALM1206'
       , 'ITRESX00-EUR-09'
       , 'ITRESX00-EUR-09' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '8'
       , 'A-ITRESX00'
       , '9ALM1184'
       , '9ALM1207'
       , 'ITRESX00-EUR-03'
       , 'ITRESX00-EUR-03' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '9'
       , 'A-ITRESX00'
       , '9ALM1185'
       , '9ALM1208'
       , 'ITRESX00-EUR-07'
       , 'ITRESX00-EUR-07' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '11'
       , 'A-CTRESX00'
       , '9ALM1193'
       , '9ALM1210'
       , 'ITRESX00-GBP-04'
       , 'ITRESX00-GBP-04' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '12'
       , 'A-CTRESX00'
       , '9ALM1194'
       , '9ALM1211'
       , 'ITRESX00-GBP-02'
       , 'ITRESX00-GBP-02' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '13'
       , 'A-CTRESX00'
       , '9ALM1195'
       , '9ALM1212'
       , 'ITRESX00-GBP-03'
       , 'ITRESX00-GBP-03' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '14'
       , 'A-CTRESX00'
       , '9ALM1196'
       , '9ALM1213'
       , 'ITRESX00-GBP-03'
       , 'ITRESX00-GBP-03' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '15'
       , 'A-ITRESX00'
       , '9ALM1186'
       , '9ALM1209'
       , 'ITRESX00-EUR-08'
       , 'ITRESX00-EUR-08' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '32'
       , 'A-ITRESX00'
       , '9ALM1367'
       , '9ALM1372'
       , 'ITRESX00-EUR-08'
       , 'ITRESX00-EUR-08' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '33'
       , 'A-ITRESX00'
       , '9ALM1368'
       , '9ALM1373'
       , 'ITRESX00-EUR-08'
       , 'ITRESX00-EUR-08' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '34'
       , 'A-ITRESX00'
       , '9ALM1369'
       , '9ALM1374'
       , 'ITRESX00-EUR-09'
       , 'ITRESX00-EUR-09' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '35'
       , 'A-ITRESX00'
       , '9ALM1370'
       , '9ALM1375'
       , 'ITRESX00-EUR-09'
       , 'ITRESX00-EUR-09' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '36'
       , 'A-ITRESX00'
       , '9ALM1371'
       , '9ALM1376'
       , 'ITRESX00-EUR-09'
       , 'ITRESX00-EUR-09' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '39'
       , 'A-ARKTRES'
       , NULL
       , NULL
       , NULL
       , NULL );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '46'
       , 'A-ITRESX00'
       , '9ALM1468'
       , NULL
       , 'ITRESX00-EUR-09'
       , 'ITRESX00-EUR-09' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '47'
       , 'A-ITRESX00'
       , '9ALM1495'
       , '9ALM1497'
       , 'ITRESX00-GBP-06'
       , 'ITRESX00-GBP-06' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '48'
       , 'A-ITRESX00'
       , '9ALM1496'
       , '9ALM1498'
       , 'ITRESX00-GBP-03'
       , 'ITRESX00-GBP-03' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '56'
       , 'A-ITRESX00'
       , '9ALM1602'
       , '9ALM1608'
       , 'ITRESX00-EUR-03'
       , 'ITRESX00-EUR-03' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '57'
       , 'A-ITRESX00'
       , '9ALM1650'
       , '9ALM1649'
       , 'ITRESX00-EUR-40'
       , 'ITRESX00-EUR-40' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '58'
       , 'A-CLETRES'
       , '9ALM1660'
       , '9ALM1659'
       , 'CLETRES-EUR-05'
       , 'CLETRES-EUR-02' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '68'
       , 'A-ARKTRES'
       , '9ALM1753'
       , '9ALM1748'
       , 'ARKTRES-EUR-02'
       , 'ARKTRES-EUR-02' );

INSERT INTO scd_lob_id_cl_cash_finsep( scd_lob_id
                                    , portfolio_owner_id
                                    , app_alm_no
                                    , mc_alm_no
                                    , app_bank_account
                                    , mc_bank_account )
VALUES ( '69'
       , 'A-ARKTRES'
       , '9ALM1752'
       , '9ALM1755'
       , 'ARKTRES-EUR-02'
       , 'ARKTRES-EUR-02' );


--End Script
SPOOL OFF