--PHOENIX-RECORD-DML-04.sql
-- Runas: FM(UAT)DBA
-- Desc: Create t_scd_asset_port_treasury entries
-- Author: y491

--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

SPOOL PHOENIX-RECORD-DML-04.OUT
--Begin Script

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'NULL'
       , 'EUR'
       , '9ALMMCX1'
       , '9ALMAPX1' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'NULL'
       , 'GBP'
       , '9ALMMCX2'
       , '9ALMAPX2' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALEUPR'
       , 'EUR'
       , 'APALEUPR'
       , 'MCALEUPR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALUKPR'
       , 'EUR'
       , 'APALUKPR'
       , 'MCALUKPR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALHYEQG'
       , 'EUR'
       , 'APALHYEQG'
       , 'MCALHYEQG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALEZEQG'
       , 'EUR'
       , 'APALEZEQG'
       , 'MCALEZEQG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALEMEQG'
       , 'EUR'
       , 'APALEMEQG'
       , 'MCALEMEQG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALDSCG'
       , 'EUR'
       , 'APALDSCG'
       , 'MCALDSCG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALGLOEQG'
       , 'EUR'
       , 'APALGLOEQG'
       , 'MCALGLOEQG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALPROPG'
       , 'EUR'
       , 'APALPROPG'
       , 'MCALPROPG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALGOVG'
       , 'EUR'
       , 'APALGOVG'
       , 'MCALGOVG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALIREQG'
       , 'EUR'
       , 'APALIREQG'
       , 'MCALIREQG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALDSCN'
       , 'EUR'
       , 'APALDSCN'
       , 'MCALDSCN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALCASHG'
       , 'EUR'
       , 'APALCASHG'
       , 'MCALCASHG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALGLOEQN'
       , 'EUR'
       , 'APALGLOEQN'
       , 'MCALGLOEQN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALCASHN'
       , 'EUR'
       , 'APALCASHN'
       , 'MCALCASHN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALEMEQN'
       , 'EUR'
       , 'APALEMEQN'
       , 'MCALEMEQN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALPROPN'
       , 'EUR'
       , 'APALPROPN'
       , 'MCALPROPN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALCORPG'
       , 'EUR'
       , 'APALCORPG'
       , 'MCALCORPG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALIREQN'
       , 'EUR'
       , 'APALIREQN'
       , 'MCALIREQN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALCORPN'
       , 'EUR'
       , 'APALCORPN'
       , 'MCALCORPN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALGOVN'
       , 'EUR'
       , 'APALGOVN'
       , 'MCALGOVN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ALEZEQN'
       , 'EUR'
       , 'APALEZEQN'
       , 'MCALEZEQN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U200'
       , 'EUR'
       , 'APU200'
       , 'MCU200' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U201'
       , 'EUR'
       , 'APU201'
       , 'MCU201' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U202'
       , 'EUR'
       , 'APU202'
       , 'MCU202' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U203'
       , 'EUR'
       , 'APU203'
       , 'MCU203' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U204'
       , 'EUR'
       , 'APU204'
       , 'MCU204' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U205'
       , 'EUR'
       , 'APU205'
       , 'MCU205' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U206'
       , 'EUR'
       , 'APU206'
       , 'MCU206' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U209'
       , 'EUR'
       , 'APU209'
       , 'MCU209' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U210'
       , 'EUR'
       , 'APU210'
       , 'MCU210' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U211'
       , 'EUR'
       , 'APU211'
       , 'MCU211' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U212'
       , 'EUR'
       , 'APU212'
       , 'MCU212' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U213'
       , 'EUR'
       , 'APU213'
       , 'MCU213' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U214'
       , 'EUR'
       , 'APU214'
       , 'MCU214' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U216'
       , 'EUR'
       , 'APU216'
       , 'MCU216' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U218'
       , 'EUR'
       , 'APU218'
       , 'MCU218' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U220'
       , 'EUR'
       , 'APU220'
       , 'MCU220' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U221'
       , 'EUR'
       , 'APU221'
       , 'MCU221' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U237'
       , 'EUR'
       , 'APU237'
       , 'MCU237' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U238'
       , 'EUR'
       , 'APU238'
       , 'MCU238' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U240'
       , 'EUR'
       , 'APU240'
       , 'MCU240' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U252'
       , 'EUR'
       , 'APU252'
       , 'MCU252' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-U253'
       , 'EUR'
       , 'APU253'
       , 'MCU253' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM3000'
       , 'EUR'
       , 'APADM3000'
       , 'MCADM3000' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM3001'
       , 'EUR'
       , 'APADM3001'
       , 'MCADM3001' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM3002'
       , 'EUR'
       , 'APADM3002'
       , 'MCADM3002' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM3003'
       , 'EUR'
       , 'APADM3003'
       , 'MCADM3003' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM3004'
       , 'EUR'
       , 'APADM3004'
       , 'MCADM3004' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM3005'
       , 'EUR'
       , 'APADM3005'
       , 'MCADM3005' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM3100'
       , 'EUR'
       , 'APADM3100'
       , 'MCADM3100' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM3101'
       , 'EUR'
       , 'APADM3101'
       , 'MCADM3101' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5101'
       , 'EUR'
       , 'APADM5101'
       , 'MCADM5101' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5102'
       , 'EUR'
       , 'APADM5102'
       , 'MCADM5102' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5103'
       , 'EUR'
       , 'APADM5103'
       , 'MCADM5103' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5104'
       , 'EUR'
       , 'APADM5104'
       , 'MCADM5104' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5105'
       , 'EUR'
       , 'APADM5105'
       , 'MCADM5105' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5106'
       , 'EUR'
       , 'APADM5106'
       , 'MCADM5106' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5107'
       , 'EUR'
       , 'APADM5107'
       , 'MCADM5107' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5110'
       , 'EUR'
       , 'APADM5110'
       , 'MCADM5110' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5111'
       , 'EUR'
       , 'APADM5111'
       , 'MCADM5111' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5112'
       , 'EUR'
       , 'APADM5112'
       , 'MCADM5112' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5113'
       , 'EUR'
       , 'APADM5113'
       , 'MCADM5113' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5114'
       , 'EUR'
       , 'APADM5114'
       , 'MCADM5114' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5115'
       , 'EUR'
       , 'APADM5115'
       , 'MCADM5115' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5116'
       , 'EUR'
       , 'APADM5116'
       , 'MCADM5116' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5118'
       , 'EUR'
       , 'APADM5118'
       , 'MCADM5118' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5119'
       , 'EUR'
       , 'APADM5119'
       , 'MCADM5119' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5122'
       , 'EUR'
       , 'APADM5122'
       , 'MCADM5122' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5123'
       , 'EUR'
       , 'APADM5123'
       , 'MCADM5123' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5124'
       , 'EUR'
       , 'APADM5124'
       , 'MCADM5124' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5125'
       , 'EUR'
       , 'APADM5125'
       , 'MCADM5125' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5126'
       , 'EUR'
       , 'APADM5126'
       , 'MCADM5126' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5127'
       , 'EUR'
       , 'APADM5127'
       , 'MCADM5127' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5128'
       , 'EUR'
       , 'APADM5128'
       , 'MCADM5128' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5129'
       , 'EUR'
       , 'APADM5129'
       , 'MCADM5129' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5131'
       , 'EUR'
       , 'APADM5131'
       , 'MCADM5131' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM5132'
       , 'EUR'
       , 'APADM5132'
       , 'MCADM5132' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM7000'
       , 'EUR'
       , 'APADM7000'
       , 'MCADM7000' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM7001'
       , 'EUR'
       , 'APADM7001'
       , 'MCADM7001' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM7500'
       , 'EUR'
       , 'APADM7500'
       , 'MCADM7500' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM9000'
       , 'EUR'
       , 'APADM9000'
       , 'MCADM9000' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5004'
       , 'EUR'
       , 'APIEC5004'
       , 'MCIEC5004' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5005'
       , 'EUR'
       , 'APIEC5005'
       , 'MCIEC5005' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5006'
       , 'EUR'
       , 'APIEC5006'
       , 'MCIEC5006' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5007'
       , 'EUR'
       , 'APIEC5007'
       , 'MCIEC5007' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5008'
       , 'EUR'
       , 'APIEC5008'
       , 'MCIEC5008' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5009'
       , 'EUR'
       , 'APIEC5009'
       , 'MCIEC5009' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5010'
       , 'EUR'
       , 'APIEC5010'
       , 'MCIEC5010' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5015'
       , 'EUR'
       , 'APIEC5015'
       , 'MCIEC5015' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5016'
       , 'EUR'
       , 'APIEC5016'
       , 'MCIEC5016' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5017'
       , 'EUR'
       , 'APIEC5017'
       , 'MCIEC5017' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5018'
       , 'EUR'
       , 'APIEC5018'
       , 'MCIEC5018' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5019'
       , 'EUR'
       , 'APIEC5019'
       , 'MCIEC5019' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5020'
       , 'EUR'
       , 'APIEC5020'
       , 'MCIEC5020' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5021'
       , 'EUR'
       , 'APIEC5021'
       , 'MCIEC5021' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5022'
       , 'EUR'
       , 'APIEC5022'
       , 'MCIEC5022' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5023'
       , 'EUR'
       , 'APIEC5023'
       , 'MCIEC5023' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5025'
       , 'EUR'
       , 'APIEC5025'
       , 'MCIEC5025' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5026'
       , 'EUR'
       , 'APIEC5026'
       , 'MCIEC5026' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5027'
       , 'EUR'
       , 'APIEC5027'
       , 'MCIEC5027' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5028'
       , 'EUR'
       , 'APIEC5028'
       , 'MCIEC5028' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC6200'
       , 'EUR'
       , 'APIEC6200'
       , 'MCIEC6200' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC6506'
       , 'EUR'
       , 'APIEC6506'
       , 'MCIEC6506' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC6509'
       , 'EUR'
       , 'APIEC6509'
       , 'MCIEC6509' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC6512'
       , 'EUR'
       , 'APIEC6512'
       , 'MCIEC6512' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC6514'
       , 'EUR'
       , 'APIEC6514'
       , 'MCIEC6514' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC6515'
       , 'EUR'
       , 'APIEC6515'
       , 'MCIEC6515' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC6516'
       , 'EUR'
       , 'APIEC6516'
       , 'MCIEC6516' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC6517'
       , 'EUR'
       , 'APIEC6517'
       , 'MCIEC6517' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC6518'
       , 'EUR'
       , 'APIEC6518'
       , 'MCIEC6518' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC6519'
       , 'EUR'
       , 'APIEC6519'
       , 'MCIEC6519' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC6520'
       , 'EUR'
       , 'APIEC6520'
       , 'MCIEC6520' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SUK5050'
       , 'EUR'
       , 'APSUK5050'
       , 'MCSUK5050' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5001'
       , 'EUR'
       , 'APIEC5001'
       , 'MCIEC5001' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5024'
       , 'EUR'
       , 'APIEC5024'
       , 'MCIEC5024' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5029'
       , 'EUR'
       , 'APIEC5029'
       , 'MCIEC5029' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC5030'
       , 'EUR'
       , 'APIEC5030'
       , 'MCIEC5030' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ECBSEG'
       , 'EUR'
       , 'APECBSEG'
       , 'MCECBSEG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ECBCASH'
       , 'EUR'
       , 'APECBCASH'
       , 'MCECBCASH' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ECBWXE'
       , 'EUR'
       , 'APECBWXE'
       , 'MCECBWXE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ECBBOND'
       , 'EUR'
       , 'APECBBOND'
       , 'MCECBBOND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ECBCORP'
       , 'EUR'
       , 'APECBCORP'
       , 'MCECBCORP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ECBINFLA'
       , 'EUR'
       , 'APECBINFLA'
       , 'MCECBINFLA' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ECBEME'
       , 'EUR'
       , 'APECBEME'
       , 'MCECBEME' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-EIRSEGPE'
       , 'EUR'
       , 'APEIRSEGPE'
       , 'MCEIRSEGPE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-EIRSEGEE'
       , 'EUR'
       , 'APEIRSEGEE'
       , 'MCEIRSEGEE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-EIRSEGEN'
       , 'EUR'
       , 'APEIRSEGEN'
       , 'MCEIRSEGEN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-EIRSEGJE'
       , 'EUR'
       , 'APEIRSEGJE'
       , 'MCEIRSEGJE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-EIRSEGNA'
       , 'EUR'
       , 'APEIRSEGNA'
       , 'MCEIRSEGNA' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-EIRSEGUF'
       , 'EUR'
       , 'APEIRSEGUF'
       , 'MCEIRSEGUF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ISGPXX01'
       , 'EUR'
       , 'APIPSGP'
       , 'MCIPSGP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IHIBGE00'
       , 'EUR'
       , 'APIPHE'
       , 'MCIPHE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIMCBF'
       , 'EUR'
       , 'APILIMCBF'
       , 'MCILIMCBF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIVXXX00'
       , 'EUR'
       , 'APIPIV'
       , 'MCIPIV' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIEEX00'
       , 'EUR'
       , 'APILRZ'
       , 'MCILRZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IFIDAM00'
       , 'EUR'
       , 'APIPFAG'
       , 'MCIPFAG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPAIED'
       , 'EUR'
       , 'APIPAIED'
       , 'MCIPAIED' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MAIDENP'
       , 'EUR'
       , 'APMAIDENP'
       , 'MCMAIDENP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPALT'
       , 'EUR'
       , 'APIPALT'
       , 'MCIPALT' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IILCXX00'
       , 'EUR'
       , 'APIPLT'
       , 'MCIPLT' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIPSX00'
       , 'EUR'
       , 'APILIP'
       , 'MCILIP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIFUEX00'
       , 'EUR'
       , 'APIPAIUF'
       , 'MCIPAIUF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIEXX00'
       , 'EUR'
       , 'APILIE'
       , 'MCILIE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPBOIM00'
       , 'EUR'
       , 'APPPBI'
       , 'MCPPBI' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-LDGGBF'
       , 'EUR'
       , 'APLDGGBF'
       , 'MCLDGGBF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-LDDGBF'
       , 'EUR'
       , 'APLDDGBF'
       , 'MCLDDGBF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PAFCPI07'
       , 'EUR'
       , 'APPAFCPI07'
       , 'MCPAFCPI07' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ENIJAP'
       , 'EUR'
       , 'APENIJAP'
       , 'MCENIJAP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FIDINDI'
       , 'EUR'
       , 'APFIDINDI'
       , 'MCFIDINDI' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FTSECH'
       , 'EUR'
       , 'APFTSECH'
       , 'MCFTSECH' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-GNO2PRH'
       , 'EUR'
       , 'APGNO2PRH'
       , 'MCGNO2PRH' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BOND2031'
       , 'EUR'
       , 'APBOND2031'
       , 'MCBOND2031' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRANSJ'
       , 'EUR'
       , 'APTRANSJ'
       , 'MCTRANSJ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PAFCPI01'
       , 'EUR'
       , 'APPAFCPI01'
       , 'MCPAFCPI01' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PRINCESL'
       , 'EUR'
       , 'APPRINCESL'
       , 'MCPRINCESL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PMRPTOTC'
       , 'EUR'
       , 'APPMRPTOTC'
       , 'MCPMRPTOTC' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FIDEUROP'
       , 'EUR'
       , 'APFIDEUROP'
       , 'MCFIDEUROP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-OCEAN1P'
       , 'EUR'
       , 'APOCEAN1P'
       , 'MCOCEAN1P' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPSCOP00'
       , 'EUR'
       , 'APIPSP'
       , 'MCIPSP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PENSCUR'
       , 'EUR'
       , 'APPENSCUR'
       , 'MCPENSCUR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IFIDMI00'
       , 'EUR'
       , 'APIPFMI'
       , 'MCIPFMI' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPMMUK00'
       , 'EUR'
       , 'APIPMMUK'
       , 'MCIPMMUK' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ENIEUZ'
       , 'EUR'
       , 'APENIEUZ'
       , 'MCENIEUZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FENPROP'
       , 'EUR'
       , 'APFENPROP'
       , 'MCFENPROP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PAFCPI04'
       , 'EUR'
       , 'APPAFCPI04'
       , 'MCPAFCPI04' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILEEXX00'
       , 'EUR'
       , 'APILEE'
       , 'MCILEE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIEEXX01'
       , 'EUR'
       , 'APIPAIEN'
       , 'MCIPAIEN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BCPPROP'
       , 'EUR'
       , 'APBCPPROP'
       , 'MCBCPPROP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ITCDXX00'
       , 'EUR'
       , 'APIPTCD'
       , 'MCIPTCD' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IUHYEX00'
       , 'EUR'
       , 'APIPUHE'
       , 'MCIPUHE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PARIS1P'
       , 'EUR'
       , 'APPARIS1P'
       , 'MCPARIS1P' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIBIMS00'
       , 'EUR'
       , 'APIPAIBM'
       , 'MCIPAIBM' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN31'
       , 'EUR'
       , 'APTRAN31'
       , 'MCTRAN31' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IHYXXX00'
       , 'EUR'
       , 'APIPHY'
       , 'MCIPHY' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IFIDUK00'
       , 'EUR'
       , 'APIPFUK'
       , 'MCIPFUK' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILHIXX00'
       , 'EUR'
       , 'APILHI'
       , 'MCILHI' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IREBNKBN'
       , 'EUR'
       , 'APIREBNKBN'
       , 'MCIREBNKBN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FIDCHIN'
       , 'EUR'
       , 'APFIDCHIN'
       , 'MCFIDCHIN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IGB2025'
       , 'EUR'
       , 'APIGB2025'
       , 'MCIGB2025' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-GREENFP'
       , 'EUR'
       , 'APGREENFP'
       , 'MCGREENFP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIIEXX00'
       , 'EUR'
       , 'APIPAIIE'
       , 'MCIPAIIE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-HEIPFRET'
       , 'EUR'
       , 'APHEIPFRET'
       , 'MCHEIPFRET' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEFIXX00'
       , 'EUR'
       , 'APIPIDB'
       , 'MCIPIDB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIDJG00'
       , 'EUR'
       , 'APILGZ'
       , 'MCILGZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIFIEX00'
       , 'EUR'
       , 'APIPAIFE'
       , 'MCIPAIFE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGIEUREQ'
       , 'EUR'
       , 'APMGIEUREQ'
       , 'MCMGIEUREQ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IAGIXX00'
       , 'EUR'
       , 'APIPAX'
       , 'MCIPAX' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIBANK00'
       , 'EUR'
       , 'APIPBZ'
       , 'MCIPBZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ICONTR00'
       , 'EUR'
       , 'APIPCH'
       , 'MCIPCH' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IVCXXX01'
       , 'EUR'
       , 'APIPVC2'
       , 'MCIPVC2' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PAFCPI06'
       , 'EUR'
       , 'APPAFCPI06'
       , 'MCPAFCPI06' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIFIEL00'
       , 'EUR'
       , 'APIPAIFZ'
       , 'MCIPAIFZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIEEXX00'
       , 'EUR'
       , 'APIPAIEE'
       , 'MCIPAIEE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPDAXX00'
       , 'EUR'
       , 'APPPDA'
       , 'MCPPDA' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PAFCPI05'
       , 'EUR'
       , 'APPAFCPI05'
       , 'MCPAFCPI05' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIETX00'
       , 'EUR'
       , 'APILTZ'
       , 'MCILTZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEEXXX00'
       , 'EUR'
       , 'APIPEE'
       , 'MCIPEE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IICXXX00'
       , 'EUR'
       , 'APIPAICP'
       , 'MCIPAICP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IINAEX00'
       , 'EUR'
       , 'APIPAINA'
       , 'MCIPAINA' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIETXX00'
       , 'EUR'
       , 'APIPTZ'
       , 'MCIPTZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FIDGLOBP'
       , 'EUR'
       , 'APFIDGLOBP'
       , 'MCFIDGLOBP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IISRGE00'
       , 'EUR'
       , 'APIPSRG'
       , 'MCIPSRG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILAIIE'
       , 'EUR'
       , 'APILAIIE'
       , 'MCILAIIE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BROADSTL'
       , 'EUR'
       , 'APBROADSTL'
       , 'MCBROADSTL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FIDINCH'
       , 'EUR'
       , 'APFIDINCH'
       , 'MCFIDINCH' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGIEUCSH'
       , 'EUR'
       , 'APMGIEUCSH'
       , 'MCMGIEUCSH' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIPROP00'
       , 'EUR'
       , 'APIPRP'
       , 'MCIPRP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPMMJX00'
       , 'EUR'
       , 'APIPMMJ'
       , 'MCIPMMJ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FIDSELG'
       , 'EUR'
       , 'APFIDSELG'
       , 'MCFIDSELG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BOND2021'
       , 'EUR'
       , 'APBOND2021'
       , 'MCBOND2021' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IFSSXX00'
       , 'EUR'
       , 'APIPFSS'
       , 'MCIPFSS' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ITEMPX09'
       , 'EUR'
       , 'APRTROC'
       , 'MCRTROC' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IBFU5YR'
       , 'EUR'
       , 'APIBFU5YR'
       , 'MCIBFU5YR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IISTEE00'
       , 'EUR'
       , 'APIPSRE'
       , 'MCIPSRE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIFIX00'
       , 'EUR'
       , 'APILFZ'
       , 'MCILFZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FIDGLBSS'
       , 'EUR'
       , 'APFIDGLBSS'
       , 'MCFIDGLBSS' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CITPAR3P'
       , 'EUR'
       , 'APCITPAR3P'
       , 'MCCITPAR3P' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CITPARKP'
       , 'EUR'
       , 'APCITPARKP'
       , 'MCCITPARKP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CALDER'
       , 'EUR'
       , 'APCALDER'
       , 'MCCALDER' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-DEBETF'
       , 'EUR'
       , 'APDEBETF'
       , 'MCDEBETF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-2016IGB'
       , 'EUR'
       , 'AP2016IGB'
       , 'MC2016IGB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AAFFPEN'
       , 'EUR'
       , 'APAAFFPEN'
       , 'MCAAFFPEN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-UK10YBD'
       , 'EUR'
       , 'APUK10YBD'
       , 'MCUK10YBD' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TOURESPP'
       , 'EUR'
       , 'APTOURESPP'
       , 'MCTOURESPP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-WESTLINK'
       , 'EUR'
       , 'APWESTLINK'
       , 'MCWESTLINK' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEHYEX00'
       , 'EUR'
       , 'APIPEHE'
       , 'MCIPEHE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIEUR00'
       , 'EUR'
       , 'APILEZ'
       , 'MCILEZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ENINAM'
       , 'EUR'
       , 'APENINAM'
       , 'MCENINAM' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPMMAX00'
       , 'EUR'
       , 'APIPMMA'
       , 'MCIPMMA' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INSMCPEQ'
       , 'EUR'
       , 'APINSMCPEQ'
       , 'MCINSMCPEQ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-COMMOD'
       , 'EUR'
       , 'APCOMMOD'
       , 'MCCOMMOD' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-RCBGLOB'
       , 'EUR'
       , 'APRCBGLOB'
       , 'MCRCBGLOB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILNCFND'
       , 'EUR'
       , 'APILNCFND'
       , 'MCILNCFND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PARIS1L'
       , 'EUR'
       , 'APPARIS1L'
       , 'MCPARIS1L' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN67'
       , 'EUR'
       , 'APTRAN67'
       , 'MCTRAN67' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIPEXX00'
       , 'EUR'
       , 'APIPAIPE'
       , 'MCIPAIPE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILBOND26'
       , 'EUR'
       , 'APILBOND26'
       , 'MCILBOND26' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ACTGLOEQ'
       , 'EUR'
       , 'APACTGLOEQ'
       , 'MCACTGLOEQ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IUKEXX00'
       , 'EUR'
       , 'APIPUK'
       , 'MCIPUK' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILLBOND'
       , 'EUR'
       , 'APILLBOND'
       , 'MCILLBOND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-I5YFIX00'
       , 'EUR'
       , 'APIP93'
       , 'MCIP93' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILSPXX00'
       , 'EUR'
       , 'APILSYF'
       , 'MCILSYF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILWXXX00'
       , 'EUR'
       , 'APIPPL'
       , 'MCIPPL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CITPAR3L'
       , 'EUR'
       , 'APCITPAR3L'
       , 'MCCITPAR3L' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEPPXX00'
       , 'EUR'
       , 'APIPEPP'
       , 'MCIPEPP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AABOFUND'
       , 'EUR'
       , 'APAABOFUND'
       , 'MCAABOFUND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-G2020ILB'
       , 'EUR'
       , 'APG2020ILB'
       , 'MCG2020ILB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IFIDEU00'
       , 'EUR'
       , 'APIPFEG'
       , 'MCIPFEG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PROTCPIF'
       , 'EUR'
       , 'APPROTCPIF'
       , 'MCPROTCPIF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-COMARKTR'
       , 'EUR'
       , 'APCOMARKTR'
       , 'MCCOMARKTR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FIDSDIF'
       , 'EUR'
       , 'APFIDSDIF'
       , 'MCFIDSDIF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PAFCPI08'
       , 'EUR'
       , 'APPAFCPI08'
       , 'MCPAFCPI08' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BOND2055'
       , 'EUR'
       , 'APBOND2055'
       , 'MCBOND2055' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-RCBUKEQ'
       , 'EUR'
       , 'APRCBUKEQ'
       , 'MCRCBUKEQ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-EURPROP'
       , 'EUR'
       , 'APEURPROP'
       , 'MCEURPROP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-VENCAP07'
       , 'EUR'
       , 'APVENCAP07'
       , 'MCVENCAP07' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIEXXX00'
       , 'EUR'
       , 'APIPEZ'
       , 'MCIPEZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PAFCPI10'
       , 'EUR'
       , 'APPAFCPI10'
       , 'MCPAFCPI10' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILCOXX00'
       , 'EUR'
       , 'APILCO'
       , 'MCILCO' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BOND2036'
       , 'EUR'
       , 'APBOND2036'
       , 'MCBOND2036' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BOND2026'
       , 'EUR'
       , 'APBOND2026'
       , 'MCBOND2026' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CENTRICA'
       , 'EUR'
       , 'APACENTRIC'
       , 'MCACENTRIC' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PAFCPI02'
       , 'EUR'
       , 'APPAFCPI02'
       , 'MCPAFCPI02' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IHIFXX00'
       , 'EUR'
       , 'APIPHAR'
       , 'MCIPHAR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIPEX00'
       , 'EUR'
       , 'APILPZ'
       , 'MCILPZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-UKPENPRP'
       , 'EUR'
       , 'APUKPENPRP'
       , 'MCUKPENPRP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN18'
       , 'EUR'
       , 'APTRAN18'
       , 'MCTRAN18' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ENIUK'
       , 'EUR'
       , 'APENIUK'
       , 'MCENIUK' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPCOXX00'
       , 'EUR'
       , 'APIPCO'
       , 'MCIPCO' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INLDBOND'
       , 'EUR'
       , 'APINLDBOND'
       , 'MCINLDBOND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ICIFXX00'
       , 'EUR'
       , 'APIPCITY'
       , 'MCIPCITY' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-EMERGMKT'
       , 'EUR'
       , 'APEMERGMKT'
       , 'MCEMERGMKT' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILBOND36'
       , 'EUR'
       , 'APILBOND36'
       , 'MCILBOND36' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ISGPXX00'
       , 'EUR'
       , 'APIPSGPA'
       , 'MCIPSGPA' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-LIFECUR'
       , 'EUR'
       , 'APLIFECUR'
       , 'MCLIFECUR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPMMEX00'
       , 'EUR'
       , 'APIPMMEX'
       , 'MCIPMMEX' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IACTXX00'
       , 'EUR'
       , 'APIPACT'
       , 'MCIPACT' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IFORES00'
       , 'EUR'
       , 'APIPFF'
       , 'MCIPFF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILSBOND'
       , 'EUR'
       , 'APILSBOND'
       , 'MCILSBOND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ABALPH'
       , 'EUR'
       , 'APABALPH'
       , 'MCABALPH' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IGB32019'
       , 'EUR'
       , 'APIGB32019'
       , 'MCIGB32019' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FIDGIL'
       , 'EUR'
       , 'APFIDGIL'
       , 'MCFIDGIL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FIDGRAS'
       , 'EUR'
       , 'APFIDGRAS'
       , 'MCFIDGRAS' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPMMUS00'
       , 'EUR'
       , 'APIPMMUS'
       , 'MCIPMMUS' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IINASD00'
       , 'EUR'
       , 'APIPNZ'
       , 'MCIPNZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGIEMMKT'
       , 'EUR'
       , 'APMGIEMMKT'
       , 'MCMGIEMMKT' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIO1'
       , 'EUR'
       , 'APILIO1'
       , 'MCILIO1' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FIDEMEA'
       , 'EUR'
       , 'APFIDEMEA'
       , 'MCFIDEMEA' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-RCBEURO'
       , 'EUR'
       , 'APRCBEURO'
       , 'MCRCBEURO' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-DARPARK'
       , 'EUR'
       , 'APDARPARK'
       , 'MCDARPARK' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEUEXX00'
       , 'EUR'
       , 'APIPEU'
       , 'MCIPEU' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IFIXXX00'
       , 'EUR'
       , 'APIPIF'
       , 'MCIPIF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILUKEX00'
       , 'EUR'
       , 'APILUK'
       , 'MCILUK' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIUSX00'
       , 'EUR'
       , 'APILUZ'
       , 'MCILUZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIJEXX00'
       , 'EUR'
       , 'APIPAIJE'
       , 'MCIPAIJE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INEFUND'
       , 'EUR'
       , 'APINEFUND'
       , 'MCINEFUND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPWHIT00'
       , 'EUR'
       , 'APIPWHIT'
       , 'MCIPWHIT' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BOND2016'
       , 'EUR'
       , 'APBOND2016'
       , 'MCBOND2016' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IREGOVBN'
       , 'EUR'
       , 'APIREGOVBN'
       , 'MCIREGOVBN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILAHEIPF'
       , 'EUR'
       , 'APILAHEIPF'
       , 'MCILAHEIPF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IISCXX00'
       , 'EUR'
       , 'APIPST'
       , 'MCIPST' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIJEX00'
       , 'EUR'
       , 'APILJZ'
       , 'MCILJZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MAIDENL'
       , 'EUR'
       , 'APMAIDENL'
       , 'MCMAIDENL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ACLAIF'
       , 'EUR'
       , 'APACLAIF'
       , 'MCACLAIF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILAB2040'
       , 'EUR'
       , 'APILAB2040'
       , 'MCILAB2040' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AAAAAMBF'
       , 'EUR'
       , 'APAAAAAMBF'
       , 'MCAAAAAMBF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CITPARKL'
       , 'EUR'
       , 'APCITPARKL'
       , 'MCCITPARKL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-DEVPAC'
       , 'EUR'
       , 'APDEVPAC'
       , 'MCDEVPAC' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILBOND31'
       , 'EUR'
       , 'APILBOND31'
       , 'MCILBOND31' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPIILX00'
       , 'EUR'
       , 'APIPIIL'
       , 'MCIPIIL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-GLOBVAL'
       , 'EUR'
       , 'APGLOBVAL'
       , 'MCGLOBVAL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AAAMBF'
       , 'EUR'
       , 'APAAAMBF'
       , 'MCAAAMBF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PAFCPI09'
       , 'EUR'
       , 'APPAFCPI09'
       , 'MCPAFCPI09' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIUKE00'
       , 'EUR'
       , 'APILKZ'
       , 'MCILKZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PRINCES'
       , 'EUR'
       , 'APPRINCES'
       , 'MCPRINCES' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILBOND46'
       , 'EUR'
       , 'APILBOND46'
       , 'MCILBOND46' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PAFCPI03'
       , 'EUR'
       , 'APPAFCPI03'
       , 'MCPAFCPI03' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILINXX00'
       , 'EUR'
       , 'APILNZ'
       , 'MCILNZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILPMXX00'
       , 'EUR'
       , 'APILRP'
       , 'MCILRP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-OCEAN1L'
       , 'EUR'
       , 'APOCEAN1L'
       , 'MCOCEAN1L' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIFXXX00'
       , 'EUR'
       , 'APIPAIFI'
       , 'MCIPAIFI' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BROADSTP'
       , 'EUR'
       , 'APBROADSTP'
       , 'MCBROADSTP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IUKPHF00'
       , 'EUR'
       , 'APIPGUKP'
       , 'MCIPGUKP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IFIDAS00'
       , 'EUR'
       , 'APIPFASS'
       , 'MCIPFASS' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIFIUU00'
       , 'EUR'
       , 'APIPAIFU'
       , 'MCIPAIFU' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IGAXXX00'
       , 'EUR'
       , 'APIPGA'
       , 'MCIPGA' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AXISPARP'
       , 'EUR'
       , 'APAXISPARP'
       , 'MCAXISPARP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-5YAAA'
       , 'EUR'
       , 'AP5YAAA'
       , 'MC5YAAA' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MSFIFUND'
       , 'EUR'
       , 'APMSFIFUND'
       , 'MCMSFIFUND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILUKPX00'
       , 'EUR'
       , 'APILUP'
       , 'MCILUP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IIDJGX00'
       , 'EUR'
       , 'APIPGZ'
       , 'MCIPGZ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ISPXXX01'
       , 'EUR'
       , 'APIPPESP'
       , 'MCIPPESP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPFIIL00'
       , 'EUR'
       , 'APIPIFIL'
       , 'MCIPIFIL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGIEUBND'
       , 'EUR'
       , 'APMGIEUBND'
       , 'MCMGIEUBND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGILSF'
       , 'EUR'
       , 'APMGILSF'
       , 'MCMGILSF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGIEMD'
       , 'EUR'
       , 'APMGIEMD'
       , 'MCMGIEMD' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGIMWGB'
       , 'EUR'
       , 'APMGIMWGB'
       , 'MCMGIMWGB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MWSGLBE'
       , 'EUR'
       , 'APMWSGLBE'
       , 'MCMWSGLBE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MWSLVEF'
       , 'EUR'
       , 'APMWSLVEF'
       , 'MCMWSLVEF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MWSPGE'
       , 'EUR'
       , 'APMWSPGE'
       , 'MCMWSPGE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILN5FI'
       , 'EUR'
       , 'APILN5FI'
       , 'MCILN5FI' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ACTUSHDG'
       , 'EUR'
       , 'APACTUSHDG'
       , 'MCACTUSHDG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MINVOL'
       , 'EUR'
       , 'APMINVOL'
       , 'MCMINVOL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN79'
       , 'EUR'
       , 'APTRAN79'
       , 'MCTRAN79' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-EMDFUND'
       , 'EUR'
       , 'APEMDFUND'
       , 'MCEMDFUND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MLLCNFCB'
       , 'EUR'
       , 'APMLLCNFCB'
       , 'MCMLLCNFCB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MLGDP10'
       , 'EUR'
       , 'APMLGDP10'
       , 'MCMLGDP10' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CFEPSUS'
       , 'EUR'
       , 'APCFEPSUS'
       , 'MCCFEPSUS' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AAAAA15'
       , 'EUR'
       , 'APAAAAA15'
       , 'MCAAAAA15' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AAAAA5'
       , 'EUR'
       , 'APAAAAA5'
       , 'MCAAAAA5' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INMGDP'
       , 'EUR'
       , 'APINMGDP'
       , 'MCINMGDP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN98'
       , 'EUR'
       , 'APTRAN98'
       , 'MCTRAN98' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN99'
       , 'EUR'
       , 'APTRAN99'
       , 'MCTRAN99' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILHICPAM'
       , 'EUR'
       , 'APILHICPAM'
       , 'MCILHICPAM' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-QBIO'
       , 'EUR'
       , 'APQBIO'
       , 'MCQBIO' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-QLAM'
       , 'EUR'
       , 'APQLAM'
       , 'MCQLAM' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-QCLE'
       , 'EUR'
       , 'APQCLE'
       , 'MCQCLE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-QCHIN'
       , 'EUR'
       , 'APQCHIN'
       , 'MCQCHIN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BOND2037'
       , 'EUR'
       , 'APBOND2037'
       , 'MCBOND2037' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INJGBP'
       , 'EUR'
       , 'APINJGBP'
       , 'MCINJGBP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INMEMP'
       , 'EUR'
       , 'APINMEMP'
       , 'MCINMEMP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INBEBP'
       , 'EUR'
       , 'APINBEBP'
       , 'MCINBEBP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INNEMP'
       , 'EUR'
       , 'APINNEMP'
       , 'MCINNEMP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INNEIP'
       , 'EUR'
       , 'APINNEIP'
       , 'MCINNEIP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INNEGP'
       , 'EUR'
       , 'APINNEGP'
       , 'MCINNEGP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IRE2047'
       , 'EUR'
       , 'APIRE2047'
       , 'MCIRE2047' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IRE2037'
       , 'EUR'
       , 'APIRE2037'
       , 'MCIRE2037' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IRE2032'
       , 'EUR'
       , 'APIRE2032'
       , 'MCIRE2032' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IRE2027'
       , 'EUR'
       , 'APIRE2027'
       , 'MCIRE2027' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IRE2042'
       , 'EUR'
       , 'APIRE2042'
       , 'MCIRE2042' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INNUKP'
       , 'EUR'
       , 'APINNUKP'
       , 'MCINNUKP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INNJEP'
       , 'EUR'
       , 'APINNJEP'
       , 'MCINNJEP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INNNAP'
       , 'EUR'
       , 'APINNNAP'
       , 'MCINNNAP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INNPAP'
       , 'EUR'
       , 'APINNPAP'
       , 'MCINNPAP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INNEUP'
       , 'EUR'
       , 'APINNEUP'
       , 'MCINNEUP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INBECP'
       , 'EUR'
       , 'APINBECP'
       , 'MCINBECP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INBEAP'
       , 'EUR'
       , 'APINBEAP'
       , 'MCINBEAP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INBCEP'
       , 'EUR'
       , 'APINBCEP'
       , 'MCINBCEP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AIBFRD1'
       , 'EUR'
       , 'APAIBFRD1'
       , 'MCAIBFRD1' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPCPOTC'
       , 'EUR'
       , 'APIPCPOTC'
       , 'MCIPCPOTC' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPCLOP'
       , 'EUR'
       , 'APIPCLOP'
       , 'MCIPCLOP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INMREP'
       , 'EUR'
       , 'APINMREP'
       , 'MCINMREP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INDTVP'
       , 'EUR'
       , 'APINDTVP'
       , 'MCINDTVP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INXGIP'
       , 'EUR'
       , 'APINXGIP'
       , 'MCINXGIP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIMRAFI'
       , 'EUR'
       , 'APILIMRAFI'
       , 'MCILIMRAFI' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IAI2025B'
       , 'EUR'
       , 'APIAI2025B'
       , 'MCIAI2025B' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INDSFP'
       , 'EUR'
       , 'APINDSFP'
       , 'MCINDSFP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-GERIL23'
       , 'EUR'
       , 'APGERIL23'
       , 'MCGERIL23' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPAIAM'
       , 'EUR'
       , 'APIPAIAM'
       , 'MCIPAIAM' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IHYGIF'
       , 'EUR'
       , 'APIHYGIF'
       , 'MCIHYGIF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TCDHYEQ'
       , 'EUR'
       , 'APTCDHYEQ'
       , 'MCTCDHYEQ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AAAAABEL'
       , 'EUR'
       , 'APAAAAABEL'
       , 'MCAAAAABEL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-GILBFUND'
       , 'EUR'
       , 'APGILBFUND'
       , 'MCGILBFUND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-2023ILBF'
       , 'EUR'
       , 'AP2023ILBF'
       , 'MC2023ILBF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IAB2032B'
       , 'EUR'
       , 'APIAB2032B'
       , 'MCIAB2032B' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IAB2042B'
       , 'EUR'
       , 'APIAB2042B'
       , 'MCIAB2042B' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IAB2037B'
       , 'EUR'
       , 'APIAB2037B'
       , 'MCIAB2037B' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IAB2027B'
       , 'EUR'
       , 'APIAB2027B'
       , 'MCIAB2027B' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IAB2047B'
       , 'EUR'
       , 'APIAB2047B'
       , 'MCIAB2047B' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BNYRRF'
       , 'EUR'
       , 'APBNYRRF'
       , 'MCBNYRRF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ETFSGD'
       , 'EUR'
       , 'APETFSGD'
       , 'MCETFSGD' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-RCSIELG'
       , 'EUR'
       , 'APRCSIELG'
       , 'MCRCSIELG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SIPTUELG'
       , 'EUR'
       , 'APSIPTUELG'
       , 'MCSIPTUELG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-STARF'
       , 'EUR'
       , 'APSTARF'
       , 'MCSTARF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SLGARS'
       , 'EUR'
       , 'APSLGARS'
       , 'MCSLGARS' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SARIEIF'
       , 'EUR'
       , 'APSARIEIF'
       , 'MCSARIEIF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ICTUELG'
       , 'EUR'
       , 'APICTUELG'
       , 'MCICTUELG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IGB2018'
       , 'EUR'
       , 'APIGB2018'
       , 'MCIGB2018' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-2017IGB'
       , 'EUR'
       , 'AP2017IGB'
       , 'MC2017IGB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IHYGETF'
       , 'EUR'
       , 'APIHYGETF'
       , 'MCIHYGETF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN131'
       , 'EUR'
       , 'APTRAN131'
       , 'MCTRAN131' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BREDDG'
       , 'EUR'
       , 'APBREDDG'
       , 'MCBREDDG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SDPBF1'
       , 'EUR'
       , 'APSDPBF1'
       , 'MCSDPBF1' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPN5FI'
       , 'EUR'
       , 'APIPN5FI'
       , 'MCIPN5FI' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SETEQDIV'
       , 'EUR'
       , 'APSETEQDIV'
       , 'MCSETEQDIV' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SETFOCUS'
       , 'EUR'
       , 'APSETFOCUS'
       , 'MCSETFOCUS' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SETINCOP'
       , 'EUR'
       , 'APSETINCOP'
       , 'MCSETINCOP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SETGLEQ'
       , 'EUR'
       , 'APSETGLEQ'
       , 'MCSETGLEQ' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN144'
       , 'EUR'
       , 'APTRAN144'
       , 'MCTRAN144' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN146'
       , 'EUR'
       , 'APTRAN146'
       , 'MCTRAN146' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BARFIF'
       , 'EUR'
       , 'APBARFIF'
       , 'MCBARFIF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CIEMTOP'
       , 'EUR'
       , 'APCIEMTOP'
       , 'MCCIEMTOP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-DSHRCASH'
       , 'EUR'
       , 'APDSHRCASH'
       , 'MCDSHRCASH' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-KBICASF'
       , 'EUR'
       , 'APKBICASF'
       , 'MCKBICASF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM1000'
       , 'EUR'
       , 'APADM1000'
       , 'MCADM1000' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM1001'
       , 'EUR'
       , 'APADM1001'
       , 'MCADM1001' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM1002'
       , 'EUR'
       , 'APADM1002'
       , 'MCADM1002' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM1003'
       , 'EUR'
       , 'APADM1003'
       , 'MCADM1003' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM1004'
       , 'EUR'
       , 'APADM1004'
       , 'MCADM1004' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM1005'
       , 'EUR'
       , 'APADM1005'
       , 'MCADM1005' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM1006'
       , 'EUR'
       , 'APADM1006'
       , 'MCADM1006' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM1007'
       , 'EUR'
       , 'APADM1007'
       , 'MCADM1007' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM1008'
       , 'EUR'
       , 'APADM1008'
       , 'MCADM1008' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM1009'
       , 'EUR'
       , 'APADM1009'
       , 'MCADM1009' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM1010'
       , 'EUR'
       , 'APADM1010'
       , 'MCADM1010' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM2000'
       , 'EUR'
       , 'APADM2000'
       , 'MCADM2000' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM4000'
       , 'EUR'
       , 'APADM4000'
       , 'MCADM4000' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ADM6000'
       , 'EUR'
       , 'APADM6000'
       , 'MCADM6000' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1004'
       , 'EUR'
       , 'APIEC1004'
       , 'MCIEC1004' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1004N'
       , 'EUR'
       , 'APIEC1004N'
       , 'MCIEC1004N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1005'
       , 'EUR'
       , 'APIEC1005'
       , 'MCIEC1005' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1008'
       , 'EUR'
       , 'APIEC1008'
       , 'MCIEC1008' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1010'
       , 'EUR'
       , 'APIEC1010'
       , 'MCIEC1010' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1011'
       , 'EUR'
       , 'APIEC1011'
       , 'MCIEC1011' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1013'
       , 'EUR'
       , 'APIEC1013'
       , 'MCIEC1013' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1013N'
       , 'EUR'
       , 'APIEC1013N'
       , 'MCIEC1013N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1014'
       , 'EUR'
       , 'APIEC1014'
       , 'MCIEC1014' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1014N'
       , 'EUR'
       , 'APIEC1014N'
       , 'MCIEC1014N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1015'
       , 'EUR'
       , 'APIEC1015'
       , 'MCIEC1015' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1015N'
       , 'EUR'
       , 'APIEC1015N'
       , 'MCIEC1015N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1016'
       , 'EUR'
       , 'APIEC1016'
       , 'MCIEC1016' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1016N'
       , 'EUR'
       , 'APIEC1016N'
       , 'MCIEC1016N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1017'
       , 'EUR'
       , 'APIEC1017'
       , 'MCIEC1017' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC1019'
       , 'EUR'
       , 'APIEC1019'
       , 'MCIEC1019' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC4001'
       , 'EUR'
       , 'APIEC4001'
       , 'MCIEC4001' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC4001N'
       , 'EUR'
       , 'APIEC4001N'
       , 'MCIEC4001N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7001N'
       , 'EUR'
       , 'APIEC7001N'
       , 'MCIEC7001N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7002'
       , 'EUR'
       , 'APIEC7002'
       , 'MCIEC7002' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7002N'
       , 'EUR'
       , 'APIEC7002N'
       , 'MCIEC7002N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7003N'
       , 'EUR'
       , 'APIEC7003N'
       , 'MCIEC7003N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7004'
       , 'EUR'
       , 'APIEC7004'
       , 'MCIEC7004' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7004N'
       , 'EUR'
       , 'APIEC7004N'
       , 'MCIEC7004N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7005'
       , 'EUR'
       , 'APIEC7005'
       , 'MCIEC7005' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7005N'
       , 'EUR'
       , 'APIEC7005N'
       , 'MCIEC7005N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7006'
       , 'EUR'
       , 'APIEC7006'
       , 'MCIEC7006' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7006N'
       , 'EUR'
       , 'APIEC7006N'
       , 'MCIEC7006N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7008'
       , 'EUR'
       , 'APIEC7008'
       , 'MCIEC7008' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7015'
       , 'EUR'
       , 'APIEC7015'
       , 'MCIEC7015' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7100'
       , 'EUR'
       , 'APIEC7100'
       , 'MCIEC7100' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7500'
       , 'EUR'
       , 'APIEC7500'
       , 'MCIEC7500' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7500N'
       , 'EUR'
       , 'APIEC7500N'
       , 'MCIEC7500N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7502'
       , 'EUR'
       , 'APIEC7502'
       , 'MCIEC7502' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7502N'
       , 'EUR'
       , 'APIEC7502N'
       , 'MCIEC7502N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7503'
       , 'EUR'
       , 'APIEC7503'
       , 'MCIEC7503' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7503N'
       , 'EUR'
       , 'APIEC7503N'
       , 'MCIEC7503N' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7601'
       , 'EUR'
       , 'APIEC7601'
       , 'MCIEC7601' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7602'
       , 'EUR'
       , 'APIEC7602'
       , 'MCIEC7602' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7702'
       , 'EUR'
       , 'APIEC7702'
       , 'MCIEC7702' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7703'
       , 'EUR'
       , 'APIEC7703'
       , 'MCIEC7703' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7705'
       , 'EUR'
       , 'APIEC7705'
       , 'MCIEC7705' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7706'
       , 'EUR'
       , 'APIEC7706'
       , 'MCIEC7706' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIETAX'
       , 'EUR'
       , 'APILIETAX'
       , 'MCILIETAX' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILRPTAX'
       , 'EUR'
       , 'APILRPTAX'
       , 'MCILRPTAX' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7013'
       , 'EUR'
       , 'APIEC7013'
       , 'MCIEC7013' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SDPB2016'
       , 'EUR'
       , 'APSDPB2016'
       , 'MCSDPB2016' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-UKGILT15'
       , 'EUR'
       , 'APUKGILT15'
       , 'MCUKGILT15' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ENIPANEU'
       , 'EUR'
       , 'APENIPANEU'
       , 'MCENIPANEU' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ENIGLO'
       , 'EUR'
       , 'APENIGLO'
       , 'MCENIGLO' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ENIPAC'
       , 'EUR'
       , 'APENIPAC'
       , 'MCENIPAC' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PIMGB'
       , 'EUR'
       , 'APPIMGB'
       , 'MCPIMGB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SPGOVT10'
       , 'EUR'
       , 'APSPGOVT10'
       , 'MCSPGOVT10' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MAPSTAR'
       , 'EUR'
       , 'APMAPSTAR'
       , 'MCMAPSTAR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MSCICH'
       , 'EUR'
       , 'APMSCICH'
       , 'MCMSCICH' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MSCIDW'
       , 'EUR'
       , 'APMSCIDW'
       , 'MCMSCIDW' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-REITNET'
       , 'EUR'
       , 'APREITNET'
       , 'MCREITNET' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IRPREIT'
       , 'EUR'
       , 'APIRPREIT'
       , 'MCIRPREIT' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IGBOCT20'
       , 'EUR'
       , 'APIGBOCT20'
       , 'MCIGBOCT20' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGCBF'
       , 'EUR'
       , 'APMGCBF'
       , 'MCMGCBF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGECB'
       , 'EUR'
       , 'APMGECB'
       , 'MCMGECB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGGGF'
       , 'EUR'
       , 'APMGGGF'
       , 'MCMGGGF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGGLF'
       , 'EUR'
       , 'APMGGLF'
       , 'MCMGGLF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGHYCB'
       , 'EUR'
       , 'APMGHYCB'
       , 'MCMGHYCB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SIESSF'
       , 'EUR'
       , 'APSIESSF'
       , 'MCSIESSF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SIGAVF'
       , 'EUR'
       , 'APSIGAVF'
       , 'MCSIGAVF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SIGPSF'
       , 'EUR'
       , 'APSIGPSF'
       , 'MCSIGPSF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SIQGQF'
       , 'EUR'
       , 'APSIQGQF'
       , 'MCSIQGQF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SISMCE'
       , 'EUR'
       , 'APSISMCE'
       , 'MCSISMCE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGFEMF'
       , 'EUR'
       , 'APBGFEMF'
       , 'MCBGFEMF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGFESD'
       , 'EUR'
       , 'APBGFESD'
       , 'MCBGFESD' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGFEFF'
       , 'EUR'
       , 'APBGFEFF'
       , 'MCBGFEFF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGFEF'
       , 'EUR'
       , 'APBGFEF'
       , 'MCBGFEF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGFEGF'
       , 'EUR'
       , 'APBGFEGF'
       , 'MCBGFEGF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGFGDE'
       , 'EUR'
       , 'APBGFGDE'
       , 'MCBGFGDE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGFWEF'
       , 'EUR'
       , 'APBGFWEF'
       , 'MCBGFWEF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGFWMF'
       , 'EUR'
       , 'APBGFWMF'
       , 'MCBGFWMF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN156'
       , 'EUR'
       , 'APTRAN156'
       , 'MCTRAN156' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN160'
       , 'EUR'
       , 'APTRAN160'
       , 'MCTRAN160' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AGLOVE'
       , 'EUR'
       , 'APAGLOVE'
       , 'MCAGLOVE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-GMOINV'
       , 'EUR'
       , 'APGMOINV'
       , 'MCGMOINV' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SILHI'
       , 'EUR'
       , 'APSILHI'
       , 'MCSILHI' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SETVRS01'
       , 'EUR'
       , 'APSETVRS01'
       , 'MCSETVRS01' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SETVRS02'
       , 'EUR'
       , 'APSETVRS02'
       , 'MCSETVRS02' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FREUGF'
       , 'EUR'
       , 'APFREUGF'
       , 'MCFREUGF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILIETAX2'
       , 'EUR'
       , 'APILIETAX2'
       , 'MCILIETAX2' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ILRPTAX2'
       , 'EUR'
       , 'APILRPTAX2'
       , 'MCILRPTAX2' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BBIGB'
       , 'EUR'
       , 'APBBIGB'
       , 'MCBBIGB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BIIFND'
       , 'EUR'
       , 'APBIIFND'
       , 'MCBIIFND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ERTGBF'
       , 'EUR'
       , 'APERTGBF'
       , 'MCERTGBF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FEUSC'
       , 'EUR'
       , 'APFEUSC'
       , 'MCFEUSC' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SETGLEQN'
       , 'EUR'
       , 'APSETGLEQN'
       , 'MCSETGLEQN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN161'
       , 'EUR'
       , 'APTRAN161'
       , 'MCTRAN161' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN167'
       , 'EUR'
       , 'APTRAN167'
       , 'MCTRAN167' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPIDBG'
       , 'EUR'
       , 'APIPIDBG'
       , 'MCIPIDBG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IPIDBN'
       , 'EUR'
       , 'APIPIDBN'
       , 'MCIPIDBN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-DSCNET'
       , 'EUR'
       , 'APDSCNET'
       , 'MCDSCNET' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MFGDEN'
       , 'EUR'
       , 'APMFGDEN'
       , 'MCMFGDEN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SCENSF'
       , 'EUR'
       , 'APSCENSF'
       , 'MCSCENSF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-NROFUT'
       , 'EUR'
       , 'APNROFUT'
       , 'MCNROFUT' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-GLVONF'
       , 'EUR'
       , 'APGLVONF'
       , 'MCGLVONF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-EMERGMKN'
       , 'EUR'
       , 'APEMERGMKN'
       , 'MCEMERGMKN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-EMDNSF'
       , 'EUR'
       , 'APEMDNSF'
       , 'MCEMDNSF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ECBNSF'
       , 'EUR'
       , 'APECBNSF'
       , 'MCECBNSF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-VGEIF'
       , 'EUR'
       , 'APVGEIF'
       , 'MCVGEIF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGASF'
       , 'EUR'
       , 'APMGASF'
       , 'MCMGASF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGFGAF'
       , 'EUR'
       , 'APBGFGAF'
       , 'MCBGFGAF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TNEHYBF'
       , 'EUR'
       , 'APTNEHYBF'
       , 'MCTNEHYBF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PRMFIEN'
       , 'EUR'
       , 'APPRMFIEN'
       , 'MCPRMFIEN' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PRMFIEG'
       , 'EUR'
       , 'APPRMFIEG'
       , 'MCPRMFIEG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SLGEQF'
       , 'EUR'
       , 'APSLGEQF'
       , 'MCSLGEQF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-SDRGBF'
       , 'EUR'
       , 'APSDRGBF'
       , 'MCSDRGBF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-HHEUGF'
       , 'EUR'
       , 'APHHEUGF'
       , 'MCHHEUGF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGFGSC'
       , 'EUR'
       , 'APBGFGSC'
       , 'MCBGFGSC' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-JPMED'
       , 'EUR'
       , 'APJPMED'
       , 'MCJPMED' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN171'
       , 'EUR'
       , 'APTRAN171'
       , 'MCTRAN171' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN176'
       , 'EUR'
       , 'APTRAN176'
       , 'MCTRAN176' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN177'
       , 'EUR'
       , 'APTRAN177'
       , 'MCTRAN177' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN178'
       , 'EUR'
       , 'APTRAN178'
       , 'MCTRAN178' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN179'
       , 'EUR'
       , 'APTRAN179'
       , 'MCTRAN179' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN180'
       , 'EUR'
       , 'APTRAN180'
       , 'MCTRAN180' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ICEMNOM'
       , 'EUR'
       , 'APICEMNOM'
       , 'MCICEMNOM' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-DCWUSS'
       , 'EUR'
       , 'APDCWUSS'
       , 'MCDCWUSS' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FSAPL'
       , 'EUR'
       , 'APFSAPL'
       , 'MCFSAPL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FSGRES'
       , 'EUR'
       , 'APFSGRES'
       , 'MCFSGRES' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FSGLI'
       , 'EUR'
       , 'APFSGLI'
       , 'MCFSGLI' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ING2030'
       , 'EUR'
       , 'APING2030'
       , 'MCING2030' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-ARBFUND'
       , 'EUR'
       , 'APARBFUND'
       , 'MCARBFUND' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7506'
       , 'EUR'
       , 'APIEC7506'
       , 'MCIEC7506' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7507'
       , 'EUR'
       , 'APIEC7507'
       , 'MCIEC7507' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7508'
       , 'EUR'
       , 'APIEC7508'
       , 'MCIEC7508' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7509'
       , 'EUR'
       , 'APIEC7509'
       , 'MCIEC7509' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7510'
       , 'EUR'
       , 'APIEC7510'
       , 'MCIEC7510' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AAAAABL2'
       , 'EUR'
       , 'APAAAAABL2'
       , 'MCAAAAABL2' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-JEUGF'
       , 'EUR'
       , 'APJEUGF'
       , 'MCJEUGF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-JEUOF'
       , 'EUR'
       , 'APJEUOF'
       , 'MCJEUOF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BEUEIF'
       , 'EUR'
       , 'APBEUEIF'
       , 'MCBEUEIF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-JGLCOF'
       , 'EUR'
       , 'APJGLCOF'
       , 'MCJGLCOF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-HICPFG'
       , 'EUR'
       , 'APHICPFG'
       , 'MCHICPFG' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FGTPCOM'
       , 'EUR'
       , 'APFGTPCOM'
       , 'MCFGTPCOM' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-AQRGRP'
       , 'EUR'
       , 'APAQRGRP'
       , 'MCAQRGRP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PUTWTR'
       , 'EUR'
       , 'APPUTWTR'
       , 'MCPUTWTR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-HHPEEF'
       , 'EUR'
       , 'APHHPEEF'
       , 'MCHHPEEF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGFWGF'
       , 'EUR'
       , 'APBGFWGF'
       , 'MCBGFWGF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PGIGCB'
       , 'EUR'
       , 'APPGIGCB'
       , 'MCPGIGCB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FGRMNF'
       , 'EUR'
       , 'APFGRMNF'
       , 'MCFGRMNF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-FSEAF'
       , 'EUR'
       , 'APFSEAF'
       , 'MCFSEAF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-HHRZNF'
       , 'EUR'
       , 'APHHRZNF'
       , 'MCHHRZNF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-JPMGNR'
       , 'EUR'
       , 'APJPMGNR'
       , 'MCJPMGNR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MSDAF'
       , 'EUR'
       , 'APMSDAF'
       , 'MCMSDAF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BSFFIS'
       , 'EUR'
       , 'APBSFFIS'
       , 'MCBSFFIS' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MGAMF'
       , 'EUR'
       , 'APMGAMF'
       , 'MCMGAMF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PIONARB'
       , 'EUR'
       , 'APPIONARB'
       , 'MCPIONARB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BKGARB'
       , 'EUR'
       , 'APBKGARB'
       , 'MCBKGARB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INVDGF'
       , 'EUR'
       , 'APINVDGF'
       , 'MCINVDGF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INSBOF'
       , 'EUR'
       , 'APINSBOF'
       , 'MCINSBOF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BNYRRA'
       , 'EUR'
       , 'APBNYRRA'
       , 'MCBNYRRA' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-GAMARB'
       , 'EUR'
       , 'APGAMARB'
       , 'MCGAMARB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INVGTR'
       , 'EUR'
       , 'APINVGTR'
       , 'MCINVGTR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-THREAM'
       , 'EUR'
       , 'APTHREAM'
       , 'MCTHREAM' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-RTESAFX'
       , 'EUR'
       , 'APRTESAFX'
       , 'MCRTESAFX' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRAN181'
       , 'EUR'
       , 'APTRAN181'
       , 'MCTRAN181' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7712'
       , 'EUR'
       , 'APIEC7712'
       , 'MCIEC7712' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7713'
       , 'EUR'
       , 'APIEC7713'
       , 'MCIEC7713' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7707'
       , 'EUR'
       , 'APIEC7707'
       , 'MCIEC7707' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7708'
       , 'EUR'
       , 'APIEC7708'
       , 'MCIEC7708' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7709'
       , 'EUR'
       , 'APIEC7709'
       , 'MCIEC7709' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7710'
       , 'EUR'
       , 'APIEC7710'
       , 'MCIEC7710' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7711'
       , 'EUR'
       , 'APIEC7711'
       , 'MCIEC7711' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-TRANEM'
       , 'EUR'
       , 'APTRANEM'
       , 'MCTRANEM' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-MSCIHD'
       , 'EUR'
       , 'APMSCIHD'
       , 'MCMSCIHD' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PIMTRB'
       , 'EUR'
       , 'APPIMTRB'
       , 'MCPIMTRB' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CPUSGI'
       , 'EUR'
       , 'APCPUSGI'
       , 'MCCPUSGI' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-RTESAFX2'
       , 'EUR'
       , 'APRTESAFX2'
       , 'MCRTESAFX2' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-VERGFF'
       , 'EUR'
       , 'APVERGFF'
       , 'MCVERGFF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-HARGEF'
       , 'EUR'
       , 'APHARGEF'
       , 'MCHARGEF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-INVGDF'
       , 'EUR'
       , 'APINVGDF'
       , 'MCINVGDF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-IEC7714'
       , 'EUR'
       , 'APIEC7714'
       , 'MCIEC7714' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-PIMGRR'
       , 'EUR'
       , 'APPIMGRR'
       , 'MCPIMGRR' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CPPUKX00'
       , 'GBP'
       , 'APBPUP'
       , 'MCBPUP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CLUKEX00'
       , 'GBP'
       , 'APBLUK'
       , 'MCBLUK' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CPFIXX00'
       , 'GBP'
       , 'APBPIF'
       , 'MCBPIF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CLCXXX00'
       , 'GBP'
       , 'APBLCF'
       , 'MCBLCF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGICFP'
       , 'GBP'
       , 'APBGICFP'
       , 'MCBGICFP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CPIEXX00'
       , 'GBP'
       , 'APBPOE'
       , 'MCBPOE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CLEEXX00'
       , 'GBP'
       , 'APBLEE'
       , 'MCBLEE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CPCXXX00'
       , 'GBP'
       , 'APBPCF'
       , 'MCBPCF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CLIFIX00'
       , 'GBP'
       , 'APBLIF'
       , 'MCBLIF' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CLPXXX00'
       , 'GBP'
       , 'APBLUP'
       , 'MCBLUP' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-BGICFL'
       , 'GBP'
       , 'APBGICFL'
       , 'MCBGICFL' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CPUKEX00'
       , 'GBP'
       , 'APBPUK'
       , 'MCBPUK' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-CABLOE'
       , 'GBP'
       , 'APCABLOE'
       , 'MCCABLOE' );

INSERT INTO t_scd_asset_port_treasury( scd_asset_portfolio
                                     , currency_id
                                     , app_alm_no
                                     , mc_alm_no )
VALUES ( 'A-GBPCASH'
       , 'GBP'
       , 'APGBPCASH'
       , 'MCGBPCASH' );
	   
--End Script
SPOOL OFF