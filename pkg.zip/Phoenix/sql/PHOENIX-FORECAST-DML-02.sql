-- PHOENIX-FORECAST-DML-02.sql
-- Runas: FM(UAT)DBA
-- Desc: Create Forecast Type entries
-- Author: y246

--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

spool PHOENIX-FORECAST-DML-02.OUT
--Begin Script

INSERT INTO t_forecast_type( forecast_type_id
                           , forecast_type_nm )
VALUES ( 0
       , 'UNKNOWN' )
/

INSERT INTO t_forecast_type( forecast_type_id
                           , forecast_type_nm )
VALUES ( 1
       , 'NEW_MONEY' )
/

INSERT INTO t_forecast_type( forecast_type_id
                           , forecast_type_nm )
VALUES ( 2
       , 'ZAP' )
/

INSERT INTO t_forecast_type( forecast_type_id
                           , forecast_type_nm )
VALUES ( 3
       , 'MGMT_CHARGE' )
/

--End Script
spool off
