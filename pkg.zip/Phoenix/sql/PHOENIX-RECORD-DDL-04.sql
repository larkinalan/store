-- PHOENIX-RECORD-DDL-04.SQL
-- Run as: FM(UAT)DBA
-- Desc: Add t_scd_asset_port_treasury table
-- Author: y491
-- Date: 21/01/2016
--
--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

SPOOL PHOENIX-RECORD-DDL-04.OUT;
--Begin Script

ALTER TABLE fmuatdba.t_scd_asset_port_treasury
   DROP PRIMARY KEY CASCADE;

DROP TABLE fmuatdba.t_scd_asset_port_treasury CASCADE CONSTRAINTS;

CREATE TABLE fmuatdba.t_scd_asset_port_treasury( scd_asset_portfolio	VARCHAR2( 50 )
												, currency_id			VARCHAR2 (3)	NOT NULL
                                                , app_alm_no			VARCHAR2( 22 )	NOT NULL
                                                , mc_alm_no				VARCHAR2( 22 )	NOT NULL
												)
TABLESPACE fmsmalldat
PCTUSED 0
PCTFREE 10
INITRANS 1
MAXTRANS 255
STORAGE( INITIAL 80 K
         NEXT 80 K
         MINEXTENTS 1
         MAXEXTENTS UNLIMITED
         PCTINCREASE 0
         BUFFER_POOL DEFAULT )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX fmuatdba.scd_asst_port_trs_pk
   ON fmuatdba.t_scd_asset_port_treasury( scd_asset_portfolio, currency_id)
   LOGGING
   TABLESPACE fmsmalldat
   PCTFREE 10
   INITRANS 2
   MAXTRANS 255
   STORAGE( INITIAL 80 K
            NEXT 80 K
            MINEXTENTS 1
            MAXEXTENTS UNLIMITED
            PCTINCREASE 0
            BUFFER_POOL DEFAULT )
   NOPARALLEL;


ALTER TABLE fmuatdba.t_scd_asset_port_treasury ADD (
  CONSTRAINT scd_asst_port_trs_pk
  PRIMARY KEY
  (scd_asset_portfolio, currency_id)
  USING INDEX fmuatdba.scd_asst_port_trs_pk);
  

CREATE INDEX fmuatdba.scd_asst_port_trs_fk_i ON fmuatdba.t_scd_asset_port_treasury
(currency_id)
LOGGING
TABLESPACE FMSMALLNDX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          32K
            NEXT             32K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


DROP SYNONYM fmuatdba.scd_asset_port_treasury;

CREATE OR REPLACE SYNONYM fmuatdba.scd_asset_port_treasury FOR fmuatdba.t_scd_asset_port_treasury;

DROP SYNONYM fmuatldr.scd_asset_port_treasury;

CREATE OR REPLACE SYNONYM fmuatldr.scd_asset_port_treasury FOR fmuatdba.t_scd_asset_port_treasury;

DROP SYNONYM readonly.scd_asset_port_treasury;

CREATE OR REPLACE SYNONYM readonly.scd_asset_port_treasury FOR fmuatdba.t_scd_asset_port_treasury;


ALTER TABLE t_scd_asset_port_treasury ADD CONSTRAINT
 scd_asst_port_trs_fk FOREIGN KEY 
  (currency_id) REFERENCES t_currency
  (currency_id)
  ENABLE VALIDATE;


GRANT SELECT ON fmuatdba.t_scd_asset_port_treasury TO batchplsql;

GRANT SELECT ON fmuatdba.t_scd_asset_port_treasury TO enduser;

GRANT SELECT ON fmuatdba.t_scd_asset_port_treasury TO fmuatldr WITH GRANT OPTION;
GRANT DELETE
    , INSERT
    , UPDATE
   ON fmuatdba.t_scd_asset_port_treasury
   TO fmuatldr;

GRANT DELETE
    , INSERT
    , SELECT
    , UPDATE
   ON fmuatdba.t_scd_asset_port_treasury
   TO ormtools;
/

--End Script
SPOOL OFF