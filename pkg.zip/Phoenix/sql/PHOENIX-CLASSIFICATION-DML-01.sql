-- PHOENIX-CLASSIFICATION-DML-01.sql
-- Runas: FM(UAT)DBA
-- Desc: New classification to allow routing of funds during phasing of FMA
-- Author: y246

--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

spool PHOENIX-CLASSIFICATION-DML-01.OUT
--Begin Script

INSERT INTO classification cn( cn.classification_id
                             , cn.classification_nm
                             , cn.classification_desc
                             , cn.owner_id
                             , cn.creation_ts )
   SELECT classification_seq.NEXTVAL
        , 'Phoenix Client Funds'
        , 'Funds that are grouped together for routing purposes to Phoenix'
        , 'GUIT'
        , SYSDATE
     FROM DUAL;

INSERT INTO category ct( ct.category_id
                       , ct.category_nm
                       , ct.classification_id
                       , ct.category_desc
                       , ct.creation_ts )
   SELECT category_seq.NEXTVAL
        , 'Phoenix Funds Not Allowed'
        , classification_seq.CURRVAL
        , 'Client Funds that are not allowed to be routed to Phoenix'
        , SYSDATE
     FROM DUAL;

INSERT INTO classification_category cc( cc.classification_id
                                      , cc.category_id )
   SELECT classification_seq.CURRVAL
        , category_seq.CURRVAL
     FROM DUAL;

INSERT INTO category ct( ct.category_id
                       , ct.category_nm
                       , ct.classification_id
                       , ct.category_desc
                       , ct.creation_ts )
   SELECT category_seq.NEXTVAL
        , 'Phoenix Funds Allowed'
        , classification_seq.CURRVAL
        , 'Client Funds that are allowed to be routed to Phoenix'
        , SYSDATE
     FROM DUAL;

INSERT INTO classification_category cc( cc.classification_id
                                      , cc.category_id )
   SELECT classification_seq.CURRVAL
        , category_seq.CURRVAL
     FROM DUAL;
     
INSERT INTO class_category_identifier ccc( ccc.classification_id
                                         , ccc.category_id
                                         , ccc.identifier_id
                                         , ccc.identifier_type_id )
   SELECT classification_seq.CURRVAL
        , category_seq.CURRVAL
        , x.ilim_id
        , 1
     FROM asset_id_xref x
    WHERE x.ext_id_type_id = 12
      AND x.external_id IN ('BPL'
                          , 'GPS'
                          , 'MEM'
                          , 'MEF'
                          , 'GRL'
                          , 'DYP'
                          , 'MCF'
                          , 'CPS'
                          , 'DPS'
                          , 'CPL'
                          , 'MEU'
                          , 'BPS');

--End Script
spool off
