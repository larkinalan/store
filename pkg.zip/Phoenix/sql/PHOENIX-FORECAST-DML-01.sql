--PHOENIX-FORECAST-DML-01.sql
-- Runas: FM(UAT)DBA
-- Desc: Create Forecast Status entries 
-- Author: y246

--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

spool PHOENIX-FORECAST-DML-01.OUT
--Begin Script

INSERT INTO forecast_status( forecast_status_id
                           , forecast_status_nm )
VALUES ( 0
       , 'UNKNOWN' );

INSERT INTO forecast_status( forecast_status_id
                           , forecast_status_nm )
VALUES ( 1
       , 'NEW' );

INSERT INTO forecast_status( forecast_status_id
                           , forecast_status_nm )
VALUES ( 2
       , 'PENDING' );

INSERT INTO forecast_status( forecast_status_id
                           , forecast_status_nm )
VALUES ( 3
       , 'PROCESSING' );

INSERT INTO forecast_status( forecast_status_id
                           , forecast_status_nm )
VALUES ( 4
       , 'MODELLED' );

INSERT INTO forecast_status( forecast_status_id
                           , forecast_status_nm )
VALUES ( 5
       , 'AWAITING_RECORDED' );

INSERT INTO forecast_status( forecast_status_id
                           , forecast_status_nm )
VALUES ( 6
       , 'RECORDED' );

INSERT INTO forecast_status( forecast_status_id
                           , forecast_status_nm )
VALUES ( 7
       , 'FAILED' );
       
--End Script
spool off
