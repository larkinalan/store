-- PHOENIX-RECORD-DDL-01.SQL
-- Run as: FM(UAT)DBA
-- Desc: Add T_LOB_ID_CLIENT_LEVEL_CASH table
-- Author: y491
-- Date: 13/01/2016
--
--SET APPINFO ON
--WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
--EXEC SCRIPT_MGR.LOG;

SPOOL PHOENIX-RECORD-DDL-01.OUT;
--Begin Script

ALTER TABLE fmuatdba.t_lob_id_client_level_cash
   DROP PRIMARY KEY CASCADE;

DROP TABLE fmuatdba.t_lob_id_client_level_cash CASCADE CONSTRAINTS;

CREATE TABLE fmuatdba.t_lob_id_client_level_cash( scd_lob_id           VARCHAR2( 50 ) NOT NULL
                                                , portfolio_owner_id   VARCHAR2( 50 ) NOT NULL
                                                , app_alm_no           VARCHAR2( 22 )
                                                , mc_alm_no            VARCHAR2( 22 )
                                                , app_bank_account     VARCHAR2( 50 )
                                                , mc_bank_account      VARCHAR2( 50 ) )
TABLESPACE fmsmalldat
PCTUSED 0
PCTFREE 10
INITRANS 1
MAXTRANS 255
STORAGE( INITIAL 80 K
         NEXT 80 K
         MINEXTENTS 1
         MAXEXTENTS UNLIMITED
         PCTINCREASE 0
         BUFFER_POOL DEFAULT )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX fmuatdba.lob_cl_lvl_csh_pk
   ON fmuatdba.t_lob_id_client_level_cash( scd_lob_id )
   LOGGING
   TABLESPACE fmsmalldat
   PCTFREE 10
   INITRANS 2
   MAXTRANS 255
   STORAGE( INITIAL 80 K
            NEXT 80 K
            MINEXTENTS 1
            MAXEXTENTS UNLIMITED
            PCTINCREASE 0
            BUFFER_POOL DEFAULT )
   NOPARALLEL;


ALTER TABLE fmuatdba.t_lob_id_client_level_cash ADD (
  CONSTRAINT lob_cl_lvl_csh_pk
  PRIMARY KEY
  (scd_lob_id)
  USING INDEX fmuatdba.lob_cl_lvl_csh_pk);


DROP SYNONYM fmuatdba.lob_id_client_level_cash;

CREATE OR REPLACE SYNONYM fmuatdba.lob_id_client_level_cash FOR fmuatdba.t_lob_id_client_level_cash;

DROP SYNONYM fmuatldr.lob_id_client_level_cash;

CREATE OR REPLACE SYNONYM fmuatldr.lob_id_client_level_cash FOR fmuatdba.t_lob_id_client_level_cash;

DROP SYNONYM readonly.lob_id_client_level_cash;

CREATE OR REPLACE SYNONYM readonly.lob_id_client_level_cash FOR fmuatdba.t_lob_id_client_level_cash;


GRANT SELECT ON fmuatdba.t_lob_id_client_level_cash TO batchplsql;

GRANT SELECT ON fmuatdba.t_lob_id_client_level_cash TO enduser;

GRANT SELECT ON fmuatdba.t_lob_id_client_level_cash TO fmuatldr WITH GRANT OPTION;
GRANT DELETE
    , INSERT
    , UPDATE
   ON fmuatdba.t_lob_id_client_level_cash
   TO fmuatldr;

GRANT DELETE
    , INSERT
    , SELECT
    , UPDATE
   ON fmuatdba.t_lob_id_client_level_cash
   TO ormtools;
/

--End Script
SPOOL OFF